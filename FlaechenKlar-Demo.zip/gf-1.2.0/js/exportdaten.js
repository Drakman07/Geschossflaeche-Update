// js/exportdaten.js — Strukturiertes Export-Datenmodell (v1.2).
// Baut aus dem Projekt-State ein versioniertes, formatneutrales Objekt, das
// Format-Writer (CSV/JSON/RIWA) in eine Datei serialisieren. Nutzt die
// bestehende Sammel-Logik (GF.export.sammlerFlaechenJeGeschoss) wieder —
// KEINE eigene Mess-/Anrechnungslogik (Haftungsgrenze: messen, nicht rechnen).
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {any} */ (global.GF = global.GF || {});
  GF.exportdaten = GF.exportdaten || {};

  // Schema-Version des Modells. Feldnamen sind oeffentlicher Vertrag —
  // Umbenennen/Entfernen erfordert eine Erhoehung dieser Zahl.
  GF.exportdaten.SCHEMA_VERSION = 1;

  function r3(n) {
    if (typeof n !== 'number' || !isFinite(n)) return null;
    return Math.round(n * 1000) / 1000;
  }
  function r4(n) {
    if (typeof n !== 'number' || !isFinite(n)) return null;
    return Math.round(n * 10000) / 10000;
  }
  function s(v) { return (v == null) ? '' : String(v); }

  function findRegion(projekt, regionId) {
    var rs = (projekt && projekt.planRegionen) || [];
    for (var i = 0; i < rs.length; i++) if (rs[i].id === regionId) return rs[i];
    return null;
  }

  // ptProMeter der Region eines Polygons (oder null wenn unkalibriert).
  function ptProMeterFuer(projekt, polygon) {
    var r = findRegion(projekt, polygon && polygon.regionId);
    if (r && r.kalibrierung && typeof r.kalibrierung.ptProMeter === 'number'
        && isFinite(r.kalibrierung.ptProMeter) && r.kalibrierung.ptProMeter > 0) {
      return r.kalibrierung.ptProMeter;
    }
    return null;
  }

  // Kantenlaengen [m] aus den lokal normierten Gauss-Koordinaten (geschlossen).
  function kantenLaengen(koordinaten) {
    var out = [];
    var n = koordinaten.length;
    for (var i = 0; i < n; i++) {
      var a = koordinaten[i], b = koordinaten[(i + 1) % n];
      out.push(r3(Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2))));
    }
    return out;
  }

  function baueVg(g) {
    var v = g && g.vollgeschoss;
    if (!v || !v.durchgefuehrt || !v.ergebnis) return null;
    var e = v.ergebnis;
    return {
      durchgefuehrt: true,
      A_G_qm: r3(e.A_G),
      A_2_30_qm: r3(e.A_2_30),
      A_anrechenbar_qm: r3(e.A_anrechenbar),
      anteil_2_30: (typeof e.anteil_2_30 === 'number') ? r4(e.anteil_2_30) : null,
      ist_vollgeschoss: e.vollgeschoss === true,
      grenzhoehe_m: r3(e.grenzhoehe)
    };
  }

  function baueTeilflaechen(projekt, g, enthaltKanten) {
    var polys = ((projekt && projekt.polygone) || []).filter(function (p) {
      return p.geschossId === g.id;
    });
    return polys.map(function (p) {
      var ptProM = ptProMeterFuer(projekt, p);
      var t = {
        id: s(p.id),
        bezeichnung: s(p.bezeichnung),
        flaeche_angesetzt_qm: r3(p.flaecheAngesetztQM),
        flaeche_gemessen_qm: r3(typeof p.flaecheGemessenQM === 'number'
          ? p.flaecheGemessenQM : p.flaecheAngesetztQM),
        manuell_korrigiert: p.manuelleKorrektur === true,
        korrektur_kommentar: s(p.korrekturKommentar),
        herleitung: ptProM ? GF.export.baueHerleitungsText(p, ptProM) : ''
      };
      if (enthaltKanten && ptProM) {
        var gz = GF.export.baueGaussZeilen(p.punkte, ptProM);
        if (gz && gz.koordinaten) {
          t.koordinaten_m = gz.koordinaten.map(function (k) {
            return { x: r3(k.x), y: r3(k.y) };
          });
          t.kanten_m = kantenLaengen(gz.koordinaten);
        }
      }
      return t;
    });
  }

  /**
   * Baut das vollstaendige Export-Datenmodell.
   * @param {object} projekt        Projekt-State
   * @param {Array|null} pdfsInState GF.state.pdfs (fuer Quelle-PDF-Namen)
   * @param {object} [opt] { vgAnrechnung:'voll'|'anteilig', enthaltKanten:bool,
   *                         demoMode:bool, jetztIso:string (Test-Determinismus) }
   */
  GF.exportdaten.baue = function (projekt, pdfsInState, opt) {
    opt = opt || {};
    var meta = (projekt && projekt.metadata) || {};
    var modus = (opt.vgAnrechnung === 'anteilig') ? 'anteilig' : 'voll';

    // Gemeinsame Sammel-Naht: identische Anrechnungs-/Grenzhoehen-Logik wie PDF.
    var sammler = GF.export.sammlerFlaechenJeGeschoss(projekt, pdfsInState, { vgAnrechnung: modus });
    var zeilen = sammler.zeilen || [];

    // Geschosse exakt wie der Sammler sortieren -> Index-Zuordnung stabil.
    var geschosseSort = ((projekt && projekt.geschosse) || []).slice().sort(function (a, b) {
      return (a.reihenfolge || 0) - (b.reihenfolge || 0);
    });

    var gesamtPolygon = 0;
    var geschosse = geschosseSort.map(function (g, idx) {
      var z = zeilen[idx] || {};
      gesamtPolygon += (typeof z.polygonFlaeche === 'number') ? z.polygonFlaeche : 0;
      return {
        nr: (typeof z.nr === 'number') ? z.nr : (idx + 1),
        bezeichnung: s(z.bezeichnung || g.bezeichnung),
        quelle_pdf: s(z.quelle),
        polygon_flaeche_qm: r3(z.polygonFlaeche),
        anrechenbare_flaeche_qm: r3(z.flaeche),
        anrechnung: (z.anrechnung === 'anteilig') ? 'anteilig' : 'voll',
        grenzhoehe_m: r3(typeof z.grenzhoehe === 'number' ? z.grenzhoehe : 2.3),
        manuell_korrigiert: z.manuell === true,
        vg: baueVg(g),
        teilflaechen: baueTeilflaechen(projekt, g, opt.enthaltKanten === true)
      };
    });

    return {
      schema: { name: 'flaechenklar-export', version: GF.exportdaten.SCHEMA_VERSION },
      erzeugt: {
        am_iso: opt.jetztIso || new Date().toISOString(),
        tool: 'FlächenKlar',
        tool_version: GF.VERSION || '0.0.0',
        build_datum: GF.BUILD_DATUM || '',
        lizenz_modus: (opt.demoMode === true) ? 'demo' : 'voll',
        demo: opt.demoMode === true
      },
      projekt: {
        projekt_name: s(meta.projektName),
        aktenzeichen: s(meta.projektNummer),
        bauvorhaben: s(meta.bauvorhaben),
        kommune: s(meta.kommune),
        sachbearbeiter: s(meta.sachbearbeiter),
        revision: (typeof meta.revision === 'number') ? meta.revision : 1,
        erstellt_am_iso: s(meta.erstelltAm),
        geaendert_am_iso: s(meta.geandertAm),
        bauherr: {
          name: s(meta.bauherr),
          pk_nr: s(meta.bauherrPKNr),
          strasse: s(meta.bauherrAnschriftStrasse),
          plz: s(meta.bauherrAnschriftPLZ),
          ort: s(meta.bauherrAnschriftOrt)
        },
        bauort: {
          strasse: s(meta.bauortStrasse),
          plz: s(meta.bauortPLZ),
          ort: s(meta.bauortOrt),
          flurnummer: s(meta.flurnummer),
          gemarkung: s(meta.gemarkung)
        },
        vg_anrechnung_modus: modus,
        grenzhoehe_anrechnung_m: (typeof meta.grenzhoeheAnrechnung === 'number')
          ? meta.grenzhoeheAnrechnung : 2.3
      },
      geschosse: geschosse,
      summe: {
        gesamt_polygon_qm: r3(gesamtPolygon),
        gesamt_anrechenbar_qm: r3(sammler.gesamt)
      }
    };
  };

})(typeof window !== 'undefined' ? window : globalThis);
