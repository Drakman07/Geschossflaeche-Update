// js/pdf-vektor.js — Vektor-Eckpunkte aus einem PDF extrahieren (fuer Snap, v1.2).
// Liest die Pfad-Operatoren (page.getOperatorList) eines VEKTOR-PDFs aus und
// liefert die Eckpunkte (Endpunkte von Linien + Rechteck-Ecken) in Tool-pt
// (= getViewport({scale:1})-Koordinaten, identisch zu polygon.punkte).
//
// pdf.js 3.x kodiert ALLE Pfade als OPS.constructPath:
//   args[0] = Array von Sub-Op-IDs (OPS.moveTo/lineTo/curveTo/rectangle/closePath)
//   args[1] = flaches Koordinaten-Array, je Sub-Op in Reihenfolge konsumiert
// Die CTM (OPS.transform/save/restore) wird mitgefuehrt; Punkte werden damit in
// den Seiten-User-Space gebracht, dann via convertToViewportPoint in Tool-pt.
// Bezier-Kurven (v1.2): adaptiv in Stuetzpunkte zerlegt (De-Casteljau), damit der
// Magnet auf der Rundung faengt und das Polygon der Kurve folgen kann — kein ML,
// kein Konturerkennen, der Mensch setzt jeden Punkt selbst.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  // CTM-Komposition wie pdf.js Util.transform: result = m ∘ n (n zuerst).
  function matMul(m, n) {
    return [
      m[0] * n[0] + m[2] * n[1],
      m[1] * n[0] + m[3] * n[1],
      m[0] * n[2] + m[2] * n[3],
      m[1] * n[2] + m[3] * n[3],
      m[0] * n[4] + m[2] * n[5] + m[4],
      m[1] * n[4] + m[3] * n[5] + m[5]
    ];
  }
  function tx(ctm, x, y) {
    return { x: ctm[0] * x + ctm[2] * y + ctm[4], y: ctm[1] * x + ctm[3] * y + ctm[5] };
  }

  // Adaptives Bezier-Flatten (v1.2): zerlegt eine kubische Kurve in Stuetzpunkte.
  // Skala-invariante Flatness (Kontrollpunkt-Abstand relativ zur Sehne) + Tiefen-
  // limit gegen Endlos-Teilung (<= 256 Segmente/Kurve). Laeuft im User-Space.
  var KURVE_MAX_TIEFE = 8;
  var KURVE_FLATNESS_REL = 0.02;   // erlaubter Kontrollpunkt-Abstand = 2 % der Sehne

  // v1.2 Detailgrad-Filter: Pfade, deren Bounding-Box-Diagonale (Seiten-User-Space,
  // pt) unter dieser Schwelle liegt, werden komplett uebersprungen. Outline-Text
  // (Bemaßungszahlen/Beschriftung als Kurven), Schraffuren, Symbole, Moeblierung
  // sind glyph-/strichgross und produzieren sonst hunderttausende Mikro-Kanten, die
  // den Snap-Index aufblaehen und den Magnet auf Buchstaben statt Wandecken ziehen.
  // Echte Strukturkanten (Waende, Maßlinien) sind laenger und bleiben unberuehrt.
  var PFAD_MIN_DIAGONALE_PT = 5;

  // v1.2 Distanz-Dezimierung: entlang eines Pfads wird ein Stuetzpunkt nur dann als
  // Snap-Ecke uebernommen, wenn er >= dieser Distanz (Tool-pt, transformiert) vom
  // zuletzt genommenen entfernt liegt — Subpfad-Start/-Ende und harte Ecken (Rechteck,
  // closePath) bleiben immer. Glyph-Kurven und dichte Schraffur-Polylinien (zehntel-
  // pt-Schritte) fallen so von hunderttausenden Mikropunkten auf wenige zusammen,
  // ohne dass die fuer den Magnet relevante Ecke (>= Snap-Radius) verloren geht.
  var PUNKT_MIN_ABSTAND_PT = 1.5;
  function mitte(a, b) { return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; }
  function kurveFlach(p0, p1, p2, p3) {
    var dx = p3.x - p0.x, dy = p3.y - p0.y;
    var sehne = Math.sqrt(dx * dx + dy * dy);
    if (sehne < 1e-9) {
      var e1 = Math.sqrt((p1.x - p0.x) * (p1.x - p0.x) + (p1.y - p0.y) * (p1.y - p0.y));
      var e2 = Math.sqrt((p2.x - p0.x) * (p2.x - p0.x) + (p2.y - p0.y) * (p2.y - p0.y));
      return Math.max(e1, e2) < 1e-6;
    }
    var d1 = Math.abs((p1.x - p0.x) * dy - (p1.y - p0.y) * dx) / sehne;
    var d2 = Math.abs((p2.x - p0.x) * dy - (p2.y - p0.y) * dx) / sehne;
    return (d1 + d2) <= sehne * KURVE_FLATNESS_REL;
  }
  function kurveUnterteile(p0, p1, p2, p3, tiefe, out) {
    if (tiefe >= KURVE_MAX_TIEFE || kurveFlach(p0, p1, p2, p3)) { out.push(p3); return; }
    var p01 = mitte(p0, p1), p12 = mitte(p1, p2), p23 = mitte(p2, p3);
    var p012 = mitte(p01, p12), p123 = mitte(p12, p23), pm = mitte(p012, p123);
    kurveUnterteile(p0, p01, p012, pm, tiefe + 1, out);
    kurveUnterteile(pm, p123, p23, p3, tiefe + 1, out);
  }
  // Haengt Stuetzpunkte (Vertices) + aufeinanderfolgende Segmente an. p0 ist bereits
  // als Vertex gesetzt; ergaenzt werden die Innenpunkte und der Endpunkt p3.
  function flacheKurve(p0, p1, p2, p3, aufPunkt) {
    var out = [];
    kurveUnterteile(p0, p1, p2, p3, 0, out);
    for (var i = 0; i < out.length; i++) aufPunkt(out[i]);
  }

  // Misst die Bounding-Box eines Pfads im Seiten-User-Space (CTM angewandt) und
  // meldet `true`, wenn die Diagonale unter PFAD_MIN_DIAGONALE_PT liegt. Reiner
  // Vorab-Scan derselben Sub-Ops wie pfadVerarbeiten; Kurven-Kontrollpunkte gehen
  // konservativ in die Box ein (eher behalten als faelschlich verwerfen). Rechteck
  // ueber seine vier Ecken. Leerer Pfad -> false (nichts zu filtern).
  function pfadZuKlein(subOps, coords, OPS, ctm) {
    var ci = 0, hat = false;
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    function acc(x, y) {
      var p = tx(ctm, x, y);
      if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x;
      if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y;
      hat = true;
    }
    for (var k = 0; k < subOps.length; k++) {
      var op = subOps[k];
      if (op === OPS.moveTo || op === OPS.lineTo) {
        acc(coords[ci++], coords[ci++]);
      } else if (op === OPS.curveTo) {
        acc(coords[ci++], coords[ci++]); acc(coords[ci++], coords[ci++]); acc(coords[ci++], coords[ci++]);
      } else if (op === OPS.curveTo2 || op === OPS.curveTo3) {
        acc(coords[ci++], coords[ci++]); acc(coords[ci++], coords[ci++]);
      } else if (op === OPS.rectangle) {
        var rx = coords[ci++], ry = coords[ci++], rw = coords[ci++], rh = coords[ci++];
        acc(rx, ry); acc(rx + rw, ry + rh);
      }
      // closePath / unbekannte Sub-Ops: keine Koordinaten
    }
    if (!hat) return false;
    var dx = maxX - minX, dy = maxY - minY;
    return Math.sqrt(dx * dx + dy * dy) < PFAD_MIN_DIAGONALE_PT;
  }

  // Verarbeitet EIN constructPath-args-Tupel: haengt transformierte Eckpunkte an
  // `vertices` und Liniensegmente an `kanten` (beide in Seiten-User-Space).
  function pfadVerarbeiten(pathArgs, OPS, ctm, vertices, kanten) {
    var subOps = pathArgs && pathArgs[0];
    var coords = pathArgs && pathArgs[1];
    if (!subOps || !coords) return;

    // Detailgrad-Filter: Bbox des Pfads (im Seiten-User-Space, CTM angewandt)
    // messen; ist die Diagonale zu klein -> Glyphe/Symbol/Schraffur, ueberspringen.
    if (pfadZuKlein(subOps, coords, OPS, ctm)) return;

    var ci = 0;
    var cur = null;       // aktueller Punkt (User-Space, untransformiert) — Kurven-Mathe
    var start = null;     // Subpfad-Startpunkt (User-Space)
    var lastV = null;     // zuletzt EMITTIERTER Snap-Punkt (Tool-pt, transformiert) | null
    var pending = null;   // uebersprungener Kandidat (Tool-pt), evtl. Subpfad-Ende

    function abst(a, b) { var dx = a.x - b.x, dy = a.y - b.y; return Math.sqrt(dx * dx + dy * dy); }
    // Dezimierender Emitter (arbeitet in Tool-pt): nimmt einen Punkt nur, wenn er hart
    // ist (Ecke) oder weit genug vom letzten genommenen entfernt liegt; sonst merken.
    function nimm(p, hart) {
      var pt = tx(ctm, p.x, p.y);
      if (lastV === null) { vertices.push(pt); lastV = pt; pending = null; return; }
      if (hart || abst(pt, lastV) >= PUNKT_MIN_ABSTAND_PT) {
        vertices.push(pt); kanten.push({ a: lastV, b: pt }); lastV = pt; pending = null;
      } else {
        pending = pt;
      }
    }
    // Gemerkten Subpfad-Endpunkt doch noch setzen (Endpunkte nie verlieren).
    function spuele() {
      if (pending && lastV) { vertices.push(pending); kanten.push({ a: lastV, b: pending }); lastV = pending; }
      pending = null;
    }
    function aufKurvenpunkt(q) { nimm(q, false); }

    for (var k = 0; k < subOps.length; k++) {
      var op = subOps[k];
      if (op === OPS.moveTo) {
        spuele();                                   // vorigen Subpfad abschliessen
        cur = { x: coords[ci++], y: coords[ci++] };
        start = cur; lastV = null; nimm(cur, true); // Startpunkt setzen, keine Kante
      } else if (op === OPS.lineTo) {
        var p = { x: coords[ci++], y: coords[ci++] };
        nimm(p, false); cur = p;
      } else if (op === OPS.curveTo) {            // c: c1 c2 end (kubisch)
        var cc1 = { x: coords[ci++], y: coords[ci++] };
        var cc2 = { x: coords[ci++], y: coords[ci++] };
        var pe = { x: coords[ci++], y: coords[ci++] };
        if (cur) flacheKurve(cur, cc1, cc2, pe, aufKurvenpunkt);
        else nimm(pe, true);
        cur = pe;
      } else if (op === OPS.curveTo2) {           // v: 1. Kontrollpunkt = aktueller Punkt
        var vc2 = { x: coords[ci++], y: coords[ci++] };
        var ve  = { x: coords[ci++], y: coords[ci++] };
        if (cur) flacheKurve(cur, cur, vc2, ve, aufKurvenpunkt);
        else nimm(ve, true);
        cur = ve;
      } else if (op === OPS.curveTo3) {           // y: 2. Kontrollpunkt = Endpunkt
        var yc1 = { x: coords[ci++], y: coords[ci++] };
        var ye  = { x: coords[ci++], y: coords[ci++] };
        if (cur) flacheKurve(cur, yc1, ye, ye, aufKurvenpunkt);
        else nimm(ye, true);
        cur = ye;
      } else if (op === OPS.rectangle) {          // x, y, w, h — harte Ecken, ohne Dezimierung
        var rx = coords[ci++], ry = coords[ci++], rw = coords[ci++], rh = coords[ci++];
        var c1 = { x: rx, y: ry }, c2 = { x: rx + rw, y: ry };
        var c3 = { x: rx + rw, y: ry + rh }, c4 = { x: rx, y: ry + rh };
        spuele();
        var t1 = tx(ctm, c1.x, c1.y), t2 = tx(ctm, c2.x, c2.y),
            t3 = tx(ctm, c3.x, c3.y), t4 = tx(ctm, c4.x, c4.y);
        vertices.push(t1, t2, t3, t4);
        kanten.push({ a: t1, b: t2 }, { a: t2, b: t3 }, { a: t3, b: t4 }, { a: t4, b: t1 });
        cur = c1; start = c1; lastV = null; pending = null;   // geschlossene Form
      } else if (op === OPS.closePath) {
        spuele();
        if (lastV && start) kanten.push({ a: lastV, b: tx(ctm, start.x, start.y) });
        cur = start;
        lastV = start ? tx(ctm, start.x, start.y) : null; pending = null;
      }
      // unbekannte Sub-Ops: still ignorieren (defensiv gegen pdf.js-Drift)
    }
    spuele();   // letzten Subpfad-Endpunkt sichern
  }

  /**
   * Reine Zerlegung einer Operatorliste in Eckpunkte + Kanten (User-Space).
   * Ohne pdf.js testbar (OPS als schlichtes {moveTo,lineTo,...}-Objekt uebergeben).
   * @param {Array<number>} fnArray
   * @param {Array<any>} argsArray
   * @param {Record<string, number>} OPS
   * @returns {{vertices: Punkt[], kanten: {a:Punkt,b:Punkt}[]}}
   */
  GF.pdf._segmenteAusOpList = function (fnArray, argsArray, OPS) {
    var vertices = [];
    var kanten = [];
    var ctm = [1, 0, 0, 1, 0, 0];
    var stack = [];
    for (var i = 0; i < fnArray.length; i++) {
      var fn = fnArray[i];
      if (fn === OPS.save) {
        stack.push(ctm.slice());
      } else if (fn === OPS.restore) {
        if (stack.length) ctm = stack.pop();
      } else if (fn === OPS.transform) {
        var a = argsArray[i];
        if (a && a.length >= 6) ctm = matMul(ctm, [a[0], a[1], a[2], a[3], a[4], a[5]]);
      } else if (fn === OPS.constructPath) {
        pfadVerarbeiten(argsArray[i], OPS, ctm, vertices, kanten);
      }
    }
    return { vertices: vertices, kanten: kanten };
  };

  /**
   * Extrahiert Snap-Eckpunkte + Kanten einer Seite in Tool-pt-Koordinaten.
   * @param {any} pdfDoc
   * @param {number} seite (1-basiert)
   * @returns {Promise<{vertices: Punkt[], kanten: {a:Punkt,b:Punkt}[]}>}
   */
  GF.pdf.snapPunkte = function (pdfDoc, seite) {
    var pdfjs = global.pdfjsLib;
    if (!pdfDoc || !pdfjs || !pdfjs.OPS) return Promise.resolve({ vertices: [], kanten: [] });
    return pdfDoc.getPage(seite).then(function (page) {
      var vp = page.getViewport({ scale: 1 });
      return page.getOperatorList().then(function (ops) {
        var roh = GF.pdf._segmenteAusOpList(ops.fnArray, ops.argsArray, pdfjs.OPS);
        // User-Space -> Tool-pt (convertToViewportPoint erledigt y-Flip + Rotation)
        var seen = Object.create(null);
        var vertices = [];
        for (var i = 0; i < roh.vertices.length; i++) {
          var p = roh.vertices[i];
          var v = vp.convertToViewportPoint(p.x, p.y);
          var x = v[0], y = v[1];
          if (!isFinite(x) || !isFinite(y)) continue;
          var key = x.toFixed(2) + ',' + y.toFixed(2);   // koinzidente Ecken zusammenfassen
          if (seen[key]) continue;
          seen[key] = 1;
          vertices.push({ x: x, y: y });
        }
        var kanten = [];
        for (var j = 0; j < roh.kanten.length; j++) {
          var ka = vp.convertToViewportPoint(roh.kanten[j].a.x, roh.kanten[j].a.y);
          var kb = vp.convertToViewportPoint(roh.kanten[j].b.x, roh.kanten[j].b.y);
          kanten.push({ a: { x: ka[0], y: ka[1] }, b: { x: kb[0], y: kb[1] } });
        }
        return { vertices: vertices, kanten: kanten };
      });
    });
  };

})(typeof window !== 'undefined' ? window : globalThis);
