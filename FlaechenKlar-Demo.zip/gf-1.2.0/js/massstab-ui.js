// @ts-check
// js/massstab-ui.js — reine Text-Builder fuer die v1.2 Parallel-Arbeiten-Politur.
// DOM-frei + ohne Seiteneffekte, damit im Test-Runner (test.html, ohne app.js)
// pruefbar. app.js ruft diese Helfer fuer Vektor-Badge + Maßstab-Banner.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.massstabUi = GF.massstabUi || /** @type {GfMassstabUiModule} */ ({});

  /**
   * Text/Klasse/Titel fuer das Vektor-Badge oben rechts.
   * @param {number|null|undefined} anteil  Vektor-Flaechenanteil [0..1] | null = Analyse laeuft
   * @param {string|null} [status]  Phase-2b-Status: 'vorbereiten' | 'magnet-aus' | 'fertig'/null.
   *   Nur bei Vektor/gemischt (anteil >= 0,3) relevant — Scans haben keine Phase 2.
   * @returns {{text:string, klasse:string, title:string}}
   */
  GF.massstabUi.badgeText = function (anteil, status) {
    if (anteil === null || anteil === undefined) {
      return { text: 'Vektor wird geprüft …', klasse: 'badge', title: 'PDF wird analysiert …' };
    }
    var prozent = Math.round(anteil * 100);
    var stufeKlasse = anteil >= 0.7 ? 'vektor-hoch' : anteil >= 0.3 ? 'vektor-mittel' : 'vektor-niedrig';
    var title = anteil >= 0.7 ? 'Vektor-PDF — präzise vermessbar'
              : anteil >= 0.3 ? 'Gemischtes PDF — Vermessung möglich, Toleranz beachten'
              :                 'Raster-PDF — Vermessung pixelbasiert, ±1-2% Toleranz';
    var text = 'Vektor ' + prozent + '%';
    // Phase-2-Suffix nur bei Vektor/gemischt; bei Scan laeuft keine Phase 2.
    if (anteil >= 0.3) {
      if (status === 'vorbereiten') text += ' · wird vorbereitet …';
      else if (status === 'magnet-aus') text += ' · Magnet aus';
    }
    return { text: text, klasse: 'badge ' + stufeKlasse, title: title };
  };

  /**
   * Text fuer das nicht-blockierende Maßstab-Banner.
   * @param {{normMassstab?:string, ptProMeter:number, stufe:string}} vorschlag
   * @param {{bezeichnung?:string}} region
   * @returns {{text:string, unsicher:boolean}}
   */
  GF.massstabUi.bannerText = function (vorschlag, region) {
    var fmt = (GF.util && GF.util.formatZahlDE) ? GF.util.formatZahlDE : function (n) { return String(n); };
    var name = (region && region.bezeichnung) ? region.bezeichnung : '?';
    var norm = (vorschlag && vorschlag.normMassstab) || '1:?';
    var ppm = vorschlag ? vorschlag.ptProMeter : 0;
    var basis = 'Maßstab ' + norm + ' (' + fmt(ppm, 2) + ' pt/m) erkannt — für Region „' + name + '" übernehmen?';
    var unsicher = !!(vorschlag && vorschlag.stufe !== 'sicher');
    return { text: unsicher ? basis + ' (unsicher, bitte prüfen)' : basis, unsicher: unsicher };
  };

})(typeof window !== 'undefined' ? window : globalThis);
