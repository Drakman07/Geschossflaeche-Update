// @ts-check
// js/region.js — Plan-Regionen + Massstabskalibrierung.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.region = GF.region || /** @type {GfRegionModule} */ ({});

  // Norm-Massstaebe in pt/m (1 m bei Massstab 1:N entspricht 1000/N mm = 1000/N * 2.834645 pt)
  // pt/m = 72000 / (25.4 * N). v1.2: gaengige Zwischen-Maßstaebe (1:25/75/150/250)
  // ergaenzt, damit auch Detail-/Teilplaene Belege liefern. Bewusst keine
  // inflationaere Liste — sonst findet plausibilitaet() immer einen "naechsten"
  // Maßstab und die Falsch-Treffer-Quote steigt.
  GF.region.NORM_MASSSTAB = {
    '1:25':  113.386,
    '1:50':   56.692,
    '1:75':   37.795,
    '1:100':  28.346,
    '1:150':  18.898,
    '1:200':  14.173,
    '1:250':  11.339,
    '1:500':   5.669,
    '1:1000':  2.835
  };

  /**
   * @param {string} pdfId
   * @param {number} seite
   * @param {Ausschnitt} ausschnitt
   * @param {string} [bezeichnung]
   * @returns {Region}
   */
  GF.region.erzeuge = function (pdfId, seite, ausschnitt, bezeichnung) {
    return {
      id: GF.util.uuid(),
      pdfId: pdfId,
      seite: seite,
      bezeichnung: bezeichnung || '',
      geschossId: null,
      ausschnitt: ausschnitt,    // {x, y, breite, hoehe} in PDF-Koordinaten
      kalibrierung: null
    };
  };

  /**
   * ptProMeter aus zwei Punkten + Sollmass.
   * @param {Punkt} p1
   * @param {Punkt} p2
   * @param {number} sollMeter
   * @returns {number}
   */
  GF.region.berechneMassstab = function (p1, p2, sollMeter) {
    if (!isFinite(sollMeter) || sollMeter <= 0) throw new Error('Sollmass muss > 0 sein');
    var d = GF.util.abstand2D(p1, p2);
    if (d === 0) throw new Error('Punkte sind identisch (Distanz 0)');
    return d / sollMeter;
  };

  /**
   * ptProMeter aus direkt eingegebenem Massstab 1:N.
   * Gilt nur fuer masshaltige Vektor-PDFs: 1 m real = 1000/N mm auf
   * Papier, 1 mm = 72/25.4 pt (PDF-Punkt = 1/72 Zoll).
   * @param {number} n - Massstabszahl N aus "1:N", ganzzahlig >= 1
   * @returns {number}
   */
  GF.region.ptProMeterAusMassstab = function (n) {
    if (!isFinite(n) || n < 1) throw new Error('Massstab muss eine Zahl >= 1 sein');
    return 72000 / (25.4 * n);
  };

  /**
   * Prozentuale Abweichung vom naechsten Norm-Massstab.
   * @param {number} ptProMeter
   * @returns {RegionPlausibilitaet}
   */
  GF.region.plausibilitaet = function (ptProMeter) {
    var beste = null;
    var besteAbw = Infinity;
    var keys = Object.keys(GF.region.NORM_MASSSTAB);
    for (var i = 0; i < keys.length; i++) {
      var norm = GF.region.NORM_MASSSTAB[keys[i]];
      var abw = Math.abs(ptProMeter - norm) / norm * 100;
      if (abw < besteAbw) { besteAbw = abw; beste = keys[i]; }
    }
    /** @type {'plausibel' | 'hinweis' | 'warnung'} */
    var stufe;
    // v1.2: 'plausibel'-Tor von 0,5 % auf 1,0 % geweitet. CAD-Export-Rundung +
    // auf 2 Nachkommastellen gerundeter Maßtext sprengen 0,5 % (bei 1:100 = ±0,14
    // pt/m) zu leicht. Das harte massstabGate (>=5 Belege, Dominanz, Mess-Skala-
    // Veto) bleibt als Gegengewicht gegen Falsch-Treffer.
    if (besteAbw < 1.0)      stufe = 'plausibel';
    else if (besteAbw < 3.0) stufe = 'hinweis';
    else                     stufe = 'warnung';
    return { naechsterNormMassstab: beste, abweichungProzent: besteAbw, stufe: stufe };
  };

  /**
   * Effektive Maßstabszahl N aus pt/m (Umkehrung von ptProMeterAusMassstab).
   * @param {number} ptProMeter
   * @returns {number|null}
   */
  GF.region.massstabAusPtProMeter = function (ptProMeter) {
    if (!isFinite(ptProMeter) || ptProMeter <= 0) return null;
    return Math.round(72000 / (25.4 * ptProMeter));
  };

  // v1.2.5-Redesign: Hartes Gate fuer den Auto-Vorschlag. Nach Falsch-Positiven
  // in der Praxis gilt: Banner nur bei maximal strenger Beweislage, sonst ist
  // die Referenzmessung der Standardweg. Konstanten benannt + justierbar.
  GF.region.GATE = {
    MIN_BELEGE: 5,                    // unabhaengige Bemassungs-Belege fuer den Sieger
    MAX_NORM_ABWEICHUNG_PROZENT: 1.0, // Median muss praktisch exakt auf der Norm liegen
    DOMINANZ_FAKTOR: 3.0,             // Sieger-Gewicht >= 3x staerkster Konkurrent
    MESSSKALA_VETO_PROZENT: 3.0,      // norm-agnostische Mess-Skala darf nicht widersprechen
    MESSSKALA_PFLICHT: true           // fail-closed: ohne Mess-Skala-Cluster kein Banner
  };

  /**
   * Hartes Freigabe-Gate fuer den Maßstab-Vorschlag. Pure Funktion, DOM-frei.
   * Bekommt die Rohdaten des Detektors (GF.pdf.massstabBelege) plus die
   * norm-agnostische Mess-Skala (GF.pdf.gemesseneSkala) und entscheidet, ob die
   * Beweislage fuer ein Vorschlags-Banner reicht. Jede Ablehnung traegt einen
   * maschinenlesbaren grund (Tests/Diagnose). Der 1:168-Fehlalarm (als Meter
   * gelesene Winkel-Labels) scheitert hier am Mess-Skala-Veto.
   * @param {{ptProMeter:number,normMassstab?:string,anzahlBelege:number,gewicht?:number,gewichtZweiter?:number}|null|undefined} belege
   * @param {{ptProMeter:number,anzahlBelege:number}|null|undefined} gemessen
   * @returns {{bestanden:boolean,grund:string,vorschlag:({normMassstab:string,ptProMeter:number,anzahlBelege:number,abweichungProzent:number}|null)}}
   */
  GF.region.massstabGate = function (belege, gemessen) {
    var G = GF.region.GATE;
    /** @param {string} grund */
    function nein(grund) { return { bestanden: false, grund: grund, vorschlag: null }; }

    if (!belege || !(belege.ptProMeter > 0)) return nein('keine-belege');
    if ((belege.anzahlBelege || 0) < G.MIN_BELEGE) return nein('zu-wenig-belege');

    var pl = GF.region.plausibilitaet(belege.ptProMeter);
    if (!pl || !pl.naechsterNormMassstab
        || pl.abweichungProzent >= G.MAX_NORM_ABWEICHUNG_PROZENT) return nein('norm-abweichung');

    var gew = belege.gewicht || 0;
    var gew2 = belege.gewichtZweiter || 0;
    if (gew2 > 0 && gew < G.DOMINANZ_FAKTOR * gew2) return nein('kein-dominanter-sieger');

    if (!gemessen || !(gemessen.ptProMeter > 0)) {
      if (G.MESSSKALA_PFLICHT) return nein('keine-mess-skala');
    } else {
      var abwMess = Math.abs(gemessen.ptProMeter - belege.ptProMeter) / belege.ptProMeter * 100;
      if (abwMess > G.MESSSKALA_VETO_PROZENT) return nein('mess-skala-widerspruch');
    }

    return {
      bestanden: true,
      grund: 'ok',
      vorschlag: {
        normMassstab: belege.normMassstab || pl.naechsterNormMassstab,
        ptProMeter: belege.ptProMeter,
        anzahlBelege: belege.anzahlBelege,
        abweichungProzent: pl.abweichungProzent
      }
    };
  };

  // Schwelle, ab der eine Referenzmessung als Widerspruch zur (gate-bestaetigten)
  // Planbemaßung gilt (Prozent). 3 % Skala = ~6 % Flaeche.
  GF.region.SCHWELLE_MESSUNG_WIDERSPRUCH_PROZENT = 3.0;

  /**
   * v1.2.5-Redesign: Gleicht eine Referenzmessung gegen die Planbemaßung ab —
   * aber NUR, wenn dieselbe harte Beweislage besteht wie fuers Banner
   * (massstabGate). Faellt das Gate durch (Scan, duenne/verrauschte Belege,
   * Fit-to-Page), urteilt die Funktion 'unbekannt' und die Messung bleibt
   * unangefochten — die Messung gewinnt IMMER, das Ergebnis steuert nur den
   * gelben "zweites Maß empfohlen"-Hinweis.
   * @param {number} ptProMeterMessung
   * @param {{ptProMeter:number,normMassstab?:string,anzahlBelege:number,gewicht?:number,gewichtZweiter?:number}|null|undefined} belege
   * @param {{ptProMeter:number,anzahlBelege:number}|null|undefined} gemessen
   * @returns {{status:('ok'|'widerspruch'|'unbekannt'),abweichungProzent:number,referenzPtProMeter:(number|null)}}
   */
  GF.region.messungAbgleich = function (ptProMeterMessung, belege, gemessen) {
    if (!isFinite(ptProMeterMessung) || ptProMeterMessung <= 0) {
      return { status: 'unbekannt', abweichungProzent: 0, referenzPtProMeter: null };
    }
    var gate = GF.region.massstabGate(belege, gemessen);
    if (!gate.bestanden || !gate.vorschlag) {
      return { status: 'unbekannt', abweichungProzent: 0, referenzPtProMeter: null };
    }
    var ref = gate.vorschlag.ptProMeter;
    var abw = Math.abs(ptProMeterMessung - ref) / ref * 100;
    return {
      status: abw > GF.region.SCHWELLE_MESSUNG_WIDERSPRUCH_PROZENT ? 'widerspruch' : 'ok',
      abweichungProzent: abw,
      referenzPtProMeter: ref
    };
  };

})(typeof window !== 'undefined' ? window : globalThis);
