// @ts-check
// js/tests.js — Test-Runner ohne externe Library.

/** @param {GfGlobalLike & {GF_test_assertions?: any}} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern + tests-Modul ist offen typisiert
  var GF = /** @type {GF & {tests: any}} */ (global.GF = global.GF || {});
  GF.tests = GF.tests || /** @type {any} */ ({});

  var TOL = 1e-9;

  function nahe(ist, soll, tol) {
    return Math.abs(ist - soll) <= (tol === undefined ? TOL : tol);
  }

  function fmt(n) {
    return (typeof n === 'number') ? n.toFixed(4) : String(n);
  }

  // ---- util-Tests ----

  function utilTests() {
    var r = [];

    // parseZahlDE
    r.push({ name: 'parseZahlDE("1,23") = 1.23',
             ok: nahe(GF.util.parseZahlDE('1,23'), 1.23, 1e-9),
             detail: 'ist=' + GF.util.parseZahlDE('1,23') });
    r.push({ name: 'parseZahlDE("8.92") = 8.92',
             ok: nahe(GF.util.parseZahlDE('8.92'), 8.92, 1e-9),
             detail: 'ist=' + GF.util.parseZahlDE('8.92') });
    r.push({ name: 'parseZahlDE("") = NaN',
             ok: isNaN(GF.util.parseZahlDE('')),
             detail: '' });
    r.push({ name: 'parseZahlDE("1.234,56") = 1234.56 (Tausender + Komma)',
             ok: nahe(GF.util.parseZahlDE('1.234,56'), 1234.56, 1e-9),
             detail: 'ist=' + GF.util.parseZahlDE('1.234,56') });

    // formatZahlDE
    r.push({ name: 'formatZahlDE(105.05, 2) = "105,05"',
             ok: GF.util.formatZahlDE(105.05, 2) === '105,05',
             detail: 'ist=' + GF.util.formatZahlDE(105.05, 2) });

    // Neue Tests: Default-Stellen und deterministische 5-auf-Rundung
    r.push({ name: 'formatZahlDE(1.234) ohne stellen-Param = "1,23" (Default 2)',
             ok: GF.util.formatZahlDE(1.234) === '1,23',
             detail: 'ist=' + GF.util.formatZahlDE(1.234) });
    r.push({ name: 'formatZahlDE(1.235, 2) = "1,24" (deterministische 5-auf-Rundung)',
             ok: GF.util.formatZahlDE(1.235, 2) === '1,24',
             detail: 'ist=' + GF.util.formatZahlDE(1.235, 2) });
    r.push({ name: 'formatZahlDE(1.234, 3) = "1,234" (Edit-Vorbelegung mit 3 Stellen)',
             ok: GF.util.formatZahlDE(1.234, 3) === '1,234',
             detail: 'ist=' + GF.util.formatZahlDE(1.234, 3) });
    // Regression-Check fuer 105.05 ist schon in dem bestehenden Test in Zeile 42-44 abgedeckt.

    // abstand2D
    r.push({ name: 'abstand2D((0,0),(3,4)) = 5',
             ok: nahe(GF.util.abstand2D({x:0,y:0},{x:3,y:4}), 5),
             detail: '' });

    // segmenteSchneidenSich
    r.push({ name: 'kreuzende Strecken erkannt',
             ok: GF.util.segmenteSchneidenSich({x:0,y:0},{x:10,y:10},{x:0,y:10},{x:10,y:0}),
             detail: '' });
    r.push({ name: 'parallele Strecken kein Schnitt',
             ok: !GF.util.segmenteSchneidenSich({x:0,y:0},{x:10,y:0},{x:0,y:5},{x:10,y:5}),
             detail: '' });

    return r;
  }

  // ---- polygon-Tests ----

  function polygonTests() {
    var r = [];

    // Rechteck 10x10 m bei 1:100 (28.346 pt/m)
    var p100 = 28.346;
    var rect10 = [
      { x: 0,         y: 0         },
      { x: 10 * p100, y: 0         },
      { x: 10 * p100, y: 10 * p100 },
      { x: 0,         y: 10 * p100 }
    ];
    var f = GF.polygon.berechneFlaeche(rect10, p100);
    r.push({ name: 'Rechteck 10x10 m -> 100 m^2',
             ok: nahe(f, 100, 1e-6),
             detail: 'ist=' + fmt(f) });

    // Dreieck Basis 10, Hoehe 10
    var tri = [
      { x: 0,         y: 0 },
      { x: 10 * p100, y: 0 },
      { x: 0,         y: 10 * p100 }
    ];
    var fT = GF.polygon.berechneFlaeche(tri, p100);
    r.push({ name: 'Dreieck (10,10) -> 50 m^2',
             ok: nahe(fT, 50, 1e-6),
             detail: 'ist=' + fmt(fT) });

    // Polygon mit < 3 Punkten -> Fehler
    var fehler = false;
    try { GF.polygon.berechneFlaeche([{x:0,y:0},{x:1,y:1}], p100); }
    catch (e) { fehler = true; }
    r.push({ name: 'Polygon mit 2 Punkten -> Fehler',
             ok: fehler, detail: '' });

    // Selbstueberschneidung erkannt
    var bowtie = [
      { x: 0, y: 0 },
      { x: 10, y: 10 },
      { x: 10, y: 0 },
      { x: 0, y: 10 }
    ];
    r.push({ name: 'Bowtie (selbstueberschneidend) erkannt',
             ok: GF.polygon.hatSelbstueberschneidung(bowtie),
             detail: '' });

    // Rechteck ist nicht selbstueberschneidend
    r.push({ name: 'Rechteck nicht selbstueberschneidend',
             ok: !GF.polygon.hatSelbstueberschneidung(rect10),
             detail: '' });

    // editKante: 10m-Kante auf 8m -> p2 wandert
    var poly = /** @type {Polygon} */ (/** @type {any} */ ({ punkte: [
      { x: 0,         y: 0 },
      { x: 10 * p100, y: 0 },
      { x: 10 * p100, y: 5 * p100 },
      { x: 0,         y: 5 * p100 }
    ]}));
    GF.polygon.editKante(poly, 0, 8, p100);   // Kante 0->1 auf 8m
    var k0Len = GF.util.abstand2D(poly.punkte[0], poly.punkte[1]) / p100;
    r.push({ name: 'editKante: 10m -> 8m',
             ok: nahe(k0Len, 8, 1e-6),
             detail: 'ist=' + fmt(k0Len) });
    // p1 und p2 unveraendert? p1 ist Index 0 (Start der Kante), p2 ist Index 1
    // Der Test fokussiert: NUR Index 1 hat sich bewegt, alle anderen fix.
    r.push({ name: 'editKante: Index 0 unveraendert',
             ok: poly.punkte[0].x === 0 && poly.punkte[0].y === 0,
             detail: '' });
    r.push({ name: 'editKante: Index 2 unveraendert',
             ok: poly.punkte[2].x === 10 * p100 && poly.punkte[2].y === 5 * p100,
             detail: '' });

    return r;
  }

  // ---- rechteck-Tests ----

  function rechteckTests() {
    var r = [];
    var p100 = 28.346;

    var ecken = GF.rechteck.ausEcken({ x: 0, y: 0 },
                                     { x: 10 * p100, y: 5 * p100 });
    r.push({ name: 'rechteck: 2 Ecken -> 4 Punkte',
             ok: Array.isArray(ecken) && ecken.length === 4,
             detail: 'n=' + (ecken && ecken.length) });

    var f = GF.polygon.berechneFlaeche(ecken, p100);
    r.push({ name: 'rechteck: 10x5 m -> 50 m^2',
             ok: nahe(f, 50, 1e-6), detail: 'ist=' + fmt(f) });

    r.push({ name: 'rechteck: nicht selbstueberschneidend',
             ok: !GF.polygon.hatSelbstueberschneidung(ecken), detail: '' });

    // Ecken normalisiert unabhaengig von Klick-Reihenfolge (Gegenecke zuerst)
    var ecken2 = GF.rechteck.ausEcken({ x: 10 * p100, y: 5 * p100 },
                                      { x: 0, y: 0 });
    r.push({ name: 'rechteck: Reihenfolge egal -> gleiche Flaeche',
             ok: nahe(GF.polygon.berechneFlaeche(ecken2, p100), 50, 1e-6),
             detail: '' });

    return r;
  }

  // ---- region-Tests ----

  function regionTests() {
    var r = [];

    // Massstab aus zwei Punkten: 334.7 pt fuer 11.79 m
    var m = GF.region.berechneMassstab({x:0,y:0}, {x:334.7,y:0}, 11.79);
    r.push({ name: 'Massstab 334.7pt / 11.79m ~ 28.39 pt/m',
             ok: nahe(m, 334.7 / 11.79, 1e-6),
             detail: 'ist=' + fmt(m) });

    // Plausibilitaet bei Norm-1:100 -> plausibel
    var pl = GF.region.plausibilitaet(28.346);
    r.push({ name: 'Plausibilitaet bei 1:100-Norm -> plausibel',
             ok: pl.stufe === 'plausibel' && pl.naechsterNormMassstab === '1:100',
             detail: 'abw=' + fmt(pl.abweichungProzent) + '% stufe=' + pl.stufe });

    // v1.2: 'plausibel'-Tor von 0,5 % auf 1,0 % geweitet. +1,5 % bleibt klar 'hinweis'.
    var pl2 = GF.region.plausibilitaet(28.346 * 1.015);
    r.push({ name: 'Plausibilitaet bei +1,5% -> hinweis',
             ok: pl2.stufe === 'hinweis',
             detail: 'abw=' + fmt(pl2.abweichungProzent) + '% stufe=' + pl2.stufe });
    // +0,8 % faellt jetzt unter 'plausibel' (frueher 'hinweis' am 0,5-%-Tor).
    var pl08 = GF.region.plausibilitaet(28.346 * 1.008);
    r.push({ name: 'Plausibilitaet bei +0,8% -> plausibel (v1.2 geweitet)',
             ok: pl08.stufe === 'plausibel',
             detail: 'abw=' + fmt(pl08.abweichungProzent) + '% stufe=' + pl08.stufe });

    // Sollmass 0 -> Fehler
    var fehler = false;
    try { GF.region.berechneMassstab({x:0,y:0}, {x:100,y:0}, 0); }
    catch (e) { fehler = true; }
    r.push({ name: 'Sollmass 0 -> Fehler', ok: fehler, detail: '' });

    // Direkteingabe: ptProMeterAusMassstab trifft alle Norm-Werte
    var normKeys = Object.keys(GF.region.NORM_MASSSTAB);
    for (var ni = 0; ni < normKeys.length; ni++) {
      var n = parseInt(normKeys[ni].split(':')[1], 10);
      var soll = GF.region.NORM_MASSSTAB[normKeys[ni]];
      var ist = GF.region.ptProMeterAusMassstab(n);
      r.push({ name: 'ptProMeterAusMassstab(' + n + ') ~ ' + soll + ' pt/m',
               ok: nahe(ist, soll, 0.001),
               detail: 'ist=' + fmt(ist) });
    }

    // Direkteingabe 1:100 ist exakt plausibel
    var plDirekt = GF.region.plausibilitaet(GF.region.ptProMeterAusMassstab(100));
    r.push({ name: 'Direkteingabe 1:100 -> plausibel',
             ok: plDirekt.stufe === 'plausibel' && plDirekt.naechsterNormMassstab === '1:100',
             detail: 'abw=' + fmt(plDirekt.abweichungProzent) + '%' });

    // Direkteingabe: krummer Massstab 1:75
    var p75 = GF.region.ptProMeterAusMassstab(75);
    r.push({ name: 'ptProMeterAusMassstab(75) ~ 37.795 pt/m',
             ok: nahe(p75, 72000 / (25.4 * 75), 1e-9),
             detail: 'ist=' + fmt(p75) });

    // Direkteingabe: ungueltige N -> Fehler
    var ungueltige = [0, -100, NaN, Infinity];
    for (var ui = 0; ui < ungueltige.length; ui++) {
      var f2 = false;
      try { GF.region.ptProMeterAusMassstab(ungueltige[ui]); }
      catch (e2) { f2 = true; }
      r.push({ name: 'ptProMeterAusMassstab(' + ungueltige[ui] + ') -> Fehler',
               ok: f2, detail: '' });
    }

    return r;
  }

  // ---- projekt-Schema-Tests ----

  function schemaTests() {
    var r = [];

    var p = GF.projekt.neu({ projektName: 'Test', sachbearbeiter: 'Tester' });
    r.push({ name: 'projekt.neu hat schemaVersion=2',
             ok: p.schemaVersion === 2, detail: 'ist=' + p.schemaVersion });
    r.push({ name: 'projekt.neu validiert ohne Fehler',
             ok: GF.projekt.validiere(p) === true, detail: '' });

    // Schema v1 (alte Files) laden ohne Fehler
    var pV1 = JSON.parse(JSON.stringify(p));
    pV1.schemaVersion = 1;
    var v1Ok = false;
    try { v1Ok = (GF.projekt.validiere(pV1) === true); } catch (e) { v1Ok = false; }
    r.push({ name: 'Schema v1 (alte .zip) wird klaglos validiert',
             ok: v1Ok, detail: '' });

    // VG-Block: gueltig
    var pVg = JSON.parse(JSON.stringify(p));
    pVg.geschosse.push({ id: 'g-dg', bezeichnung: 'DG', reihenfolge: 1,
      vollgeschoss: {
        durchgefuehrt: true,
        berechnetAm: '2026-05-12T10:00:00+02:00',
        berechnetVon: 'Tester',
        eingaben: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                     gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
        ergebnis: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120, A_2_30: 88.80,
                     zweidrittel_flaeche: 80, anteil_2_30: 0.74, vollgeschoss: true,
                     differenz: 8.80, warnungen: [] },
        plausibilitaet: null,
        kommentar: ''
      }});
    var pVgOk = false;
    try { pVgOk = (GF.projekt.validiere(pVg) === true); } catch (e) { pVgOk = false; }
    r.push({ name: 'Schema v2 mit gueltigem vollgeschoss-Block validiert',
             ok: pVgOk, detail: '' });

    // Manipuliert: schemaVersion falsch
    var pBad = JSON.parse(JSON.stringify(p));
    pBad.schemaVersion = 999;
    var fehler = false;
    try { GF.projekt.validiere(pBad); } catch (e) { fehler = true; }
    r.push({ name: 'falsche schemaVersion -> Fehler',
             ok: fehler, detail: '' });

    // Polygon mit dangling regionId
    var pBad2 = JSON.parse(JSON.stringify(p));
    pBad2.polygone.push({
      id: 'x', geschossId: 'y', regionId: 'NICHT_EXISTENT',
      bezeichnung: '', punkte: [{x:0,y:0},{x:1,y:0},{x:0,y:1}]
    });
    var fehler2 = false;
    try { GF.projekt.validiere(pBad2); } catch (e) { fehler2 = true; }
    r.push({ name: 'dangling regionId -> Fehler',
             ok: fehler2, detail: '' });

    return r;
  }

  // ---- lizenz-Tests ----

  /**
   * Setzt window.GF_LIZENZ vor fn() und stellt es danach wieder her.
   * Pruefe-Tests sind safe: pruefeWhitelist() liest die ID synchron beim
   * Aufruf, danach laeuft alles in Promise-then-Closures mit dem schon
   * gefangenen Wert weiter — Wiederherstellung im finally ist deshalb OK.
   *
   * @param {{id: string} | undefined} val
   * @param {Function} fn
   * @returns {any}
   */
  function withGlobalLizenz(val, fn) {
    var prev = global.GF_LIZENZ;
    var hadKey = 'GF_LIZENZ' in /** @type {any} */ (global);
    if (val === undefined) {
      try { delete (/** @type {any} */ (global)).GF_LIZENZ; }
      catch (e) { global.GF_LIZENZ = /** @type {any} */ (undefined); }
    } else {
      global.GF_LIZENZ = val;
    }
    try { return fn(); }
    finally {
      if (hadKey) global.GF_LIZENZ = prev;
      else {
        try { delete (/** @type {any} */ (global)).GF_LIZENZ; }
        catch (e) { global.GF_LIZENZ = /** @type {any} */ (undefined); }
      }
    }
  }

  /**
   * Setzt localStorage['gf.lizenz.demo.start'] vor fn() und stellt es
   * danach wieder her.
   * @param {string | null} isoOrNull
   * @param {Function} fn
   * @returns {any}
   */
  function withDemoStart(isoOrNull, fn) {
    var KEY = 'gf.lizenz.demo.start';
    var prev = null;
    var hadKey = false;
    try {
      prev = localStorage.getItem(KEY);
      hadKey = (prev !== null);
      if (isoOrNull === null) localStorage.removeItem(KEY);
      else localStorage.setItem(KEY, isoOrNull);
    } catch (e) { /* privater Modus / Quota */ }
    try { return fn(); }
    finally {
      try {
        if (hadKey && prev !== null) localStorage.setItem(KEY, prev);
        else localStorage.removeItem(KEY);
      } catch (e) {}
    }
  }

  function diagnoseTests() {
    var r = [];

    /** @type {any} */
    var fakeProjekt = {
      schemaVersion: 2,
      appVersion: '0.1.0-dev',
      metadata: {
        projektName: 'Max Mustermann Anbau',
        bauherr: 'Max Mustermann',
        bauherrAnschriftStrasse: 'Hauptstr. 1',
        bauherrAnschriftPLZ: '92345',
        bauherrAnschriftOrt: 'Postbauer-Heng',
        bauherrPKNr: 'PK-12345',
        sachbearbeiter: 'Frau Schmidt',
        bauortStrasse: 'Nebenstr. 2',
        bauortPLZ: '92345',
        bauortOrt: 'Postbauer-Heng',
        flurnummer: '123/4',
        gemarkung: 'Postbauer-Heng',
        kommune: 'Markt Postbauer-Heng',
        projektNummer: '2026/16',
        bauvorhaben: 'Anbau',
        zusatzinfo: '',
        erstelltAm: '',
        geandertAm: '',
        revision: 1,
        vgAnrechnung: null
      },
      einstellungen: {},
      historie: [],
      pdfs: [
        { id: 'p1', dateiName: 'plan.pdf', anzahlSeiten: 3,
          binaer: new Uint8Array([1,2,3]), pdfDoc: { fake: true } }
      ],
      planRegionen: [{ id: 'r1' }],
      geschosse: [
        { id: 'g1', bezeichnung: 'EG', reihenfolge: 0, vollgeschoss: { ja: true } },
        { id: 'g2', bezeichnung: 'OG', reihenfolge: 1 }
      ],
      polygone: [
        { id: 'p1', regionId: 'r1', geschossId: 'g1', flaeche: 100.5, punkte: [] },
        { id: 'p2', regionId: 'r1', geschossId: 'g2', flaeche: 80.25, punkte: [] }
      ]
    };

    // Minimal: nur tool/version/browser, kein projekt
    var minimal = GF.diagnose.erstelle({ tiefe: 'minimal', projekt: fakeProjekt });
    r.push({ name: 'diagnose_minimal_enthaelt_tool_version',
             ok: minimal.tool === 'FlaechenKlar' && typeof minimal.version === 'string',
             detail: 'tool=' + minimal.tool + ' version=' + minimal.version });
    r.push({ name: 'diagnose_minimal_enthaelt_browser',
             ok: typeof minimal.browser === 'object' && minimal.browser !== null,
             detail: '' });
    r.push({ name: 'diagnose_minimal_KEIN_projekt',
             ok: minimal.projekt === undefined,
             detail: 'projekt=' + JSON.stringify(minimal.projekt) });

    // Standard: metadata redacted + stats, KEIN snapshot
    var standard = GF.diagnose.erstelle({ tiefe: 'standard', projekt: fakeProjekt });
    r.push({ name: 'diagnose_standard_enthaelt_stats',
             ok: standard.projekt && standard.projekt.stats &&
                 standard.projekt.stats.anzahlPolygone === 2 &&
                 standard.projekt.stats.anzahlGeschosse === 2 &&
                 standard.projekt.stats.anzahlMitVgBerechnung === 1,
             detail: JSON.stringify(standard.projekt && standard.projekt.stats) });
    r.push({ name: 'diagnose_standard_KEIN_snapshot',
             ok: standard.projekt && standard.projekt.snapshot === undefined,
             detail: 'snapshot=' + (standard.projekt && JSON.stringify(standard.projekt.snapshot)) });

    // Voll: snapshot vorhanden mit Polygonen, geschossen
    var voll = GF.diagnose.erstelle({ tiefe: 'voll', projekt: fakeProjekt });
    r.push({ name: 'diagnose_voll_enthaelt_snapshot',
             ok: voll.projekt && voll.projekt.snapshot &&
                 voll.projekt.snapshot.polygone.length === 2 &&
                 voll.projekt.snapshot.geschosse.length === 2,
             detail: '' });

    // Anonymisierung: PII redacted in voll
    var meta = voll.projekt.metadata;
    r.push({ name: 'diagnose_PII_bauherr_redacted',
             ok: meta.bauherr === '<redacted>',
             detail: 'ist=' + meta.bauherr });
    r.push({ name: 'diagnose_PII_sachbearbeiter_redacted',
             ok: meta.sachbearbeiter === '<redacted>',
             detail: 'ist=' + meta.sachbearbeiter });
    r.push({ name: 'diagnose_PII_adresse_redacted',
             ok: meta.bauherrAnschriftStrasse === '<redacted>' &&
                 meta.bauortStrasse === '<redacted>',
             detail: '' });
    r.push({ name: 'diagnose_NICHT_PII_kommune_bleibt',
             ok: meta.kommune === 'Markt Postbauer-Heng',
             detail: 'ist=' + meta.kommune });

    // Snapshot enthaelt KEINE PDF-Binaerdaten
    var pdfSnap = voll.projekt.snapshot.pdfs[0];
    r.push({ name: 'diagnose_snapshot_KEIN_pdf_binaer',
             ok: pdfSnap.binaer === undefined && pdfSnap.pdfDoc === undefined,
             detail: 'keys=' + Object.keys(pdfSnap).join(',') });

    // Leeres Projekt: minimal sollte trotzdem laufen
    var leer = GF.diagnose.erstelle({ tiefe: 'minimal', projekt: null });
    r.push({ name: 'diagnose_minimal_ohne_projekt_ok',
             ok: leer.tool === 'FlaechenKlar' && leer.projekt === undefined,
             detail: '' });

    return r;
  }

  function lizenzTests() {
    var r = [];
    // Bekannte SHA256-Vektoren (vorgeneriert via tools/build-allowlist.js):
    var HASH_DEMO_001 = '81b22855e3a3cf0aa984b3daa221025dc4664c03b728f3ea95b4049b4af5de2f';
    var DAY_MS = 24 * 60 * 60 * 1000;

    // ---- 4.1 holeID (3 Tests) ----

    withGlobalLizenz(undefined, function () {
      r.push({ name: 'lizenz_test_holeID_ohne_window_GF_LIZENZ',
               ok: GF.lizenz.holeID() === null,
               detail: 'ist=' + GF.lizenz.holeID() });
    });

    withGlobalLizenz({ id: 'GF-PH-2026-001' }, function () {
      r.push({ name: 'lizenz_test_holeID_korrektes_praefix',
               ok: GF.lizenz.holeID() === 'GF-PH-2026-001',
               detail: 'ist=' + GF.lizenz.holeID() });
    });

    withGlobalLizenz({ id: 'VG-PH-2026-001' }, function () {
      // console.warn unterdruecken (Tool warnt absichtlich bei falschem Praefix)
      var origWarn = console.warn;
      console.warn = function () {};
      try {
        r.push({ name: 'lizenz_test_holeID_falsches_praefix',
                 ok: GF.lizenz.holeID() === null,
                 detail: 'ist=' + GF.lizenz.holeID() });
      } finally {
        console.warn = origWarn;
      }
    });

    // ---- 4.4 Demo-Tage (4 Tests, sync) ----

    var jetzt = Date.now();
    withDemoStart(new Date(jetzt).toISOString(), function () {
      r.push({ name: 'lizenz_test_tageVerbleibend_frischer_start',
               ok: GF.lizenz.tageVerbleibend() === 14,
               detail: 'ist=' + GF.lizenz.tageVerbleibend() });
    });
    withDemoStart(new Date(jetzt - 5 * DAY_MS).toISOString(), function () {
      r.push({ name: 'lizenz_test_tageVerbleibend_nach_5_tagen',
               ok: GF.lizenz.tageVerbleibend() === 9,
               detail: 'ist=' + GF.lizenz.tageVerbleibend() });
    });
    withDemoStart(new Date(jetzt - 20 * DAY_MS).toISOString(), function () {
      r.push({ name: 'lizenz_test_tageVerbleibend_ueberschritten',
               ok: GF.lizenz.tageVerbleibend() === 0,
               detail: 'ist=' + GF.lizenz.tageVerbleibend() });
    });
    withDemoStart(new Date(jetzt - 15 * DAY_MS).toISOString(), function () {
      r.push({ name: 'lizenz_test_demoAbgelaufen_true',
               ok: GF.lizenz.demoAbgelaufen() === true,
               detail: 'ist=' + GF.lizenz.demoAbgelaufen() });
    });

    // ---- 4.2 sha256Hex (2 Tests, async) ----

    var pSha1 = GF.lizenz.sha256Hex('GF-PH-2026-001').then(function (hash) {
      r.push({ name: 'sha256("GF-PH-2026-001") liefert 64-Hex',
               ok: typeof hash === 'string' && /^[0-9a-f]{64}$/.test(hash),
               detail: hash.slice(0, 16) + '...' });
    });

    var pSha2 = GF.lizenz.sha256Hex('GF-DEMO-001').then(function (hash) {
      r.push({ name: 'lizenz_test_sha256Hex_known_vector',
               ok: hash === HASH_DEMO_001,
               detail: 'ist=' + (hash || '').slice(0, 24) + '...' });
    });

    // ---- 4.3 pruefeWhitelist (5 Tests, async) ----

    /**
     * Mock-Fetcher-Factory: liefert beim Aufruf das gewuenschte Resultat.
     * @param {any} resultOrError
     * @param {boolean} [rejects]
     * @returns {{fn: (url: string) => Promise<any>, calls: number}}
     */
    function mockFetcher(resultOrError, rejects) {
      var state = { fn: /** @type {(url: string) => Promise<any>} */ (function () { return Promise.resolve(); }), calls: 0 };
      state.fn = function () {
        state.calls += 1;
        if (rejects) return Promise.reject(resultOrError);
        return Promise.resolve(resultOrError);
      };
      return state;
    }

    var p1 = withGlobalLizenz(undefined, function () {
      var mock = mockFetcher({ hashes: [] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_demo_modus',
                 ok: res.ok === false && res.modus === 'demo' && mock.calls === 0,
                 detail: 'res=' + JSON.stringify(res) + ' calls=' + mock.calls });
      });
    });

    var p2 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: [HASH_DEMO_001] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_id_in_liste',
                 ok: res.ok === true && res.modus === 'voll',
                 detail: JSON.stringify(res) });
      });
    });

    var p3 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: [] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_id_nicht_in_liste',
                 ok: res.ok === false && res.modus === 'voll' && res.grund === 'unbekannt',
                 detail: JSON.stringify(res) });
      });
    });

    var p4 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher(new Error('mock net err'), true);
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_netzwerk_fehler',
                 ok: res.ok === false && res.grund === 'netzwerk',
                 detail: JSON.stringify(res) });
      });
    });

    var p5 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      // Antwort ohne 'hashes'-Feld → 'kaputt'
      var mock = mockFetcher({});
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_kaputt',
                 ok: res.ok === false && res.grund === 'kaputt',
                 detail: JSON.stringify(res) });
      });
    });

    // hashes-Array enthaelt nicht-Hex-Werte (number, null) → 'kaputt'.
    // Schuetzt vor stillen indexOf-Misses bei verfaelschten Listen.
    var p6 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: [HASH_DEMO_001, 12345, null] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_hashes_nicht_hex',
                 ok: res.ok === false && res.grund === 'kaputt',
                 detail: JSON.stringify(res) });
      });
    });

    // hashes-Array enthaelt zu kurzen Hex-String → 'kaputt'
    var p7 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: ['abc'] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_hash_zu_kurz',
                 ok: res.ok === false && res.grund === 'kaputt',
                 detail: JSON.stringify(res) });
      });
    });

    // ---- 4.5 updates.vergleiche (6 Tests, sync) ----
    // Lebt im Update-Subsystem aber hängt am Lizenz/Versions-Thema.

    if (GF.updates && typeof GF.updates.vergleiche === 'function') {
      var v = GF.updates.vergleiche;
      r.push({ name: 'vergleiche("1.0.0","1.0.0") = 0',
               ok: v('1.0.0', '1.0.0') === 0,
               detail: 'ist=' + v('1.0.0', '1.0.0') });
      r.push({ name: 'vergleiche("1.0.0","1.0.1") = -1',
               ok: v('1.0.0', '1.0.1') === -1,
               detail: 'ist=' + v('1.0.0', '1.0.1') });
      r.push({ name: 'vergleiche("2.0.0","1.99.99") = 1',
               ok: v('2.0.0', '1.99.99') === 1,
               detail: 'ist=' + v('2.0.0', '1.99.99') });
      // Pre-Release-Suffix wird ignoriert (semver-relaxed): "0.1.0-dev" == "0.1.0"
      r.push({ name: 'vergleiche("0.1.0-dev","0.1.0") = 0 (Suffix wird gestrippt)',
               ok: v('0.1.0-dev', '0.1.0') === 0,
               detail: 'ist=' + v('0.1.0-dev', '0.1.0') });
      r.push({ name: 'vergleiche("0.1.0-rc1","0.2.0") = -1 (Suffix wird gestrippt)',
               ok: v('0.1.0-rc1', '0.2.0') === -1,
               detail: 'ist=' + v('0.1.0-rc1', '0.2.0') });
      // Garbage-In → behandelt als 0.0.0, gleicher Garbage → 0
      r.push({ name: 'vergleiche("foo","bar") = 0 (beide → 0.0.0)',
               ok: v('foo', 'bar') === 0,
               detail: 'ist=' + v('foo', 'bar') });
    }

    return Promise.all([pSha1, pSha2, p1, p2, p3, p4, p5, p6, p7]).then(function () {
      return r;
    });
  }

  // ---- pdf-Tests (vektorAnteil-Heuristik + Viewport-Mathe) ----

  function pdfTests() {
    var r = [];

    // Fake OPS-Tabelle mit unverwechselbaren IDs (entspricht pdf.js-Verhalten)
    var OPS = {
      moveTo: 1, lineTo: 2, curveTo: 3, curveTo2: 4, curveTo3: 5,
      closePath: 6, rectangle: 7, fill: 8, stroke: 9, fillStroke: 10,
      eoFill: 11, eoFillStroke: 12, closeStroke: 13, closeFillStroke: 14,
      save: 50, restore: 51, transform: 52, constructPath: 53,
      paintImageXObject: 100, paintImageMaskXObject: 101,
      paintInlineImageXObject: 102, paintJpegXObject: 103,
      paintImageXObjectRepeat: 104, paintImageMaskXObjectRepeat: 105
    };

    // Reines Vektor-PDF
    var s1 = GF.pdf._zaehleOps([1, 2, 2, 2, 3, 6], OPS);
    r.push({ name: 'zaehleOps: 6 Vektor-Ops -> vektor=6, bild=0',
             ok: s1.vektor === 6 && s1.bild === 0,
             detail: JSON.stringify(s1) });

    // Reines Raster-PDF (1 Bild)
    var s2 = GF.pdf._zaehleOps([100], OPS);
    r.push({ name: 'zaehleOps: 1 Bild -> bild=1, vektor=0',
             ok: s2.vektor === 0 && s2.bild === 1,
             detail: '' });

    // Gemischt
    var s3 = GF.pdf._zaehleOps([1, 2, 100, 3, 102, 999 /* andere */], OPS);
    r.push({ name: 'zaehleOps: gemischt vektor=3, bild=2, andere=1',
             ok: s3.vektor === 3 && s3.bild === 2 && s3.andere === 1,
             detail: JSON.stringify(s3) });

    // ---- v1.2: berechneAnteil ist FLAECHENBASIERT (anteil = 1 - bildFlaeche) ----
    // Reiner Vektorplan (kein Raster) -> 1.0
    r.push({ name: 'berechneAnteil(bildFlaeche=0, vektor>0) = 1.0',
             ok: GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 100, bild: 0, bildFlaeche: 0 })) === 1.0,
             detail: '' });
    // Voll-Scan (Raster deckt ganzes Blatt) -> 0.0
    r.push({ name: 'berechneAnteil(bildFlaeche=1) = 0.0',
             ok: GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 0, bild: 1, bildFlaeche: 1 })) === 0.0,
             detail: '' });
    // Leere Seite (kein Vektor, kein Bild) -> 0
    r.push({ name: 'berechneAnteil(leer) = 0',
             ok: GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 0, bild: 0, bildFlaeche: 0 })) === 0,
             detail: '' });
    // Scan mit reichem Vektor-Overlay: Raster deckt 85 % -> 0.15 < 0.3 (Sperre greift trotz Overlay)
    var anteilScan = GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 150, bild: 1, bildFlaeche: 0.85 }));
    r.push({ name: 'berechneAnteil(bildFlaeche=0.85, viel Overlay) < 0.3',
             ok: anteilScan < 0.3,
             detail: 'anteil=' + fmt(anteilScan) });
    // Vektorplan mit kleinem eingebettetem Logo (5 %) -> 0.95, kein Fehlalarm
    var anteilLogo = GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 200, bild: 1, bildFlaeche: 0.05 }));
    r.push({ name: 'berechneAnteil(bildFlaeche=0.05) > 0.9 (kein Scan)',
             ok: anteilLogo > 0.9,
             detail: 'anteil=' + fmt(anteilLogo) });

    // ---- v1.2: _analysiere (flaechenbasiert, mit CTM-Verfolgung) ----
    var blatt = 1000 * 700;
    // Voll-Scan: 1 Bild ueber das ganze Blatt (transform [B,0,0,H,0,0]) -> bildFlaeche ~ 1
    var aScan = GF.pdf._analysiere(
      [OPS.save, OPS.transform, OPS.paintImageXObject, OPS.restore],
      [null, [1000, 0, 0, 700, 0, 0], ['img', 1000, 700], null], OPS, blatt);
    r.push({ name: '_analysiere: Voll-Scan -> bildFlaeche ~ 1, anteil < 0.3',
             ok: nahe(aScan.bildFlaeche, 1, 1e-6) && GF.pdf._berechneAnteil(aScan) < 0.3,
             detail: 'bildFlaeche=' + fmt(aScan.bildFlaeche) });
    // Reiner Vektorplan: constructPath/fill, kein Bild -> bildFlaeche 0, anteil 1
    var aVek = GF.pdf._analysiere(
      [OPS.constructPath, OPS.fill, OPS.constructPath, OPS.stroke],
      [[[OPS.moveTo], [0, 0]], null, [[OPS.moveTo], [1, 1]], null], OPS, blatt);
    r.push({ name: '_analysiere: Vektorplan -> bildFlaeche 0, anteil 1',
             ok: aVek.bildFlaeche === 0 && GF.pdf._berechneAnteil(aVek) === 1.0,
             detail: 'vektor=' + aVek.vektor + ' bildFlaeche=' + fmt(aVek.bildFlaeche) });
    // Kleines Logo: Bild 100x70 auf 1000x700-Blatt -> bildFlaeche ~ 0.01
    var aLogo = GF.pdf._analysiere(
      [OPS.constructPath, OPS.fill, OPS.save, OPS.transform, OPS.paintImageXObject, OPS.restore],
      [[[OPS.moveTo], [0, 0]], null, null, [100, 0, 0, 70, 0, 0], ['logo', 100, 70], null], OPS, blatt);
    r.push({ name: '_analysiere: kleines Logo -> bildFlaeche ~ 0.01, anteil > 0.9',
             ok: nahe(aLogo.bildFlaeche, 0.01, 1e-3) && GF.pdf._berechneAnteil(aLogo) > 0.9,
             detail: 'bildFlaeche=' + fmt(aLogo.bildFlaeche) });
    // CTM-Verschachtelung: restore verwirft die grosse Skalierung -> nur kleines Bild zaehlt
    var aCtm = GF.pdf._analysiere(
      [OPS.save, OPS.transform, OPS.restore, OPS.transform, OPS.paintImageXObject],
      [null, [1000, 0, 0, 700, 0, 0], null, [50, 0, 0, 50, 0, 0], ['img', 50, 50]], OPS, blatt);
    r.push({ name: '_analysiere: restore verwirft grosse CTM -> bildFlaecheAbs = 2500',
             ok: nahe(aCtm.bildFlaecheAbs, 2500, 1e-6),
             detail: 'bildFlaecheAbs=' + fmt(aCtm.bildFlaecheAbs) });

    // ---- Viewport-Mathe ----

    // zoomUmPunkt: Maus bei (100,100), Zoom 1->2, Pan(0,0)
    // mausPdf = 0 + 100/1 = 100, neuPan = 100 - 100/2 = 50
    var pan = GF.pdf.zoomUmPunkt(100, 100, 1, 2, { x: 0, y: 0 });
    r.push({ name: 'zoomUmPunkt: Maus (100,100), zoom 1->2 -> pan(50,50)',
             ok: nahe(pan.x, 50) && nahe(pan.y, 50),
             detail: 'pan=' + JSON.stringify(pan) });

    // Verifikation invariante Position: nach dem Zoom liegt PDF-Punkt (100,100) bei canvas (100,100)
    // canvasX = (pdfX - panX) * zoom = (100 - 50) * 2 = 100
    r.push({ name: 'Maus-Position invariant: PDF(100,100) bleibt bei canvas(100,100)',
             ok: nahe((100 - pan.x) * 2, 100) && nahe((100 - pan.y) * 2, 100),
             detail: '' });

    // fitViewport: cache 400x300, canvas 800x600 -> zoom < 2.0 (mit 5% Rand)
    var fakeCache  = /** @type {any} */ ({ breitePt: 400, hoehePt: 300 });
    var fakeCanvas = /** @type {any} */ ({ width: 800, height: 600 });
    var fit = GF.pdf.fitViewport(fakeCache, fakeCanvas);
    r.push({ name: 'fitViewport: zoom = min(2,2) * 0.95 = 1.9',
             ok: nahe(fit.zoom, 1.9, 1e-6),
             detail: 'zoom=' + fmt(fit.zoom) });

    // Seite ist zentriert: panX so, dass Mittelpunkt der Seite (200) bei canvas-Mitte (400) landet
    // canvasX(200) = (200 - panX) * zoom = 400 -> panX = 200 - 400/zoom = 200 - 210.5 = -10.5
    r.push({ name: 'fitViewport: Seitenmitte landet in Canvas-Mitte',
             ok: nahe((200 - fit.panX) * fit.zoom, 400, 1e-3),
             detail: 'panX=' + fmt(fit.panX) });

    return r;
  }

  // ---- Container-Roundtrip (.gfproj ZIP) ----
  // Async: liefert Promise<Array<{name, ok, detail}>>
  function containerRoundtripTest() {
    if (!global.fflate) {
      return Promise.resolve([{
        name: 'gfproj-Roundtrip: fflate verfuegbar', ok: false, detail: 'fflate fehlt'
      }]);
    }

    var projekt = GF.projekt.neu({ projektName: 'Test-Roundtrip', sachbearbeiter: 'Tester' });
    // 2 PDFs, 1 Geschoss, 1 Region, 1 Polygon — vollstaendiger Datenflow
    var pdfA = { id: 'pdf-a', dateiName: 'plan-1.pdf', originalDateiName: 'EG.pdf',
                 groesseBytes: 0, anzahlSeiten: 1, vektorAnteil: 0.9 };
    var pdfB = { id: 'pdf-b', dateiName: 'plan-2.pdf', originalDateiName: 'OG.pdf',
                 groesseBytes: 0, anzahlSeiten: 1, vektorAnteil: 0.5 };
    projekt.pdfs = [pdfA, pdfB];
    projekt.geschosse = [{ id: 'g1', bezeichnung: 'EG', reihenfolge: 0 }];
    projekt.planRegionen = [{
      id: 'r1', pdfId: 'pdf-a', seite: 1, geschossId: 'g1', bezeichnung: 'EG-Region',
      ausschnitt: { x: 10, y: 10, breite: 200, hoehe: 150 },
      kalibrierung: { punkt1: {x:0,y:0}, punkt2: {x:100,y:0}, abstandMeter: 5,
                      ptProMeter: 20, quelle: 'manuell',
                      abweichungVonNormProzent: 0, normMassstab: '1:100' }
    }];
    projekt.polygone = [{
      id: 'p1', regionId: 'r1', geschossId: 'g1', bezeichnung: 'Aussenkontur',
      punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:100},{x:0,y:100}],
      flaecheGemessenQM: 25, flaecheAngesetztQM: 25,
      manuelleKorrektur: false, korrekturKommentar: '',
      farbeOverlay: '#ff8800', deckkraft: 0.5
    }];

    // Mini-PDF-Header — beginnt mit %PDF- (sonst Magic-Check failt)
    var pdfABytes = new TextEncoder().encode('%PDF-1.4\n%minimal A\n%%EOF\n');
    var pdfBBytes = new TextEncoder().encode('%PDF-1.4\n%minimal B\n%%EOF\n');
    var binaer = { 'plan-1.pdf': pdfABytes, 'plan-2.pdf': pdfBBytes };

    return GF.projekt.speichere(projekt, binaer).then(function (blob) {
      return blob.arrayBuffer().then(function (ab) {
        var fakeFile = /** @type {File} */ (/** @type {any} */ ({
          name: 'test.gfproj',
          arrayBuffer: function () { return Promise.resolve(ab); }
        }));
        return GF.projekt.lade(fakeFile);
      });
    }).then(function (ergebnis) {
      var r = [];
      r.push({ name: 'Roundtrip: projektName erhalten',
               ok: ergebnis.projekt.metadata.projektName === 'Test-Roundtrip',
               detail: 'ist=' + ergebnis.projekt.metadata.projektName });
      r.push({ name: 'Roundtrip: 2 PDFs erhalten',
               ok: ergebnis.projekt.pdfs.length === 2,
               detail: 'ist=' + ergebnis.projekt.pdfs.length });
      r.push({ name: 'Roundtrip: Polygon-Flaeche erhalten',
               ok: nahe(ergebnis.projekt.polygone[0].flaecheGemessenQM, 25, 1e-9),
               detail: 'ist=' + ergebnis.projekt.polygone[0].flaecheGemessenQM });
      r.push({ name: 'Roundtrip: PDF-A Bytes identisch',
               ok: bytesGleich(ergebnis.pdfBinaer['plan-1.pdf'], pdfABytes),
               detail: 'len=' + ergebnis.pdfBinaer['plan-1.pdf'].length });
      r.push({ name: 'Roundtrip: PDF-B Bytes identisch',
               ok: bytesGleich(ergebnis.pdfBinaer['plan-2.pdf'], pdfBBytes),
               detail: 'len=' + ergebnis.pdfBinaer['plan-2.pdf'].length });
      r.push({ name: 'Roundtrip: Kalibrierung ptProMeter erhalten',
               ok: nahe(ergebnis.projekt.planRegionen[0].kalibrierung.ptProMeter, 20, 1e-9),
               detail: '' });
      return r;
    }).catch(function (err) {
      return [{ name: 'gfproj-Roundtrip', ok: false, detail: err.message }];
    });
  }

  function bytesGleich(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  // ---- vollgeschoss-Tests (portiert aus VG-Tool v1.2.0) ----
  // Toleranz fuer Laengen/Flaechen: 0.01 (Geometrie ist rundungsempfindlich).

  var VG_TOL = 0.01;

  var VG_BERECHNUNGS_FAELLE = [
    {
      name: 'VG-A symm. Satteldach 45 Grad, h_K=1,00',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 88.80, vollgeschoss: true }
    },
    {
      name: 'VG-B flaches Dach 25 Grad, h_K=0,40',
      eingabe: { L_B: 10, L_L: 12, h_KL: 0.4, h_KR: 0.4, alpha_L: 25, alpha_R: 25,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 4.0744, X2: 4.0744, Bm: 1.8512, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 22.214, vollgeschoss: false }
    },
    {
      name: 'VG-C asymm. h_KL=1,5/h_KR=0,8 alpha_L=30/alpha_R=35',
      eingabe: { L_B: 8, L_L: 10, h_KL: 1.5, h_KR: 0.8, alpha_L: 30, alpha_R: 35,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.3856, X2: 2.1421, Bm: 4.4723, A_G: 80.00,
                   zweidrittel_flaeche: 53.333, A_2_30: 44.723, vollgeschoss: false }
    },
    {
      name: 'VG-D mit Gaube links (verschiebt 2,30-Linie)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 2.0, a: 0.3 }], gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 90.80, vollgeschoss: true }
    },
    {
      name: 'VG-E Abzuege getrennt (A_kleiner Nenner / A_groesser Zaehler)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 6, A_groesser: 2 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 114.00,
                   zweidrittel_flaeche: 76.00, A_2_30: 86.80, vollgeschoss: true }
    },
    {
      name: 'VG-G zwei Gauben links, unterschiedliche Traufabstaende',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 1.0, a: 0.0 }, { b: 1.5, a: 0.5 }],
                 gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 91.30, vollgeschoss: true }
    },
    {
      name: 'VG-F Pultdach (h_KR=2,5 >= Grenze -> X2=0)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 2.5, alpha_L: 45, alpha_R: 30,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 0.00, Bm: 8.70, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 104.40, vollgeschoss: true }
    },
    {
      name: 'VG-H h_KL genau an Grenze (=2,30) -> X1=0',
      eingabe: { L_B: 10, L_L: 12, h_KL: 2.30, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 0.00, X2: 1.30, Bm: 8.70, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 104.40, vollgeschoss: true }
    },
    {
      name: 'VG-I beide Kniestoecke >= 2,30 (Vollwand-DG)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 2.5, h_KR: 2.5, alpha_L: 30, alpha_R: 30,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 0.00, X2: 0.00, Bm: 10.00, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 120.00, vollgeschoss: true }
    }
  ];

  function vollgeschossTests() {
    var r = [];
    if (!GF.Vollgeschoss || !GF.Vollgeschoss.berechne) {
      r.push({ name: 'GF.Vollgeschoss.berechne verfuegbar', ok: false,
               detail: 'Modul vollgeschoss.js nicht geladen' });
      return r;
    }

    VG_BERECHNUNGS_FAELLE.forEach(function (fall) {
      var ergebnis = GF.Vollgeschoss.berechne(fall.eingabe);
      ['X1', 'X2', 'Bm', 'A_G', 'zweidrittel_flaeche', 'A_2_30'].forEach(function (k) {
        var ist = ergebnis[k];
        var soll = fall.erwartung[k];
        r.push({
          name: fall.name + ' - ' + k,
          ok: nahe(ist, soll, VG_TOL),
          detail: 'ist=' + fmt(ist) + ', soll=' + fmt(soll)
        });
      });
      r.push({
        name: fall.name + ' - vollgeschoss',
        ok: ergebnis.vollgeschoss === fall.erwartung.vollgeschoss,
        detail: 'ist=' + ergebnis.vollgeschoss
      });
    });

    var p = GF.Vollgeschoss.validierung.parseEingabe;
    var b = GF.Vollgeschoss.berechne;

    // Mikrotest 1: Komma-Parsing
    var m1 = p({ L_B: '10,5', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45' });
    r.push({ name: 'VG-Mikro: parseEingabe akzeptiert Komma',
             ok: m1.fehler.length === 0 && nahe(m1.eingabe.L_B, 10.5),
             detail: 'fehler=' + m1.fehler.length + ' L_B=' + m1.eingabe.L_B });

    // Mikrotest 2: alpha=0 -> Fehler
    var m2 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '0', alpha_R: '45' });
    r.push({ name: 'VG-Mikro: alpha_L=0 produziert Fehler',
             ok: m2.fehler.some(function (f) { return f.indexOf('alpha_L') !== -1; }),
             detail: JSON.stringify(m2.fehler) });

    // Mikrotest 3: alpha=90 -> Fehler
    var m3 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '90' });
    r.push({ name: 'VG-Mikro: alpha_R=90 produziert Fehler',
             ok: m3.fehler.some(function (f) { return f.indexOf('alpha_R') !== -1; }),
             detail: JSON.stringify(m3.fehler) });

    // Mikrotest 4: Bm-Clamp + Warnung
    var m4 = b({ L_B: 4, L_L: 10, h_KL: 0, h_KR: 0, alpha_L: 15, alpha_R: 15,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: sehr flaches Dach clampt Bm=0 + Warnung',
             ok: m4.Bm === 0 && m4.warnungen.some(function (w) { return w.indexOf('Bm') !== -1; }),
             detail: 'Bm=' + m4.Bm });

    // Mikrotest 5: leere optionale Felder -> 0
    var m5 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                 A_kleiner: '', A_groesser: '' });
    r.push({ name: 'VG-Mikro: leere optionale Felder werden 0',
             ok: m5.fehler.length === 0 && m5.eingabe.A_kleiner === 0 && m5.eingabe.A_groesser === 0,
             detail: '' });

    // Mikrotest 6: Sum Gaubenbreiten > L_L -> Fehler
    var m6 = p({ L_B: '10', L_L: '5', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                 gauben_links: [{ b: '6', a: '0' }] });
    r.push({ name: 'VG-Mikro: Summe Gaubenbreiten > L_L produziert Fehler',
             ok: m6.fehler.some(function (f) { return /Gaubenbreiten/.test(f); }),
             detail: JSON.stringify(m6.fehler) });

    // Mikrotest 7: Plausi-Obergrenze L_B > 500
    var m7 = p({ L_B: '10000', L_L: '8', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45' });
    r.push({ name: 'VG-Mikro: L_B > 500 m produziert Fehler',
             ok: m7.fehler.some(function (f) { return f.indexOf('L_B') !== -1; }),
             detail: '' });

    // Mikrotest 8: A_kleiner > A_G_brutto -> Warnung + nicht VG
    var m8 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 200, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: A_kleiner > A_G_brutto produziert Warnung + vollgeschoss=false',
             ok: m8.warnungen.some(function (w) { return w.indexOf('Abzug') !== -1; }) && m8.vollgeschoss === false,
             detail: 'vollgeschoss=' + m8.vollgeschoss });

    // Mikrotest 9: Gauben-Warnung wenn a >= X
    var m9 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 1.0, a: 1.5 }], gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: Gaube mit a >= X warnt und traegt nicht bei',
             ok: m9.warnungen.some(function (w) { return /Gaube #1 links/.test(w); }) && nahe(m9.A_2_30, 88.80, VG_TOL),
             detail: 'A_2_30=' + m9.A_2_30 });

    // ---- v1.1: variable Anrechnungs-Grenzhoehe ----
    // Basis-Setup = VG-A (L_B 10, L_L 12, h_K 1,00, 45 Grad).

    // GH-1: grenzhoehe 1,50 -> X_anr = (1,5-1,0)/tan45 = 0,5; Bm_anr = 9;
    // A_anrechenbar = 9*12 = 108. VG-Werte (2,30-basiert) unveraendert.
    var g1 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0,
                 grenzhoehe: 1.5 });
    r.push({ name: 'VG-GH1: grenzhoehe 1,50 - A_anrechenbar=108, VG-Werte unveraendert',
             ok: nahe(g1.A_anrechenbar, 108.00, VG_TOL) && nahe(g1.A_2_30, 88.80, VG_TOL)
                 && nahe(g1.X1_anr, 0.50, VG_TOL) && nahe(g1.X2_anr, 0.50, VG_TOL)
                 && nahe(g1.Bm_anr, 9.00, VG_TOL) && nahe(g1.X1, 1.30, VG_TOL)
                 && g1.vollgeschoss === true && nahe(g1.grenzhoehe, 1.5, VG_TOL),
             detail: 'A_anr=' + fmt(g1.A_anrechenbar) + ' A_2_30=' + fmt(g1.A_2_30)
                   + ' X1_anr=' + fmt(g1.X1_anr) });

    // GH-2: grenzhoehe 2,30 explizit -> kein zweiter Lauf, Werte identisch
    var g2 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0,
                 grenzhoehe: 2.3 });
    r.push({ name: 'VG-GH2: grenzhoehe 2,30 - A_anrechenbar identisch A_2_30',
             ok: g2.A_anrechenbar === g2.A_2_30 && g2.X1_anr === g2.X1
                 && g2.X2_anr === g2.X2 && g2.Bm_anr === g2.Bm
                 && nahe(g2.grenzhoehe, 2.3, VG_TOL),
             detail: 'A_anr=' + fmt(g2.A_anrechenbar) });

    // GH-3: grenzhoehe fehlt -> Default 2,30 (Alt-Projekt-Kompatibilitaet)
    var g3 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-GH3: grenzhoehe fehlt - Default 2,30',
             ok: nahe(g3.grenzhoehe, 2.3, VG_TOL) && g3.A_anrechenbar === g3.A_2_30,
             detail: 'grenzhoehe=' + fmt(g3.grenzhoehe) });

    // GH-4: grenzhoehe <= Kniestoecke -> volle Grundflaeche anrechenbar
    var g4 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0,
                 grenzhoehe: 1.0 });
    r.push({ name: 'VG-GH4: grenzhoehe <= Kniestock - A_anrechenbar = volle Flaeche',
             ok: nahe(g4.A_anrechenbar, 120.00, VG_TOL) && nahe(g4.X1_anr, 0, VG_TOL)
                 && nahe(g4.Bm_anr, 10.00, VG_TOL),
             detail: 'A_anr=' + fmt(g4.A_anrechenbar) });

    // GH-5: Gaube im zweiten Lauf mit eigenen X-Werten (VG-D-Setup, 1,50):
    // Gaube b=2,0/a=0,3: 2,0*(0,5-0,3)=0,4 -> A_anrechenbar = 108 + 0,4 = 108,4
    var g5 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 2.0, a: 0.3 }], gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0, grenzhoehe: 1.5 });
    r.push({ name: 'VG-GH5: Gaube zaehlt im Anrechnungs-Lauf mit eigenen X-Werten',
             ok: nahe(g5.A_anrechenbar, 108.40, VG_TOL) && nahe(g5.A_2_30, 90.80, VG_TOL),
             detail: 'A_anr=' + fmt(g5.A_anrechenbar) + ' A_2_30=' + fmt(g5.A_2_30) });

    // GH-6: parseEingabe prueft Bereich 0,5-3,0
    var g6 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                 grenzhoehe: '0,3' });
    r.push({ name: 'VG-GH6: grenzhoehe 0,3 produziert Bereichs-Fehler',
             ok: g6.fehler.some(function (f) { return f.indexOf('Grenzhoehe') !== -1; }),
             detail: JSON.stringify(g6.fehler) });

    // GH-7: leeres Grenzhoehe-Feld -> 0 -> berechne() nutzt Default 2,30
    var g7p = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                  grenzhoehe: '' });
    var g7 = b(g7p.eingabe);
    r.push({ name: 'VG-GH7: leeres Grenzhoehe-Feld faellt auf 2,30 zurueck',
             ok: g7p.fehler.length === 0 && nahe(g7.grenzhoehe, 2.3, VG_TOL),
             detail: 'grenzhoehe=' + fmt(g7.grenzhoehe) });

    // GH-8: Projekt-Metadata - Default 2,30 + lenient-Reset bei Unsinn
    if (GF.projekt && GF.projekt.neu && GF.projekt.validiere) {
      var g8p = GF.projekt.neu({ projektName: 'GH-Test' });
      var g8DefaultOk = g8p.metadata.grenzhoeheAnrechnung === 2.3;
      g8p.metadata.grenzhoeheAnrechnung = 99;
      GF.projekt.validiere(g8p);
      r.push({ name: 'VG-GH8: metadata.grenzhoeheAnrechnung Default + lenient-Reset',
               ok: g8DefaultOk && g8p.metadata.grenzhoeheAnrechnung === 2.3,
               detail: 'nachReset=' + g8p.metadata.grenzhoeheAnrechnung });
    }

    // Mikrotest 10: A_kleiner > 1000 -> Fehler (Tippfehler-Schutz)
    var m10 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                  A_kleiner: '5000' });
    r.push({ name: 'VG-Mikro: A_kleiner > 1000 m^2 produziert Fehler',
             ok: m10.fehler.some(function (f) { return f.indexOf('Abzug < 2,30 m') !== -1; }),
             detail: '' });

    // Mikrotest 11: anteil_2_30 = null bei A_G <= 0
    var m11 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                  gauben_links: [], gauben_rechts: [], A_kleiner: 200, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: anteil_2_30 = null bei A_G <= 0 (kein NaN)',
             ok: m11.anteil_2_30 === null,
             detail: 'anteil_2_30=' + m11.anteil_2_30 });

    // Mikrotest 12: anteil_2_30 = A_2_30 / A_G (praezise)
    var m12 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                  gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: anteil_2_30 = A_2_30 / A_G (Fall A ~0,74)',
             ok: Math.abs(m12.anteil_2_30 - (m12.A_2_30 / m12.A_G)) < 1e-9
              && m12.anteil_2_30 > 0.73 && m12.anteil_2_30 < 0.75,
             detail: 'anteil_2_30=' + m12.anteil_2_30 });

    // Geometrie-Smoketest: querschnitt / grundriss / aufriss liefern Werte
    var ergG = b(VG_BERECHNUNGS_FAELLE[0].eingabe);
    var q = GF.Vollgeschoss.geometrie.querschnitt(VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    r.push({ name: 'VG-Geom: querschnitt liefert konturAussen mit 5 Punkten',
             ok: Array.isArray(q.konturAussen) && q.konturAussen.length === 5,
             detail: '' });
    r.push({ name: 'VG-Geom: querschnitt liefert hochpolygon bei Fall A',
             ok: Array.isArray(q.hochpolygon) && q.hochpolygon.length >= 3,
             detail: 'punkte=' + (q.hochpolygon || []).length });

    var gr = GF.Vollgeschoss.geometrie.grundriss(VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    r.push({ name: 'VG-Geom: grundriss liefert L_B/L_L korrekt',
             ok: gr.L_B === 10 && gr.L_L === 12,
             detail: '' });

    var auL = GF.Vollgeschoss.geometrie.aufriss('links',  VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    var auR = GF.Vollgeschoss.geometrie.aufriss('rechts', VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    r.push({ name: 'VG-Geom: aufriss links liefert h_K=1,0',
             ok: auL.h_K === 1.0 && auL.seite === 'links',
             detail: '' });
    r.push({ name: 'VG-Geom: aufriss rechts liefert h_K=1,0',
             ok: auR.h_K === 1.0 && auR.seite === 'rechts',
             detail: '' });

    // ---- v1.2.3: manuelle Korrektur der Flaeche >= 2,30 m (A_2_30_override) ----
    // Basis = Fall A (L_B 10, L_L 12, h_K 1,00, 45 Grad): A_2_30 = 88,80; A_G = 120;
    // zweidrittel_flaeche = 80; ohne Override ist vollgeschoss = true.
    var basisOV = { L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                    gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 };

    // OV-1: Override > Schwelle zieht durch (A_2_30, Anteil); gemessen bleibt erhalten.
    var ov1 = b(Object.assign({}, basisOV, { A_2_30_override: 100.5 }));
    r.push({ name: 'VG-OV1: Override 100,5 setzt A_2_30 + Anteil durch, gemessen=88,80',
             ok: nahe(ov1.A_2_30, 100.5, VG_TOL) && ov1.A_2_30_manuell === true
                 && nahe(ov1.A_2_30_gemessen, 88.80, VG_TOL)
                 && nahe(ov1.anteil_2_30, 100.5 / 120, 1e-6)
                 && ov1.vollgeschoss === true,
             detail: 'A_2_30=' + fmt(ov1.A_2_30) + ' gemessen=' + fmt(ov1.A_2_30_gemessen)
                   + ' anteil=' + fmt(ov1.anteil_2_30) });

    // OV-1b: bei Standard-Grenzhoehe 2,30 folgt die anrechenbare Flaeche dem Override.
    r.push({ name: 'VG-OV1b: A_anrechenbar folgt Override bei Grenzhoehe 2,30',
             ok: nahe(ov1.A_anrechenbar, 100.5, VG_TOL),
             detail: 'A_anr=' + fmt(ov1.A_anrechenbar) });

    // OV-2: Override < Schwelle kippt das Urteil (88,80 -> 50 < 80).
    var ov2 = b(Object.assign({}, basisOV, { A_2_30_override: 50 }));
    r.push({ name: 'VG-OV2: Override 50 kippt vollgeschoss auf false',
             ok: ov2.vollgeschoss === false && ov2.A_2_30_manuell === true
                 && nahe(ov2.A_2_30, 50, VG_TOL),
             detail: 'vollgeschoss=' + ov2.vollgeschoss + ' A_2_30=' + fmt(ov2.A_2_30) });

    // OV-3: Override innerhalb 0,005 m^2 (88,804) greift nicht -> kein manuell-Flag.
    var ov3 = b(Object.assign({}, basisOV, { A_2_30_override: 88.804 }));
    r.push({ name: 'VG-OV3: Override innerhalb 0,005 m^2 wird ignoriert',
             ok: ov3.A_2_30_manuell === false && nahe(ov3.A_2_30, 88.80, VG_TOL)
                 && nahe(ov3.A_2_30_gemessen, 88.80, VG_TOL),
             detail: 'A_2_30=' + fmt(ov3.A_2_30) + ' manuell=' + ov3.A_2_30_manuell });

    // OV-4: bei abweichender Grenzhoehe (1,50) bleibt A_anrechenbar unberuehrt
    // (108 aus dem Anrechnungs-Lauf); nur A_2_30/Urteil folgen dem Override.
    var ov4 = b(Object.assign({}, basisOV, { grenzhoehe: 1.5, A_2_30_override: 100.5 }));
    r.push({ name: 'VG-OV4: Override laesst A_anrechenbar bei Grenzhoehe 1,50 unberuehrt',
             ok: nahe(ov4.A_anrechenbar, 108.00, VG_TOL) && nahe(ov4.A_2_30, 100.5, VG_TOL)
                 && ov4.A_2_30_manuell === true,
             detail: 'A_anr=' + fmt(ov4.A_anrechenbar) + ' A_2_30=' + fmt(ov4.A_2_30) });

    // OV-5: ohne Override bleibt A_2_30_manuell false und gemessen == A_2_30.
    var ov5 = b(basisOV);
    r.push({ name: 'VG-OV5: ohne Override A_2_30_manuell=false, gemessen==A_2_30',
             ok: ov5.A_2_30_manuell === false && ov5.A_2_30_gemessen === ov5.A_2_30,
             detail: 'manuell=' + ov5.A_2_30_manuell });

    return r;
  }

  function exportAnrechnungTests() {
    var r = [];
    if (!GF.export || !GF.export.sammlerFlaechenJeGeschoss) {
      r.push({ name: 'GF.export.sammlerFlaechenJeGeschoss vorhanden',
               ok: false, detail: 'Funktion fehlt — export.js nicht geladen?' });
      return r;
    }

    // Mock-Projekt: 1 PDF, 1 Region, 1 Geschoss (DG), 1 Polygon, 1 VG-Block
    /**
     * @param {boolean} vgVorhanden
     * @returns {Projekt}
     */
    function machProjekt(vgVorhanden) {
      var p = GF.projekt.neu({ projektName: 'TestExport', sachbearbeiter: 'Tester' });
      p.pdfs.push(/** @type {any} */ ({ id: 'pdf-1', dateiName: 'Plan.pdf', containerPfad: 'plan-1.pdf' }));
      p.planRegionen.push(/** @type {any} */ ({ id: 'reg-1', pdfId: 'pdf-1', geschossId: 'g-dg',
                            seite: 1, rect: { x: 0, y: 0, w: 100, h: 100 } }));
      p.geschosse.push({ id: 'g-dg', bezeichnung: 'DG', reihenfolge: 1 });
      p.polygone.push(/** @type {any} */ ({ id: 'pl-1', regionId: 'reg-1', geschossId: 'g-dg',
                        bezeichnung: 'Hauptgebaeude',
                        punkte: [{x:0,y:0},{x:10,y:0},{x:10,y:10},{x:0,y:10}],
                        flaecheAngesetztQM: 100, manuelleKorrektur: false }));
      if (vgVorhanden) {
        p.geschosse[0].vollgeschoss = /** @type {VollgeschossBlock} */ (/** @type {any} */ ({
          durchgefuehrt: true,
          berechnetAm: '2026-05-12T10:00:00+02:00',
          berechnetVon: 'Tester',
          eingaben: { L_B: 10, L_L: 10, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                       gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
          ergebnis: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 100, A_2_30: 42.5,
                       zweidrittel_flaeche: 66.67, anteil_2_30: 0.425, vollgeschoss: false,
                       differenz: -24.17, warnungen: [] },
          plausibilitaet: null,
          kommentar: ''
        }));
      }
      return p;
    }

    // 1) 'voll'-Modus: Zeile zeigt Polygonflaeche
    var pVoll = machProjekt(true);
    var tVoll = GF.export.sammlerFlaechenJeGeschoss(pVoll, { vgAnrechnung: 'voll' });
    r.push({ name: 'voll-Modus: Zeile zeigt Polygonflaeche (100 m²)',
             ok: tVoll.zeilen.length === 1 && Math.abs(tVoll.zeilen[0].flaeche - 100) < 0.001
                 && tVoll.zeilen[0].anrechnung === 'voll',
             detail: 'flaeche=' + tVoll.zeilen[0].flaeche + ', anr=' + tVoll.zeilen[0].anrechnung });

    // 2) 'anteilig'-Modus: Zeile zeigt A_2_30
    var pAnt = machProjekt(true);
    var tAnt = GF.export.sammlerFlaechenJeGeschoss(pAnt, { vgAnrechnung: 'anteilig' });
    r.push({ name: 'anteilig-Modus: Zeile zeigt A_2_30 (42,5 m²) + anrechnung="anteilig"',
             ok: tAnt.zeilen.length === 1 && Math.abs(tAnt.zeilen[0].flaeche - 42.5) < 0.001
                 && tAnt.zeilen[0].anrechnung === 'anteilig'
                 && Math.abs((tAnt.zeilen[0].polygonFlaeche || 0) - 100) < 0.001,
             detail: 'flaeche=' + tAnt.zeilen[0].flaeche + ', polygon=' + tAnt.zeilen[0].polygonFlaeche });

    // 3) anteilig-Modus + Geschoss ohne VG: bleibt Polygonflaeche
    var pKein = machProjekt(false);
    var tKein = GF.export.sammlerFlaechenJeGeschoss(pKein, { vgAnrechnung: 'anteilig' });
    r.push({ name: 'anteilig-Modus + kein VG: Polygonflaeche bleibt, anrechnung="voll"',
             ok: tKein.zeilen.length === 1 && Math.abs(tKein.zeilen[0].flaeche - 100) < 0.001
                 && tKein.zeilen[0].anrechnung === 'voll',
             detail: 'flaeche=' + tKein.zeilen[0].flaeche + ', anr=' + tKein.zeilen[0].anrechnung });

    // 4) Gesamtsumme entspricht Summe der gewaehlten Werte
    r.push({ name: 'Gesamtsumme = Summe der gewaehlten flaeche-Werte (anteilig)',
             ok: Math.abs(tAnt.gesamt - 42.5) < 0.001,
             detail: 'gesamt=' + tAnt.gesamt });

    // 4c) v1.1: anteilig mit abweichender Grenzhoehe nutzt A_anrechenbar
    var pGh = machProjekt(true);
    pGh.geschosse[0].vollgeschoss.eingaben.grenzhoehe = 1.5;
    pGh.geschosse[0].vollgeschoss.ergebnis.grenzhoehe = 1.5;
    pGh.geschosse[0].vollgeschoss.ergebnis.A_anrechenbar = 77.7;
    var tGh = GF.export.sammlerFlaechenJeGeschoss(pGh, { vgAnrechnung: 'anteilig' });
    r.push({ name: 'v1.1 anteilig + Grenzhoehe 1,50: Zeile zeigt A_anrechenbar (77,7 m²)',
             ok: tGh.zeilen.length === 1 && Math.abs(tGh.zeilen[0].flaeche - 77.7) < 0.001
                 && tGh.zeilen[0].anrechnung === 'anteilig'
                 && Math.abs((tGh.zeilen[0].grenzhoehe || 0) - 1.5) < 0.001,
             detail: 'flaeche=' + tGh.zeilen[0].flaeche + ', gh=' + tGh.zeilen[0].grenzhoehe });

    // 4d) v1.1: alter VG-Block ohne grenzhoehe-Felder -> weiter A_2_30
    var tAlt = GF.export.sammlerFlaechenJeGeschoss(machProjekt(true), { vgAnrechnung: 'anteilig' });
    r.push({ name: 'v1.1 anteilig + Alt-Block ohne grenzhoehe: faellt auf A_2_30 zurueck',
             ok: Math.abs(tAlt.zeilen[0].flaeche - 42.5) < 0.001
                 && Math.abs((tAlt.zeilen[0].grenzhoehe || 0) - 2.3) < 0.001,
             detail: 'flaeche=' + tAlt.zeilen[0].flaeche });

    // 4b) Rechenweg-Helfer baueSummenkette (reine Funktion, deutsches Komma)
    if (GF.export.baueSummenkette) {
      var bsk = GF.export.baueSummenkette([12.34, 5.67], 18.01);
      r.push({ name: 'baueSummenkette: "12,34 + 5,67 = 18,01 m²"',
               ok: bsk === '12,34 + 5,67 = 18,01 m²', detail: bsk });
      var bsk3 = GF.export.baueSummenkette([12.34, 5.67, 3.10], 21.11);
      r.push({ name: 'baueSummenkette: drei Werte verkettet',
               ok: bsk3 === '12,34 + 5,67 + 3,10 = 21,11 m²', detail: bsk3 });
      var bskEin = GF.export.baueSummenkette([100], 100);
      r.push({ name: 'baueSummenkette: ein Wert -> nur Summe (keine Kette)',
               ok: bskEin === '100,00 m²', detail: bskEin });
      var bskLeer = GF.export.baueSummenkette([], 0);
      r.push({ name: 'baueSummenkette: leer -> Summe 0,00 m²',
               ok: bskLeer === '0,00 m²', detail: bskLeer });
      var bskNF = GF.export.baueSummenkette([10, Infinity, 5], 999);
      r.push({ name: 'baueSummenkette: nicht-finiter Wert -> nur Summe (keine irrefuehrende Kette)',
               ok: bskNF === '999,00 m²', detail: bskNF });
    } else {
      r.push({ name: 'GF.export.baueSummenkette vorhanden',
               ok: false, detail: 'Test-Hook fehlt' });
    }

    // 4c) v1.1 Herleitung: istRechteck (reine Funktion, pt-Koordinaten, ptProMeter)
    if (GF.export.istRechteck) {
      var rePunkte = [{x:0,y:0},{x:100,y:0},{x:100,y:50},{x:0,y:50}]; // 10 m x 5 m bei 10 pt/m
      var re = GF.export.istRechteck(rePunkte, 10);
      r.push({ name: 'istRechteck: 10x5-Rechteck erkannt (laenge/breite/flaeche)',
               ok: !!re && Math.abs(re.laenge - 10) < 0.001 && Math.abs(re.breite - 5) < 0.001
                   && Math.abs(re.flaeche - 50) < 0.001,
               detail: JSON.stringify(re) });
      var schief = GF.export.istRechteck([{x:0,y:0},{x:100,y:0},{x:120,y:50},{x:0,y:50}], 10);
      r.push({ name: 'istRechteck: schiefes Viereck (Winkel weit ab von 90°) -> null',
               ok: schief === null, detail: JSON.stringify(schief) });
      var lForm = GF.export.istRechteck(
        [{x:0,y:0},{x:100,y:0},{x:100,y:30},{x:50,y:30},{x:50,y:50},{x:0,y:50}], 10);
      r.push({ name: 'istRechteck: L-Form (6 Punkte) -> null',
               ok: lForm === null, detail: JSON.stringify(lForm) });
      var ohneKal = GF.export.istRechteck(rePunkte, 0);
      r.push({ name: 'istRechteck: ptProMeter 0 -> null',
               ok: ohneKal === null, detail: JSON.stringify(ohneKal) });
    } else {
      r.push({ name: 'GF.export.istRechteck vorhanden', ok: false, detail: 'Test-Hook fehlt' });
    }

    // 4d) v1.1 Herleitung: baueGaussZeilen (normierte Koordinaten + Kreuzsumme)
    if (GF.export.baueGaussZeilen) {
      var penta = [{x:0,y:0},{x:100,y:0},{x:100,y:40},{x:60,y:75},{x:0,y:50}];
      var gz = GF.export.baueGaussZeilen(penta, 10);
      r.push({ name: 'baueGaussZeilen: Pentagon -> 5 Koordinaten, Flaeche 60,50',
               ok: !!gz && gz.koordinaten.length === 5
                   && Math.abs(gz.kreuzsumme - 121) < 0.001
                   && Math.abs(gz.flaeche - 60.5) < 0.001,
               detail: gz ? 'kreuz=' + gz.kreuzsumme + ' fl=' + gz.flaeche : 'null' });
      var gzNorm = GF.export.baueGaussZeilen(
        [{x:200,y:300},{x:300,y:300},{x:300,y:350},{x:200,y:350}], 10);
      var minOk = !!gzNorm && gzNorm.koordinaten.every(function (k) { return k.x >= 0 && k.y >= 0; })
                  && gzNorm.koordinaten.some(function (k) { return k.x === 0; })
                  && gzNorm.koordinaten.some(function (k) { return k.y === 0; });
      r.push({ name: 'baueGaussZeilen: Koordinaten lokal normiert (Ursprung = min)',
               ok: minOk && Math.abs(gzNorm.flaeche - 50) < 0.001,
               detail: JSON.stringify(gzNorm && gzNorm.koordinaten) });
      r.push({ name: 'baueGaussZeilen: <3 Punkte -> null',
               ok: GF.export.baueGaussZeilen([{x:0,y:0},{x:1,y:1}], 10) === null, detail: '' });
      r.push({ name: 'baueGaussZeilen: ptProMeter 0 -> null',
               ok: GF.export.baueGaussZeilen(penta, 0) === null, detail: '' });
    } else {
      r.push({ name: 'GF.export.baueGaussZeilen vorhanden', ok: false, detail: 'Test-Hook fehlt' });
    }

    // 4e) v1.1 Herleitung: baueHerleitungsText (Inline-Zeile je Teilflaeche)
    if (GF.export.baueHerleitungsText) {
      var rePoly = { punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:50},{x:0,y:50}],
                     flaecheGemessenQM: 50, flaecheAngesetztQM: 50 };
      var ht = GF.export.baueHerleitungsText(rePoly, 10);
      r.push({ name: 'baueHerleitungsText: Rechteck -> "10,00 m × 5,00 m = 50,00 m²"',
               ok: ht === '10,00 m × 5,00 m = 50,00 m²', detail: ht });
      // Seit v1.2.3: eine manuelle Korrektur wird in der Herleitung NICHT mehr
      // vermerkt (kein PDF-Hinweis; nur im Tool sichtbar). Der Text ist identisch
      // zum Rechteck ohne Korrektur.
      var koPoly = { punkte: rePoly.punkte, manuelleKorrektur: true,
                     flaecheGemessenQM: 50, flaecheAngesetztQM: 48 };
      var htKo = GF.export.baueHerleitungsText(koPoly, 10);
      r.push({ name: 'baueHerleitungsText: Korrektur ohne PDF-Vermerk (nur Rechteck-Text)',
               ok: htKo === '10,00 m × 5,00 m = 50,00 m²',
               detail: htKo });
      var pePoly = { punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:40},{x:60,y:75},{x:0,y:50}],
                     flaecheGemessenQM: 60.5, flaecheAngesetztQM: 60.5 };
      var htPe = GF.export.baueHerleitungsText(pePoly, 10);
      r.push({ name: 'baueHerleitungsText: Pentagon -> Anhang-Verweis mit Eckpunktzahl',
               ok: htPe === '5 Eckpunkte - Herleitung siehe Rechenweg-Anhang', detail: htPe });
      var htOhne = GF.export.baueHerleitungsText({ punkte: [] }, 10);
      r.push({ name: 'baueHerleitungsText: ohne Punkte -> "nicht verfügbar"',
               ok: htOhne === 'Herleitung nicht verfügbar (keine Kalibrierung)', detail: htOhne });
    } else {
      r.push({ name: 'GF.export.baueHerleitungsText vorhanden', ok: false, detail: 'Test-Hook fehlt' });
    }

    // 4f) v1.1 Herleitung: baueAnhangPlan (Seitenplanung Anhang)
    if (GF.export.baueAnhangPlan) {
      var apRe = GF.export.baueAnhangPlan(
        [{ punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:50},{x:0,y:50}] }], 10);
      r.push({ name: 'baueAnhangPlan: nur Rechteck -> 0 Seiten',
               ok: Array.isArray(apRe) && apRe.length === 0, detail: JSON.stringify(apRe) });
      var pent = { punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:40},{x:60,y:75},{x:0,y:50}] };
      var apPe = GF.export.baueAnhangPlan([pent], 10);
      r.push({ name: 'baueAnhangPlan: Pentagon -> 1 Seite, 1 Abschnitt mit Kopf+Formel',
               ok: apPe.length === 1 && apPe[0].length === 1
                   && apPe[0][0].mitKopf === true && apPe[0][0].mitFormel === true
                   && apPe[0][0].vonPunkt === 0 && apPe[0][0].bisPunkt === 5,
               detail: 'seiten=' + apPe.length });
      var monsterPunkte = [];
      for (var mi = 0; mi < 100; mi++) {
        var mw = mi / 100 * 2 * Math.PI;
        monsterPunkte.push({ x: 500 + 400 * Math.cos(mw), y: 500 + 400 * Math.sin(mw) });
      }
      var apMo = GF.export.baueAnhangPlan([{ punkte: monsterPunkte }], 10);
      var moLetzte = apMo.length ? apMo[apMo.length - 1] : [];
      var moLetzterAbschnitt = moLetzte.length ? moLetzte[moLetzte.length - 1] : null;
      var moAlleZeilen = 0;
      apMo.forEach(function (s) { s.forEach(function (a) { moAlleZeilen += a.bisPunkt - a.vonPunkt; }); });
      r.push({ name: 'baueAnhangPlan: 100-Punkte-Polygon -> mehrere Seiten, alle Punkte abgedeckt',
               ok: apMo.length >= 2 && moAlleZeilen === 100
                   && !!moLetzterAbschnitt && moLetzterAbschnitt.mitFormel === true,
               detail: 'seiten=' + apMo.length + ' zeilen=' + moAlleZeilen });
      r.push({ name: 'baueAnhangPlan: ptProMeter 0 -> 0 Seiten',
               ok: GF.export.baueAnhangPlan([pent], 0).length === 0, detail: '' });
    } else {
      r.push({ name: 'GF.export.baueAnhangPlan vorhanden', ok: false, detail: 'Test-Hook fehlt' });
    }

    // 5) metadata.vgAnrechnung Validierung: 'voll' / 'anteilig' / null akzeptiert
    var pmA = GF.projekt.neu({ projektName: 'T', sachbearbeiter: '' });
    pmA.metadata.vgAnrechnung = 'voll';
    var okA = false; try { okA = GF.projekt.validiere(pmA) === true; } catch (e) { okA = false; }
    r.push({ name: 'metadata.vgAnrechnung="voll" wird akzeptiert',
             ok: okA && pmA.metadata.vgAnrechnung === 'voll', detail: '' });

    var pmB = GF.projekt.neu({ projektName: 'T', sachbearbeiter: '' });
    pmB.metadata.vgAnrechnung = 'anteilig';
    var okB = false; try { okB = GF.projekt.validiere(pmB) === true; } catch (e) { okB = false; }
    r.push({ name: 'metadata.vgAnrechnung="anteilig" wird akzeptiert',
             ok: okB && pmB.metadata.vgAnrechnung === 'anteilig', detail: '' });

    // 6) Unbekannter Wert wird auf null zurueckgesetzt (lenient)
    var pmC = GF.projekt.neu({ projektName: 'T', sachbearbeiter: '' });
    pmC.metadata.vgAnrechnung = /** @type {any} */ ('irgendwas');
    try { GF.projekt.validiere(pmC); } catch (e) { /* nicht erwartet */ }
    r.push({ name: 'metadata.vgAnrechnung mit unbekanntem Wert wird auf null zurueckgesetzt',
             ok: pmC.metadata.vgAnrechnung === null,
             detail: 'ist=' + pmC.metadata.vgAnrechnung });

    // 7) ExportDialog.sammleVgGeschosse listet nur VG-Geschosse
    if (GF.ExportDialog && GF.ExportDialog.sammleVgGeschosse) {
      var vg = GF.ExportDialog.sammleVgGeschosse(pVoll);
      r.push({ name: 'ExportDialog.sammleVgGeschosse: 1 VG-Geschoss erkannt',
               ok: vg.length === 1 && vg[0].geschoss.bezeichnung === 'DG'
                   && Math.abs(vg[0].polygonFlaeche - 100) < 0.001
                   && Math.abs(vg[0].A_2_30 - 42.5) < 0.001,
               detail: JSON.stringify(vg.map(function (x) { return {n:x.geschoss.bezeichnung, p:x.polygonFlaeche, a:x.A_2_30}; })) });
      var vgKein = GF.ExportDialog.sammleVgGeschosse(pKein);
      r.push({ name: 'ExportDialog.sammleVgGeschosse: kein VG-Geschoss erkannt',
               ok: vgKein.length === 0, detail: 'len=' + vgKein.length });
    }

    return r;
  }

  // ---- v1.2: Strukturierter Fachverfahren-Export ----

  // Mock-Projekt fuer die Export-Tests: 1 PDF, 1 kalibrierte Region (10 pt/m),
  // 1 Geschoss (DG), 1 Polygon (10 m x 10 m = 100 m²), optional VG-Block.
  function machExportProjekt(vgVorhanden, opt) {
    opt = opt || {};
    var p = /** @type {any} */ (GF.projekt.neu({ projektName: 'TestExport', sachbearbeiter: 'Tester' }));
    p.metadata.projektNummer = '2022/16';
    p.metadata.bauvorhaben = opt.bauvorhaben || 'Neubau EFH';
    p.pdfs.push({ id: 'pdf-1', dateiName: 'Plan.pdf', containerPfad: 'plan-1.pdf' });
    p.planRegionen.push({ id: 'reg-1', pdfId: 'pdf-1', geschossId: 'g-dg', seite: 1,
      kalibrierung: { ptProMeter: 10, normMassstab: '1:100' } });
    p.geschosse.push({ id: 'g-dg', bezeichnung: opt.geschoss || 'DG', reihenfolge: 1 });
    p.polygone.push({ id: 'pl-1', regionId: 'reg-1', geschossId: 'g-dg', bezeichnung: 'Hauptgebaeude',
      punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:100},{x:0,y:100}],
      flaecheAngesetztQM: 100, flaecheGemessenQM: 100, manuelleKorrektur: false });
    if (vgVorhanden) {
      p.geschosse[0].vollgeschoss = {
        durchgefuehrt: true,
        ergebnis: { A_G: 100, A_2_30: 42.5, A_anrechenbar: 42.5,
                    zweidrittel_flaeche: 66.67, anteil_2_30: 0.425, vollgeschoss: false,
                    grenzhoehe: 2.3, warnungen: [] }
      };
    }
    return p;
  }

  function exportdatenTests() {
    var r = [];
    if (!GF.exportdaten || !GF.exportdaten.baue) {
      r.push({ name: 'GF.exportdaten.baue vorhanden', ok: false, detail: 'exportdaten.js nicht geladen?' });
      return r;
    }
    var ISO = '2026-06-16T08:00:00.000Z';

    // 1) voll-Modus: anrechenbar == Polygonflaeche
    var mVoll = GF.exportdaten.baue(machExportProjekt(true), null, { vgAnrechnung: 'voll', jetztIso: ISO });
    r.push({ name: 'exportdaten voll: anrechenbar=Polygonflaeche (100)',
             ok: mVoll.geschosse.length === 1
                 && Math.abs(mVoll.geschosse[0].anrechenbare_flaeche_qm - 100) < 0.001
                 && Math.abs(mVoll.geschosse[0].polygon_flaeche_qm - 100) < 0.001
                 && mVoll.geschosse[0].anrechnung === 'voll',
             detail: 'anr=' + mVoll.geschosse[0].anrechenbare_flaeche_qm });

    // 2) anteilig-Modus: anrechenbar == A_2_30, vg-Block gefuellt
    var mAnt = GF.exportdaten.baue(machExportProjekt(true), null, { vgAnrechnung: 'anteilig', jetztIso: ISO });
    var g0 = mAnt.geschosse[0];
    r.push({ name: 'exportdaten anteilig: anrechenbar=A_2_30 (42,5) + vg-Block',
             ok: Math.abs(g0.anrechenbare_flaeche_qm - 42.5) < 0.001
                 && g0.anrechnung === 'anteilig'
                 && !!g0.vg && Math.abs(g0.vg.A_2_30_qm - 42.5) < 0.001
                 && g0.vg.ist_vollgeschoss === false
                 && Math.abs(g0.vg.grenzhoehe_m - 2.3) < 0.001,
             detail: JSON.stringify(g0.vg) });

    // 3) Summe == sammler.gesamt
    var samm = GF.export.sammlerFlaechenJeGeschoss(machExportProjekt(true), null, { vgAnrechnung: 'anteilig' });
    r.push({ name: 'exportdaten: summe.gesamt_anrechenbar_qm == sammler.gesamt',
             ok: Math.abs(mAnt.summe.gesamt_anrechenbar_qm - samm.gesamt) < 0.001,
             detail: 'modell=' + mAnt.summe.gesamt_anrechenbar_qm + ' sammler=' + samm.gesamt });

    // 4) Schema-Invarianten + Meta-Mapping + Determinismus (jetztIso)
    r.push({ name: 'exportdaten: schema.version=1, aktenzeichen=projektNummer, am_iso fix',
             ok: !!mVoll.schema && mVoll.schema.version === 1
                 && mVoll.projekt.aktenzeichen === '2022/16'
                 && mVoll.projekt.vg_anrechnung_modus === 'voll'
                 && mVoll.erzeugt.am_iso === ISO,
             detail: 'v=' + (mVoll.schema && mVoll.schema.version) + ' az=' + mVoll.projekt.aktenzeichen });

    // 5) Teilflaechen mit Kanten (opt-in): 4 Kanten à 10 m + Herleitungs-Text
    var mK = GF.exportdaten.baue(machExportProjekt(false), null,
      { vgAnrechnung: 'voll', enthaltKanten: true, jetztIso: ISO });
    var tf = mK.geschosse[0].teilflaechen[0];
    r.push({ name: 'exportdaten enthaltKanten: 4 Kanten à 10 m + Herleitung',
             ok: !!tf && Array.isArray(tf.kanten_m) && tf.kanten_m.length === 4
                 && Math.abs(tf.kanten_m[0] - 10) < 0.001
                 && typeof tf.herleitung === 'string' && tf.herleitung.indexOf('100,00 m²') >= 0,
             detail: 'kanten=' + JSON.stringify(tf && tf.kanten_m) });

    return r;
  }

  function exportformatTests() {
    var r = [];
    if (!GF.exportformat || !GF.exportformat.get || !GF.exportdaten) {
      r.push({ name: 'GF.exportformat + exportdaten vorhanden', ok: false, detail: 'Module nicht geladen?' });
      return r;
    }
    var ISO = '2026-06-16T08:00:00.000Z';
    var p = machExportProjekt(true, { geschoss: 'DG; Spitzboden', bauvorhaben: '=SUMME(A1)' });
    var modell = GF.exportdaten.baue(p, null, { vgAnrechnung: 'voll', jetztIso: ISO });

    var csvW = GF.exportformat.get('csv');
    if (!csvW) {
      r.push({ name: 'CSV-Writer registriert', ok: false, detail: 'fehlt' });
    } else {
      var c = csvW.schreibe(modell);
      r.push({ name: 'CSV: UTF-8-BOM am Anfang', ok: c.text.charCodeAt(0) === 0xFEFF, detail: 'cp0=' + c.text.charCodeAt(0) });
      r.push({ name: 'CSV: Semikolon-Trenner + CRLF', ok: c.text.indexOf(';') >= 0 && c.text.indexOf('\r\n') >= 0, detail: '' });
      r.push({ name: 'CSV: Zahl als "100,00" (Komma-Dezimal)', ok: c.text.indexOf('100,00') >= 0, detail: '' });
      r.push({ name: 'CSV: Zelle mit Semikolon wird gequotet', ok: c.text.indexOf('"DG; Spitzboden"') >= 0, detail: '' });
      r.push({ name: 'CSV: Formel-Injection neutralisiert (=)', ok: c.text.indexOf("'=SUMME(A1)") >= 0, detail: '' });
      r.push({ name: 'CSV: Dateiname _Fachdaten_2026-06-16.csv', ok: /_Fachdaten_2026-06-16\.csv$/.test(c.dateiname), detail: c.dateiname });
      var c2 = csvW.schreibe(modell);
      r.push({ name: 'CSV: deterministisch (zwei Laeufe identisch)', ok: c2.text === c.text, detail: '' });
    }

    var jsonW = GF.exportformat.get('json');
    if (!jsonW) {
      r.push({ name: 'JSON-Writer registriert', ok: false, detail: 'fehlt' });
    } else {
      var j = jsonW.schreibe(modell);
      var parsed = null, okParse = true;
      try { parsed = JSON.parse(j.text); } catch (e) { okParse = false; }
      r.push({ name: 'JSON: parse-bar + schema.version + Zahl numerisch',
               ok: okParse && !!parsed && parsed.schema.version === 1
                   && typeof parsed.summe.gesamt_anrechenbar_qm === 'number',
               detail: okParse ? ('v=' + parsed.schema.version) : 'parse-fehler' });
    }

    return r;
  }

  // ---- v1.2: Assistiertes Messen (Vektor-Extraktion, Snap, Maßketten) ----

  function vektorTests() {
    var r = [];
    if (!GF.pdf || !GF.pdf._segmenteAusOpList) {
      r.push({ name: 'GF.pdf._segmenteAusOpList vorhanden', ok: false, detail: 'pdf-vektor.js nicht geladen?' });
      return r;
    }
    var OPS = { moveTo:1, lineTo:2, curveTo:3, curveTo2:4, curveTo3:5,
                rectangle:6, closePath:7, transform:8, save:9, restore:10, constructPath:11 };
    function nahe(a, b) { return Math.abs(a - b) < 1e-6; }
    function hatVertex(vs, x, y) { return vs.some(function (p) { return nahe(p.x, x) && nahe(p.y, y); }); }

    var r1 = GF.pdf._segmenteAusOpList(
      [OPS.constructPath],
      [[[OPS.moveTo, OPS.lineTo, OPS.lineTo, OPS.lineTo], [0,0, 10,0, 10,10, 0,10]]], OPS);
    r.push({ name: 'vektor: moveTo+3 lineTo -> 4 Vertices, 3 Kanten',
      ok: r1.vertices.length === 4 && r1.kanten.length === 3
          && hatVertex(r1.vertices, 0, 0) && hatVertex(r1.vertices, 10, 10),
      detail: 'v=' + r1.vertices.length + ' k=' + r1.kanten.length });

    var r2 = GF.pdf._segmenteAusOpList([OPS.constructPath], [[[OPS.rectangle], [5,5, 20,10]]], OPS);
    r.push({ name: 'vektor: rectangle -> 4 Ecken + 4 Kanten',
      ok: r2.vertices.length === 4 && r2.kanten.length === 4
          && hatVertex(r2.vertices, 5, 5) && hatVertex(r2.vertices, 25, 15),
      detail: 'v=' + r2.vertices.length + ' k=' + r2.kanten.length });

    var r3 = GF.pdf._segmenteAusOpList(
      [OPS.save, OPS.transform, OPS.constructPath, OPS.restore],
      [null, [1,0,0,1,100,50], [[OPS.moveTo, OPS.lineTo], [0,0, 10,0]], null], OPS);
    r.push({ name: 'vektor: CTM-Translation (100,50) verschiebt Punkte',
      ok: hatVertex(r3.vertices, 100, 50) && hatVertex(r3.vertices, 110, 50),
      detail: JSON.stringify(r3.vertices) });

    var r4 = GF.pdf._segmenteAusOpList(
      [OPS.constructPath], [[[OPS.moveTo, OPS.curveTo], [0,0, 1,1, 2,2, 9,9]]], OPS);
    r.push({ name: 'vektor: gerade "Kurve" (Kontrollpkt auf Sehne) -> Endpunkt + 1 Kante',
      ok: r4.vertices.length === 2 && hatVertex(r4.vertices, 9, 9) && !hatVertex(r4.vertices, 1, 1) && r4.kanten.length === 1,
      detail: JSON.stringify(r4) });

    var r4b = GF.pdf._segmenteAusOpList(
      [OPS.constructPath], [[[OPS.moveTo, OPS.curveTo], [0,0, 5.5,0, 10,4.5, 10,10]]], OPS);
    r.push({ name: 'vektor: gekruemmte Kurve -> Stuetzpunkte (Polygon folgt Rundung)',
      ok: r4b.vertices.length > 2 && r4b.kanten.length >= 2
          && hatVertex(r4b.vertices, 0, 0) && hatVertex(r4b.vertices, 10, 10),
      detail: 'v=' + r4b.vertices.length + ' k=' + r4b.kanten.length });

    var r4c = GF.pdf._segmenteAusOpList(
      [OPS.constructPath], [[[OPS.moveTo, OPS.curveTo2], [0,0, 4,6, 10,0]]], OPS);
    r.push({ name: 'vektor: curveTo2 (v) -> Endpunkt (10,0), Kontrollpunkt nicht als Ecke',
      ok: hatVertex(r4c.vertices, 10, 0) && !hatVertex(r4c.vertices, 4, 6) && r4c.kanten.length >= 1,
      detail: JSON.stringify(r4c.vertices) });

    var r5 = GF.pdf._segmenteAusOpList(
      [OPS.transform, OPS.constructPath],
      [[2,0,0,2,0,0], [[OPS.moveTo, OPS.lineTo], [3,4, 5,6]]], OPS);
    r.push({ name: 'vektor: CTM-Skalierung 2x -> (3,4)->(6,8)',
      ok: hatVertex(r5.vertices, 6, 8) && hatVertex(r5.vertices, 10, 12),
      detail: JSON.stringify(r5.vertices) });

    // v1.2: Pfad-Bbox-Filter — winzige Pfade (Outline-Text, Schraffur, Symbole)
    // mit Bbox-Diagonale < 5 pt fallen ganz raus; lange Strukturkanten bleiben.
    var r6 = GF.pdf._segmenteAusOpList(
      [OPS.constructPath], [[[OPS.moveTo, OPS.lineTo, OPS.lineTo], [0,0, 2,0, 2,2]]], OPS);
    r.push({ name: 'vektor: Pfad-Bbox < 5pt -> komplett verworfen (0 Vertices)',
      ok: r6.vertices.length === 0 && r6.kanten.length === 0,
      detail: 'v=' + r6.vertices.length + ' k=' + r6.kanten.length });

    var r7 = GF.pdf._segmenteAusOpList(
      [OPS.constructPath, OPS.constructPath],
      [ [[OPS.moveTo, OPS.lineTo, OPS.lineTo], [0,0, 2,0, 2,2]],   // winzig -> raus
        [[OPS.moveTo, OPS.lineTo], [0,0, 100,0]] ],                // Wand -> bleibt
      OPS);
    r.push({ name: 'vektor: winziger Pfad verworfen, Wandkante (100pt) bleibt',
      ok: r7.vertices.length === 2 && r7.kanten.length === 1
          && hatVertex(r7.vertices, 100, 0) && !hatVertex(r7.vertices, 2, 2),
      detail: 'v=' + r7.vertices.length + ' k=' + r7.kanten.length });

    // v1.2: Distanz-Dezimierung — eine lange Polylinie aus 0,5-pt-Schritten (wie
    // geflattete Outline-Kurven/Schraffuren) wird auf wenige Stuetzpunkte (>=1,5 pt
    // Abstand) ausgeduennt; Start UND Endpunkt bleiben erhalten. (61 Eingabepunkte.)
    var soPoly = [OPS.moveTo], coPoly = [0, 0];
    for (var px = 0.5; px <= 30.0001; px += 0.5) { soPoly.push(OPS.lineTo); coPoly.push(+px.toFixed(2), 0); }
    var r8 = GF.pdf._segmenteAusOpList([OPS.constructPath], [[soPoly, coPoly]], OPS);
    r.push({ name: 'vektor: Polylinie aus 61 Mikro-Schritten -> dezimiert (<=25 Vertices), Endpunkte bleiben',
      ok: r8.vertices.length <= 25 && r8.vertices.length >= 15
          && r8.kanten.length === r8.vertices.length - 1
          && hatVertex(r8.vertices, 0, 0) && hatVertex(r8.vertices, 30, 0),
      detail: 'v=' + r8.vertices.length + ' k=' + r8.kanten.length });

    return r;
  }

  function snapTests() {
    var r = [];
    if (!GF.snap || !GF.snap.toleranzPt || !GF.util.KDTree || !GF.polygon || !GF.polygon.snap) {
      r.push({ name: 'GF.snap + Primitiven vorhanden', ok: false, detail: 'snap.js/util/polygon nicht geladen?' });
      return r;
    }
    r.push({ name: 'snap.toleranzPt(12, zoom): 0,5->24 / 2->6',
      ok: GF.snap.toleranzPt(12, 0.5) === 24 && GF.snap.toleranzPt(12, 2) === 6, detail: '' });

    var kd = new GF.util.KDTree([{x:0,y:0},{x:100,y:0},{x:100,y:100}], 50);
    var s1 = GF.polygon.snap.aufEndpunkt({x:102,y:2}, kd, 5);
    r.push({ name: 'snap: (102,2) tol 5 -> rastet auf (100,0)',
      ok: !!s1.snapped && Math.abs(s1.x - 100) < 1e-9 && Math.abs(s1.y - 0) < 1e-9, detail: JSON.stringify(s1) });
    var s2 = GF.polygon.snap.aufEndpunkt({x:300,y:300}, kd, 12);
    r.push({ name: 'snap: (300,300) -> kein Treffer (unveraendert)',
      ok: !s2.snapped && s2.x === 300 && s2.y === 300, detail: JSON.stringify(s2) });
    var s3 = GF.snap.naechster({x:101,y:1}, { kdTree: kd }, 12, 1);
    r.push({ name: 'snap.naechster: (101,1) px12 zoom1 -> (100,0)',
      ok: !!s3.snapped && Math.abs(s3.x - 100) < 1e-9, detail: JSON.stringify(s3) });

    // v1.2: Detailgrad-Cap — _ausPunkten baut den Index aus {vertices,kanten}.
    // Normalfall -> KDTree; leer -> null; ueber MAX_VERTICES -> uebersprungen.
    if (GF.snap._ausPunkten && typeof GF.snap.MAX_VERTICES === 'number') {
      var idxN = GF.snap._ausPunkten({ vertices: [{x:0,y:0},{x:1,y:1}],
        kanten: [{a:{x:0,y:0},b:{x:1,y:1}}] });
      r.push({ name: 'snap: _ausPunkten normal -> KDTree gebaut, nicht uebersprungen',
        ok: !!idxN && !!idxN.kdTree && idxN.vertexAnzahl === 2 && !idxN.uebersprungen,
        detail: JSON.stringify({ v: idxN && idxN.vertexAnzahl, u: idxN && idxN.uebersprungen }) });

      r.push({ name: 'snap: _ausPunkten leer -> null',
        ok: GF.snap._ausPunkten({ vertices: [], kanten: [] }) === null, detail: '' });

      var viele = [];
      for (var iv = 0; iv <= GF.snap.MAX_VERTICES; iv++) viele.push({ x: iv, y: 0 });
      var idxC = GF.snap._ausPunkten({ vertices: viele, kanten: [] });
      r.push({ name: 'snap: _ausPunkten > MAX_VERTICES -> uebersprungen, kdTree null',
        ok: !!idxC && idxC.uebersprungen === true && idxC.kdTree === null
            && idxC.vertexAnzahl === viele.length,
        detail: JSON.stringify({ max: GF.snap.MAX_VERTICES, v: idxC && idxC.vertexAnzahl,
          u: idxC && idxC.uebersprungen }) });
    } else {
      r.push({ name: 'snap: _ausPunkten + MAX_VERTICES vorhanden', ok: false,
        detail: 'Detailgrad-Cap nicht implementiert' });
    }

    return r;
  }

  function masskettenTests() {
    var r = [];
    if (!GF.pdf || !GF.pdf._parseMassText || !GF.pdf.massstabBelege) {
      r.push({ name: 'GF.pdf._parseMassText + massstabBelege vorhanden', ok: false, detail: 'pdf-massketten.js nicht geladen?' });
      return r;
    }
    var P = GF.pdf._parseMassText;
    r.push({ name: 'massketten: _parseMassText "3,00"->3 / "2,95"->2,95',
      ok: Math.abs(P('3,00') - 3) < 1e-9 && Math.abs(P('2,95') - 2.95) < 1e-9, detail: '' });
    r.push({ name: 'massketten: _parseMassText verwirft "abc"/"250"/"0,20"',
      ok: isNaN(P('abc')) && isNaN(P('250')) && isNaN(P('0,20')), detail: '' });

    // v1.2.5-Redesign: massstabVorschlag ist geloescht — massstabBelege liefert
    // die Rohdaten, GF.region.massstabGate entscheidet (eigene Suite unten).
    r.push({ name: 'massketten: massstabVorschlag entfernt (Redesign)',
      ok: GF.pdf['massstabVorschlag'] === undefined, detail: typeof GF.pdf['massstabVorschlag'] });

    // v1.2.5-Redesign: norm-AGNOSTISCHE Mess-Skala + hartes Freigabe-Gate.
    if (GF.pdf.gemesseneSkala && GF.region && GF.region.massstabGate
        && GF.region.messungAbgleich && GF.region.massstabAusPtProMeter
        && GF.region.ptProMeterAusMassstab) {
      var ppNenn = GF.region.ptProMeterAusMassstab(50);   // 56,69 (Nennmaßstab 1:50)
      var ppMess = ppNenn * 0.96;                          // ~54,4 (Plan 4 % kleiner exportiert)
      var kanteBei = function (x, y, wert, pp) {
        var halb = wert * pp / 2;
        return { a: { x: x - halb, y: y }, b: { x: x + halb, y: y } };
      };
      var mkOff = [ {wertMeter:9,x:0,y:0}, {wertMeter:8,x:1000,y:0}, {wertMeter:6,x:0,y:1000}, {wertMeter:5,x:1000,y:1000} ];
      var knOff = [ kanteBei(0,0,9,ppMess), kanteBei(1000,0,8,ppMess), kanteBei(0,1000,6,ppMess), kanteBei(1000,1000,5,ppMess) ];
      var gm = GF.pdf.gemesseneSkala(mkOff, knOff);
      r.push({ name: 'massstab: gemesseneSkala liest off-scale pt/m (norm-agnostisch)',
        ok: !!gm && Math.abs(gm.ptProMeter - ppMess) < 0.5 && gm.anzahlBelege >= 3,
        detail: gm ? JSON.stringify({pp: Math.round(gm.ptProMeter*100)/100, n: gm.anzahlBelege}) : 'null' });

      r.push({ name: 'massstab: gemesseneSkala <3 Maße -> null',
        ok: GF.pdf.gemesseneSkala([{wertMeter:9,x:0,y:0}], [kanteBei(0,0,9,ppMess)]) === null,
        detail: '' });

      r.push({ name: 'massstab: direktBelegAbgleich entfernt (Redesign)',
        ok: GF.region['direktBelegAbgleich'] === undefined
            && GF.region['SCHWELLE_DIREKT_BEMASSUNG_PROZENT'] === undefined,
        detail: '' });

      r.push({ name: 'massstab: massstabAusPtProMeter(~54,4) -> 52',
        ok: GF.region.massstabAusPtProMeter(ppMess) === 52,
        detail: String(GF.region.massstabAusPtProMeter(ppMess)) });

      // ---- massstabGate-Matrix: jede Ablehnung mit maschinenlesbarem grund ----
      var pp100 = GF.region.ptProMeterAusMassstab(100);
      var G = GF.region.GATE;
      var belGut = { ptProMeter: pp100, normMassstab: '1:100', anzahlBelege: 6, gewicht: 1200, gewichtZweiter: 0 };
      var gmGut = { ptProMeter: pp100 * 1.002, anzahlBelege: 5 };

      var g1 = GF.region.massstabGate(belGut, gmGut);
      r.push({ name: 'gate: harte Beweislage -> bestanden, Vorschlag mit Abweichung',
        ok: !!g1 && g1.bestanden === true && !!g1.vorschlag
            && g1.vorschlag.normMassstab === '1:100' && g1.vorschlag.anzahlBelege === 6
            && g1.vorschlag.abweichungProzent < 1,
        detail: JSON.stringify(g1 && g1.vorschlag) });

      var g2 = GF.region.massstabGate(null, gmGut);
      r.push({ name: 'gate: keine Belege -> keine-belege',
        ok: !!g2 && !g2.bestanden && g2.grund === 'keine-belege', detail: g2 && g2.grund });

      var g3 = GF.region.massstabGate(
        { ptProMeter: pp100, normMassstab: '1:100', anzahlBelege: G.MIN_BELEGE - 1, gewicht: 900, gewichtZweiter: 0 }, gmGut);
      r.push({ name: 'gate: ' + (G.MIN_BELEGE - 1) + ' Belege -> zu-wenig-belege',
        ok: !!g3 && !g3.bestanden && g3.grund === 'zu-wenig-belege', detail: g3 && g3.grund });

      var g4 = GF.region.massstabGate(
        { ptProMeter: pp100 * 1.02, normMassstab: '1:100', anzahlBelege: 6, gewicht: 1200, gewichtZweiter: 0 },
        { ptProMeter: pp100 * 1.02, anzahlBelege: 5 });
      r.push({ name: 'gate: Median 2 % neben Norm -> norm-abweichung',
        ok: !!g4 && !g4.bestanden && g4.grund === 'norm-abweichung', detail: g4 && g4.grund });

      var g5 = GF.region.massstabGate(
        { ptProMeter: pp100, normMassstab: '1:100', anzahlBelege: 6, gewicht: 1200, gewichtZweiter: 500 }, gmGut);
      r.push({ name: 'gate: Sieger nur 2,4x Konkurrent -> kein-dominanter-sieger',
        ok: !!g5 && !g5.bestanden && g5.grund === 'kein-dominanter-sieger', detail: g5 && g5.grund });

      var g6 = GF.region.massstabGate(belGut, null);
      r.push({ name: 'gate: ohne Mess-Skala (fail-closed) -> keine-mess-skala',
        ok: !!g6 && !g6.bestanden && g6.grund === 'keine-mess-skala', detail: g6 && g6.grund });

      // 1:168-Regression (EFH-Schraege): Winkel-Labels bilden Muell-Cluster
      // ~16,84 pt/m, waehrend 23 echte Belege 1:100 stuetzen. Frueher entschied
      // der Konsens-Vorrang — im Redesign blockt das Mess-Skala-Veto den Banner
      // KOMPLETT: widerspruechliche Signalwelt => kein Vorschlag, Nutzer misst.
      var gmMuell = { ptProMeter: 16.844, anzahlBelege: 8 };
      var belViel = { ptProMeter: 28.32, normMassstab: '1:100', anzahlBelege: 23, gewicht: 4000, gewichtZweiter: 0 };
      var g7 = GF.region.massstabGate(belViel, gmMuell);
      r.push({ name: 'gate: 1:168-Muell-Cluster widerspricht -> mess-skala-widerspruch (kein Banner)',
        ok: !!g7 && !g7.bestanden && g7.grund === 'mess-skala-widerspruch', detail: g7 && g7.grund });

      // ---- messungAbgleich: Messung gewinnt, Gate liefert nur den Gelb-Hinweis ----
      var m1 = GF.region.messungAbgleich(pp100 * 1.005, belGut, gmGut);
      r.push({ name: 'messung: passt zur gate-bestaetigten Bemaßung -> ok',
        ok: !!m1 && m1.status === 'ok' && m1.abweichungProzent < 3 && m1.referenzPtProMeter === pp100,
        detail: m1 && JSON.stringify({s: m1.status, abw: Math.round(m1.abweichungProzent * 10) / 10}) });

      var m2 = GF.region.messungAbgleich(pp100 * 0.92, belGut, gmGut);
      r.push({ name: 'messung: 8 % neben gate-bestaetigter Bemaßung -> widerspruch (gelb)',
        ok: !!m2 && m2.status === 'widerspruch' && m2.abweichungProzent > 3,
        detail: m2 && JSON.stringify({s: m2.status, abw: Math.round(m2.abweichungProzent * 10) / 10}) });

      // Portierte 1:168-Regression: faellt das Gate (Muell-Cluster), urteilt
      // messungAbgleich 'unbekannt' — die Messung bleibt unangefochten, KEIN Gelb.
      var m3 = GF.region.messungAbgleich(pp100, belViel, gmMuell);
      var m4 = GF.region.messungAbgleich(pp100, null, null);
      r.push({ name: 'messung: Gate gefallen (1:168-Repro) / keine Belege -> unbekannt, kein Gelb',
        ok: !!m3 && m3.status === 'unbekannt' && !!m4 && m4.status === 'unbekannt',
        detail: JSON.stringify({repro: m3 && m3.status, leer: m4 && m4.status}) });
    }

    // v1.2.5-Redesign: massstabBelege liefert Rohdaten (gewicht/gewichtZweiter
    // fuer das Dominanz-Kriterium) — KEIN stufe-Feld mehr, das Gate entscheidet.
    if (GF.pdf.massstabBelege && GF.region && GF.region.ptProMeterAusMassstab && GF.region.plausibilitaet) {
      var pp2 = GF.region.ptProMeterAusMassstab(100);
      var norm2 = GF.region.plausibilitaet(pp2).naechsterNormMassstab;
      var kante2 = function (x, y, wert) {
        var halb = wert * pp2 / 2;
        return { a: { x: x - halb, y: y }, b: { x: x + halb, y: y } };
      };
      var mk3 = [ {text:'3,00',wertMeter:3,x:0,y:0}, {text:'5,00',wertMeter:5,x:1000,y:0}, {text:'4,00',wertMeter:4,x:0,y:1000} ];
      var kn3 = [ kante2(0,0,3), kante2(1000,0,5), kante2(0,1000,4) ];
      var vb = GF.pdf.massstabBelege(mk3, kn3);
      r.push({ name: 'massketten: massstabBelege 3 Belege -> ' + norm2 + ' + Gewichte, ohne stufe',
        ok: !!vb && vb.normMassstab === norm2 && vb.anzahlBelege === 3
            && vb.belege.length === 3 && vb.gewicht > 0 && vb.gewichtZweiter === 0
            && vb['stufe'] === undefined,
        detail: vb ? JSON.stringify({norm:vb.normMassstab, n:vb.anzahlBelege, gew:Math.round(vb.gewicht), gew2:vb.gewichtZweiter}) : 'null' });

      var mk1 = [ {text:'3,00',wertMeter:3,x:0,y:0} ];
      var kn1 = [ kante2(0,0,3) ];
      var vb1 = GF.pdf.massstabBelege(mk1, kn1);
      r.push({ name: 'massketten: massstabBelege 1 Beleg -> Rohdaten (nicht null, kein stufe)',
        ok: !!vb1 && vb1.anzahlBelege === 1 && vb1['stufe'] === undefined && vb1.belege.length === 1,
        detail: vb1 ? JSON.stringify({n:vb1.anzahlBelege, gew:Math.round(vb1.gewicht)}) : 'null' });

      r.push({ name: 'massketten: massstabBelege leere Eingabe -> null',
        ok: GF.pdf.massstabBelege([], kn1) === null && GF.pdf.massstabBelege(mk1, []) === null,
        detail: '' });

      // v1.2 Regression (1:100 statt 1:500): Bei dichtem 5-m-Raster findet jeder
      // "5"-Maßtext sowohl seine echte (lange) Maßlinie -> 1:100 als auch eine kurze
      // Zufallskante (1-m-Feature) -> 1:500 (Faktor 5 = Norm-Abstand). Reines Stimmen-
      // Zaehlen kippt auf 1:500. Korrekt: Belege nach Maßlinien-Laenge gewichten —
      // die wenigen langen echten Linien (grosse Maße) gewinnen -> 1:100.
      var pp100 = GF.region.ptProMeterAusMassstab(100);
      var pp500 = GF.region.ptProMeterAusMassstab(500);
      var mkR = [], knR = [];
      for (var ri = 0; ri < 5; ri++) {
        var xx = ri * 1000;
        mkR.push({ text: '5', wertMeter: 5, x: xx, y: 0 });
        // kurze Zufallskante -> 1:500, Abw. 0 % (gewinnt das Zaehlen)
        var halbDecoy = 5 * pp500 / 2;
        knR.push({ a: { x: xx - halbDecoy, y: 0 }, b: { x: xx + halbDecoy, y: 0 } });
        // echte (lange) Maßlinie -> 1:100, minimal daneben (0,1 %), verliert das Zaehlen
        var halbEcht = 5 * pp100 * 1.001 / 2;
        knR.push({ a: { x: xx - halbEcht, y: 0 }, b: { x: xx + halbEcht, y: 0 } });
      }
      for (var rj = 0; rj < 3; rj++) {
        var yy = 1000 + rj * 1000;
        mkR.push({ text: '16', wertMeter: 16, x: 0, y: yy });
        var halb16 = 16 * pp100 / 2;   // nur echte lange Linie -> 1:100, exakt
        knR.push({ a: { x: -halb16, y: yy }, b: { x: halb16, y: yy } });
      }
      var vbR = GF.pdf.massstabBelege(mkR, knR);
      r.push({ name: 'massketten: 5-m-Raster -> 1:100 (laengen-gewichtet, nicht 1:500 durch Zaehlen)',
        ok: !!vbR && vbR.normMassstab === '1:100' && Math.abs(vbR.ptProMeter - pp100) < 0.5,
        detail: vbR ? JSON.stringify({ norm: vbR.normMassstab, n: vbR.anzahlBelege, pp: +vbR.ptProMeter.toFixed(2) }) : 'null' });
      // Redesign: Konkurrenz-Gewicht wird mitgeliefert (1:500-Decoys > 0), Sieger dominiert.
      r.push({ name: 'massketten: 5-m-Raster -> gewichtZweiter > 0 und gewicht > gewichtZweiter',
        ok: !!vbR && vbR.gewichtZweiter > 0 && vbR.gewicht > vbR.gewichtZweiter,
        detail: vbR ? JSON.stringify({ gew: Math.round(vbR.gewicht), gew2: Math.round(vbR.gewichtZweiter) }) : 'null' });
    }
    return r;
  }

  // v1.2.5-Redesign: reine Text-Builder — neutrales Vektor-Badge, Evidenz-Banner
  // (nur nach bestandenem Gate) und die Maßstab-Statusanzeige. DOM-frei testbar.
  function politurTests() {
    var r = [];
    if (!GF.massstabUi || !GF.massstabUi.badgeText || !GF.massstabUi.bannerText
        || !GF.massstabUi.statusText) {
      r.push({ name: 'GF.massstabUi vorhanden (badgeText + bannerText + statusText)', ok: false, detail: 'massstab-ui.js nicht geladen?' });
      return r;
    }
    var bt = GF.massstabUi.badgeText;
    var a0 = bt(null, null);
    r.push({ name: 'badgeText: anteil null -> "wird geprüft", klasse badge',
      ok: a0.text === 'Vektor wird geprüft …' && a0.klasse === 'badge', detail: JSON.stringify(a0) });
    var a1 = bt(0.8, 'fertig');
    r.push({ name: 'badgeText: 0,8 fertig -> "Vektor 80%", neutral (keine Ampelklasse)',
      ok: a1.text === 'Vektor 80%' && a1.klasse === 'badge', detail: JSON.stringify(a1) });
    var a2 = bt(0.8, 'vorbereiten');
    r.push({ name: 'badgeText: 0,8 vorbereiten -> "· wird vorbereitet …", neutral',
      ok: a2.text === 'Vektor 80% · wird vorbereitet …' && a2.klasse === 'badge', detail: JSON.stringify(a2) });
    var a3 = bt(0.8, 'magnet-aus');
    r.push({ name: 'badgeText: 0,8 magnet-aus -> "· Magnet aus", neutral',
      ok: a3.text === 'Vektor 80% · Magnet aus' && a3.klasse === 'badge', detail: JSON.stringify(a3) });
    var a4 = bt(0.5, 'fertig');
    r.push({ name: 'badgeText: 0,5 -> neutral, Titel "Gemischtes PDF"',
      ok: a4.text === 'Vektor 50%' && a4.klasse === 'badge' && a4.title.indexOf('Gemischtes') === 0,
      detail: JSON.stringify(a4) });
    var a5 = bt(0.1, 'vorbereiten');
    r.push({ name: 'badgeText: Scan (0,1) -> "Vektor 10%" ohne Suffix, neutral',
      ok: a5.text === 'Vektor 10%' && a5.klasse === 'badge', detail: JSON.stringify(a5) });

    var bn = GF.massstabUi.bannerText;
    var vGate = { normMassstab: '1:100', ptProMeter: 28.346, anzahlBelege: 6, abweichungProzent: 0.4 };
    var b1 = bn(vGate, { bezeichnung: 'EG' });
    r.push({ name: 'bannerText: Evidenz-Text mit Belegen + Abweichung + Region',
      ok: b1.text === 'Maßstab 1:100 erkannt — 6 Bemaßungen bestätigen, Abweichung 0,4 %. Für Region „EG" übernehmen?'
          && b1['unsicher'] === undefined,
      detail: b1.text });
    var b3 = bn(vGate, {});
    r.push({ name: 'bannerText: Region ohne Bezeichnung -> „?"',
      ok: b3.text.indexOf('Region „?"') >= 0, detail: b3.text });

    // statusText: die EINE Ampel — rot (fehlt) / gruen (gesetzt) / gelb (Widerspruch).
    var st = GF.massstabUi.statusText;
    r.push({ name: 'statusText: keine Region -> null (Anzeige versteckt)',
      ok: st(null) === null, detail: '' });
    var s1 = st({ kalibrierung: null });
    r.push({ name: 'statusText: unkalibriert -> rot "Maßstab fehlt", aktion messen',
      ok: !!s1 && s1.klasse === 'mass-status-fehlt' && s1.aktion === 'messen'
          && s1.text === 'Maßstab fehlt — Referenzmaß messen',
      detail: JSON.stringify(s1) });
    var s2 = st({ kalibrierung: { ptProMeter: 28.346, normMassstab: '1:100', widerspruchProzent: null } });
    r.push({ name: 'statusText: gesetzt ohne Widerspruch -> gruen mit Norm + pt/m',
      ok: !!s2 && s2.klasse === 'mass-status-ok' && s2.aktion === null
          && s2.text === 'Maßstab: 1:100 (28,35 pt/m)',
      detail: JSON.stringify(s2) });
    var s3 = st({ kalibrierung: { ptProMeter: 26.1, normMassstab: '1:100', widerspruchProzent: 4.2 } });
    r.push({ name: 'statusText: Widerspruch 4,2 % -> gelb "Zweites Maß empfohlen", aktion nachmessen',
      ok: !!s3 && s3.klasse === 'mass-status-pruefen' && s3.aktion === 'nachmessen'
          && /weicht 4,2 % ab/.test(s3.text) && /Zweites Maß empfohlen/.test(s3.text),
      detail: JSON.stringify(s3) });
    var s4 = st({ kalibrierung: { ptProMeter: 27.3 } });
    r.push({ name: 'statusText: gesetzt ohne Norm-Feld -> gruen mit "≈1:N"',
      ok: !!s4 && s4.klasse === 'mass-status-ok' && s4.text.indexOf('≈1:104') >= 0,
      detail: JSON.stringify(s4) });
    var s5 = st({ kalibrierung: { ptProMeter: 28.346, normMassstab: '1:100', widerspruchProzent: 2.0 } });
    r.push({ name: 'statusText: Widerspruch unter Schwelle (2 %) -> bleibt gruen',
      ok: !!s5 && s5.klasse === 'mass-status-ok', detail: JSON.stringify(s5) });
    return r;
  }

  GF.tests.fmt = fmt;
  GF.tests.runAll = function () {
    return {
      util: utilTests(),
      polygon: polygonTests(),
      rechteck: rechteckTests(),
      region: regionTests(),
      schema: schemaTests(),
      pdf: pdfTests(),
      vollgeschoss: vollgeschossTests(),
      diagnose: diagnoseTests(),
      exportAnrechnung: exportAnrechnungTests(),
      exportdaten: exportdatenTests(),
      exportformat: exportformatTests(),
      vektor: vektorTests(),
      snap: snapTests(),
      massketten: masskettenTests(),
      politur: politurTests()
    };
  };
  GF.tests.runLizenzTests = lizenzTests;
  GF.tests.runContainerTests = containerRoundtripTest;

})(typeof window !== 'undefined' ? window : globalThis);
