// @ts-check
// js/massstab-ui.js — reine Text-Builder fuer Vektor-Badge, Maßstab-Banner und
// die Maßstab-Statusanzeige (v1.2.5-Redesign). DOM-frei + ohne Seiteneffekte,
// damit im Test-Runner (test.html, ohne app.js) pruefbar.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.massstabUi = GF.massstabUi || /** @type {GfMassstabUiModule} */ ({});

  /**
   * Text/Klasse/Titel fuer das Vektor-Badge oben rechts. v1.2.5-Redesign:
   * bewusst OHNE Ampelfarben — die einzige Ampel im Tool ist der Maßstab-
   * Status. Das Badge ist reine PDF-Info (Vektor vs. Scan), immer neutral.
   * @param {number|null|undefined} anteil  Vektor-Flaechenanteil [0..1] | null = Analyse laeuft
   * @param {string|null} [status]  Phase-2b-Status: 'vorbereiten' | 'magnet-aus' | 'fertig'/null.
   *   Nur bei Vektor/gemischt (anteil >= 0,3) relevant — Scans haben keine Phase 2.
   * @returns {{text:string, klasse:string, title:string}}
   */
  GF.massstabUi.badgeText = function (anteil, status) {
    if (anteil === null || anteil === undefined) {
      return { text: 'Vektor wird geprüft …', klasse: 'badge', title: 'PDF wird analysiert …' };
    }
    var prozent = Math.round(anteil * 100);
    var title = anteil >= 0.7 ? 'Vektor-PDF — präzise vermessbar'
              : anteil >= 0.3 ? 'Gemischtes PDF — Vermessung möglich, Toleranz beachten'
              :                 'Raster-PDF — Vermessung pixelbasiert, ±1-2% Toleranz';
    var text = 'Vektor ' + prozent + '%';
    // Phase-2-Suffix nur bei Vektor/gemischt; bei Scan laeuft keine Phase 2.
    if (anteil >= 0.3) {
      if (status === 'vorbereiten') text += ' · wird vorbereitet …';
      else if (status === 'magnet-aus') text += ' · Magnet aus';
    }
    return { text: text, klasse: 'badge', title: title };
  };

  /**
   * Text fuer das nicht-blockierende Maßstab-Banner. Kommt nur noch bei
   * gate-bestandener Beweislage (GF.region.massstabGate) — der Text nennt die
   * Evidenz, damit der Sachbearbeiter die Uebernahme fundiert entscheidet.
   * @param {{normMassstab?:string, ptProMeter:number, anzahlBelege?:number, abweichungProzent?:number}} vorschlag
   * @param {{bezeichnung?:string}} region
   * @returns {{text:string}}
   */
  GF.massstabUi.bannerText = function (vorschlag, region) {
    var fmt = (GF.util && GF.util.formatZahlDE) ? GF.util.formatZahlDE : function (n) { return String(n); };
    var name = (region && region.bezeichnung) ? region.bezeichnung : '?';
    var norm = (vorschlag && vorschlag.normMassstab) || '1:?';
    var n = (vorschlag && vorschlag.anzahlBelege) || 0;
    var abw = (vorschlag && typeof vorschlag.abweichungProzent === 'number')
      ? vorschlag.abweichungProzent : null;
    var text = 'Maßstab ' + norm + ' erkannt — ' + n + ' Bemaßungen bestätigen'
      + (abw !== null ? ', Abweichung ' + fmt(abw, 1) + ' %' : '')
      + '. Für Region „' + name + '" übernehmen?';
    return { text: text };
  };

  /**
   * Text/Klasse/Aktion fuer die persistente Maßstab-Statusanzeige (Sidebar).
   * Die EINE Ampel des Tools: gruen = gesetzt, rot = fehlt, gelb nur wenn die
   * gate-bestaetigte Planbemaßung der Messung widerspricht (widerspruchProzent).
   * @param {{kalibrierung?:({ptProMeter:number, normMassstab?:(string|null), widerspruchProzent?:(number|null)}|null)}|null|undefined} region
   * @returns {{text:string, klasse:string, aktion:(string|null)}|null}  null = keine Region aktiv
   */
  GF.massstabUi.statusText = function (region) {
    if (!region) return null;
    var fmt = (GF.util && GF.util.formatZahlDE) ? GF.util.formatZahlDE : function (n) { return String(n); };
    var kal = region.kalibrierung;
    if (!kal || !(kal.ptProMeter > 0)) {
      return { text: 'Maßstab fehlt — Referenzmaß messen', klasse: 'mass-status-fehlt', aktion: 'messen' };
    }
    var schwelle = (GF.region && GF.region.SCHWELLE_MESSUNG_WIDERSPRUCH_PROZENT) || 3.0;
    var norm = kal.normMassstab;
    if (!norm && GF.region && GF.region.massstabAusPtProMeter) {
      var nEff = GF.region.massstabAusPtProMeter(kal.ptProMeter);
      norm = nEff ? ('≈1:' + nEff) : null;
    }
    var anzeige = norm || (fmt(kal.ptProMeter, 2) + ' pt/m');
    if (typeof kal.widerspruchProzent === 'number' && kal.widerspruchProzent > schwelle) {
      return {
        text: 'Maßstab ' + anzeige + ' gesetzt — Planbemaßung weicht '
          + fmt(kal.widerspruchProzent, 1) + ' % ab. Zweites Maß empfohlen.',
        klasse: 'mass-status-pruefen',
        aktion: 'nachmessen'
      };
    }
    return {
      text: 'Maßstab: ' + anzeige + ' (' + fmt(kal.ptProMeter, 2) + ' pt/m)',
      klasse: 'mass-status-ok',
      aktion: null
    };
  };

})(typeof window !== 'undefined' ? window : globalThis);
