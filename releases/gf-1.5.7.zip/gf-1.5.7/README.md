<p align="center">
  <img src="assets/flaechenklar_logo.svg" alt="FlächenKlar" width="420">
</p>

# FlächenKlar

Offline lauffähiges HTML/JS-Werkzeug, mit dem Sachbearbeiter im Bauamt einer bayerischen Kommune **Geschossflächen aus digitalen Bauantrags-PDFs** ermitteln können. Ergebnis ist ein PDF-Aufmaßprotokoll als Berechnungsgrundlage für den Herstellungsbeitrag (Art. 5 KAG Bayern).

*Arbeitstitel bis Mai 2026: gf-Tool / Geschossflächen-Tool. Funktionsumfang und Datenformat sind unverändert.*

**Status:** v1.5.7 (Stand 23.10.2026, in Vorbereitung) — Release über `npm run bump` + `tools/release.js` (Schrittfolge: Typecheck → Tests → Release-Checker-Gate → Build-ZIP → Smoke-Test → Browser-Demo → Auslieferungs-Kanäle). Aktuelle Nummer immer in `js/version.js`.

## Schnellstart

1. `lib/`-Bibliotheken besorgen (siehe `lib/README.md`)
2. Optional: `data/lizenz.example.js` → `data/lizenz.js` mit eigener Gemeinde-ID
3. Optional: `data/kommune.example.js` → `data/kommune.js` mit Kommunal-Stammdaten
4. `index.html` doppelklicken — öffnet im Default-Browser

## Entwicklung — Type-Check (optional, nur Dev)

Das Tool nutzt JSDoc-Annotationen + TypeScript-Compiler im `--checkJs --noEmit`-Modus für statische Type-Prüfung. Die App selbst läuft weiter ohne Node/npm direkt aus `index.html`; die Type-Pipeline ist rein Dev-Tooling.

```bash
npm install        # einmalig — installiert TypeScript + Lib-Typen als devDeps
npm run typecheck  # prüft alle js/*.js strict (@ts-check + strict: true)
```

Strict-Mode (`strict: true`, `checkJs: true`) ist seit dem Fold vom 15.07.2026 in der Basis-`tsconfig.json` aktiv — alle js-Dateien laufen strict, `npm run typecheck` deckt alles in einem Lauf ab (kein separater Strict-Lauf mehr). Details: `CLAUDE.md`, Abschnitt „Strict-Typecheck“.

## Verzeichnisse

```
FlaechenKlar/
├── index.html              # App-Einstieg (Doppelklick)
├── test.html               # Test-Runner
├── update.bat / update.ps1 # Windows-Updater
├── package.json            # Dev-Tooling (TypeScript-Typecheck)
├── tsconfig.json           # JSDoc + checkJs Konfiguration
├── data/                   # Kunden-spezifisch, NICHT im Repo (außer .example.js)
├── js/                     # Klassische Scripts, alle unter window.GF.* + @ts-check
├── types/                  # JSDoc-Typen (.d.ts) für GF-Namespace
├── lib/                    # Offline-Drittlibs (pdf.js, jsPDF, fflate)
├── css/                    # Stylesheet
├── tools/                  # Release-/Build-/Prüf-Werkzeuge (release.js, bump-version.js, publish-channels.js, deploy-demo.js, explorer-runner.js, build-docs.mjs, build-allowlist.js)
└── docs/                   # SPEC.md + Benutzerhandbuch
```

## Verhältnis zum Vollgeschoss-Tool

Eigenständige Anwendung mit eigenem Repo und eigenem Vertrieb. Teilt sich aber das **Lizenz-System** (Whitelist-Hash gegen `allowlist.json` auf GitHub Pages) — Code 1:1 vom VG-Tool übernommen, ID-Präfix `GF-` statt `VG-`. Detail siehe `docs/SPEC.md`.

## Was das Tool NICHT tut

- Beitragsbescheid-Berechnung (Satzungsanwendung ist Aufgabe der Behörde)
- Automatische Außenkontur-Erkennung (KI/ML bewusst nicht im MVP)
- Cloud-Speicherung / Online-Verarbeitung (Datenschutz)

## Lizenz

Siehe `LICENSE.md`. Stichwort: proprietär, kundenspezifisch lizenziert via ID + Whitelist.
