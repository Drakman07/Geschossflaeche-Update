@echo off
REM ==================================================================
REM  FlaechenKlar Companion-Updater
REM  Doppelklick startet das PowerShell-Update-Skript.
REM  Kundendaten im Ordner data\ bleiben unangetastet.
REM ==================================================================
echo.
echo  FlaechenKlar Update
echo  ===================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
echo.
echo  Druecken Sie eine Taste, um dieses Fenster zu schliessen.
pause >nul
