/* =====================================================================
 * data/lizenz.example.js — VORLAGE fuer neue Auslieferungen
 * ---------------------------------------------------------------------
 * Kopiere diese Datei zu data/lizenz.js und setze die Gemeinde-ID ein.
 *
 * ID-Format: GF-XX-YYYY-NNN
 *   GF-      fester Praefix (Geschossflaechen-Tool)
 *   XX       Gemeinde-Kuerzel (PH = Postbauer-Heng, NM = Neumarkt, ...)
 *   YYYY     Ausstellungsjahr
 *   NNN      laufende Nummer (3-stellig)
 *
 * Beispiele:
 *   GF-PH-2026-001   (Postbauer-Heng, 1. Verkauf 2026)
 *   GF-NM-2026-002   (Neumarkt i.d.OPf., 2. Verkauf 2026)
 *
 * Beim Update-Check hasht die App diese ID via SHA256 und prueft den
 * Hash gegen die oeffentliche allowlist.json. Die ID selbst landet
 * niemals als Klartext auf einem Server.
 *
 * WICHTIG: Bei Auslieferung MUSS gleichzeitig der SHA256-Hash dieser
 * ID in die allowlist.json auf gh-pages aufgenommen werden, sonst
 * verweigert die App bzw. der update.bat das Update.
 * ===================================================================== */

window.GF_LIZENZ = {
  id: 'GF-XX-YYYY-NNN'
};
