# Lizenz

**Copyright © 2026 Alexander Geitner. Alle Rechte vorbehalten.**

Das **Geschossflächen-Tool** (gf-tool) ist proprietäre Software und wird kundenspezifisch lizenziert.

## Nutzungsrecht

Die Nutzung der Software ist nur lizenzierten Kommunen gestattet. Eine gültige Lizenz wird über eine ID im Format `GF-XX-YYYY-NNN` ausgewiesen, die in `data/lizenz.js` hinterlegt wird. Die Berechtigung wird zusätzlich über eine öffentliche Whitelist (`allowlist.json` auf GitHub Pages) verifiziert.

## Demo-Modus

Ohne `data/lizenz.js` läuft die Software 14 Tage als Demo (volle Funktionalität mit Wasserzeichen im Aufmaßprotokoll). Nach Ablauf nur noch im Nur-Lesen-Modus.

## Drittlibs

Die Software bindet folgende Open-Source-Bibliotheken offline ein:

- **pdf.js** — Mozilla Public License 2.0 (MPL-2.0)
- **jsPDF** — MIT License
- **fflate** — MIT License

Lizenztexte siehe `lib/`-Unterordner nach Installation der Libraries.

## Haftungsausschluss

Diese Software unterstützt bei der Ermittlung von Geschossflächen aus Bauantrags-PDFs. Sie ersetzt **keine baurechtliche Prüfung** und führt **keine Beitragsberechnung** durch — die Anwendung der Gebühren- und Beitragssatzung obliegt der zuständigen Sachbearbeiterin oder dem zuständigen Sachbearbeiter. Das Ergebnis ist ohne Gewähr und unverbindlich.
