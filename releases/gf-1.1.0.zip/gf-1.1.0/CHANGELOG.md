# Changelog — FlächenKlar

Alle nennenswerten Änderungen werden hier dokumentiert.
*Arbeitstitel bis Mai 2026: gf-Tool / Geschossflächen-Tool.*

## [1.1.0] — 2026-06-15

### Hinzugefügt
- **Variable Anrechnungs-Grenzhöhe** (kommunale Satzung, z. B. 1,50 m statt 2,30 m):
  - Neues Eingabefeld „Grenzhöhe" im VG-Modal (projektweit, Default 2,30 m,
    Bereich 0,50–3,00 m). Änderung rechnet alle gespeicherten VG-Berechnungen
    des Projekts automatisch nach.
  - Berechnung liefert zusätzlich `A_anrechenbar` (Fläche ≥ Grenzhöhe).
    Die Vollgeschoss-Beurteilung (2/3-Regel) bleibt unverändert bei 2,30 m
    nach Art. 83 Abs. 7 BayBO.
  - Querschnitt (Modal + PDF) zeigt bei abweichender Grenzhöhe eine zweite
    Linie in Teal mit eigener Schraffur für die anrechenbare Zone.
  - Anteiliger Export nutzt die anrechenbare Fläche; Aufmaßblatt, Export-Dialog,
    VG-Beurteilungsblatt und Methodik-Texte dokumentieren die verwendete
    Grenzhöhe. Bei 2,30 m bleiben alle Ausgaben wortidentisch zu v1.0.
  - Projekt-Schema: optionales `metadata.grenzhoeheAnrechnung` (Schema-Version
    bleibt 2, alte Projekte laden unverändert mit Default 2,30).
- **Rechenweg im Aufmaßprotokoll** (opt-in): Häkchen „Rechenweg anzeigen" im
  Export-Dialog ergänzt explizite Additions-Schritte der Teilflächen je Region
  und der Geschosse zur Gesamtfläche (Bürger-Nachvollziehbarkeit).
- **Rechenweg-Herleitung je Teilfläche** (Teil des Rechenweg-Häkchens):
  rechteckige Teilflächen als „Länge × Breite = Fläche" direkt unter der
  Polygon-Tabelle, unregelmäßige Flächen als Gauß-Koordinatentabelle mit
  Formelzeile auf eigenen Rechenweg-Anhangseiten (Seitenzählung läuft mit;
  manuell korrigierte Flächen: gemessener Wert hergeleitet, angesetzter
  ausgewiesen).

### Geändert
- `test.html` lädt jetzt auch `js/export.js` — die exportAnrechnung-Tests
  liefen vorher nie (Bestandslücke).
- `test.html` rendert und zählt die exportAnrechnung-Testgruppe jetzt mit —
  die Gruppe lief zwar, fehlte aber in Anzeige und Gesamtzahl (Suite zeigt
  jetzt 197 statt 168 Prüfungen).
- `vg-geometrie.js`: doppelte lokale 2,30-Konstanten zu einer Modul-Konstante
  zusammengeführt.

## [1.0.0] — 2026-05-16

Erstes stabiles Release. Solo-Dev-Tool für bayerische Bauämter.

### Hinzugefügt (Phase A8)
- Reproduzierbarer Release-Build via `npm run build-release` (Allowlist-Manifest, SHA256-Integritaetscheck, Self-Verify)
- `version.txt` im Release-ZIP-Root verhindert Update-Endlosschleife bei Erstinstallationen
- `update.ps1`: ZipSlip-Defense vor Expand-Archive (Defense-in-Depth, SHA256-Check fängt's bereits)

### Geändert
- `update.ps1`: selektives `data/`-Exclude — `data/*.example.js`-Updates kommen jetzt beim Kunden an (war: komplettes `data/` ausgeschlossen)
- `DOWNLOAD_URL` zeigt auf das öffentliche Update-Repo (war: `example.com`-Placeholder)
- VERSION von `0.1.0-dev` auf `1.0.0`

### Stand der vorigen Phasen
- A1–A5: VG-Integration (Vollgeschoss-Berechnung Art. 83 Abs. 7 BayBO)
- A6: Lizenz-Workflow mit SHA256-Whitelist auf GitHub Pages
- A7: Vorgänger-VG-Tool als archiviert markiert
- B1–B3: TypeScript-Migration via JSDoc + `tsc --checkJs`

## [0.1.0-dev] — 2026-05-12

### Hinzugefügt
- Phase-0-Skelett: Verzeichnisstruktur, klassische Scripts mit `window.GF.*`-Namespace
- Lizenzsystem aus VG-Tool übernommen, ID-Präfix auf `GF-` umgestellt
- Update-Mechanismus (`update.bat` + `update.ps1`) 1:1 aus VG-Tool
- Plan-Datei und SPEC.md angelegt
- Test-Runner (`test.html`) mit ersten Unit-Tests für `util`, `polygon`, `region`, `projekt`, `lizenz`
- Stubs für PDF-Loading, Region/Geschoss/Polygon-Verwaltung, Projekt-Speicherung, Export
- Auto-Recovery via IndexedDB (Wrapper)

### Bekannte Einschränkungen (Phase 0)
- `lib/pdf.min.js`, `lib/pdf.worker.min.js`, `lib/fflate.min.js` müssen manuell besorgt werden (`lib/README.md`)
- `GF.projekt.speichere/lade` und `GF.export.aufmassprotokoll` sind Stubs (Phase 4/5)
- Keine UI für PDF-Anzeige (Phase 1)
