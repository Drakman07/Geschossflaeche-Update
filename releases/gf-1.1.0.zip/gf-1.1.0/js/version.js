// @ts-check
// Versions- und Vertriebs-Konstanten fuer FlaechenKlar.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern: GF wird ueber alle Dateien hinweg
  // inkrementell aufgebaut.
  global.GF = global.GF || {};

  // Aktuelle Version dieses Builds.
  global.GF.VERSION = '1.1.0';

  // Build-Datum dieses Releases im Format YYYY-MM-DD.
  global.GF.BUILD_DATUM = '2026-06-15';

  // URL, die beim "Auf Updates pruefen"-Klick abgerufen wird.
  // Inhalt der Datei muss in Zeile 1 die Versionsnummer "x.y.z" enthalten.
  // Update-Repo "Geschossflaeche-Update" ist live (siehe docs/AUSLIEFERUNG.md).
  global.GF.VERSION_CHECK_URL = 'https://drakman07.github.io/Geschossflaeche-Update/version.txt';

  // URL, die im Update-Modal als "Download"-Link aufgemacht wird
  // (Fallback, falls update.bat fehlt).
  global.GF.DOWNLOAD_URL = 'https://drakman07.github.io/Geschossflaeche-Update/releases/';
})(typeof window !== 'undefined' ? window : globalThis);
