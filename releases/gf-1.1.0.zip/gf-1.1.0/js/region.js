// @ts-check
// js/region.js — Plan-Regionen + Massstabskalibrierung.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.region = GF.region || /** @type {GfRegionModule} */ ({});

  // Norm-Massstaebe in pt/m (1 m bei Massstab 1:N entspricht 1000/N mm = 1000/N * 2.834645 pt)
  GF.region.NORM_MASSSTAB = {
    '1:50':   56.692,
    '1:100':  28.346,
    '1:200':  14.173,
    '1:500':   5.669,
    '1:1000':  2.835
  };

  /**
   * @param {string} pdfId
   * @param {number} seite
   * @param {Ausschnitt} ausschnitt
   * @param {string} [bezeichnung]
   * @returns {Region}
   */
  GF.region.erzeuge = function (pdfId, seite, ausschnitt, bezeichnung) {
    return {
      id: GF.util.uuid(),
      pdfId: pdfId,
      seite: seite,
      bezeichnung: bezeichnung || '',
      geschossId: null,
      ausschnitt: ausschnitt,    // {x, y, breite, hoehe} in PDF-Koordinaten
      kalibrierung: null
    };
  };

  /**
   * ptProMeter aus zwei Punkten + Sollmass.
   * @param {Punkt} p1
   * @param {Punkt} p2
   * @param {number} sollMeter
   * @returns {number}
   */
  GF.region.berechneMassstab = function (p1, p2, sollMeter) {
    if (!isFinite(sollMeter) || sollMeter <= 0) throw new Error('Sollmass muss > 0 sein');
    var d = GF.util.abstand2D(p1, p2);
    if (d === 0) throw new Error('Punkte sind identisch (Distanz 0)');
    return d / sollMeter;
  };

  /**
   * ptProMeter aus direkt eingegebenem Massstab 1:N.
   * Gilt nur fuer masshaltige Vektor-PDFs: 1 m real = 1000/N mm auf
   * Papier, 1 mm = 72/25.4 pt (PDF-Punkt = 1/72 Zoll).
   * @param {number} n - Massstabszahl N aus "1:N", ganzzahlig >= 1
   * @returns {number}
   */
  GF.region.ptProMeterAusMassstab = function (n) {
    if (!isFinite(n) || n < 1) throw new Error('Massstab muss eine Zahl >= 1 sein');
    return 72000 / (25.4 * n);
  };

  /**
   * Prozentuale Abweichung vom naechsten Norm-Massstab.
   * @param {number} ptProMeter
   * @returns {RegionPlausibilitaet}
   */
  GF.region.plausibilitaet = function (ptProMeter) {
    var beste = null;
    var besteAbw = Infinity;
    var keys = Object.keys(GF.region.NORM_MASSSTAB);
    for (var i = 0; i < keys.length; i++) {
      var norm = GF.region.NORM_MASSSTAB[keys[i]];
      var abw = Math.abs(ptProMeter - norm) / norm * 100;
      if (abw < besteAbw) { besteAbw = abw; beste = keys[i]; }
    }
    /** @type {'plausibel' | 'hinweis' | 'warnung'} */
    var stufe;
    if (besteAbw < 0.5)      stufe = 'plausibel';
    else if (besteAbw < 3.0) stufe = 'hinweis';
    else                     stufe = 'warnung';
    return { naechsterNormMassstab: beste, abweichungProzent: besteAbw, stufe: stufe };
  };

})(typeof window !== 'undefined' ? window : globalThis);
