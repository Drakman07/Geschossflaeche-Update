// @ts-check
// js/vollgeschoss.js — Vollgeschoss-Berechnung Dachgeschoss nach Art. 83 Abs. 7 BayBO.
// Portiert aus VG-Tool v1.2.0 (identische Algorithmen). Reine Berechnungslogik (kein DOM).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  /** @type {2.30} m, lichte Hoehe fuer die Vollgeschoss-Beurteilung (Art. 83 Abs. 7 BayBO, gesetzlich fix) */
  var GRENZHOEHE = 2.30;

  /**
   * @param {number} grad
   * @returns {number}
   */
  function tanGrad(grad) {
    return Math.tan(grad * Math.PI / 180);
  }

  /** @param {number} h @returns {string} z.B. "2,30" */
  function fmtGrenz(h) {
    return h.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  /**
   * @param {Gaube[]} gauben
   * @param {number} X Eindringtiefe (m)
   * @param {string} seitenLabel
   * @param {string[]} warnungen
   * @param {number} grenz lichte Hoehe (m)
   * @returns {number}
   */
  function summeGauben(gauben, X, seitenLabel, warnungen, grenz) {
    var s = 0;
    for (var i = 0; i < gauben.length; i++) {
      var g = gauben[i];
      if (!g) continue;
      var b = +g.b || 0;
      var a = +g.a || 0;
      if (b <= 0) continue;
      if (X > 0 && a >= X) {
        warnungen.push('Gaube #' + (i + 1) + ' ' + seitenLabel
          + ': Traufabstand a (' + a.toLocaleString('de-DE') + ' m)'
          + ' ist >= Eindringtiefe X (' + X.toLocaleString('de-DE', { maximumFractionDigits: 2 }) + ' m)'
          + ' — Gaube trägt nicht zur Fläche >=' + fmtGrenz(grenz) + ' m bei.');
      }
      s += Math.max(0, b * (X - a));
    }
    return s;
  }

  /**
   * @param {VgEingaben} e
   * @param {string[]} warnungen
   * @param {number} grenz lichte Hoehe (m)
   * @returns {{X1: number, X2: number, Bm: number}}
   */
  function berechneGrenzlinien(e, warnungen, grenz) {
    var X1 = e.h_KL >= grenz ? 0 : (grenz - e.h_KL) / tanGrad(e.alpha_L);
    var X2 = e.h_KR >= grenz ? 0 : (grenz - e.h_KR) / tanGrad(e.alpha_R);
    var Bm = e.L_B - X1 - X2;
    if (Bm < 0) {
      warnungen.push('Bm rechnerisch < 0 (Kniestöcke und Dachneigungen so flach, dass sich die ' + fmtGrenz(grenz) + '-m-Linien überschneiden). Bm wurde auf 0 gesetzt.');
      Bm = 0;
    }
    return { X1: X1, X2: X2, Bm: Bm };
  }

  /**
   * @param {VgEingaben} e
   * @param {string[]} warnungen
   * @returns {{A_G: number, A_G_brutto: number}}
   */
  function berechneGrundflaeche(e, warnungen) {
    var A_G_brutto = e.L_B * e.L_L;
    if (e.A_kleiner > A_G_brutto) {
      warnungen.push('Abzug < 2,30 m (' + e.A_kleiner.toLocaleString('de-DE')
        + ' m^2) ist größer als die Gebäude-Grundfläche ('
        + A_G_brutto.toLocaleString('de-DE') + ' m^2). Eingabe prüfen.');
    }
    return { A_G: A_G_brutto - e.A_kleiner, A_G_brutto: A_G_brutto };
  }

  /**
   * @param {VgEingaben} e
   * @param {number} X1
   * @param {number} X2
   * @param {number} Bm
   * @param {string[]} warnungen
   * @param {number} grenz lichte Hoehe (m)
   * @returns {number}
   */
  function berechneFlaecheUeberGrenz(e, X1, X2, Bm, warnungen, grenz) {
    var A_rechteck = Bm * e.L_L;
    var A_Gauben_L = summeGauben(e.gauben_links  || [], X1, 'links',  warnungen, grenz);
    var A_Gauben_R = summeGauben(e.gauben_rechts || [], X2, 'rechts', warnungen, grenz);
    return A_rechteck + A_Gauben_L + A_Gauben_R - e.A_groesser;
  }

  /**
   * @param {VgEingaben} e
   * @returns {VgErgebnis}
   */
  function berechneVollgeschoss(e) {
    /** @type {string[]} */
    var warnungen = [];
    // Durchlauf 1: fix 2,30 m — Grundlage der VG-Beurteilung (BayBO), unveraendert zu v1.0.
    var grenz = berechneGrenzlinien(e, warnungen, GRENZHOEHE);
    var grund = berechneGrundflaeche(e, warnungen);
    var A_2_30 = berechneFlaecheUeberGrenz(e, grenz.X1, grenz.X2, grenz.Bm, warnungen, GRENZHOEHE);

    // A_G: bevorzugt die im gf-Tool ermittelte Polygonflaeche, sonst Rechteck-Modell.
    var A_G_geometrie = grund.A_G;
    var hatPolygonAG = typeof e.A_G_polygon === 'number' && isFinite(e.A_G_polygon) && e.A_G_polygon > 0;
    var A_G = hatPolygonAG ? e.A_G_polygon : A_G_geometrie;

    if (hatPolygonAG && A_G_geometrie > 0) {
      var abwPct = Math.abs(A_G - A_G_geometrie) / A_G_geometrie * 100;
      if (abwPct > 5) {
        warnungen.push('Polygonfläche (' + A_G.toLocaleString('de-DE', { maximumFractionDigits: 2 })
          + ' m^2) weicht um ' + abwPct.toLocaleString('de-DE', { maximumFractionDigits: 1 })
          + ' % von L_B * L_L (' + A_G_geometrie.toLocaleString('de-DE', { maximumFractionDigits: 2 })
          + ' m^2) ab. Eingaben prüfen.');
      }
    }

    if (A_2_30 > A_G) {
      warnungen.push('A_2,30 > A_G — Eingaben prüfen (Fläche mit >=2,30 m kann nicht größer als Gesamtgeschossfläche sein).');
    }

    var zweidrittel_breite  = (2 / 3) * e.L_B;
    var zweidrittel_flaeche = (2 / 3) * A_G;
    var vollgeschoss = (A_G > 0) && (A_2_30 >= zweidrittel_flaeche);

    // Durchlauf 2: variable Grenzhoehe fuer die Flaechenanrechnung (kommunale
    // Satzung, z.B. 1,50 m). Beeinflusst NUR A_anrechenbar — die VG-Beurteilung
    // oben bleibt bei 2,30 m. Bei 2,30 m kein zweiter Lauf (Werte identisch).
    var gh = (typeof e.grenzhoehe === 'number' && isFinite(e.grenzhoehe) && e.grenzhoehe > 0)
      ? e.grenzhoehe : GRENZHOEHE;
    var X1_anr = grenz.X1, X2_anr = grenz.X2, Bm_anr = grenz.Bm;
    var A_anrechenbar = A_2_30;
    if (gh !== GRENZHOEHE) {
      // Eigene Warnungs-Liste: Gauben-/Bm-Hinweise des zweiten Laufs wuerden
      // die 2,30er-Hinweise nur doppeln und werden verworfen.
      /** @type {string[]} */
      var warnungen2 = [];
      var grenzAnr = berechneGrenzlinien(e, warnungen2, gh);
      X1_anr = grenzAnr.X1;
      X2_anr = grenzAnr.X2;
      Bm_anr = grenzAnr.Bm;
      A_anrechenbar = berechneFlaecheUeberGrenz(e, X1_anr, X2_anr, Bm_anr, warnungen2, gh);
      if (A_anrechenbar > A_G) {
        warnungen.push('Anrechenbare Fläche (>=' + fmtGrenz(gh) + ' m) > A_G — Eingaben prüfen.');
      }
    }

    return {
      X1: grenz.X1,
      X2: grenz.X2,
      Bm: grenz.Bm,
      zweidrittel_breite: zweidrittel_breite,
      A_G: A_G,
      A_G_geometrie: A_G_geometrie,
      A_G_quelle: hatPolygonAG ? 'polygon' : 'geometrie',
      zweidrittel_flaeche: zweidrittel_flaeche,
      A_2_30: A_2_30,
      vollgeschoss: vollgeschoss,
      differenz: A_2_30 - zweidrittel_flaeche,
      anteil_2_30: (A_G > 0) ? (A_2_30 / A_G) : null,
      grenzhoehe: gh,
      A_anrechenbar: A_anrechenbar,
      X1_anr: X1_anr,
      X2_anr: X2_anr,
      Bm_anr: Bm_anr,
      warnungen: warnungen
    };
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.Vollgeschoss = GF.Vollgeschoss || /** @type {GfVollgeschossModule} */ ({});
  GF.Vollgeschoss.berechne = berechneVollgeschoss;
  GF.Vollgeschoss.GRENZHOEHE = GRENZHOEHE;

})(typeof window !== 'undefined' ? window : globalThis);
