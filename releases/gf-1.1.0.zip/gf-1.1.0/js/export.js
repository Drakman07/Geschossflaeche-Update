// @ts-check
// js/export.js — Aufmassprotokoll-PDF via jsPDF + Plan-Snapshot.
//
// Liefert:
//   GF.export.aufmassprotokoll(projekt, pdfsInState, optionen) -> Promise<Blob>
//
//   optionen = {
//     enthaltAufmassblatt: true|false,
//     enthaltBerechnung:   true|false,
//     demoMode:            true|false,    // diagonales Wasserzeichen
//     wappenDataUrl:       string|null    // optional, Kommunenwappen
//   }
//
// Layout: A4 hochformat, Margin 15mm, dezent farbig (Brand-Blau).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.export = GF.export || /** @type {GfExportModule} */ ({});

  // ---- Layout-Konstanten (mm) ----
  var SEITE_W = 210, SEITE_H = 297;
  var M_LEFT = 18, M_RIGHT = 18, M_TOP = 18, M_BOT = 18;
  var INHALT_W = SEITE_W - M_LEFT - M_RIGHT;

  // Farben (jsPDF: 0-255)
  var BRAND       = [0, 51, 153];
  var BRAND_HELL  = [232, 238, 248];
  var BAUHERR_BG  = [253, 246, 226];
  var GRAU_TEXT   = [102, 102, 102];
  var GRAU_LINIE  = [220, 224, 232];
  var SCHWARZ     = [26, 26, 26];
  var WARN_ORANGE = [217, 119, 6];
  var GESAMT_BG   = [0, 51, 153];
  var WEISS       = [255, 255, 255];

  /**
   * Erzeugt das Aufmassprotokoll. Liefert Promise<Blob>.
   */
  GF.export.aufmassprotokoll = function (projekt, pdfsInState, optionen) {
    if (!global.jspdf || !global.jspdf.jsPDF) {
      return Promise.reject(new Error('jsPDF nicht geladen'));
    }
    optionen = optionen || {};
    var opt = {
      enthaltAufmassblatt: optionen.enthaltAufmassblatt !== false,
      enthaltBerechnung:   optionen.enthaltBerechnung   !== false,
      enthaltKantenmasse:  optionen.enthaltKantenmasse  !== false,
      enthaltVgBlock:      optionen.enthaltVgBlock      !== false,
      // Rechenweg = explizite Additions-Schritte fuer Buerger-Nachvollziehbarkeit.
      // Opt-in (Default false), aendert Standard-Export nicht.
      enthaltRechenweg:    optionen.enthaltRechenweg === true,
      demoMode:            !!optionen.demoMode,
      wappenDataUrl:       optionen.wappenDataUrl || null,
      // Anrechnungs-Modus fuer VG-Geschosse: 'voll' (Polygonflaeche) | 'anteilig' (A_2,30)
      // Fallback 'voll' = bisheriges Verhalten.
      vgAnrechnung:        (optionen.vgAnrechnung === 'anteilig') ? 'anteilig' : 'voll'
    };

    var doc = new global.jspdf.jsPDF('p', 'mm', 'a4');

    // Plan-Snapshots vorrendern (asynchron) — VG-Diagramme werden direkt mit
    // jsPDF-Primitiven gezeichnet, kein async Vorrender noetig.
    // FlaechenKlar-Logo parallel als PNG-DataURL holen, damit das Aufmassblatt-
    // Deckblatt es einbetten kann.
    return Promise.all([
      rendereAlleRegionen(projekt, pdfsInState, opt),
      holeLogoAlsPng()
    ]).then(function (results) {
      var snapshotsByRegionId = results[0];
      var logoPng = results[1]; // null wenn Konvertierung fehlschlaegt
      return zeichneAllesIntoDoc(doc, projekt, pdfsInState, snapshotsByRegionId, opt, logoPng);
    });
  };

  // ============================================================
  // FlaechenKlar-Logo: SVG aus assets/ in eine PNG-DataURL konvertieren,
  // damit jsPDF es per addImage() ins Aufmassprotokoll einbetten kann.
  // Cache auf Modul-Ebene — pro Browser-Sitzung nur einmal konvertieren.
  // ============================================================
  var _logoPngCache = null;

  function holeLogoAlsPng() {
    if (_logoPngCache) return Promise.resolve(_logoPngCache);
    return new Promise(function (resolve) {
      var img = new Image();
      img.onload = function () {
        try {
          // Hochskaliert rendern, damit das Logo im PDF auch beim Druck
          // gestochen scharf bleibt. Faktor 4 deckt gaengige Drucker-DPI ab.
          var w = img.naturalWidth || 620;
          var h = img.naturalHeight || 160;
          var scale = 4;
          var c = document.createElement('canvas');
          c.width = w * scale;
          c.height = h * scale;
          var ctx = c.getContext('2d');
          ctx.scale(scale, scale);
          ctx.drawImage(img, 0, 0, w, h);
          _logoPngCache = c.toDataURL('image/png');
          resolve(_logoPngCache);
        } catch (e) {
          console.warn('[gf-export] Logo-Konvertierung fehlgeschlagen:', e);
          resolve(null);
        }
      };
      img.onerror = function () {
        console.warn('[gf-export] Logo nicht ladbar:', img.src);
        resolve(null);
      };
      img.src = 'assets/flaechenklar_logo.svg';
    });
  }

  /**
   * Komfort-Wrapper: prueft, ob im Projekt eine VG-Berechnung vorliegt.
   * Falls ja, oeffnet er den Anrechnungs-Dialog und ruft danach
   * GF.export.aufmassprotokoll mit dem gewaehlten Modus auf.
   * Falls nein, geht es ohne Dialog direkt durch.
   *
   * Liefert Promise<Blob|null>. null = User hat den Dialog abgebrochen.
   */
  GF.export.starteExport = function (projekt, pdfsInState, optionen) {
    optionen = optionen || {};
    var hatVg = false;
    if (projekt && Array.isArray(projekt.geschosse)) {
      for (var i = 0; i < projekt.geschosse.length; i++) {
        var g = projekt.geschosse[i];
        if (g && g.vollgeschoss && g.vollgeschoss.durchgefuehrt === true
            && g.vollgeschoss.ergebnis
            && typeof g.vollgeschoss.ergebnis.A_2_30 === 'number') {
          hatVg = true;
          break;
        }
      }
    }
    if (!hatVg || !GF.ExportDialog) {
      // Kein VG -> bisheriges Verhalten: 'voll' (Polygonsumme) ohne Dialog.
      var dirOpt = Object.assign({}, optionen);
      if (!dirOpt.vgAnrechnung) dirOpt.vgAnrechnung = 'voll';
      return GF.export.aufmassprotokoll(projekt, pdfsInState, dirOpt);
    }
    return new Promise(function (resolve, reject) {
      GF.ExportDialog.oeffne(projekt, function (modus) {
        if (modus == null) { resolve(null); return; }
        var dlgOpt = Object.assign({}, optionen, { vgAnrechnung: modus });
        GF.export.aufmassprotokoll(projekt, pdfsInState, dlgOpt).then(resolve, reject);
      });
    });
  };

  function zeichneAllesIntoDoc(doc, projekt, pdfsInState, snapshotsByRegionId, opt, logoPng) {
      console.info('[gf-export] Eingaben:', {
        geschosse: (projekt.geschosse || []).length,
        regionen:  (projekt.planRegionen || []).length,
        polygone:  (projekt.polygone || []).length,
        pdfs:      (projekt.pdfs || []).length,
        snapshots: Object.keys(snapshotsByRegionId).length,
        enthaltAufmassblatt: opt.enthaltAufmassblatt,
        enthaltBerechnung:   opt.enthaltBerechnung
      });

      var seitenZaehler = { aktuell: 0, gesamt: 0 };
      if (opt.enthaltAufmassblatt) seitenZaehler.gesamt += 1;
      if (opt.enthaltBerechnung) {
        seitenZaehler.gesamt += zaehleBerechnungSeiten(projekt, opt.enthaltVgBlock, opt.enthaltRechenweg);
      } else if (opt.enthaltVgBlock) {
        // Region-lose VG-Bloecke (Sonderfall, siehe unten) werden auch OHNE
        // Berechnungsdarstellung gezeichnet -> hier mitzaehlen, sonst stimmt
        // "Seite x / y" nicht (zaehleBerechnungSeiten lief oben nicht).
        (projekt.geschosse || []).forEach(function (g) {
          if (g.vollgeschoss && g.vollgeschoss.durchgefuehrt
              && !(projekt.planRegionen || []).some(function (rg) { return rg.geschossId === g.id; })) {
            seitenZaehler.gesamt += 1;
          }
        });
      }
      console.info('[gf-export] Erwartete Seitenzahl:', seitenZaehler.gesamt);

      var ersterSeite = true;
      if (opt.enthaltAufmassblatt) {
        seitenZaehler.aktuell++;
        zeichneAufmassblatt(doc, projekt, pdfsInState, seitenZaehler, opt, logoPng);
        ersterSeite = false;
        console.info('[gf-export] Aufmaßblatt gezeichnet, jsPDF-Pages:',
                     doc.internal.getNumberOfPages());
      }
      if (opt.enthaltBerechnung) {
        var iter = 0;
        var letztesGeschossId = null;
        gehDurchRegionen(projekt, function (geschoss, region, regionIdxImGeschoss, regionenImGeschoss) {
          iter++;
          if (!ersterSeite) doc.addPage();
          ersterSeite = false;
          seitenZaehler.aktuell++;
          zeichneBerechnungSeite(doc, projekt, pdfsInState, geschoss, region,
                                  regionIdxImGeschoss, regionenImGeschoss,
                                  snapshotsByRegionId[region.id] || null,
                                  seitenZaehler, opt);
          // Rechenweg-Anhang (opt-in): Gauss-Tabellen fuer nicht-rechteckige
          // Teilflaechen, direkt hinter der Region-Seite.
          if (opt.enthaltRechenweg) {
            var anhangPolygone = (projekt.polygone || []).filter(function (p) {
              return p.regionId === region.id;
            });
            var anhangSeiten = baueAnhangPlan(anhangPolygone,
              region.kalibrierung ? region.kalibrierung.ptProMeter : 0);
            if (anhangSeiten.length > 0) {
              zeichneRechenwegAnhang(doc, projekt, geschoss, region, anhangSeiten,
                                     seitenZaehler, opt);
            }
          }
          // VG-Block direkt nach der letzten Region eines Geschosses
          // (regionIdxImGeschoss ist 1-basiert; letzte = regionenImGeschoss)
          if (opt.enthaltVgBlock
              && regionIdxImGeschoss === regionenImGeschoss
              && geschoss.vollgeschoss && geschoss.vollgeschoss.durchgefuehrt) {
            doc.addPage();
            seitenZaehler.aktuell++;
            zeichneVollgeschossBlock(doc, projekt, geschoss, seitenZaehler, opt);
          }
          letztesGeschossId = geschoss.id;
        });
      }

      // VG-Bloecke fuer Geschosse OHNE Regionen (Sonderfall) — nach allem anhaengen
      if (opt.enthaltVgBlock) {
        (projekt.geschosse || []).forEach(function (g) {
          if (!g.vollgeschoss || !g.vollgeschoss.durchgefuehrt) return;
          var hatRegion = (projekt.planRegionen || []).some(function (r) { return r.geschossId === g.id; });
          if (hatRegion) return; // wurde schon in der Schleife behandelt
          if (!ersterSeite) doc.addPage();
          ersterSeite = false;
          seitenZaehler.aktuell++;
          zeichneVollgeschossBlock(doc, projekt, g, seitenZaehler, opt);
        });
      }

      console.info('[gf-export] Output: ' + doc.internal.getNumberOfPages() + ' Seiten gesamt.');
      return doc.output('blob');
  }

  // ============================================================
  // Helfer fuer Regionen-Iteration in Reihenfolge
  // ============================================================

  function gehDurchRegionen(projekt, callback) {
    var geschosse = (projekt.geschosse || []).slice().sort(function (a, b) {
      return (a.reihenfolge || 0) - (b.reihenfolge || 0);
    });
    geschosse.forEach(function (g) {
      var regionen = (projekt.planRegionen || []).filter(function (r) { return r.geschossId === g.id; });
      regionen.forEach(function (r, idx) { callback(g, r, idx + 1, regionen.length); });
    });
  }

  function zaehleBerechnungSeiten(projekt, mitVgBlock, mitRechenweg) {
    var n = 0;
    gehDurchRegionen(projekt, function (g, r) {
      n++;
      if (mitRechenweg) {
        var polys = (projekt.polygone || []).filter(function (p) { return p.regionId === r.id; });
        n += baueAnhangPlan(polys, r.kalibrierung ? r.kalibrierung.ptProMeter : 0).length;
      }
    });
    if (mitVgBlock) {
      (projekt.geschosse || []).forEach(function (g) {
        if (g.vollgeschoss && g.vollgeschoss.durchgefuehrt) n++;
      });
    }
    return n;
  }

  // ============================================================
  // Plan-Snapshot: rendert pro Region einen hochaufgeloesten PNG
  // ============================================================

  function rendereAlleRegionen(projekt, pdfsInState, opt) {
    if (!projekt.planRegionen || projekt.planRegionen.length === 0) return Promise.resolve({});
    var result = Object.create(null);
    var kette = Promise.resolve();
    projekt.planRegionen.forEach(function (region) {
      kette = kette.then(function () {
        var pdf = pdfsInState && pdfsInState.filter(function (p) { return p.id === region.pdfId; })[0];
        if (!pdf || !pdf.pdfDoc) return null;
        return rendereRegionSnapshot(pdf.pdfDoc, region, projekt, opt).then(function (dataUrl) {
          if (dataUrl) result[region.id] = dataUrl;
        });
      }).catch(function (e) {
        console.warn('[gf-export] Snapshot fuer Region ' + region.id + ' fehlgeschlagen:', e);
      });
    });
    return kette.then(function () { return result; });
  }

  // Rendert einen Region-Ausschnitt + Polygon-Overlay + Kantenmasse
  // auf einen Offscreen-Canvas, liefert JPEG-DataURL.
  // SCALE wird dynamisch so gewaehlt, dass die Zielgroesse ca. 2400 px Breite
  // hat (~340 DPI auf 174 mm Druckbreite — beim Reinzoomen bleiben Masse
  // lesbar). JPEG@0.90 statt PNG haelt die Datei-Groesse niedrig bei
  // gleichzeitig scharfen Linien.
  function rendereRegionSnapshot(pdfDoc, region, projekt, opt) {
    var zeigeMasse = !opt || opt.enthaltKantenmasse !== false;
    var ZIEL_PX_BREITE = 3300;       // ~480 DPI auf der Ziel-Druckbreite
    var SCALE_MIN = 1.5;             // kleine Regionen leicht supersamplen
    var SCALE_MAX = 5.0;             // Obergrenze (Speicher + Geschwindigkeit)
    var SCALE = ZIEL_PX_BREITE / Math.max(1, region.ausschnitt.breite);
    if (SCALE < SCALE_MIN) SCALE = SCALE_MIN;
    if (SCALE > SCALE_MAX) SCALE = SCALE_MAX;

    return pdfDoc.getPage(region.seite).then(function (page) {
      var viewport = page.getViewport({ scale: SCALE });
      var ax = region.ausschnitt.x * SCALE;
      var ay = region.ausschnitt.y * SCALE;
      var aw = region.ausschnitt.breite * SCALE;
      var ah = region.ausschnitt.hoehe  * SCALE;

      // Volle Seite rendern, dann Ausschnitt extrahieren
      var voll = document.createElement('canvas');
      voll.width  = Math.ceil(viewport.width);
      voll.height = Math.ceil(viewport.height);
      var ctxVoll = voll.getContext('2d');
      return page.render({ canvasContext: ctxVoll, viewport: viewport }).promise.then(function () {
        var ziel = document.createElement('canvas');
        ziel.width  = Math.max(1, Math.ceil(aw));
        ziel.height = Math.max(1, Math.ceil(ah));
        var ctx = ziel.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, ziel.width, ziel.height);
        ctx.drawImage(voll, ax, ay, aw, ah, 0, 0, ziel.width, ziel.height);

        var polygone = (projekt.polygone || []).filter(function (p) { return p.regionId === region.id; });
        var ptProMeter = region.kalibrierung && region.kalibrierung.ptProMeter;
        // Wenn Kantenmasse abgeschaltet: ptProMeter undefined uebergeben, dann
        // ueberspringt zeichnePolygonAufSnapshot den Kantenmass-Block.
        var ptForLabels = zeigeMasse ? ptProMeter : null;
        polygone.forEach(function (p) {
          zeichnePolygonAufSnapshot(ctx, p, region.ausschnitt, SCALE, ptForLabels);
        });
        // JPEG mit Quality 0.96 — Druckqualitaet auch im starken Reinzoomen
        var datenUrl = ziel.toDataURL('image/jpeg', 0.96);
        console.info('[gf-export] Snapshot Region "' + region.bezeichnung +
                     '": ' + ziel.width + 'x' + ziel.height + ' px, ' +
                     Math.round(datenUrl.length / 1024) + ' KB (base64)');
        return datenUrl;
      });
    });
  }

  function zeichnePolygonAufSnapshot(ctx, p, ausschnitt, SCALE, ptProMeter) {
    if (!p.punkte || p.punkte.length < 3) return;
    var farbe = p.farbeOverlay || '#7f8c8d';
    var deckkraft = (typeof p.deckkraft === 'number') ? p.deckkraft : 0.5;

    function pdfToSnap(pt) {
      return { x: (pt.x - ausschnitt.x) * SCALE, y: (pt.y - ausschnitt.y) * SCALE };
    }

    ctx.save();
    ctx.beginPath();
    p.punkte.forEach(function (pt, i) {
      var c = pdfToSnap(pt);
      if (i === 0) ctx.moveTo(c.x, c.y); else ctx.lineTo(c.x, c.y);
    });
    ctx.closePath();
    if (deckkraft > 0) {
      ctx.globalAlpha = deckkraft;
      ctx.fillStyle = farbe;
      ctx.fill();
      ctx.globalAlpha = 1.0;
    }
    ctx.strokeStyle = farbe;
    ctx.lineWidth = 3 * (SCALE / 3);
    ctx.stroke();

    // Polygon-Label im geometrischen Mittel
    var cx = 0, cy = 0;
    p.punkte.forEach(function (pt) {
      var c = pdfToSnap(pt);
      cx += c.x; cy += c.y;
    });
    cx /= p.punkte.length; cy /= p.punkte.length;
    var label = p.bezeichnung + ' · ' + formatZahl(p.flaecheAngesetztQM, 2) + ' m²';
    ctx.font = 'bold ' + (12 * SCALE / 1.2) + 'px Helvetica, Arial';
    var w = ctx.measureText(label).width;
    var pad = 5 * SCALE / 1.2;
    var h = 16 * SCALE / 1.2;
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(cx - w / 2 - pad, cy - h / 2, w + 2 * pad, h);
    ctx.fillStyle = farbe;
    ctx.fillText(label, cx - w / 2, cy + 4 * SCALE / 1.2);

    // Kantenmasse pro Kante
    if (ptProMeter && ptProMeter > 0) {
      var n = p.punkte.length;
      ctx.font = (10 * SCALE / 1.2) + 'px Helvetica, Arial';
      for (var i = 0; i < n; i++) {
        var a = p.punkte[i];
        var b = p.punkte[(i + 1) % n];
        var dx = b.x - a.x, dy = b.y - a.y;
        var lenM = Math.sqrt(dx * dx + dy * dy) / ptProMeter;
        if (lenM < 0.01) continue;
        var mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
        var c = pdfToSnap(mid);
        var t = formatZahl(lenM, 2) + ' m';
        var tw = ctx.measureText(t).width;
        var tp = 3 * SCALE / 1.2;
        var th = 13 * SCALE / 1.2;
        ctx.fillStyle = 'rgba(255,255,255,0.95)';
        ctx.fillRect(c.x - tw / 2 - tp, c.y - th / 2, tw + 2 * tp, th);
        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = 1 * SCALE / 1.2;
        ctx.strokeRect(c.x - tw / 2 - tp, c.y - th / 2, tw + 2 * tp, th);
        ctx.fillStyle = '#7c3a07';
        ctx.fillText(t, c.x - tw / 2, c.y + 3 * SCALE / 1.2);
      }
    }
    ctx.restore();
  }

  // ============================================================
  // Aufmassblatt — kompakte Akten-Zusammenfassung
  // ============================================================

  function zeichneAufmassblatt(doc, projekt, pdfsInState, seitenZaehler, opt, logoPng) {
    zeichneKopf(doc, projekt, opt);
    var y = M_TOP + 14;   // direkt unter Kopfzeile

    // FlaechenKlar-Logo links oben (wenn verfuegbar). Quell-SVG ist 620x160,
    // wir zeigen es ca. 60 mm breit fuer eine ruhige Aufmachung auf A4.
    if (logoPng) {
      var logoBreite = 60;
      var logoHoehe  = logoBreite * 160 / 620;
      try {
        doc.addImage(logoPng, 'PNG', M_LEFT, y - 2, logoBreite, logoHoehe);
        y += logoHoehe + 2;
      } catch (e) {
        console.warn('[gf-export] Logo-Einbettung fehlgeschlagen:', e);
      }
    }

    // Titel
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.text('Aufmaßermittlung', M_LEFT, y + 5);
    doc.setFontSize(12);
    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'normal');
    doc.text('Geschossflächen aus Bauantrag', M_LEFT, y + 11);

    // Trennlinie
    setColor(doc, 'draw', BRAND);
    doc.setLineWidth(0.5);
    doc.line(M_LEFT, y + 14, M_LEFT + INHALT_W, y + 14);
    y += 20;

    // Projektdaten-Karte (heller Grau-Hintergrund)
    y = zeichneKarte(doc, y, 'PROJEKT', [
      ['Bauvorhaben', projekt.metadata.bauvorhaben],
      ['Bauort',      adresseZusammen(projekt.metadata.bauortStrasse, projekt.metadata.bauortPLZ, projekt.metadata.bauortOrt)],
      ['Flur',        flurZusammen(projekt.metadata.flurnummer, projekt.metadata.gemarkung)],
      ['Projekt-Nr.', projekt.metadata.projektNummer],
      ['Sachbearbeiter', projekt.metadata.sachbearbeiter],
      ['Erstellt am', formatDatum(projekt.metadata.erstelltAm)]
    ], BRAND_HELL);

    y += 4;

    // Bauherr-Karte (gelbliche Toenung)
    y = zeichneKarte(doc, y, 'BAUHERR', [
      ['Name',      projekt.metadata.bauherr],
      ['Anschrift', adresseZusammen(projekt.metadata.bauherrAnschriftStrasse, projekt.metadata.bauherrAnschriftPLZ, projekt.metadata.bauherrAnschriftOrt)],
      ['PK-Nr.',    projekt.metadata.bauherrPKNr]
    ], BAUHERR_BG);

    y += 6;

    // Ermittelte Flaechen — Tabelle
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Ermittelte Flächen', M_LEFT, y);
    y += 4;

    var tabelle = sammlerFlaechenJeGeschoss(projekt, pdfsInState, opt);
    y = zeichneFlaechenTabelle(doc, y, tabelle.zeilen);
    y += 2;

    // Rechenweg (opt-in): explizite Additionskette der Geschosse -> Gesamtflaeche.
    // Auch bei nur einer Zeile anzeigen, damit das Haekchen nie wirkungslos bleibt.
    if (opt.enthaltRechenweg && tabelle.zeilen.length > 0) {
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      var gKette = 'Rechenweg:  ' + tabelle.zeilen.map(function (z) {
        return (z.bezeichnung || 'Geschoss') + ' ' + formatZahl(z.flaeche || 0, 2);
      }).join('  +  ') + '  =  ' + formatZahl(tabelle.gesamt, 2) + ' m²';
      var gZeilen = doc.splitTextToSize(gKette, INHALT_W);
      doc.text(gZeilen, M_LEFT, y + 3);
      y += gZeilen.length * 3.6 + 4;
    }

    // Gesamtsumme - großer blauer Balken
    setColor(doc, 'fill', GESAMT_BG);
    doc.rect(M_LEFT, y, INHALT_W, 14, 'F');
    setColor(doc, 'text', WEISS);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text('GESAMTFLÄCHE', M_LEFT + 6, y + 9);
    doc.setFontSize(15);
    var gesamtTxt = formatZahl(tabelle.gesamt, 2) + ' m²';
    var tw = doc.getTextWidth(gesamtTxt);
    doc.text(gesamtTxt, M_LEFT + INHALT_W - 6 - tw, y + 9);
    y += 18;

    // Zusatzinfo (optional, mehrzeilig)
    if (projekt.metadata.zusatzinfo) {
      setColor(doc, 'text', BRAND);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text('Zusatzinfo', M_LEFT, y);
      y += 5;
      setColor(doc, 'text', SCHWARZ);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      var zeilen = doc.splitTextToSize(projekt.metadata.zusatzinfo, INHALT_W);
      doc.text(zeilen, M_LEFT, y);
      y += zeilen.length * 4 + 4;
    }

    // Methodik-Hinweis bei anteiliger Anrechnung: nennt die betroffenen Geschosse.
    var anteiligeZeilen = (tabelle.zeilen || [])
      .filter(function (z) { return z.anrechnung === 'anteilig'; });
    var anteiligeNamen = anteiligeZeilen.map(function (z) { return z.bezeichnung; });
    if (anteiligeNamen.length > 0) {
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      var namen = anteiligeNamen.length === 1
        ? anteiligeNamen[0]
        : anteiligeNamen.slice(0, -1).join(', ') + ' und ' + anteiligeNamen[anteiligeNamen.length - 1];
      // Grenzhoehe ist projektweit einheitlich -> erste anteilige Zeile reicht.
      var methGh = anteiligeZeilen[0].grenzhoehe || 2.3;
      var methTxt;
      if (Math.abs(methGh - 2.3) > 1e-9) {
        methTxt = 'Anteilige Anrechnung fuer ' + namen
          + ': in die Geschossflaeche fliesst nur der Bereich mit lichter Hoehe >= '
          + formatZahl(methGh, 2) + ' m ein (kommunale Satzung; die Vollgeschoss-Beurteilung'
          + ' selbst erfolgt unveraendert mit 2,30 m nach Art. 83 Abs. 7 BayBO).'
          + ' Details siehe beigefuegtes Vollgeschoss-Beurteilungsblatt.';
      } else {
        methTxt = 'Anteilige Anrechnung fuer ' + namen
          + ': in die Geschossflaeche fliesst nur der Bereich mit lichter Hoehe >= 2,30 m ein'
          + ' (vgl. Art. 83 Abs. 7 BayBO). Details siehe beigefuegtes Vollgeschoss-Beurteilungsblatt.';
      }
      var mZeilen = doc.splitTextToSize(methTxt, INHALT_W);
      doc.text(mZeilen, M_LEFT, y);
    }

    zeichneFuss(doc, projekt, seitenZaehler);
    if (opt.demoMode) zeichneWasserzeichen(doc);
  }

  // ---- Anrechnungs-Grenzhoehe (v1.1) ----
  // Weicht die im VG-Ergebnis gespeicherte Satzungs-Grenzhoehe von 2,30 m ab?
  function grenzAbweichend(r) {
    return !!(r && typeof r.grenzhoehe === 'number' && isFinite(r.grenzhoehe)
      && Math.abs(r.grenzhoehe - 2.3) > 1e-9);
  }
  // Anrechenbare Flaeche: A_anrechenbar bei abweichender Grenzhoehe,
  // sonst A_2_30 (auch fuer alte VG-Blocks ohne das Feld).
  function anrechenbareFlaeche(r) {
    return (grenzAbweichend(r) && typeof r.A_anrechenbar === 'number' && isFinite(r.A_anrechenbar))
      ? r.A_anrechenbar : r.A_2_30;
  }

  function sammlerFlaechenJeGeschoss(projekt, pdfsInState, opt) {
    // Rueckwaerts-kompatibel zur 2-Parameter-API (tests.js ruft (projekt, opt)):
    // Wenn der zweite Parameter kein Array ist und der dritte fehlt, wird er
    // als opt interpretiert und der PDF-Lookup faellt auf projekt.pdfs zurueck.
    if (pdfsInState && !Array.isArray(pdfsInState) && opt === undefined) {
      opt = pdfsInState;
      pdfsInState = null;
    }
    opt = opt || {};
    var pdfQuelle = (Array.isArray(pdfsInState) && pdfsInState.length > 0)
      ? pdfsInState
      : (projekt.pdfs || []);
    var modusAnteilig = (opt.vgAnrechnung === 'anteilig');
    var geschosse = (projekt.geschosse || []).slice().sort(function (a, b) {
      return (a.reihenfolge || 0) - (b.reihenfolge || 0);
    });
    var zeilen = [];
    var gesamt = 0;
    geschosse.forEach(function (g, idx) {
      var polys = (projekt.polygone || []).filter(function (p) { return p.geschossId === g.id; });
      var polygonSumme = polys.reduce(function (s, p) { return s + (p.flaecheAngesetztQM || 0); }, 0);

      // Anrechnung: standardmaessig Polygonsumme. Wenn der Modus 'anteilig' ist
      // UND das Geschoss eine durchgefuehrte VG-Berechnung mit A_2_30 hat, wird
      // die anrechenbare Flaeche verwendet (A_anrechenbar bei abweichender
      // Satzungs-Grenzhoehe, sonst A_2_30).
      var flaeche = polygonSumme;
      var anrechnung = 'voll';
      var zeileGrenzhoehe = 2.3;
      if (modusAnteilig && g.vollgeschoss && g.vollgeschoss.durchgefuehrt
          && g.vollgeschoss.ergebnis
          && typeof g.vollgeschoss.ergebnis.A_2_30 === 'number'
          && isFinite(g.vollgeschoss.ergebnis.A_2_30)) {
        flaeche = anrechenbareFlaeche(g.vollgeschoss.ergebnis);
        anrechnung = 'anteilig';
        if (grenzAbweichend(g.vollgeschoss.ergebnis)) {
          zeileGrenzhoehe = g.vollgeschoss.ergebnis.grenzhoehe;
        }
      }
      gesamt += flaeche;

      // Quelle: erste Region des Geschosses zeigt PDF-Datei
      var regionen = (projekt.planRegionen || []).filter(function (r) { return r.geschossId === g.id; });
      var quellen = regionen.map(function (r) {
        var pdf = pdfQuelle.filter(function (pp) { return pp.id === r.pdfId; })[0];
        return pdf ? (pdf.dateiName || pdf.originalDateiName) : '?';
      }).filter(function (n, i, arr) { return arr.indexOf(n) === i; });
      var manuell = polys.some(function (p) { return p.manuelleKorrektur === true; });
      // VG-Beurteilung erscheint zusaetzlich auf einem eigenen Blatt;
      // bei anteiliger Anrechnung wird hier eine kleine Sub-Zeile mit Hinweis
      // und voller Grundflaeche angefuegt.
      zeilen.push({
        nr: idx + 1,
        bezeichnung: g.bezeichnung,
        quelle: quellen.join(', '),
        flaeche: flaeche,
        polygonFlaeche: polygonSumme,
        anrechnung: anrechnung,
        grenzhoehe: zeileGrenzhoehe,
        manuell: manuell
      });
    });
    return { zeilen: zeilen, gesamt: gesamt };
  }

  function zeichneFlaechenTabelle(doc, y, zeilen) {
    var rowH = 9;
    var colNr = 10;
    var colWert = 35;
    var colBez = INHALT_W - colNr - colWert;

    // Header
    setColor(doc, 'fill', BRAND);
    doc.rect(M_LEFT, y, INHALT_W, rowH, 'F');
    setColor(doc, 'text', WEISS);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Nr.', M_LEFT + 3, y + 6);
    doc.text('Geschoss', M_LEFT + colNr, y + 6);
    var wertHdr = 'Fläche';
    doc.text(wertHdr, M_LEFT + INHALT_W - 3 - doc.getTextWidth(wertHdr), y + 6);
    y += rowH;

    setColor(doc, 'text', SCHWARZ);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    zeilen.forEach(function (z, i) {
      var hatAnteilig = (z.anrechnung === 'anteilig');
      var rowExtraH = hatAnteilig ? 4 : 0;
      // Zeilenwechsel-Hintergrund
      if (i % 2 === 0) {
        setColor(doc, 'fill', [248, 250, 253]);
        doc.rect(M_LEFT, y, INHALT_W, rowH + 5 + rowExtraH, 'F');
      }
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'bold');
      doc.text(String(z.nr), M_LEFT + 3, y + 6);
      setColor(doc, 'text', SCHWARZ);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text(z.bezeichnung, M_LEFT + colNr, y + 6);

      // Wert rechts
      var wert = formatZahl(z.flaeche, 2) + ' m²';
      var ww = doc.getTextWidth(wert);
      doc.text(wert, M_LEFT + INHALT_W - 3 - ww, y + 6);

      // Quelle in kleiner Schrift
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      setColor(doc, 'text', GRAU_TEXT);
      var quellTxt = 'Plan: ' + (z.quelle || '-');
      if (z.manuell) quellTxt += '  ·  manuelle Korrektur';
      doc.text(quellTxt, M_LEFT + colNr, y + 11);

      // Sub-Zeile bei anteiliger Anrechnung: Hinweis + volle Grundflaeche
      if (hatAnteilig) {
        setColor(doc, 'text', BRAND);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        var anrTxt = 'Anrechnung: anteilig >= '
          + formatZahl(z.grenzhoehe || 2.3, 2) + ' m  ·  Grundflaeche '
          + formatZahl(z.polygonFlaeche || 0, 2) + ' m²';
        doc.text(anrTxt, M_LEFT + colNr, y + 15);
        doc.setFont('helvetica', 'normal');
      }

      doc.setFontSize(10);
      y += rowH + 5 + rowExtraH;
    });

    // Bottom-Linie
    setColor(doc, 'draw', GRAU_LINIE);
    doc.setLineWidth(0.3);
    doc.line(M_LEFT, y, M_LEFT + INHALT_W, y);
    return y;
  }

  // Karte mit Label/Wert-Paaren
  function zeichneKarte(doc, y, titel, paare, hintergrund) {
    var labelB = 38;
    var rowH = 5.5;
    var paareGefiltert = paare.filter(function (p) { return p[1] && String(p[1]).trim(); });
    if (paareGefiltert.length === 0) {
      paareGefiltert.push(['(leer)', '-']);
    }
    var hoehe = 8 + paareGefiltert.length * rowH + 4;

    // Hintergrund
    setColor(doc, 'fill', hintergrund);
    doc.roundedRect(M_LEFT, y, INHALT_W, hoehe, 2, 2, 'F');

    // Titel-Streifen oben
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(titel, M_LEFT + 4, y + 6);

    // Trenner unter Titel
    setColor(doc, 'draw', BRAND);
    doc.setLineWidth(0.4);
    doc.line(M_LEFT + 4, y + 7.5, M_LEFT + INHALT_W - 4, y + 7.5);

    var ty = y + 12;
    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    paareGefiltert.forEach(function (pa) {
      doc.text(pa[0], M_LEFT + 4, ty);
      setColor(doc, 'text', SCHWARZ);
      // Mehrzeiliger Wert? Bei Adressen wollen wir's einzeilig — Komma-getrennt
      var zeilen = doc.splitTextToSize(String(pa[1]), INHALT_W - labelB - 8);
      doc.text(zeilen, M_LEFT + labelB, ty);
      ty += rowH;
      setColor(doc, 'text', GRAU_TEXT);
    });
    return y + hoehe;
  }

  // ============================================================
  // Berechnungsdarstellung (pro Region eine Seite)
  // ============================================================

  function zeichneBerechnungSeite(doc, projekt, pdfsInState, geschoss, region, regionIdx, regionAnzahl, snapshotDataUrl, seitenZaehler, opt) {
    zeichneKopf(doc, projekt, opt);
    var y = M_TOP + 14;

    // Seitentitel
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text(geschoss.bezeichnung + (regionAnzahl > 1 ? ' · Region ' + regionIdx + ' von ' + regionAnzahl : ''),
             M_LEFT, y + 4);
    y += 7;

    // Untertitel: Plan-Datei + Massstab
    var pdfQuelleBerechnung = (Array.isArray(pdfsInState) && pdfsInState.length > 0)
      ? pdfsInState
      : (projekt.pdfs || []);
    var pdf = pdfQuelleBerechnung.filter(function (p) { return p.id === region.pdfId; })[0];
    var planName = pdf ? (pdf.dateiName || pdf.originalDateiName) : '?';
    var massstab = '';
    if (region.kalibrierung && region.kalibrierung.normMassstab) {
      massstab = ' · Maßstab ' + region.kalibrierung.normMassstab;
    } else if (region.kalibrierung && region.kalibrierung.ptProMeter) {
      massstab = ' · ' + formatZahl(region.kalibrierung.ptProMeter, 2) + ' pt/m';
    }
    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text('Quelle: ' + planName + ', Seite ' + region.seite + massstab, M_LEFT, y + 4);
    y += 8;

    // Plan-Snapshot
    var bildHoehe = 0;
    if (snapshotDataUrl) {
      var dim = sicherBildGroesse(region.ausschnitt, INHALT_W, 140);
      // Rahmen
      setColor(doc, 'draw', GRAU_LINIE);
      doc.setLineWidth(0.4);
      doc.rect(M_LEFT, y, dim.w, dim.h, 'S');
      try {
        doc.addImage(snapshotDataUrl, 'JPEG', M_LEFT, y, dim.w, dim.h);
      } catch (e) {
        console.warn('[gf-export] addImage fehlgeschlagen:', e);
        // Bild warf beim Einbetten — Platzhalter in den Rahmen, sonst stuende
        // im Rechtsdokument ein leerer Kasten ohne Hinweis.
        setColor(doc, 'text', GRAU_TEXT);
        doc.setFontSize(9);
        doc.text('(Plan-Ausschnitt konnte nicht eingebettet werden)', M_LEFT + 4, y + dim.h / 2);
      }
      bildHoehe = dim.h;
    } else {
      // Kein Snapshot — Platzhalter
      setColor(doc, 'draw', GRAU_LINIE);
      doc.setLineWidth(0.4);
      doc.rect(M_LEFT, y, INHALT_W, 50, 'S');
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFontSize(9);
      doc.text('(Plan-Ausschnitt konnte nicht erzeugt werden)', M_LEFT + 4, y + 28);
      bildHoehe = 50;
    }
    y += bildHoehe + 6;

    // Polygon-Tabelle
    var polygone = (projekt.polygone || []).filter(function (p) { return p.regionId === region.id; });
    y = zeichnePolygonTabelle(doc, y, polygone, opt,
                              region.kalibrierung ? region.kalibrierung.ptProMeter : 0);

    // Methodik-Notiz
    y += 4;
    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    doc.text('Berechnung nach Shoelace-Formel (Gauß).', M_LEFT, y);

    zeichneFuss(doc, projekt, seitenZaehler);
    if (opt.demoMode) zeichneWasserzeichen(doc);
  }

  // Rendert die Rechenweg-Anhangseiten einer Region (Gauss-Koordinatentabellen).
  // seiten stammt aus baueAnhangPlan — dieselbe Quelle wie die Seitenzaehlung.
  function zeichneRechenwegAnhang(doc, projekt, geschoss, region, seiten, seitenZaehler, opt) {
    var ptProMeter = region.kalibrierung ? region.kalibrierung.ptProMeter : 0;
    seiten.forEach(function (abschnitte) {
      doc.addPage();
      seitenZaehler.aktuell++;
      zeichneKopf(doc, projekt, opt);
      var y = M_TOP + 14;
      setColor(doc, 'text', BRAND);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text('Rechenweg-Anhang - ' + geschoss.bezeichnung, M_LEFT, y + 4);
      y += 10;
      abschnitte.forEach(function (a) {
        var g = baueGaussZeilen(a.polygon.punkte, ptProMeter);
        if (!g) {
          setColor(doc, 'text', GRAU_TEXT);
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(9);
          doc.text((a.polygon.bezeichnung || ('Teilfläche ' + (a.index + 1)))
                   + ': Koordinaten nicht verfügbar (keine Kalibrierung).', M_LEFT, y + 3.2);
          y += 6;
          return;
        }
        var name = a.polygon.bezeichnung || ('Teilfläche ' + (a.index + 1));
        doc.setFontSize(9);
        if (a.mitKopf) {
          setColor(doc, 'text', SCHWARZ);
          doc.setFont('helvetica', 'bold');
          doc.text(name + ' - Gauß\'sche Flächenformel aus den Eckpunkten:', M_LEFT, y + 3.2);
          y += 4.5;
          setColor(doc, 'text', GRAU_TEXT);
          doc.setFont('helvetica', 'normal');
          doc.text('Pkt', M_LEFT + 6, y + 3.2);
          doc.text('x [m]', M_LEFT + 30, y + 3.2);
          doc.text('y [m]', M_LEFT + 50, y + 3.2);
          y += 4;
        } else {
          setColor(doc, 'text', GRAU_TEXT);
          doc.setFont('helvetica', 'italic');
          doc.text('(Fortsetzung ' + name + ')', M_LEFT, y + 3.2);
          y += 4.5;
          doc.setFont('helvetica', 'normal');
        }
        setColor(doc, 'text', SCHWARZ);
        for (var i = a.vonPunkt; i < a.bisPunkt; i++) {
          var k = g.koordinaten[i];
          var xs = formatZahl(k.x, 2), ys = formatZahl(k.y, 2);
          doc.text(String(i + 1), M_LEFT + 6, y + 3.2);
          doc.text(xs, M_LEFT + 40 - doc.getTextWidth(xs), y + 3.2);
          doc.text(ys, M_LEFT + 60 - doc.getTextWidth(ys), y + 3.2);
          y += 4;
        }
        if (a.mitFormel) {
          setColor(doc, 'text', BRAND);
          doc.setFont('helvetica', 'bold');
          // Nur WinAnsi-Zeichen (jsPDF-Standardfont): "Summe(...)" statt Sigma,
          // ASCII-Minus statt U+2212 — sonst kippt jsPDF den String in UTF-16
          // und der Viewer zeigt Zeichensalat.
          doc.text('A = ½ · |Summe(xi·yi+1 - xi+1·yi)| = ½ · ' + formatZahl(g.kreuzsumme, 2)
                   + ' = ' + formatZahl(g.flaeche, 2) + ' m²', M_LEFT + 6, y + 3.6);
          y += 5;
          if (a.polygon.manuelleKorrektur) {
            setColor(doc, 'text', WARN_ORANGE);
            doc.setFont('helvetica', 'italic');
            doc.setFontSize(8);
            doc.text('gemessen; manuell angesetzt '
                     + formatZahl(a.polygon.flaecheAngesetztQM, 2) + ' m²', M_LEFT + 6, y + 3.2);
            y += 4;
          }
          doc.setFont('helvetica', 'normal');
          y += 2;
        }
      });
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(7.5);
      doc.text('Koordinaten auf cm gerundet; die Flächenberechnung erfolgt intern mit voller Genauigkeit.',
               M_LEFT, SEITE_H - M_BOT - 8);
      zeichneFuss(doc, projekt, seitenZaehler);
      if (opt.demoMode) zeichneWasserzeichen(doc);
    });
  }

  function sicherBildGroesse(ausschnitt, maxW, maxH) {
    // Originalverhaeltnis aus PDF-Pt
    var ratio = ausschnitt.breite / ausschnitt.hoehe;
    var w = maxW;
    var h = w / ratio;
    if (h > maxH) {
      h = maxH;
      w = h * ratio;
    }
    return { w: w, h: h };
  }

  function zeichnePolygonTabelle(doc, y, polygone, opt, ptProMeter) {
    var rowH = 7;
    // Header
    setColor(doc, 'fill', BRAND);
    doc.rect(M_LEFT, y, INHALT_W, rowH, 'F');
    setColor(doc, 'text', WEISS);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('Bezeichnung', M_LEFT + 3, y + 5);
    var wertHdr = 'Fläche';
    doc.text(wertHdr, M_LEFT + INHALT_W - 3 - doc.getTextWidth(wertHdr), y + 5);
    y += rowH;

    if (polygone.length === 0) {
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.text('(keine Polygone in dieser Region)', M_LEFT + 3, y + 5);
      return y + rowH;
    }

    setColor(doc, 'text', SCHWARZ);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    var summe = 0;
    polygone.forEach(function (p, i) {
      var rowExtra = p.manuelleKorrektur ? 6 : 0;
      if (i % 2 === 0) {
        setColor(doc, 'fill', [248, 250, 253]);
        doc.rect(M_LEFT, y, INHALT_W, rowH + rowExtra, 'F');
      }
      // Farbschwatch links als Indikator
      var farbe = hexZuRgb(p.farbeOverlay || '#7f8c8d');
      setColor(doc, 'fill', farbe);
      doc.rect(M_LEFT + 1.5, y + 1.5, 2, rowH - 3, 'F');

      setColor(doc, 'text', SCHWARZ);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text(p.bezeichnung, M_LEFT + 6, y + 5);
      var wert = formatZahl(p.flaecheAngesetztQM, 2) + ' m²';
      var ww = doc.getTextWidth(wert);
      doc.text(wert, M_LEFT + INHALT_W - 3 - ww, y + 5);
      summe += p.flaecheAngesetztQM || 0;

      if (p.manuelleKorrektur) {
        setColor(doc, 'text', WARN_ORANGE);
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8);
        var gemessen = formatZahl(p.flaecheGemessenQM, 2);
        var grund = (p.korrekturKommentar || '').replace(/\s+/g, ' ').trim();
        var hinweis = 'manuell angesetzt (gemessen ' + gemessen + ' m²)' + (grund ? ' - ' + grund : '');
        var zeilen = doc.splitTextToSize(hinweis, INHALT_W - 8);
        doc.text(zeilen, M_LEFT + 6, y + 10);
        doc.setFontSize(10);
      }
      y += rowH + rowExtra;
    });

    // Herleitung je Teilflaeche (opt-in): Rechtecke als L×B-Zeile,
    // unregelmaessige Formen verweisen auf den Rechenweg-Anhang.
    if (opt && opt.enthaltRechenweg && polygone.length > 0) {
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      polygone.forEach(function (p, i) {
        var txt = (p.bezeichnung || ('Teilfläche ' + (i + 1))) + ':  '
                + baueHerleitungsText(p, ptProMeter);
        var tz = doc.splitTextToSize(txt, INHALT_W - 9);
        doc.text(tz, M_LEFT + 6, y + 4);
        y += tz.length * 3.6 + 1.2;
      });
      y += 1;
    }

    // Rechenweg (opt-in): explizite Additionskette der Teilflaechen.
    // Auch bei nur einem Polygon anzeigen (baueSummenkette gibt dann nur die Summe).
    if (opt && opt.enthaltRechenweg && polygone.length > 0) {
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      var rwWerte = polygone.map(function (p) { return p.flaecheAngesetztQM || 0; });
      var rwZeilen = doc.splitTextToSize('Rechenweg:  ' + baueSummenkette(rwWerte, summe), INHALT_W - 9);
      doc.text(rwZeilen, M_LEFT + 6, y + 4);
      y += rwZeilen.length * 3.6 + 2;
    }

    // Zwischensumme
    setColor(doc, 'draw', GRAU_LINIE);
    doc.setLineWidth(0.4);
    doc.line(M_LEFT, y, M_LEFT + INHALT_W, y);
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Zwischensumme', M_LEFT + 6, y + 5);
    var st = formatZahl(summe, 2) + ' m²';
    var sw = doc.getTextWidth(st);
    doc.text(st, M_LEFT + INHALT_W - 3 - sw, y + 5);

    return y + rowH;
  }

  // ============================================================
  // Kopfzeile / Fusszeile / Wasserzeichen
  // ============================================================

  function zeichneKopf(doc, projekt, opt) {
    var meta = projekt.metadata || {};
    var y = M_TOP - 8;

    // Wappen links
    if (opt.wappenDataUrl) {
      try {
        doc.addImage(opt.wappenDataUrl, 'PNG', M_LEFT, y - 2, 12, 12);
      } catch (e) { /* still */ }
    }

    // Kommunenname
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(meta.kommune || '', M_LEFT + (opt.wappenDataUrl ? 14 : 0), y + 4);

    // Rechts: Projekt-Nr. + Name
    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    var rechts = [];
    if (meta.projektNummer) rechts.push('Projekt-Nr. ' + meta.projektNummer);
    if (meta.projektName)   rechts.push(meta.projektName);
    var rTxt = rechts.join(' · ');
    if (rTxt) {
      doc.text(rTxt, M_LEFT + INHALT_W - doc.getTextWidth(rTxt), y + 4);
    }

    // Trennlinie
    setColor(doc, 'draw', BRAND);
    doc.setLineWidth(0.3);
    doc.line(M_LEFT, y + 8, M_LEFT + INHALT_W, y + 8);
  }

  function zeichneFuss(doc, projekt, seitenZaehler) {
    var meta = projekt.metadata || {};
    var y = SEITE_H - M_BOT + 6;
    setColor(doc, 'draw', GRAU_LINIE);
    doc.setLineWidth(0.3);
    doc.line(M_LEFT, y - 2, M_LEFT + INHALT_W, y - 2);

    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);

    var jetzt = new Date();
    var d = jetzt.toLocaleDateString('de-DE') + ' ' + jetzt.toLocaleTimeString('de-DE', { hour:'2-digit', minute:'2-digit' });
    var tool = 'FlächenKlar' + (GF.VERSION ? ' v' + GF.VERSION : '');
    doc.text(d, M_LEFT, y + 3);
    doc.text(tool, M_LEFT + INHALT_W / 2 - doc.getTextWidth(tool) / 2, y + 3);
    var pg = 'Seite ' + seitenZaehler.aktuell + ' / ' + seitenZaehler.gesamt;
    doc.text(pg, M_LEFT + INHALT_W - doc.getTextWidth(pg), y + 3);

    if (meta.bauherr) {
      var bz = (meta.projektName || '') + (meta.bauherr ? ' · ' + meta.bauherr : '');
      doc.setFontSize(7);
      doc.text(bz, M_LEFT, y + 7);
    }
  }

  // ============================================================
  // Vollgeschoss-Block — Diagramme rendern + Seite zeichnen
  // ============================================================

  /* ----- Direkte jsPDF-Vektor-Zeichnung der VG-Diagramme -----
   * Portiert aus VG-Tool js/pdf.js, robust gegen file:// und ohne
   * SVG-zu-Image-Konvertierung. Verbraucht GF.Vollgeschoss.geometrie.*
   * direkt (Meter-Koordinaten).
   */

  function vgFmtKurz(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '-';
    // Pre-Round: Konsistenz mit formatZahlDE/formatZahl (5-auf deterministisch).
    var gerundet = Math.round(n * 100) / 100;
    return gerundet.toLocaleString('de-DE', { maximumFractionDigits: 2, minimumFractionDigits: 2 });
  }

  // C-Konstanten (RGB-Tripel)
  var C_VG_SUCCESS    = [21, 128, 61];
  var C_VG_SUCCESS_BG = [220, 252, 231];
  var C_VG_DANGER     = [185, 28, 28];
  var C_VG_WARN       = [180, 83, 9];
  var C_VG_SOFT       = [75, 85, 99];
  var C_VG_BORDER2    = [209, 213, 219];
  var C_VG_FLAECHE_BG = [243, 244, 246];
  var C_VG_GAUBE_FILL = [220, 178, 130];
  // Anrechnungs-Grenzhoehe (v1.1): Brand-Teal fuer zweite Linie + Schraffur
  var C_VG_ANR        = [30, 165, 150];
  var C_VG_ANR_BG     = [223, 243, 240];

  function vgQuerschnitt(doc, dx, dy, dw, dh, q) {
    var maxX = q.L_B || 1;
    var maxY = q.hoeheGesamt + 0.5;
    var padL = 12, padR = 12, padT = 6, padB = 14;
    var innerW = dw - padL - padR;
    var innerH = dh - padT - padB;
    var sx = innerW / maxX, sy = innerH / maxY;
    var s = Math.min(sx, sy);
    var drawW = maxX * s, drawH = maxY * s;
    var ox = dx + padL + (innerW - drawW) / 2;
    var oy = dy + padT + drawH;

    function P(p) { return [ox + p.x * s, oy - p.y * s]; }

    // Bodenlinie
    setColor(doc, 'draw', C_VG_BORDER2);
    doc.setLineWidth(0.2);
    doc.line(dx + padL - 4, oy + 0.3, dx + dw - padR + 4, oy + 0.3);

    // Aussenkontur
    var k = q.konturAussen.map(P);
    var deltas = [];
    for (var i = 1; i < k.length; i++) {
      deltas.push([k[i][0] - k[i-1][0], k[i][1] - k[i-1][1]]);
    }
    setColor(doc, 'fill', C_VG_FLAECHE_BG);
    setColor(doc, 'draw', C_VG_SOFT);
    doc.setLineWidth(0.4);
    doc.lines(deltas, k[0][0], k[0][1], [1, 1], 'FD', true);

    // Anrechnungs-Zone bei abweichender Satzungs-Grenzhoehe (v1.1):
    // Teal-Schraffur ZUERST, damit die gruene VG-Zone darueber sichtbar bleibt.
    if (q.anrechnung && q.anrechnung.hochpolygon && q.anrechnung.hochpolygon.length >= 3) {
      var ap = q.anrechnung.hochpolygon.map(P);
      var ad = [];
      for (var ja = 1; ja < ap.length; ja++) {
        ad.push([ap[ja][0] - ap[ja-1][0], ap[ja][1] - ap[ja-1][1]]);
      }
      setColor(doc, 'fill', C_VG_ANR_BG);
      setColor(doc, 'draw', C_VG_ANR);
      doc.setLineWidth(0.3);
      doc.lines(ad, ap[0][0], ap[0][1], [1, 1], 'FD', true);
    }

    // Schraffur >= 2,30 m
    if (q.hochpolygon && q.hochpolygon.length >= 3) {
      var hp = q.hochpolygon.map(P);
      var hd = [];
      for (var j = 1; j < hp.length; j++) {
        hd.push([hp[j][0] - hp[j-1][0], hp[j][1] - hp[j-1][1]]);
      }
      setColor(doc, 'fill', C_VG_SUCCESS_BG);
      setColor(doc, 'draw', C_VG_SUCCESS);
      doc.setLineWidth(0.3);
      doc.lines(hd, hp[0][0], hp[0][1], [1, 1], 'FD', true);
    }

    // 2,30-Linie gestrichelt
    var yG = oy - q.grenzhoehe * s;
    setColor(doc, 'draw', C_VG_DANGER);
    doc.setLineWidth(0.3);
    if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([1.2, 0.9], 0);
    doc.line(ox - 2, yG, ox + drawW + 2, yG);
    if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([], 0);
    setColor(doc, 'text', C_VG_DANGER);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.text('2,30 m', ox + drawW + 1, yG - 0.5);

    // Anrechnungs-Grenzlinie (Teal, gestrichelt) + Label, nur bei Abweichung
    if (q.anrechnung) {
      var yA = oy - q.anrechnung.grenzhoehe * s;
      setColor(doc, 'draw', C_VG_ANR);
      doc.setLineWidth(0.3);
      if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([1.2, 0.9], 0);
      doc.line(ox - 2, yA, ox + drawW + 2, yA);
      if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([], 0);
      setColor(doc, 'text', C_VG_ANR);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.text(vgFmtKurz(q.anrechnung.grenzhoehe) + ' m', ox + 1, yA - 0.5);
    }

    // Tracking-Linien X1/X2
    setColor(doc, 'draw', [156, 163, 175]);
    doc.setLineWidth(0.2);
    if (q.X1 > 0) { var xX1 = ox + q.X1 * s; doc.line(xX1, oy, xX1, yG); }
    if (q.X2 > 0) { var xX2r = ox + (q.L_B - q.X2) * s; doc.line(xX2r, oy, xX2r, yG); }

    // Bm-Pfeil
    var ah = 0.7;
    if (q.Bm > 0 && q.X1 + q.X2 < q.L_B) {
      var xa = ox + q.X1 * s;
      var xb = ox + (q.L_B - q.X2) * s;
      var ybm = yG - 1.8;
      setColor(doc, 'draw', C_VG_SUCCESS);
      setColor(doc, 'fill', C_VG_SUCCESS);
      doc.setLineWidth(0.4);
      doc.line(xa, ybm, xb, ybm);
      doc.lines([[1, ah], [-1, -ah], [0, -ah], [1, ah]], xa, ybm, [1, 1], 'F', true);
      doc.lines([[-1, ah], [1, -ah], [0, -ah], [-1, ah]], xb, ybm, [1, 1], 'F', true);
      setColor(doc, 'text', C_VG_SUCCESS);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.text(vgFmtKurz(q.Bm) + ' m', (xa + xb) / 2, ybm - 0.8, { align: 'center' });
    }

    // X1/X2-Pfeile
    var yX12 = oy + 3.0;
    setColor(doc, 'draw', C_VG_DANGER);
    setColor(doc, 'fill', C_VG_DANGER);
    setColor(doc, 'text', C_VG_DANGER);
    doc.setLineWidth(0.4);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    if (q.X1 > 0) {
      var xa1 = ox, xb1 = ox + q.X1 * s;
      doc.line(xa1, yX12, xb1, yX12);
      doc.lines([[1, ah], [-1, -ah], [0, -ah], [1, ah]], xa1, yX12, [1, 1], 'F', true);
      doc.lines([[-1, ah], [1, -ah], [0, -ah], [-1, ah]], xb1, yX12, [1, 1], 'F', true);
      doc.text(vgFmtKurz(q.X1) + ' m', (xa1 + xb1) / 2, yX12 + 2.8, { align: 'center' });
    }
    if (q.X2 > 0) {
      var xa2 = ox + (q.L_B - q.X2) * s;
      var xb2 = ox + drawW;
      doc.line(xa2, yX12, xb2, yX12);
      doc.lines([[1, ah], [-1, -ah], [0, -ah], [1, ah]], xa2, yX12, [1, 1], 'F', true);
      doc.lines([[-1, ah], [1, -ah], [0, -ah], [-1, ah]], xb2, yX12, [1, 1], 'F', true);
      doc.text(vgFmtKurz(q.X2) + ' m', (xa2 + xb2) / 2, yX12 + 2.8, { align: 'center' });
    }

    // Maßangaben: Breite (unten), Kniestock-Hoehen (seitlich), Dachneigungen (Dachflaechen)
    setColor(doc, 'text', C_VG_SOFT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.text(vgFmtKurz(q.L_B) + ' m', ox + drawW / 2, oy + 11.5, { align: 'center' });
    doc.text(vgFmtKurz(q.h_KL) + ' m', ox - 0.8, oy - q.h_KL * s / 2, { align: 'right', baseline: 'middle' });
    doc.text(vgFmtKurz(q.h_KR) + ' m', ox + drawW + 0.8, oy - q.h_KR * s / 2, { align: 'left', baseline: 'middle' });
    // Dachneigungen jeweils mittig auf der linken/rechten Dachflaeche
    var dachLx = ox + (q.xFirst * s) / 2;
    var dachLy = (oy - q.h_KL * s + (oy - q.firstHoehe * s)) / 2 - 0.8;
    doc.text(vgFmtKurz(q.alpha_L).replace(',00','') + '°', dachLx, dachLy, { align: 'center' });
    var dachRx = ox + q.xFirst * s + (drawW - q.xFirst * s) / 2;
    var dachRy = (oy - q.h_KR * s + (oy - q.firstHoehe * s)) / 2 - 0.8;
    doc.text(vgFmtKurz(q.alpha_R).replace(',00','') + '°', dachRx, dachRy, { align: 'center' });
  }

  function vgGrundriss(doc, dx, dy, dw, dh, g) {
    var maxX = g.L_L || 1, maxY = g.L_B || 1;
    var padL = 12, padR = 18, padT = 4, padB = 8;
    var innerW = dw - padL - padR, innerH = dh - padT - padB;
    var sx = innerW / maxX, sy = innerH / maxY;
    var s = Math.min(sx, sy);
    var drawW = maxX * s, drawH = maxY * s;
    var ox = dx + padL + (innerW - drawW) / 2;
    var oy = dy + padT;

    setColor(doc, 'fill', C_VG_SUCCESS_BG);
    doc.rect(ox, oy, drawW, drawH, 'F');

    if (g.X1 > 0) {
      setColor(doc, 'fill', C_VG_FLAECHE_BG);
      doc.rect(ox, oy, drawW, g.X1 * s, 'F');
      setColor(doc, 'draw', C_VG_DANGER);
      doc.setLineWidth(0.3);
      if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([1.2, 0.9], 0);
      doc.line(ox, oy + g.X1 * s, ox + drawW, oy + g.X1 * s);
      if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([], 0);
    }
    if (g.X2 > 0) {
      setColor(doc, 'fill', C_VG_FLAECHE_BG);
      doc.rect(ox, oy + drawH - g.X2 * s, drawW, g.X2 * s, 'F');
      setColor(doc, 'draw', C_VG_DANGER);
      doc.setLineWidth(0.3);
      if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([1.2, 0.9], 0);
      doc.line(ox, oy + drawH - g.X2 * s, ox + drawW, oy + drawH - g.X2 * s);
      if (typeof doc.setLineDashPattern === 'function') doc.setLineDashPattern([], 0);
    }

    setColor(doc, 'draw', C_VG_SOFT);
    doc.setLineWidth(0.5);
    doc.rect(ox, oy, drawW, drawH);

    function zeichneListe(liste, oben) {
      for (var i = 0; i < liste.length; i++) {
        var gp = liste[i];
        var gx = ox + gp.ortgang * s;
        var gw = gp.b * s;
        var gy, gh;
        if (oben) {
          gy = oy + gp.a * s;
          gh = Math.max(2, gp.eingedrungen * s);
        } else {
          gh = Math.max(2, gp.eingedrungen * s);
          gy = oy + drawH - gp.a * s - gh;
        }
        setColor(doc, 'fill', C_VG_GAUBE_FILL);
        setColor(doc, 'draw', C_VG_WARN);
        doc.setLineWidth(0.3);
        doc.rect(gx, gy, gw, gh, 'FD');
        // Labels AUSSERHALB des Aussenrahmens: oben -> oberhalb der Bauplanflaeche,
        // unten -> unterhalb. Erste Zeile: G-Nummer fett. Zweite Zeile: b × a.
        setColor(doc, 'text', [124, 58, 10]);
        var basisY = oben ? oy - 4.5 : oy + drawH + 4.5;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(6);
        doc.text('G' + (i + 1), gx + gw / 2, basisY, { align: 'center' });
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(5);
        var detailY = oben ? basisY - 2.8 : basisY + 2.8;
        doc.text(vgFmtKurz(gp.b) + ' x ' + vgFmtKurz(gp.a) + ' m', gx + gw / 2, detailY, { align: 'center' });
      }
    }
    zeichneListe(g.gauben_links,  true);
    zeichneListe(g.gauben_rechts, false);

    setColor(doc, 'text', C_VG_SOFT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text(vgFmtKurz(g.L_L) + ' m', ox + drawW / 2, dy + dh - 1.5, { align: 'center' });
    doc.text(vgFmtKurz(g.L_B) + ' m', ox - 1.5, oy + drawH / 2, { align: 'right', baseline: 'middle' });
    if (g.X1 > 0) {
      setColor(doc, 'text', C_VG_DANGER);
      doc.setFontSize(6);
      doc.text(vgFmtKurz(g.X1) + ' m', ox + drawW + 1, oy + g.X1 * s / 2, { baseline: 'middle' });
    }
    if (g.X2 > 0) {
      setColor(doc, 'text', C_VG_DANGER);
      doc.setFontSize(6);
      doc.text(vgFmtKurz(g.X2) + ' m', ox + drawW + 1, oy + drawH - g.X2 * s / 2, { baseline: 'middle' });
    }
  }

  function vgAufriss(doc, dx, dy, dw, dh, a) {
    var maxX = a.L_L || 1;
    var maxY = (a.firstHoehe || a.h_K || 1) + 0.5;
    var padL = 8, padR = 8, padT = 4, padB = 8;
    var innerW = dw - padL - padR, innerH = dh - padT - padB;
    var sx = innerW / maxX, sy = innerH / maxY;
    var s = Math.min(sx, sy);
    var drawW = maxX * s, drawH = maxY * s;
    var ox = dx + padL + (innerW - drawW) / 2;
    var oy = dy + padT + drawH;

    setColor(doc, 'draw', C_VG_BORDER2);
    doc.setLineWidth(0.2);
    doc.line(ox - 4, oy + 0.3, ox + drawW + 4, oy + 0.3);

    setColor(doc, 'fill', C_VG_FLAECHE_BG);
    setColor(doc, 'draw', C_VG_SOFT);
    doc.setLineWidth(0.4);
    doc.rect(ox, oy - a.h_K * s, drawW, a.h_K * s, 'FD');

    setColor(doc, 'draw', C_VG_SOFT);
    doc.setLineWidth(0.4);
    doc.line(ox, oy - a.firstHoehe * s, ox + drawW, oy - a.firstHoehe * s);
    setColor(doc, 'draw', [156, 163, 175]);
    doc.setLineWidth(0.3);
    doc.line(ox, oy - a.h_K * s, ox + 5, oy - a.firstHoehe * s);
    doc.line(ox + drawW, oy - a.h_K * s, ox + drawW - 5, oy - a.firstHoehe * s);

    a.gauben.forEach(function (gp, idx) {
      var gx = ox + gp.ortgang * s;
      var gw = gp.b * s;
      var gh = gp.dachhoehe * s;
      var gy = oy - (gp.sitzhoehe + gp.dachhoehe) * s;
      setColor(doc, 'fill', C_VG_GAUBE_FILL);
      setColor(doc, 'draw', C_VG_WARN);
      doc.setLineWidth(0.3);
      doc.rect(gx, gy, gw, gh, 'FD');
      // Label: G-Nummer fett oben, Breite klein darunter
      setColor(doc, 'text', [124, 58, 10]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6);
      doc.text('G' + (idx + 1), gx + gw / 2, gy - 3.5, { align: 'center' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(5);
      doc.text(vgFmtKurz(gp.b) + ' m', gx + gw / 2, gy - 0.5, { align: 'center' });
    });

    setColor(doc, 'text', C_VG_SOFT);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.text((a.seite === 'links' ? 'Linke Seite' : 'Rechte Seite') + '  ·  ' + vgFmtKurz(a.L_L) + ' m',
             ox + drawW / 2, dy + dh - 1.5, { align: 'center' });
    doc.text(vgFmtKurz(a.h_K) + ' m', ox - 1, oy - a.h_K * s / 2, { align: 'right', baseline: 'middle' });
    doc.text(vgFmtKurz(a.alpha).replace(',00','') + '°',
             ox + drawW - 1, oy - a.firstHoehe * s - 1, { align: 'right' });
  }

  /**
   * Zeichnet eine komplette VG-Beurteilungs-Seite fuer ein Geschoss.
   * Diagramme werden direkt mit jsPDF-Primitiven gezeichnet (Vektor).
   */
  function zeichneVollgeschossBlock(doc, projekt, geschoss, seitenZaehler, opt) {
    var vg = geschoss.vollgeschoss;
    if (!vg) return;
    var e = vg.eingaben || {};
    var r = vg.ergebnis || {};
    var geom = global.GF && global.GF.Vollgeschoss && global.GF.Vollgeschoss.geometrie;

    zeichneKopf(doc, projekt, opt);
    var y = M_TOP + 22;

    // Titel-Band
    setColor(doc, 'fill', BRAND);
    doc.rect(M_LEFT, y, INHALT_W, 10, 'F');
    setColor(doc, 'text', WEISS);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('Vollgeschoss-Beurteilung - ' + (geschoss.bezeichnung || ''), M_LEFT + 4, y + 7);
    setColor(doc, 'text', WEISS);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    var rechts = 'Art. 83 Abs. 7 BayBO';
    doc.text(rechts, M_LEFT + INHALT_W - 4 - doc.getTextWidth(rechts), y + 7);
    y += 14;

    // Eingaben-Block
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Eingaben (aus Bauantrag)', M_LEFT, y);
    y += 5;
    setColor(doc, 'text', SCHWARZ);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);

    var spalteLB = M_LEFT;
    var spalteLW = INHALT_W / 2;
    var abweichend = grenzAbweichend(r);
    // Bei abweichender Grenzhoehe + vollem Unterblock (>=2 Warnungen oder Kommentar)
    // die Diagramme staerker verkleinern, damit Methodik/Kommentar sicher ueber dem
    // Fuss bleiben (sonst Ueberlappung — das Layout-Budget der VG-Seite ist dann eng).
    var engBudget = abweichend && (((r.warnungen || []).length >= 2) || !!(vg.kommentar && vg.kommentar.trim()));
    var zRows = [
      ['Gebäude', 'L_B = ' + formatM(e.L_B) + ' · L_L = ' + formatM(e.L_L)],
      ['Kniestöcke', 'h_KL = ' + formatM(e.h_KL) + ' · h_KR = ' + formatM(e.h_KR)],
      ['Dachneigungen', 'Alpha L = ' + formatGrad(e.alpha_L) + ' · Alpha R = ' + formatGrad(e.alpha_R)],
      ['Gauben links', formatGauben(e.gauben_links)],
      ['Gauben rechts', formatGauben(e.gauben_rechts)],
      ['Abzüge', 'A_kleiner = ' + formatQM(e.A_kleiner) + ' · A_größer = ' + formatQM(e.A_groesser)]
    ];
    if (abweichend) {
      zRows.push(['Grenzhöhe', formatM(r.grenzhoehe) + ' (Anrechnung lt. Satzung)']);
    }
    zRows.forEach(function (row) {
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'bold');
      doc.text(row[0] + ':', spalteLB, y);
      setColor(doc, 'text', SCHWARZ);
      doc.setFont('helvetica', 'normal');
      doc.text(row[1], spalteLB + 32, y);
      y += 5;
    });
    y += 4;

    // Diagramme direkt mit jsPDF-Primitiven (Vektor, keine SVG-Konvertierung)
    var diagW = (INHALT_W - 4) / 2;
    // Hoehe leicht reduziert (240->215), damit auf der VG-Seite mit
    // Anrechenbare-Zeile (abweichende Grenzhoehe) Tabelle + Methodik sicher
    // ueber den Fuss passen.
    var diagH = diagW * ((engBudget ? 172 : abweichend ? 195 : 215) / 400);

    if (geom) {
      try {
        bildRahmen(doc, M_LEFT, y, diagW, diagH);
        labelOben(doc, 'Grundriss (Draufsicht)', M_LEFT + 2, y - 1);
        vgGrundriss(doc, M_LEFT, y, diagW, diagH, geom.grundriss(e, r));
      } catch (ex) { console.warn('[gf-export] Grundriss fehlgeschlagen:', ex); }
      try {
        bildRahmen(doc, M_LEFT + diagW + 4, y, diagW, diagH);
        var qsLabel = abweichend
          ? 'Querschnitt mit 2,30-m- und ' + formatZahl(r.grenzhoehe, 2) + '-m-Linie'
          : 'Querschnitt mit 2,30-m-Linie';
        labelOben(doc, qsLabel, M_LEFT + diagW + 4 + 2, y - 1);
        vgQuerschnitt(doc, M_LEFT + diagW + 4, y, diagW, diagH, geom.querschnitt(e, r));
      } catch (ex) { console.warn('[gf-export] Querschnitt fehlgeschlagen:', ex); }
    }
    y += diagH + 6;

    var aufW = (INHALT_W - 4) / 2;
    var aufH = aufW * ((engBudget ? 142 : abweichend ? 162 : 180) / 400);
    if (geom) {
      try {
        bildRahmen(doc, M_LEFT, y, aufW, aufH);
        labelOben(doc, 'Aufriss links', M_LEFT + 2, y - 1);
        vgAufriss(doc, M_LEFT, y, aufW, aufH, geom.aufriss('links', e, r));
      } catch (ex) { console.warn('[gf-export] Aufriss links fehlgeschlagen:', ex); }
      try {
        bildRahmen(doc, M_LEFT + aufW + 4, y, aufW, aufH);
        labelOben(doc, 'Aufriss rechts', M_LEFT + aufW + 4 + 2, y - 1);
        vgAufriss(doc, M_LEFT + aufW + 4, y, aufW, aufH, geom.aufriss('rechts', e, r));
      } catch (ex) { console.warn('[gf-export] Aufriss rechts fehlgeschlagen:', ex); }
    }
    y += aufH + 8;

    // Ergebnis-Hero
    var heroH = 22;
    var istVg = !!r.vollgeschoss;
    setColor(doc, 'fill', istVg ? [212, 245, 212] : [245, 212, 212]);
    doc.rect(M_LEFT, y, INHALT_W, heroH, 'F');
    setColor(doc, 'text', istVg ? [17, 85, 17] : [122, 16, 16]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    var hdr = (istVg ? 'Geschoss ist Vollgeschoss' : 'Kein Vollgeschoss');
    doc.text(hdr, M_LEFT + 6, y + 9);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    var anteil = (r.anteil_2_30 != null) ? formatZahl(r.anteil_2_30 * 100, 1) + ' %' : '-';
    var reserve = (typeof r.differenz === 'number') ? formatZahl(r.differenz, 2) + ' m² ' + (r.differenz >= 0 ? 'Reserve' : 'Fehlbetrag') + ' zur 2/3-Schwelle' : '';
    doc.text('Anteil ab 2,30 m: ' + anteil + (reserve ? '  ·  ' + reserve : ''), M_LEFT + 6, y + 17);
    y += heroH + 6;

    // Stats-Tabelle
    var statRows = [
      ['Geschoss-Grundfläche A_G',     formatQM(r.A_G)],
      ['Fläche ab 2,30 m (A_2,30)',    formatQM(r.A_2_30)],
      ['2/3-Schwelle nach BayBO',      formatQM(r.zweidrittel_flaeche)],
      ['Restbreite Bm',                formatM(r.Bm)],
      ['X1 (links) / X2 (rechts)',     formatM(r.X1) + ' / ' + formatM(r.X2)]
    ];
    if (abweichend) {
      // Anrechenbare Flaeche direkt nach A_2,30 einsortieren
      statRows.splice(2, 0,
        ['Anrechenbare Fläche (lichte Höhe >= ' + formatZahl(r.grenzhoehe, 2) + ' m)',
         formatQM(r.A_anrechenbar)]);
    }
    var statRowH = 5.5;
    statRows.forEach(function (row, idx) {
      if (idx % 2 === 0) {
        setColor(doc, 'fill', [248, 250, 253]);
        doc.rect(M_LEFT, y, INHALT_W, statRowH, 'F');
      }
      setColor(doc, 'text', GRAU_TEXT);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(row[0], M_LEFT + 3, y + 4);
      setColor(doc, 'text', SCHWARZ);
      doc.setFont('helvetica', 'bold');
      var w = doc.getTextWidth(row[1]);
      doc.text(row[1], M_LEFT + INHALT_W - 3 - w, y + 4);
      y += statRowH;
    });
    y += 4;

    // Warnungen (falls vorhanden)
    if (Array.isArray(r.warnungen) && r.warnungen.length > 0) {
      setColor(doc, 'fill', [255, 247, 237]);
      var hWarn = 4 + r.warnungen.length * 4;
      doc.rect(M_LEFT, y, INHALT_W, hWarn, 'F');
      setColor(doc, 'text', [124, 58, 10]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.text('Hinweise:', M_LEFT + 2, y + 4);
      doc.setFont('helvetica', 'normal');
      r.warnungen.forEach(function (w, i) {
        doc.text('• ' + w, M_LEFT + 16, y + 4 + i * 4);
      });
      y += hWarn + 4;
    }

    // Kommentar (falls vorhanden)
    if (vg.kommentar && vg.kommentar.trim()) {
      setColor(doc, 'fill', BAUHERR_BG);
      var kZeilen = doc.splitTextToSize(vg.kommentar, INHALT_W - 8);
      var kH = 4 + kZeilen.length * 4;
      doc.rect(M_LEFT, y, INHALT_W, kH, 'F');
      setColor(doc, 'text', SCHWARZ);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.text(kZeilen, M_LEFT + 4, y + 4);
      y += kH + 4;
    }

    // Methodik-Hinweis (klein, fliesst unter dem Inhalt)
    setColor(doc, 'text', GRAU_TEXT);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7);
    var aGQuelle = (r.A_G_quelle === 'polygon')
      ? 'Die Geschoss-Grundflaeche A_G entspricht der im Tool ermittelten Polygonflaeche dieses Geschosses.'
      : 'Die Geschoss-Grundflaeche A_G wird aus L_B * L_L abzueglich A_kleiner berechnet (kein Vergleichs-Polygon verfuegbar).';
    var meth = 'Methodik: Ein Geschoss gilt nach Art. 83 Abs. 7 BayBO als Vollgeschoss, wenn mindestens zwei Drittel seiner Grundflaeche eine lichte Hoehe von mindestens 2,30 m aufweisen. Die geometrischen Eingaben werden manuell aus dem Bauantrag entnommen; das Tool berechnet daraus A_2,30. ' + aGQuelle;
    if (abweichend) {
      meth += ' Fuer die Flaechenanrechnung im Aufmassblatt gilt abweichend die kommunale Satzungs-Grenzhoehe von '
        + formatZahl(r.grenzhoehe, 2) + ' m (anrechenbare Flaeche); die Vollgeschoss-Beurteilung selbst erfolgt unveraendert mit 2,30 m.';
    }
    var mZeilen = doc.splitTextToSize(meth, INHALT_W);
    // Fliesst direkt unter dem letzten Inhaltsblock. maxTop ist die unterste
    // erlaubte Position der ersten Zeile, damit die letzte Zeile knapp ueber dem
    // Fuss endet. Vorher war der Hinweis fest am Seitenfuss verankert und
    // ueberlappte bei VG-Berechnung (besonders mit Anrechenbare-Zeile) die
    // Stats-Tabelle.
    var maxTop = SEITE_H - M_BOT + 1 - (mZeilen.length - 1) * 3;
    doc.text(mZeilen, M_LEFT, Math.min(y + 4, maxTop));

    if (opt.demoMode) zeichneWasserzeichen(doc);
    zeichneFuss(doc, projekt, seitenZaehler);
  }

  function bildRahmen(doc, x, y, w, h) {
    setColor(doc, 'draw', GRAU_LINIE);
    doc.setLineWidth(0.2);
    doc.rect(x, y, w, h);
  }
  function labelOben(doc, text, x, y) {
    setColor(doc, 'text', BRAND);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.text(text, x, Math.max(y, 6));
  }
  function formatM(n) { return (typeof n === 'number' && isFinite(n)) ? formatZahl(n, 2) + ' m' : '-'; }
  function formatQM(n) { return (typeof n === 'number' && isFinite(n)) ? formatZahl(n, 2) + ' m²' : '-'; }
  function formatGrad(n) { return (typeof n === 'number' && isFinite(n)) ? formatZahl(n, 1) + ' °' : '-'; }
  function formatGauben(liste) {
    if (!Array.isArray(liste) || liste.length === 0) return 'keine';
    return liste.map(function (g, i) {
      return 'G' + (i + 1) + ' (b=' + formatZahl(g.b || 0, 2) + ' m, a=' + formatZahl(g.a || 0, 2) + ' m)';
    }).join(', ');
  }

  function zeichneWasserzeichen(doc) {
    doc.saveGraphicsState && doc.saveGraphicsState();
    setColor(doc, 'text', [200, 200, 200]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(60);
    var text = 'DEMO - NICHT ZUR BEHÖRDLICHEN VERWENDUNG';
    // Diagonal: jsPDF kann text(..., {angle: deg}) — Anker im Zentrum
    var cx = SEITE_W / 2, cy = SEITE_H / 2;
    doc.text(text, cx, cy, { angle: 35, align: 'center', baseline: 'middle' });
    doc.restoreGraphicsState && doc.restoreGraphicsState();
  }

  // ============================================================
  // Helfer
  // ============================================================

  function setColor(doc, kind, rgb) {
    if (kind === 'text') doc.setTextColor(rgb[0], rgb[1], rgb[2]);
    else if (kind === 'fill') doc.setFillColor(rgb[0], rgb[1], rgb[2]);
    else if (kind === 'draw') doc.setDrawColor(rgb[0], rgb[1], rgb[2]);
  }

  function hexZuRgb(hex) {
    var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '');
    if (!m) return [127, 140, 141];
    return [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)];
  }

  // Baut die Additionskette "a + b + c = summe m²" fuer den Rechenweg.
  // werte: Array von Teilflaechen (m²); gesamt: die Summe. Nicht-finite Werte
  // werden ignoriert. Bei <2 gueltigen Teilen nur die Summe ausgeben.
  function baueSummenkette(werte, gesamt) {
    var alle = werte || [];
    var teile = alle.filter(function (w) { return typeof w === 'number' && isFinite(w); });
    // Wurde ein nicht-finiter Wert verworfen, waere die Kette "a + b = gesamt"
    // irrefuehrend (Kette != Summe). Dann nur die Gesamtsumme ausgeben.
    if (teile.length < 2 || teile.length !== alle.length) return formatZahl(gesamt || 0, 2) + ' m²';
    var kette = teile.map(function (w) { return formatZahl(w, 2); }).join(' + ');
    return kette + ' = ' + formatZahl(gesamt, 2) + ' m²';
  }

  // Liefert {laenge, breite, flaeche} in m/m², wenn das Polygon ein Rechteck ist:
  // genau 4 Punkte, alle Winkel 90° ± 2° (Toleranz wie Zeichen-Snap), und
  // runde2(L)·runde2(B) trifft die Gauss-Flaeche auf 2 Nachkommastellen —
  // sonst null. Verhindert "10,00 × 5,00 = 50,01, Tabelle sagt 50,00".
  function istRechteck(punkte, ptProMeter) {
    if (!Array.isArray(punkte) || punkte.length !== 4) return null;
    if (!isFinite(ptProMeter) || ptProMeter <= 0) return null;
    var kanten = [];
    for (var i = 0; i < 4; i++) {
      var a = punkte[i], b = punkte[(i + 1) % 4];
      kanten.push({ dx: b.x - a.x, dy: b.y - a.y,
                    len: Math.sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y)) });
    }
    var COS_TOL = Math.cos(88 * Math.PI / 180); // |cos| <= cos(88°) entspricht 90° ± 2°
    for (var k = 0; k < 4; k++) {
      var e1 = kanten[k], e2 = kanten[(k + 1) % 4];
      if (e1.len === 0 || e2.len === 0) return null;
      var cos = (e1.dx * e2.dx + e1.dy * e2.dy) / (e1.len * e2.len);
      if (Math.abs(cos) > COS_TOL) return null;
    }
    var laenge = (kanten[0].len + kanten[2].len) / 2 / ptProMeter;
    var breite = (kanten[1].len + kanten[3].len) / 2 / ptProMeter;
    var flaeche;
    try { flaeche = GF.polygon.berechneFlaeche(punkte, ptProMeter); } catch (e) { return null; }
    var r2 = function (v) { return Math.round(v * 100) / 100; };
    if (Math.round(r2(laenge) * r2(breite) * 100) !== Math.round(flaeche * 100)) return null;
    return { laenge: laenge, breite: breite, flaeche: flaeche };
  }

  // Baut die Gauss-Koordinatentabelle fuer den Rechenweg-Anhang: Punkte lokal
  // normiert (Ursprung = kleinstes x/y), pt -> m. kreuzsumme = |Σ(xi·yj − xj·yi)|,
  // flaeche = kreuzsumme/2 — identisch zu GF.polygon.berechneFlaeche, nur mit
  // ausweisbaren Zwischenwerten. Liefert null bei <3 Punkten oder fehlender Kalibrierung.
  function baueGaussZeilen(punkte, ptProMeter) {
    if (!Array.isArray(punkte) || punkte.length < 3) return null;
    if (!isFinite(ptProMeter) || ptProMeter <= 0) return null;
    var minX = Infinity, minY = Infinity;
    punkte.forEach(function (p) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
    });
    var koordinaten = punkte.map(function (p) {
      return { x: (p.x - minX) / ptProMeter, y: (p.y - minY) / ptProMeter };
    });
    var summe = 0;
    for (var i = 0; i < koordinaten.length; i++) {
      var j = (i + 1) % koordinaten.length;
      summe += koordinaten[i].x * koordinaten[j].y - koordinaten[j].x * koordinaten[i].y;
    }
    var kreuzsumme = Math.abs(summe);
    return { koordinaten: koordinaten, kreuzsumme: kreuzsumme, flaeche: kreuzsumme / 2 };
  }

  // Inline-Herleitungszeile fuer eine Teilflaeche (ohne "Teilflaeche X:"-Prefix).
  // Rechteck: "L × B = F"; sonst Verweis auf den Rechenweg-Anhang. Bei manueller
  // Korrektur wird der gemessene Wert hergeleitet und der angesetzte benannt.
  function baueHerleitungsText(polygon, ptProMeter) {
    var punkte = polygon && polygon.punkte;
    if (!Array.isArray(punkte) || punkte.length < 3 || !isFinite(ptProMeter) || ptProMeter <= 0) {
      return 'Herleitung nicht verfügbar (keine Kalibrierung)';
    }
    var korrektur = polygon.manuelleKorrektur
      ? ', manuell angesetzt ' + formatZahl(polygon.flaecheAngesetztQM, 2) + ' m²' : '';
    var prefix = polygon.manuelleKorrektur ? 'gemessen ' : '';
    var rect = istRechteck(punkte, ptProMeter);
    if (rect) {
      return prefix + formatZahl(rect.laenge, 2) + ' m × ' + formatZahl(rect.breite, 2)
             + ' m = ' + formatZahl(rect.flaeche, 2) + ' m²' + korrektur;
    }
    return punkte.length + ' Eckpunkte - Herleitung siehe Rechenweg-Anhang' + korrektur;
  }

  // Zeilenbudget einer Anhangseite (Zeilen à 4 mm im Inhaltsbereich unter
  // Seitentitel, mit Reserve fuer Fussnote/Fusszeile).
  var ANHANG_ZEILEN_PRO_SEITE = 48;

  // Plant die Anhangseiten einer Region: nur nicht-rechteckige Teilflaechen.
  // Liefert Array von Seiten; jede Seite = Array von Abschnitten
  // {index, polygon, vonPunkt, bisPunkt, mitKopf, mitFormel}. Grosse Polygone
  // werden ueber Seitengrenzen gechunkt (Fortsetzungs-Abschnitte ohne Kopf).
  // Counter (zaehleBerechnungSeiten) und Renderer nutzen DIESE Funktion,
  // damit "Seite x von y" nie auseinanderlaeuft.
  function baueAnhangPlan(polygone, ptProMeter) {
    var seiten = [];
    var aktuelle = [];
    var frei = ANHANG_ZEILEN_PRO_SEITE;
    function neueSeite() {
      if (aktuelle.length) seiten.push(aktuelle);
      aktuelle = [];
      frei = ANHANG_ZEILEN_PRO_SEITE;
    }
    (polygone || []).forEach(function (p, i) {
      var punkte = p && p.punkte;
      if (!Array.isArray(punkte) || punkte.length < 3) return;
      if (!isFinite(ptProMeter) || ptProMeter <= 0) return;
      if (istRechteck(punkte, ptProMeter)) return;
      var von = 0;
      while (von < punkte.length) {
        var kopfZeilen = (von === 0) ? 2 : 1; // Titel+Tabellenkopf bzw. "Fortsetzung"
        if (frei < kopfZeilen + 5) neueSeite(); // zu wenig Restplatz: naechste Seite
        var platz = frei - kopfZeilen - 2;      // 2 Zeilen Reserve fuer Formelzeile
        var bis = Math.min(punkte.length, von + Math.max(3, platz));
        var fertig = (bis === punkte.length);
        aktuelle.push({ index: i, polygon: p, vonPunkt: von, bisPunkt: bis,
                        mitKopf: von === 0, mitFormel: fertig });
        frei -= kopfZeilen + (bis - von) + (fertig ? 2 : 0);
        von = bis;
        if (!fertig) neueSeite();
      }
      frei -= 1; // Leerzeile zwischen Teilflaechen
    });
    if (aktuelle.length) seiten.push(aktuelle);
    return seiten;
  }

  function formatZahl(n, stellen) {
    if (typeof n !== 'number' || !isFinite(n)) return '-';
    var st = stellen || 2;
    // Pre-Round: siehe util.js#formatZahlDE
    var faktor = Math.pow(10, st);
    return (Math.round(n * faktor) / faktor).toFixed(st).replace('.', ',');
  }

  function formatDatum(iso) {
    if (!iso) return '';
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE');
    } catch (e) { return ''; }
  }

  function adresseZusammen(strasse, plz, ort) {
    var t = [];
    if (strasse) t.push(strasse);
    var po = [plz, ort].filter(function (x) { return x; }).join(' ');
    if (po) t.push(po);
    return t.join(', ');
  }

  function flurZusammen(flurnummer, gemarkung) {
    var t = [];
    if (flurnummer) t.push('Fl.Nr. ' + flurnummer);
    if (gemarkung)  t.push('Gmkg. ' + gemarkung);
    return t.join(' · ');
  }

  // Test-Hook: stabiler Name fuer den Flaechen-Sammler. Die Funktion ist rein
  // (kein DOM, kein State) und wird in tests.js benutzt.
  GF.export.sammlerFlaechenJeGeschoss = sammlerFlaechenJeGeschoss;

  // Test-Hook: reine Funktion fuer den Rechenweg, in tests.js geprueft.
  // @ts-ignore - nicht im GfExportModule-Typ deklariert (nur Test-Zugriff)
  GF.export.baueSummenkette = baueSummenkette;

  // Test-Hook: reine Funktion fuer die Rechteck-Erkennung, in tests.js geprueft.
  // @ts-ignore - nicht im GfExportModule-Typ deklariert (nur Test-Zugriff)
  GF.export.istRechteck = istRechteck;

  // Test-Hook: reine Funktion fuer die Gauss-Tabelle, in tests.js geprueft.
  // @ts-ignore - nicht im GfExportModule-Typ deklariert (nur Test-Zugriff)
  GF.export.baueGaussZeilen = baueGaussZeilen;

  // Test-Hook: reine Funktion fuer die Inline-Herleitungszeile, in tests.js geprueft.
  // @ts-ignore - nicht im GfExportModule-Typ deklariert (nur Test-Zugriff)
  GF.export.baueHerleitungsText = baueHerleitungsText;

  // Test-Hook: reine Funktion fuer die Anhang-Seitenplanung, in tests.js geprueft.
  // @ts-ignore - nicht im GfExportModule-Typ deklariert (nur Test-Zugriff)
  GF.export.baueAnhangPlan = baueAnhangPlan;

  // Test-Hook: voller Seiten-Render-Pfad ohne canvas/pdf.js. Der Aufrufer
  // uebergibt ein fertiges jsPDF-doc und eine Snapshot-Map (regionId -> dataUrl
  // oder null). Nur fuer Node-Harness/Tests; im Browser ungenutzt.
  // @ts-ignore - nicht im GfExportModule-Typ deklariert (nur Test-Zugriff)
  GF.export.__renderInDoc = zeichneAllesIntoDoc;

})(typeof window !== 'undefined' ? window : globalThis);
