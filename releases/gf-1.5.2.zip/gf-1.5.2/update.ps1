# ===================================================================
#  FlaechenKlar Companion-Updater (PowerShell)
#  -------------------------------------------------------------------
#  Laedt das neueste Release-ZIP und ersetzt alle Code-Dateien im
#  Installationsordner — mit EINER Ausnahme:
#
#    data\   bleibt unangetastet  (Wappen, kommune.js, lizenz.js)
#
#  Ablauf:
#    1. Lese Gemeinde-ID aus data\lizenz.js (Demo-Modus, falls fehlend)
#    2. Hashe ID via SHA256, pruefe gegen oeffentliche allowlist.json
#    3. Vergleiche lokale version.txt mit Server-version.txt
#    4. Falls neuere Version: ZIP herunterladen + Code-Dateien ersetzen
#       (data\, update.bat, update.ps1, FlaechenKlar.bat, launcher.ps1
#        bleiben unveraendert)
#
#  Schalter -NurPruefen: bricht nach Schritt 1-3 ab, OHNE etwas
#  herunterzuladen. Exit-Codes fuer Aufrufer (launcher.ps1):
#    0  = nichts zu tun (aktuell / Demo / keine Wartung / Netzfehler)
#   10  = Update verfuegbar UND berechtigt
#    1  = harter Fehler (ungueltige Server-Antwort etc., wie bisher)
# ===================================================================

param(
    [switch]$NurPruefen
)

$ErrorActionPreference = 'Stop'

# --- TLS 1.2 erzwingen ----------------------------------------------------
# PowerShell 5.1 (.NET Framework) startet auf aelteren Windows-Staenden mit
# SSL3/TLS 1.0 als Default. Der Update-Server (Cloudflare) spricht nur
# TLS 1.2 und hoeher - ohne diese Zeile scheitert JEDER Aufruf mit
# "Es konnte kein geschuetzter SSL/TLS-Kanal erstellt werden", obwohl die
# URL im Browser normal erreichbar ist (Traunstein, 13.08.2026).
# NUR Tls12 setzen (additiv per -bor, bestehende Flags bleiben erhalten):
# Tls13 existiert im .NET-Framework-Enum sehr wohl (ab .NET 4.8), wird von
# Schannel auf Windows-Staenden vor Server 2022 / Windows 10 1903 aber NICHT
# unterstuetzt - das Bit haette hier keinen Nutzen (Cloudflare akzeptiert
# Tls12) und koennte den Handshake auf genau den Zielsystemen verschlechtern,
# die dieser Fix erreichen soll.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

# Basis-URLs des Update-Servers (gh-pages des Update-Repos).
$versionUrl   = 'https://download.flaechenklar.de/version.txt'
$releaseBase  = 'https://download.flaechenklar.de/releases/'
$allowlistUrl = 'https://download.flaechenklar.de/allowlist.json'

$installDir = $PSScriptRoot
$versionDatei = Join-Path $installDir 'version.txt'
$lizenzDatei = Join-Path $installDir 'data\lizenz.js'

# --- Lizenz-ID lesen + Whitelist pruefen --------------------------------
if (-not (Test-Path $lizenzDatei)) {
    Write-Host ''
    Write-Host 'Demo-Version' -ForegroundColor Yellow
    Write-Host 'Diese Installation ist eine Demo-Version. Updates sind nur fuer'
    Write-Host 'lizenzierte Installationen verfuegbar. Bitte kontaktieren Sie'
    Write-Host 'den Anbieter fuer eine Voll-Lizenz fuer Ihre Gemeinde.'
    exit 0
}

$lizenzInhalt = Get-Content $lizenzDatei -Raw
$match = [regex]::Match($lizenzInhalt, "id\s*:\s*['""]([A-Z0-9\-]+)['""]")
if (-not $match.Success) {
    Write-Host ''
    Write-Host 'FEHLER: data\lizenz.js enthaelt keine erkennbare ID.' -ForegroundColor Red
    Write-Host 'Erwartetes Format: window.GF_LIZENZ = { id: "GF-XX-YYYY-NNN" };'
    exit 1
}
$lizenzId = $match.Groups[1].Value
if (-not $lizenzId.StartsWith('GF-')) {
    Write-Host ''
    Write-Host ('FEHLER: Lizenz-ID hat falsches Praefix (' + $lizenzId + ').') -ForegroundColor Red
    Write-Host 'Erwartet: GF-XX-YYYY-NNN'
    exit 1
}
Write-Host ('Lizenz-ID: ' + $lizenzId)

# SHA256 der ID berechnen
$idBytes = [System.Text.Encoding]::UTF8.GetBytes($lizenzId)
$sha = [System.Security.Cryptography.SHA256]::Create()
try { $hashBytes = $sha.ComputeHash($idBytes) } finally { $sha.Dispose() }
$hashHex = -join ($hashBytes | ForEach-Object { $_.ToString('x2') })

# Whitelist abrufen
Write-Host 'Pruefe Wartungs-Status ...'
try {
    $al = Invoke-RestMethod -Uri $allowlistUrl -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 8
} catch {
    Write-Host ''
    Write-Host 'FEHLER: Wartungs-Server nicht erreichbar.' -ForegroundColor Red
    Write-Host ('  ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('  Aktives TLS-Protokoll: ' + [Net.ServicePointManager]::SecurityProtocol) -ForegroundColor Red
    exit 1
}
if (-not $al.hashes -or $al.hashes.Count -eq 0) {
    Write-Host ''
    Write-Host 'FEHLER: Wartungs-Liste ist leer oder ungueltig.' -ForegroundColor Red
    exit 1
}
if (-not ($al.hashes -contains $hashHex)) {
    Write-Host ''
    Write-Host 'Wartungsvertrag abgelaufen' -ForegroundColor Yellow
    Write-Host 'Ihre aktuelle Programmversion laeuft unbegrenzt weiter. Um neue'
    Write-Host 'Versionen zu erhalten, erneuern Sie bitte Ihren Wartungsvertrag.'
    exit 0
}
Write-Host 'Wartung gueltig.'
Write-Host ''

# --- Lokale Version lesen -----------------------------------------------
if (Test-Path $versionDatei) {
    $lokal = (Get-Content $versionDatei -First 1).Trim()
} else {
    $lokal = '0.0.0'
}
Write-Host ('Installierte Version: ' + $lokal)

# --- Neueste Version von version.txt lesen ------------------------------
try {
    $remoteVersionTxt = Invoke-WebRequest -Uri $versionUrl -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 8
    $zeilen = ($remoteVersionTxt.Content -split "`r?`n")
    $neu = ($zeilen[0] -as [string]).Trim()
    if ($neu.StartsWith('v')) { $neu = $neu.Substring(1) }
} catch {
    Write-Host ''
    Write-Host 'FEHLER: Update-Server nicht erreichbar.' -ForegroundColor Red
    Write-Host ('  ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('  Aktives TLS-Protokoll: ' + [Net.ServicePointManager]::SecurityProtocol) -ForegroundColor Red
    exit 1
}
if (-not ($neu -match '^\d+\.\d+\.\d+$')) {
    Write-Host ''
    Write-Host ('FEHLER: Server lieferte ungueltiges Versionsformat: ' + $neu) -ForegroundColor Red
    exit 1
}
Write-Host ('Verfuegbare Version:  ' + $neu)

try {
    $vLokal = [version]$lokal
    $vNeu   = [version]$neu
} catch {
    Write-Host ''
    Write-Host 'FEHLER: Versions-Format ungueltig (erwarte x.y.z).' -ForegroundColor Red
    exit 1
}
if ($vNeu -le $vLokal) {
    Write-Host ''
    Write-Host 'Sie sind bereits auf dem neuesten Stand.' -ForegroundColor Green
    exit 0
}

if ($NurPruefen) {
    # Nur Pruef-Naht bis hierher (Lizenz + Whitelist + Versionsvergleich) —
    # kein Download. Aufrufer (launcher.ps1) liest den Exit-Code.
    Write-Host ''
    Write-Host ('Update verfuegbar: ' + $neu) -ForegroundColor Green
    exit 10
}

$zipUrl = $releaseBase + 'gf-' + $neu + '.zip'

$tmpZip = Join-Path $env:TEMP 'gf-update.zip'
$tmpDir = Join-Path $env:TEMP 'gf-update'

if (Test-Path $tmpZip) { Remove-Item $tmpZip -Force }
if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }

$rcExit = 0
try {
    Write-Host ''
    Write-Host ('Lade ' + $zipUrl + ' ...')
    Invoke-WebRequest -Uri $zipUrl -OutFile $tmpZip -UseBasicParsing

    # --- ZIP-Integritaet pruefen (SHA-256 gegen .sha256-Datei) -------------
    $shaUrl = $zipUrl + '.sha256'
    Write-Host 'Pruefe ZIP-Integritaet ...'
    try {
        $shaResp = Invoke-WebRequest -Uri $shaUrl -UseBasicParsing `
            -Headers @{ 'Cache-Control' = 'no-cache' }
        # GitHub Pages serviert .sha256 als application/octet-stream.
        # PowerShell 5.1 IWR gibt dann Byte[] statt String zurueck — Trim()
        # waere nicht definiert. Daher bei Bedarf in UTF-8 dekodieren.
        $rawContent = $shaResp.Content
        if ($rawContent -is [byte[]]) {
            $rawContent = [System.Text.Encoding]::UTF8.GetString($rawContent)
        }
        $erwartetHash = $rawContent.Trim().ToLower()
    } catch {
        Write-Host ''
        Write-Host 'FEHLER: SHA256-Pruefsumme nicht verfuegbar.' -ForegroundColor Red
        Write-Host ('  ' + $_.Exception.Message) -ForegroundColor Red
        exit 1
    }
    if (-not ($erwartetHash -match '^[0-9a-f]{64}$')) {
        Write-Host ''
        Write-Host 'FEHLER: SHA256-Pruefsumme ungueltig formatiert.' -ForegroundColor Red
        exit 1
    }
    $istHash = (Get-FileHash -Path $tmpZip -Algorithm SHA256).Hash.ToLower()
    if ($istHash -ne $erwartetHash) {
        Write-Host ''
        Write-Host 'FEHLER: ZIP-Pruefsumme stimmt nicht ueberein. Update abgebrochen.' -ForegroundColor Red
        Write-Host ('  Erwartet: ' + $erwartetHash)
        Write-Host ('  Ist:      ' + $istHash)
        exit 1
    }
    Write-Host 'Pruefsumme OK.'

    # --- ZipSlip-Defense ----------------------------------------------------
    # Pfad-Traversal-Schutz: kein Entry darf '..\' oder absolute Wurzel haben.
    # Defense-in-Depth (SHA256-Check vorher faengt das bereits, falls Hash OK).
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zipReader = [System.IO.Compression.ZipFile]::OpenRead($tmpZip)
    try {
        foreach ($entry in $zipReader.Entries) {
            $name = $entry.FullName
            if ($name -match '(^|[\\/])\.\.([\\/]|$)' -or
                $name -match '^[\\/]' -or
                $name -match '^[A-Za-z]:[\\/]') {
                Write-Host ''
                Write-Host ('FEHLER: Unsicherer ZIP-Eintrag erkannt: ' + $name) -ForegroundColor Red
                Write-Host '       Update abgebrochen (Pfad-Traversal-Schutz).' -ForegroundColor Red
                exit 1
            }
        }
    } finally {
        $zipReader.Dispose()
    }

    Write-Host 'Entpacke ...'
    Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force

    $inhalt = Get-ChildItem $tmpDir
    $unterordner = $inhalt | Where-Object { $_.PSIsContainer }
    if ($unterordner.Count -eq 1 -and ($inhalt.Count -eq 1 -or ($inhalt | Where-Object { -not $_.PSIsContainer }).Count -eq 0)) {
        $src = $unterordner[0].FullName
    } else {
        $src = $tmpDir
    }

    Write-Host 'Aktualisiere Dateien ...'
    # /XF mit vollqualifiziertem Pfad ($src-Anchor) schuetzt kundenspezifische
    # Dateien in data/ (lizenz.js, kommune.js, wappen.jpg) ohne andere
    # Treffer wie js/lizenz.js auszuschliessen. update.bat / update.ps1 /
    # FlaechenKlar.bat / launcher.ps1 per Dateiname (sind im Repo nur an
    # einer Stelle vorhanden) — ein laufendes Skript darf sich beim
    # robocopy nicht selbst ueberschreiben.
    # data/*.example.js bleibt updatebar (CRITICAL #4 — A8 Fix).
    #
    # Aufruf via & mit @-Splatting (NICHT Start-Process -ArgumentList @array).
    # Start-Process in PS 5.1 joined Array-Args ohne Quoting — Pfade mit
    # Leerzeichen (z.B. C:\Program Files\...) brechen das Robocopy-Parsing.
    # Direkter Call mit Splatting macht PowerShell-Argument-Handling +
    # liefert ExitCode via $LASTEXITCODE.

    # Self-Replace-Naht: die live Bootstrap-Dateien (update.bat/update.ps1/
    # launcher.ps1/FlaechenKlar.bat) bleiben hier per /XF geschuetzt, damit sich
    # kein laufendes Skript mitten im Update selbst ueberschreibt. Ihre
    # Aktualisierung reist als byte-gleicher .neu-Zwilling mit (anderer Name ->
    # nicht ausgeschlossen) und wird beim naechsten Start vom Finalizer in
    # FlaechenKlar.bat/launcher.ps1 uebernommen (X.neu -> X).
    # Spec: docs/superpowers/specs/2026-08-13-self-replace-bootstrap-naht-design.md
    $rcArgs = @(
        $src, $installDir,
        '/E',
        '/XF', (Join-Path $src 'data\lizenz.js'),
               (Join-Path $src 'data\kommune.js'),
               (Join-Path $src 'data\wappen.jpg'),
               'update.bat', 'update.ps1',
               'FlaechenKlar.bat', 'launcher.ps1',
        '/NFL', '/NDL', '/NJH', '/NJS', '/NP'
    )
    & robocopy @rcArgs
    $rcExit = $LASTEXITCODE
}
finally {
    if (Test-Path $tmpZip) { Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue }
    if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue }
}

if ($rcExit -ge 8) {
    Write-Host ''
    Write-Host ('FEHLER: Robocopy meldet Exit-Code ' + $rcExit + '.') -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host ('Update auf Version ' + $neu + ' erfolgreich installiert.') -ForegroundColor Green
Write-Host 'Sie koennen die App jetzt wieder oeffnen (index.html im Browser).'
