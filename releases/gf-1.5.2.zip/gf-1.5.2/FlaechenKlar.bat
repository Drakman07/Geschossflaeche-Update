@echo off
REM ==================================================================
REM  FlaechenKlar Start-Launcher
REM  Prueft beim Start kurz auf Updates und oeffnet danach das Tool.
REM  Siehe launcher.ps1 fuer den Ablauf.
REM ==================================================================

REM --- Self-Replace-Finalizer -------------------------------------------
REM  Staged Bootstrap-Zwillinge (X.neu -> X) uebernehmen, solange das Ziel
REM  nicht als Prozess laeuft UND der Zwilling nicht leer ist (abgebrochener/
REM  unvollstaendiger Download wird uebersprungen). FlaechenKlar.bat.neu
REM  bleibt aussen vor (diese Datei laeuft gerade) - die uebernimmt
REM  launcher.ps1. Fehler still ignoriert.
for %%F in (launcher.ps1 update.ps1 update.bat) do if exist "%~dp0%%F.neu" for %%A in ("%~dp0%%F.neu") do if %%~zA GTR 0 move /Y "%~dp0%%F.neu" "%~dp0%%F" >nul 2>&1

REM  Testhaken: nur finalisieren, Tool NICHT starten.
if /I "%~1"=="finalize-only" goto :ende

start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0launcher.ps1"

:ende
