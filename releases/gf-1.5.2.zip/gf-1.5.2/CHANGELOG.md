# Changelog — FlächenKlar

Alle nennenswerten Änderungen werden hier dokumentiert.
*Arbeitstitel bis Mai 2026: gf-Tool / Geschossflächen-Tool.*

## [1.5.2] — 2026-08-14

### Geändert
- **Self-Replace-Naht: der Update-Weg aktualisiert sich selbst.** Die vier
  Start-/Update-Dateien (`update.ps1`, `update.bat`, `launcher.ps1`,
  `FlaechenKlar.bat`) reisen jetzt als byte-gleiche `.neu`-Zwillinge im
  Release-ZIP mit und werden beim nächsten Start vom Finalizer übernommen
  (`X.neu` → `X`), jeweils von der Komponente, die das Ziel nicht als Prozess
  laufen hat — ohne dass ein laufendes Skript sich selbst überschreibt. Damit
  erreichen Verbesserungen am Update-Weg (Endpunkte, TLS-Fix) künftige
  Installationen automatisch, statt am `/XF`-Selbstausschluss zu hängen.
  Spec: `docs/superpowers/specs/2026-08-13-self-replace-bootstrap-naht-design.md`.

### Hinzugefügt
- **Warnhinweise gegen falsche Gemeinde-/Stammdaten-Zuordnung.** Ein
  Hinweisbalken meldet, wenn sich einer Akte keine eindeutige Gemeinde
  zuordnen lässt (kein oder mehrere gleich passende Profile) — sonst könnten
  Beitragssätze, Wappen oder Briefkopf von der falschen Gemeinde stammen; ein
  zweiter Balken erinnert, dass ein Stammdaten-Entwurf im Browser erst nach
  Ablage als `kommune.js` und Neuladen installationsweit aktiv wird. Beide
  verlinken per Klick zur passenden Maske.
- **Knopf „Beitragssätze aus Stammdaten übernehmen"** in Schritt 2 des
  Beitragsbescheids — lädt die vier Satz-Felder erneut aus den Stammdaten,
  nützlich nach nachträglicher Korrektur der Gemeinde-Zuordnung
  (Rückfrage-Dialog vor dem Überschreiben). Umgesetzt in einer
  Parallel-Session (Feature „Gemeinde-Zuordnung robust machen"), mit 1.5.2
  ausgeliefert.

## [1.5.1] — 2026-08-13

### Behoben
- **Update schlug auf älteren Windows-Servern mit „Es konnte kein
  geschützter SSL/TLS-Kanal erstellt werden" fehl**, obwohl der Update-
  Server im Browser normal erreichbar war. PowerShell 5.1 startet dort mit
  TLS 1.0 als .NET-Default; der Update-Server (Cloudflare) akzeptiert nur
  TLS 1.2+. `update.ps1` und `launcher.ps1` erzwingen jetzt TLS 1.2,
  bevor der erste Netzaufruf erfolgt.

## [1.5.0] — 2026-08-12

### Hinzugefügt
- **Start-Launcher `FlaechenKlar.bat`.** Neuer empfohlener Startweg statt
  `index.html`: prüft beim Programmstart automatisch und ohne spürbare
  Verzögerung, ob ein Update vorliegt, und bietet es bei Treffer per
  Ja/Nein-Dialog direkt zur Installation an — der bisherige Umweg über den
  Programmordner und `update.bat` entfällt. Bei „Nein" öffnet sich das Tool
  sofort, beim nächsten Start wird erneut gefragt. `index.html` bleibt
  funktionsfähig (kein Zwang), zeigt aber einen wegklickbaren Hinweis auf
  den neuen Weg.
- **Changelog-Anzeige im Update-Dialog.** Sowohl der neue Launcher-Dialog
  als auch „Hilfe → Auf Updates prüfen" zeigen jetzt kurz, was sich seit
  der installierten Version geändert hat (bis zu 8 Punkte, neueste zuerst),
  statt nur die nackte Versionsnummer.
- **Änderungen an `update.ps1`:** neuer Schalter `-NurPruefen` (nur
  Lizenz-/Versions-Check, kein Download) als technische Grundlage für den
  Launcher — bestehendes manuelles `update.bat` unverändert nutzbar.

## [1.4.4] — 2026-08-12

### Behoben
- **Aufmaßprotokoll übernahm bei Verwaltungsgemeinschaften nicht das Wappen
  der im Projekt gewählten Gemeinde.** Der Beitragsbescheid tauschte das
  Wappen korrekt aus (nutzte den eingefrorenen Projekt-Snapshot der
  gewählten Gemeinde), das Aufmaßprotokoll griff dagegen nur auf das live im
  Startbildschirm angezeigte Wappen zu — das bleibt dauerhaft auf der
  Standard-Gemeinde stehen und wird bei Gemeindewahl im Projektdaten-Dialog
  nicht aktualisiert. Betroffen: jede Verwaltungsgemeinschaft mit mehreren
  hinterlegten Gemeinden. Fix: Aufmaßprotokoll nutzt jetzt dieselbe
  Vorrang-Regel wie der Bescheid (Projekt-Snapshot zuerst, Live-Wappen nur
  als Fallback für Alt-Projekte/Ein-Gemeinde-Installationen).

## [1.4.3] — 2026-08-06

### Behoben
- **Beitragsbescheid: Fälligkeitsdatum sprang beim Eintippen des Versanddatums
  auf 1902.** Ein natives Datumsfeld meldet beim Eintippen (statt Kalenderklick)
  bereits Zwischenzustände — nach der ersten Jahresziffer stand dort z. B.
  "0002-08-07". Die automatische Fälligkeitsberechnung übernahm dieses
  unvollständige Jahr, und JavaScript rechnet Kurzjahre unter 100 auf 1900+x
  hoch, wodurch sich "1902-09-11" ergab; ein Schutzmechanismus gegen
  Überschreiben verhinderte danach die Korrektur, sodass das falsche Datum
  stehen blieb. Betroffen war jedes eingetippte (nicht per Kalender gewählte)
  Versanddatum. Die Datumsableitung verwirft jetzt unvollständige/implausible
  Jahre (< 1000) und liefert dafür kein Datum, statt eines falschen.

## [1.4.2] — 2026-08-05

### Behoben
- **Beitragsbescheid-Dialog ließ sich ohne Plan/Aufmaß nicht öffnen.** Für
  eine Nacherhebung wegen reiner Grundstücksmehrung (z. B. Zukauf, Geschoss-
  fläche unverändert) gibt es konzeptionell keinen Plan zu vermessen — das
  Tool erzwang trotzdem den Umweg über Plan+Fläche. Der Beitragsbescheid-
  Button ist jetzt auch ohne Aufmaß klickbar; ohne aufgemessene Fläche fragt
  eine Rückfrage nach dem Sonderfall und belegt „Nacherhebung" mit dem neuen
  Häkchen „Geschossfläche unverändert" vor (übernimmt die bereits veranlagte
  Geschossfläche unverändert als „neu" — die Geschossflächen-Mehrfläche
  bleibt automatisch 0, nur die Grundstücks-Mehrfläche zählt). Liegt
  tatsächlich ein Aufmaß vor oder ist die Geschossfläche für die aktive
  Satzung relevant, verhindert die Validierung weiterhin einen ungemessenen
  Export.

## [1.4.1] — 2026-07-26

### Behoben
- **Ablauf-Leiste prüfte projektweit statt je Geschoss.** Die Schritte
  „Plan-Ausschnitt", „Maßstab festlegen" und „Fläche aufmessen" galten schon
  als erledigt, sobald irgendein Geschoss im Projekt einen Ausschnitt/
  Maßstab/Fläche hatte — ein frisch angelegtes zweites Geschoss (z. B.
  Obergeschoss neben einem fertigen Erdgeschoss) zeigte dadurch fälschlich
  Schritt 4 an, obwohl es selbst noch nichts hatte. Die Leiste filtert jetzt
  nach dem aktiven Geschoss.

### Hinzugefügt
- **Namens-Vorschläge beim Geschoss-Anlegen.** „Neues Geschoss anlegen"
  zeigt jetzt Schaltflächen mit den üblichen Bezeichnungen (Kellergeschoss,
  Erdgeschoss, 1./2. Obergeschoss, Dachgeschoss) statt eines reinen
  Freitext-Eingabefensters. Eigene Bezeichnungen bleiben weiterhin möglich.

## [1.4.0] — 2026-07-26

### Hinzugefügt
- **Ablauf-Leiste.** Eine Schritt-Leiste zeigt durchgängig, wo man im
  Arbeitsablauf steht und was als Nächstes kommt.
- **Canvas-Aktionsbalken und Selbsterklärung gesperrter Buttons.** Gesperrte
  Werkzeuge erklären beim Hover, warum sie gesperrt sind, statt stumm zu
  bleiben.
- **Eigener Abzugsflächen-Dialog statt Browser-Eingabefenster.** Abzugsflächen
  werden jetzt über ein Formular im Tool-Design erfasst statt über die
  hässlichen `prompt()`-Fenster des Browsers.
- **Stammdaten direkt in `data/` speichern.** Über die File-System-Access-API
  landet ein gespeichertes Gemeinde-Profil direkt in der richtigen Datei —
  das bisherige Kopier-Ritual (Download, manuell umbenennen, in `data/`
  verschieben) entfällt.
- **Doppel-Bescheid-Hinweis vor Export.** Bei zwei Beitragsarten (Wasser und
  Kanal) weist das Tool vor dem Export darauf hin, dass zwei getrennte
  Bescheide entstehen.
- **Bescheidmaske als 4-Schritt-Wizard.** Empfänger & Grundstück,
  Beitragssätze, Zahlung & Unterschrift, Texte prüfen — mit
  Pflichtfelder-Zähler pro Schritt und Status-Badges für aktive
  Standardtexte.
- **Beitragsbescheid: abweichender Unterzeichner pro Fall.** Der Bescheid
  kann jetzt wahlweise einen vom Sachbearbeiter abweichenden Unterzeichner
  tragen, mit optionalem Zeichnungsvermerk („i. A.", „i. V.") über dem
  Unterschriftsstrich. Pflegbar je Gemeinde-Profil in den Stammdaten, pro
  Fall in den Projektdaten überschreibbar. Ohne gepflegten Unterzeichner
  bleibt die Ausgabe unverändert.
- **Kleinvieh:** Benutzerhandbuch als .zip herunterladbar, Download-Toast
  nach Exporten, verständlichere Fehlertexte, deutlicherer
  Kontrollmaß-Hinweis, aktualisiertes README.
- **Interne Qualitätssicherung:** Ein neuer explorativer Prüf-Runner
  (fk-explorer) simuliert reale Bedienabläufe per Zufallssteuerung und
  prüft dabei nicht mehr nur die Zahl im Speicher, sondern auch die
  tatsächlich ausgelieferten Dateien (Aufmaßprotokoll-PDF, Bescheid-PDF/DOCX,
  CSV-/RIWA-Export) gegen die Rechen-Naht. Fand dabei den Re-Kalibrierungs-
  Fehler unten.

### Geändert
- **Fachjargon eingedeutscht.** „Ausschnitt"/„Fläche" statt „Region"/
  „Polygon", durchgängige Sie-Anrede in der gesamten Bedienoberfläche.
- **Der Unterzeichner steht jetzt beim Öffnen der Projektdaten in der Maske.**
  Der in den Stammdaten hinterlegte Unterzeichner (samt Zeichnungsvermerk und
  Amtsbezeichnung) wird beim **Öffnen** eingesetzt, nicht mehr erst beim
  Übernehmen. Damit steht auf dem Bescheid genau das, was vorher im Formular
  zu sehen war: Wer für einen einzelnen Fall selbst zeichnen will, leert das
  Unterzeichner-Feld und übernimmt — vorher füllte derselbe Klick das Feld
  wieder aus den Stammdaten, es gab über die Maske keinen Weg zurück zum
  Regelfall. Beim nächsten Öffnen steht der Stammdaten-Unterzeichner wieder
  im Feld.
- **Zeichnungsvermerk und Amtsbezeichnung hängen am Unterzeichner.** Wird das
  Unterzeichner-Feld geleert, werden beide mit geleert, solange sie den
  Stammdaten-Stand tragen — sonst stünde der Sachbearbeiter unter der
  Amtsbezeichnung des Bürgermeisters. Von Hand eingetragene Texte bleiben
  stehen.

### Behoben
- **Demo-Wasserzeichen im Beitragsbescheid war abgeschnitten.** Der Hinweis
  stand als einzelne Zeile in 60 pt im PDF und war damit rund 545 mm lang —
  auf einem 210 mm breiten Blatt ragte er 118 mm über jede Seitenkante hinaus.
  Auf dem Papier blieb nur das Mittelstück „ZUR BEHOERDLICHEN V" stehen, das
  Wort DEMO fehlte komplett. Ein Demo-Bescheid war damit auf dem Ausdruck nicht
  von einem amtlichen zu unterscheiden. Jetzt zweizeilig wie im
  Aufmaßprotokoll, mit demselben Grauwert. Wortlaut und Größen liegen nun an
  EINER Stelle für alle drei Ausgaben (Aufmaßprotokoll, Bescheid-PDF,
  Bescheid-Word) — vorher drei eigene Textkopien, deren Wortlaut schon
  auseinandergelaufen war. Betrifft nur den Demo-Modus, nicht die Vollversion.
- **Re-Kalibrierung rechnete gespeicherte Polygon-Flächen nicht neu.**
  Wurde eine Region nachträglich re-kalibriert (Maßstab korrigiert), blieb
  die im Projekt gespeicherte Fläche auf dem alten Wert stehen — der
  Export las diese veraltete Fläche, das Aufmaßprotokoll zeigte eine
  falsche, beitragsrelevante Zahl (Art. 5 KAG). Vom neuen fk-explorer
  gefunden (Nachrechner-Orakel). Betrifft nur Projekte, bei denen nach dem
  ersten Aufmaß eine Region re-kalibriert wurde.

## [1.3.3] — 2026-07-23

### Behoben
- **Beitragsbescheid bei Nacherhebung jetzt nachvollziehbar.** Rückmeldung
  einer Gemeinde aus dem Demo-Einsatz: wurde ein Grundstück bereits teilweise
  veranlagt, zog der Bescheid die Mehrfläche zwar korrekt ab, ohne dass für
  den Empfänger erkennbar war, warum der Betrag niedriger ausfällt. Ziffer II
  zeigt jetzt vor der Beitragsberechnung eine Zahlen-Herleitung (Fläche
  gesamt neu ermittelt minus bereits veranlagt = beitragspflichtige
  Mehrfläche); Bescheiddatum/-nummer des Vorbescheids bleiben optional und
  fallen bei leeren Angaben auf einen generischen Satz zurück.
- **Beitragsbescheid bei zwei Beitragspflichtigen (Gesamtschuldner) jetzt
  vollständig angeschrieben.** Im Anschriftenfeld bekommt jetzt jede Person
  ihre eigene Anrede direkt vor dem Namen (vorher fehlte die Anrede bei zwei
  Personen ganz); die Briefanrede spricht jetzt beide Pflichtigen einzeln an
  (zweite Zeile für den zweiten Pflichtigen statt nur den ersten).

## [1.3.2] — 2026-07-23

### Hinzugefügt
- **Abzugsflächen je Geschoss** (Projekt-Schema v6): Kommunen können jetzt
  Bereiche von der Grundfläche eines Geschosses abziehen, die zwar innerhalb
  der Umrisspolygone liegen, aber nicht mitzählen — Luftraum bei Galerien,
  abgemauerte Bereiche. Zwei Erfassungswege: eine im Plan gezeichnete
  Abzugsfläche (Polygon-Flag) oder ein manuell eingetippter Posten je
  Geschoss (Bezeichnung + Fläche). Beide Wege fließen über die neue,
  zentrale Funktion `GF.export.abzugLageFuerGeschoss` in Geschosstabelle,
  Teilflächentabelle im Aufmaßprotokoll, Exportdatenmodell (CSV/JSON/RIWA)
  und Sidebar ein — eine Abzugsfläche wird nirgends doppelt oder gar nicht
  gezählt. Bei **anteiliger** Vollgeschoss-Anrechnung wirken die Abzüge
  bewusst nicht (die VG-Rechnung bringt mit `A_kleiner`/`A_groesser` eigene
  Abzugsgrößen mit — ein zweiter Abzug wäre Doppelerfassung); der Posten
  bleibt sichtbar, wird aber als „nicht angesetzt" ausgewiesen. Übersteigen
  die Abzüge die Grundfläche, wird auf 0 geklemmt statt negativ zu rechnen.
  Alte Projekte ohne `abzuege`-Array werden beim Laden automatisch
  nachgezogen (Forward-Migration, `GF.projekt.fuelleAbzuege`); die
  Rückrichtung gibt es nicht — v6-Projekte lassen sich in älteren
  Tool-Versionen nicht mehr öffnen.

### Dokumentation
- **Code-Obfuskation im Release-ZIP** (seit v1.3.0 aktiv, siehe Nachtrag im
  [1.3.0]-Eintrag unten) jetzt in `docs/AUSLIEFERUNG.md` dokumentiert —
  war zuvor nur im Build-Skript-Code selbst nachvollziehbar.

## [1.3.1] — 2026-07-22

### Behoben
- **Beitragsbescheid: ausstellende Behörde erscheint auch bei der Reihenfolge
  „Plan zuerst, Stammdaten danach".** Wurde ein Plan importiert, bevor eine
  `data/kommune.js` vorlag (typischer Erst-/Demo-Ablauf), legte das Tool die Akte
  mit leerem Gemeinde-Snapshot an — der Bescheid fand danach keine erlassende
  Behörde für den Briefkopf (§ 119 AO). Neu: Bei genau **einer** hinterlegten
  Gemeinde übernimmt der Bescheid diese jetzt automatisch, ohne die Akte neu
  anzulegen. Bei mehreren Gemeinden (Verwaltungsgemeinschaft) bleibt es bewusst
  bei der bestehenden Auswahlpflicht über die Projektdaten — es wird keine
  Gemeinde geraten. Benutzerhandbuch Abschnitt 16 um einen Reihenfolge-Hinweis
  ergänzt.

## [1.3.0] — 2026-07-15

### Hinzugefügt
- **Foto-Import mit 4-Punkt-Entzerrung** (vorgezogen aus der v1.4-Planung): Über
  den neuen Toolbar-Button „+ Foto" (oder Drag&Drop von JPG/PNG) lässt sich ein
  Handyfoto eines Papierplans laden. Im Entzerrungs-Dialog klickt man die vier
  Ecken eines Rechtecks mit bekannten Maßen an (Punkte nachträglich ziehbar,
  Zoom-Lupe fürs präzise Setzen), gibt Breite und Höhe in Metern ein — das Tool
  rechnet die Perspektive heraus und legt automatisch eine kalibrierte
  Plan-Region über das entzerrte Bild. Danach funktionieren Polygon-Aufmaß,
  Vollgeschoss-Beurteilung und Aufmaßprotokoll wie bei einer PDF.
  **Pflicht-Kontrollmaß:** Die Region bleibt als „Kontrollmaß offen!" markiert,
  bis eine geschriebene Bemaßung mit dem Maßstab-Werkzeug nachgemessen wurde
  (Schwelle 2 %); bei Abweichung bietet das Tool an, auf das Kontrollmaß
  umzustellen. Projektdatei-Schema auf v3 erweitert (Original-Foto wird
  archivfest mitgespeichert, die Entzerrung beim Öffnen exakt reproduziert);
  Auto-Recovery sichert Foto-Projekte jetzt ebenfalls.
- **Testabdeckung**: 26 neue Selbsttests für die Entzerrungs-Mathematik
  (Homographie, Ecken-Sortierung, Kontrollmaß, Schema v3) plus
  Container-Roundtrip mit Foto-Eintrag; die RIWA-Selbsttests laufen jetzt auch
  in test.html mit (Lücke geschlossen). Gesamt: 540 Prüfungen (inkl. der
  mit main zusammengeführten Maßstab-Redesign-Tests).
- **Maßstab-System auf main (v1.2.4–v1.2.7) zusammengeführt**: Referenzmessung
  ist jetzt auch hier der einzige manuelle Weg (Schnellwahl und Direkteingabe
  „1:N" entfernt), die persistente Status-Ampel ersetzt die alten Badges —
  siehe die Einträge [1.2.4] bis [1.2.7] unten für die Einzelheiten.

> **Nachtrag 23.07.2026 (Dokumentation, kein Code-Fix):** Seit diesem Release
> obfuskiert `tools/build-release.js` standardmäßig den eigenen `js/**`-Code im
> bezahlten Release-ZIP (Nachbauschutz). War bei Einführung nicht in diesem
> Changelog dokumentiert — nachgetragen in `docs/AUSLIEFERUNG.md`, Abschnitt
> „Code-Obfuskation im Release-ZIP".

## [1.2.7] — 2026-07-06

### Geändert
- **Update-Hinweis im Hilfemenü**: Kein manueller Download-Link mehr im
  Update-Dialog. Fehlt `update.bat` oder schlägt das Update fehl, verweist
  der Hinweistext jetzt darauf, sich an den Anbieter zu wenden, statt einen
  ZIP-Direktlink anzubieten.
- **Vollgeschoss-Beurteilung: Abweichung Grundfläche/Polygon nicht mehr im
  Aufmaßblatt.** Weicht die Polygonfläche um mehr als 5 % von `L_B × L_L`
  ab, sieht der Sachbearbeiter das weiterhin sofort im Tool (Infobox an der
  Vergleichs-Polygon-Auswahl). Im gedruckten Aufmaßblatt erscheint dieser
  Plausibilitäts-Hinweis nicht mehr — analog zur manuellen Kantenmaß-/
  Flächenkorrektur, die dort ebenfalls nicht auftaucht.

### Behoben
- **Manueller Vollgeschoss-Wert (Fläche ≥ 2,30 m): Häkchen/×-Buttons saßen
  visuell außerhalb des Eingabefelds.** Zwei CSS-Ursachen: (1) Die
  Bearbeiten-Box blieb nach Bestätigen/Abbrechen sichtbar, weil ihr eigenes
  `display: inline-flex` die `[hidden]`-Regel des Browsers aushebelte und
  sich mit dem fertigen Wert überlagerte. (2) Das Eingabefeld sollte 80 px
  breit sein, verlor aber gegen eine generischere Regel und lief auf volle
  Zeilenbreite, wodurch Einheit und Buttons aus der Box gedrängt wurden.

## [1.2.6] — 2026-07-05

*Maßstab-Redesign: „Messen ist Standard, Automatik nur bei Beweislage."
Nach Falsch-Positiven der automatischen Erkennung in der Praxis wurde das
gesamte Maßstab-System auf Sicherheit umgebaut.*

### Geändert
- **Referenzmessung ist der Standardweg**: Der Maßstab wird pro Region über
  zwei Punkte einer bekannten Bemaßung + Sollmaß gemessen. Erkennt das Tool
  nach dem Aufziehen einer Region den Maßstab nicht sicher, springt es von
  selbst ins Messwerkzeug — kein Suchen, kein Hinweis-Popup-Stapel.
- **Automatische Erkennung nur noch bei harter Beweislage**: Ein
  Vorschlags-Banner erscheint ausschließlich, wenn mindestens fünf
  unabhängige Bemaßungen exakt denselben Norm-Maßstab bestätigen (unter 1 %
  Abweichung), kein konkurrierender Maßstab nennenswert mitspielt und die
  norm-agnostische Mess-Skala nicht widerspricht. Das Banner nennt die
  Beweislage („6 Bemaßungen bestätigen, Abweichung 0,4 %"); übernommen wird
  ausschließlich per Klick — nie automatisch. „Selbst messen" startet
  direkt die Referenzmessung.
- **Eine Ampel statt zwei**: Grün = Maßstab gesetzt, Rot = fehlt, Gelb nur
  im Sonderfall „gesetzt, aber die sicher gelesene Planbemaßung weicht über
  3 % von der Messung ab" (zweites Maß empfohlen — die Messung bleibt der
  gültige Wert). Neue persistente Statusanzeige in der Sidebar; die
  Regions-Pillen folgen derselben Logik. Der Vektor-Badge oben ist jetzt
  neutral grau — er beschreibt nur noch die PDF-Qualität, nicht den Maßstab.
- **Meldungen konsolidiert**: statt gestaffelter Hinweis-/Warn-Toasts nach
  Norm-Nähe eine klare Erfolgsmeldung, Warnung nur beim echten Widerspruch
  zur Planbemaßung.

### Entfernt
- **Maßstab-Schnellwahl (1:50–1:1000) und Direkteingabe „1:N"**: Plankopf-
  Angaben können bei verzerrten oder „an Seite anpassen"-Exporten lügen —
  die Referenzmessung prüft die tatsächliche Blatt-Skala automatisch mit.
- **„Unsicher"-Vorschlag** (Banner bei nur 1–2 Belegen) ersatzlos.

### Behoben
- **1:168-Fehlalarm durch Grad-Labels endgültig geblockt**: Als Meter
  gelesene Winkel-Angaben (schräge Wände) konnten eine falsche Mess-Skala
  vortäuschen. Im neuen Gate blockt eine widersprüchliche Signallage jeden
  Vorschlag komplett — der Sachbearbeiter misst dann selbst, statt zwischen
  zwei Automatik-Meinungen wählen zu müssen.

### Hinweis
- **Bestehende Projekte bleiben unverändert**: Gesetzte Maßstäbe gelten
  weiter (Anzeige grün), keine Migration, keine Rückwirkung.

## [1.2.5] — 2026-07-04

### Behoben
- **Kein Fehlalarm mehr beim manuellen Maßstab auf detailreichen Plänen**: Bei der
  Maßstab-Direkteingabe verwarf das Tool bislang einen korrekten Nennmaßstab, wenn
  ein Plan viele Winkel- und Gradangaben enthält (etwa Grundrisse mit schrägen
  Wänden). Die norm-agnostische Bemaßungs-Messung deutete solche Grad-Labels
  fälschlich als Meter-Maße, verrechnete sie mit den langen Maßketten und „maß"
  daraus einen falschen Maßstab (z. B. 1:168 statt 1:100) — samt Empfehlung, den
  falschen Wert zu übernehmen, was die Flächen fast verdreifacht hätte. Jetzt hat
  ein sicherer Beleg-Konsens Vorrang: Bestätigen genügend echte Maßlinien den
  eingegebenen Norm-Maßstab, wird die Eingabe bestätigt statt verworfen. Der Schutz
  vor tatsächlich nicht maßstabsgetreuen Exporten (Fit-to-Page, Sammelblatt) bleibt
  unverändert erhalten — er greift weiterhin, wenn kein sicherer Norm-Konsens
  vorliegt.

## [1.2.4] — 2026-07-02

### Geändert
- **„Erstellt am" im Aufmaßblatt zeigt jetzt das Export-Datum**: Das Datum in der
  PROJEKT-Karte des Aufmaßprotokolls ist ab sofort der Zeitpunkt, an dem die PDF
  erzeugt wird — nicht mehr das Anlagedatum des Projekts. Wird ein älterer Vorgang
  erneut geöffnet und exportiert, trägt das Blatt das dann-aktuelle Datum.

## [1.2.3] — 2026-06-25

### Hinzugefügt
- **Manuelle Korrektur der Fläche ≥ 2,30 m in der Vollgeschoss-Beurteilung**: Der
  errechnete Wert der Fläche mit einer lichten Höhe von mindestens 2,30 m lässt
  sich jetzt direkt in der VG-Maske von Hand nachjustieren — genau wie ein
  Kantenmaß beim Polygon, wenn es um Zentimeter nicht passt. Der korrigierte Wert
  ist maßgeblich und zieht durch: der Anteil ≥ 2,30 m, das Vollgeschoss-Urteil und
  die anrechenbare Fläche rechnen damit. Der errechnete Ausgangswert bleibt intern
  erhalten; ändert man danach eine geometrische Eingabe, verfällt die Korrektur
  automatisch.

### Geändert
- **Kein Korrektur-Vermerk mehr im Aufmaßprotokoll**: Wird eine Teilfläche manuell
  überschrieben, druckt das Protokoll nur noch den angesetzten Wert — der frühere
  Zusatz „manuelle Korrektur" bzw. „gemessen … manuell angesetzt …" entfällt. Dass
  korrigiert wurde, bleibt im Tool sichtbar (orange Markierung); im CSV-/JSON-Export
  bleibt das Feld erhalten.

## [1.2.2] — 2026-06-25

### Hinzugefügt
- **Maßstabs-Abgleich gegen die Planbemaßung**: Bei der Maßstab-Direkteingabe
  gleicht das Tool den eingegebenen Nennmaßstab jetzt still gegen die im Plan
  gemessenen Bemaßungen ab. Ist ein PDF zwar elektronisch (Vektor), aber nicht
  maßstabsgetreu exportiert (etwa „Auf Seite anpassen", verkleinerte
  Ausfertigung oder Sammelblatt mit mehreren Maßstäben), weicht der eingegebene
  Nennmaßstab von der tatsächlich gemessenen Skala ab. Das Tool meldet das dann
  („Planbemaßung ergibt 1:52, eingegeben wurde 1:50") und bietet an, den
  gemessenen Maßstab zu übernehmen. Stimmen beide überein, bestätigt es kurz; ist
  keine Bemaßung lesbar, bleibt alles unverändert (kein Fehlalarm im Normalfall).
- **Nicht maßstabsgetreue Pläne im Aufmaßprotokoll ausgewiesen**: Weicht der
  Maßstab einer Region spürbar vom Norm-Maßstab ab, vermerkt das Protokoll dies
  („nicht maßstabsgetreu, X % Abweichung") als Transparenz für die
  Beitragsgrundlage.

### Geändert
- Der Hinweis bei erkanntem Vektor-PDF verspricht nicht mehr pauschal
  „Direkteingabe zuverlässig", sondern stellt klar, dass der Nennmaßstab nur bei
  unskaliertem Export stimmt und gegen die Bemaßung abgeglichen wird.

## [1.2.1] — 2026-06-21

### Behoben
- **In-Programm-Update-Prüfung von `file://` repariert**: Der „Auf Updates
  prüfen"-Knopf rief die Update-Adressen über `drakman07.github.io` ab. Seit
  die Custom-Domain an GitHub Pages hängt, antwortet diese mit einem
  301-Redirect ohne `Access-Control-Allow-Origin`-Header — ein `fetch()` aus
  der lokal geöffneten `index.html` (Herkunft „null") scheitert daran an der
  CORS-Prüfung, sodass das Tool „Update-Server nicht erreichbar" meldete. Die
  drei Adressen (`VERSION_CHECK_URL` und `DOWNLOAD_URL` in `js/version.js`,
  `ALLOWLIST_URL` in `js/lizenz.js`) zeigen jetzt direkt auf
  `https://download.flaechenklar.de/…` (liefert `Access-Control-Allow-Origin:
  *` ohne Redirect). Der `update.bat`/`update.ps1`-Weg war nie betroffen und
  bleibt unverändert; die Adressen dort wurden zur Konsistenz mitgezogen.

## [1.2.0] — 2026-06-21

### Hinzugefügt
- **Daten-Export (CSV und JSON)**: Das Aufmaß lässt sich zusätzlich zum
  PDF-Protokoll als CSV (Tabellenkalkulation) und JSON (maschinenlesbar)
  ausgeben — Geschosse, Regionen und anrechenbare Flächen strukturiert für
  die Weiterverarbeitung. Neue Module `js/exportdaten.js` (Datenmodell) und
  `js/exportformat.js` (CSV-/JSON-Writer).
- **Vektor-Snapping (Magnet)**: Beim Zeichnen rasten Eck- und Stützpunkte an
  den Original-Vektorlinien maßhaltiger CAD-PDFs ein. `Shift` beim Klick
  schaltet den Snap kurzzeitig aus. Neues Modul `js/snap.js` (KD-Baum-Index
  über die PDF-Vektoren).
- **Maßketten-Auto-Maßstab**: Das Tool liest die Bemaßung (Maßketten) aus
  Vektor-PDFs aus und schlägt den Maßstab automatisch vor; bei drei
  übereinstimmenden Belegen gilt die Einstufung als sicher. Manuelles
  Kalibrieren entfällt bei maßhaltigen Plänen. Erweiterung in
  `js/pdf-massketten.js` / `js/pdf-vektor.js`.
- **Rechteck-Werkzeug**: Rechteckige Flächen mit zwei Klicks über die
  Diagonale anlegen statt mit vier Einzelpunkten. Mündet in den bestehenden
  Polygon-Speicherpfad — Validierung, VG-Berechnung und Export bleiben
  unverändert. Neues Modul `js/rechteck.js`.
- **Plan mit Leertaste pannen**: `Leertaste` halten und ziehen verschiebt den
  Plan mit der Maus — auch während einer laufenden Polygon-Zeichnung.
  Im Kürzel-Dialog und Benutzerhandbuch dokumentiert.

### Geändert
- **Maßstab-Statusanzeige** überarbeitet (`js/massstab-ui.js`): klarere
  Banner- und Badge-Darstellung der aktiven Maßstab-Quelle (Referenzstrecke,
  Direkteingabe, Maßketten-Vorschlag), insbesondere beim parallelen Arbeiten
  an mehreren Plänen.
- **Release-Build** (`tools/build-release.js`): Manifest um
  `assets/fonts/*.woff2` und die zugehörige OFL-Lizenz erweitert, damit die
  Geist-Schriften im Kunden-ZIP enthalten sind (sonst Arial-Fallback).
- Test-Suite um die neuen Module erweitert (Rechteck, Vektor-Snapping,
  Maßketten, Daten-Export) — `test.html`.

## [1.1.0] — 2026-06-15

### Hinzugefügt
- **Maßstab-Direkteingabe** (für maßhaltige CAD-/Vektor-PDFs): Methodenwahl im
  Maßstab-Werkzeug — Weg A „Maßstab direkt eingeben" (Schnell-Buttons
  1:50/1:100/1:200/1:500/1:1000 oder Feld „1 : ___", nur Ganzzahl) neben dem
  bisherigen Weg B (Referenzstrecke). Das Tool erkennt den Vektor-Anteil der PDF
  (grün „Vektor-PDF erkannt", gelb „gemischt"); bei erkannten Scans ist die
  Direkteingabe gesperrt (fail-closed).
- **Variable Anrechnungs-Grenzhöhe** (kommunale Satzung, z. B. 1,50 m statt 2,30 m):
  - Neues Eingabefeld „Grenzhöhe" im VG-Modal (projektweit, Default 2,30 m,
    Bereich 0,50–3,00 m). Änderung rechnet alle gespeicherten VG-Berechnungen
    des Projekts automatisch nach.
  - Berechnung liefert zusätzlich `A_anrechenbar` (Fläche ≥ Grenzhöhe).
    Die Vollgeschoss-Beurteilung (2/3-Regel) bleibt unverändert bei 2,30 m
    nach Art. 83 Abs. 7 BayBO.
  - Querschnitt (Modal + PDF) zeigt bei abweichender Grenzhöhe eine zweite
    Linie in Teal mit eigener Schraffur für die anrechenbare Zone.
  - Anteiliger Export nutzt die anrechenbare Fläche; Aufmaßblatt, Export-Dialog,
    VG-Beurteilungsblatt und Methodik-Texte dokumentieren die verwendete
    Grenzhöhe. Bei 2,30 m bleiben alle Ausgaben wortidentisch zu v1.0.
  - Projekt-Schema: optionales `metadata.grenzhoeheAnrechnung` (Schema-Version
    bleibt 2, alte Projekte laden unverändert mit Default 2,30).
- **Rechenweg im Aufmaßprotokoll** (opt-in): Häkchen „Rechenweg anzeigen" im
  Export-Dialog ergänzt explizite Additions-Schritte der Teilflächen je Region
  und der Geschosse zur Gesamtfläche (Bürger-Nachvollziehbarkeit).
- **Rechenweg-Herleitung je Teilfläche** (Teil des Rechenweg-Häkchens):
  rechteckige Teilflächen als „Länge × Breite = Fläche" direkt unter der
  Polygon-Tabelle, unregelmäßige Flächen als Gauß-Koordinatentabelle mit
  Formelzeile auf eigenen Rechenweg-Anhangseiten (Seitenzählung läuft mit;
  manuell korrigierte Flächen: gemessener Wert hergeleitet, angesetzter
  ausgewiesen).

### Geändert
- `test.html` lädt jetzt auch `js/export.js` — die exportAnrechnung-Tests
  liefen vorher nie (Bestandslücke).
- `test.html` rendert und zählt die exportAnrechnung-Testgruppe jetzt mit —
  die Gruppe lief zwar, fehlte aber in Anzeige und Gesamtzahl (Suite zeigt
  jetzt 197 statt 168 Prüfungen).
- `vg-geometrie.js`: doppelte lokale 2,30-Konstanten zu einer Modul-Konstante
  zusammengeführt.

## [1.0.0] — 2026-05-16

Erstes stabiles Release. Solo-Dev-Tool für bayerische Bauämter.

### Hinzugefügt (Phase A8)
- Reproduzierbarer Release-Build via `npm run build-release` (Allowlist-Manifest, SHA256-Integritaetscheck, Self-Verify)
- `version.txt` im Release-ZIP-Root verhindert Update-Endlosschleife bei Erstinstallationen
- `update.ps1`: ZipSlip-Defense vor Expand-Archive (Defense-in-Depth, SHA256-Check fängt's bereits)

### Geändert
- `update.ps1`: selektives `data/`-Exclude — `data/*.example.js`-Updates kommen jetzt beim Kunden an (war: komplettes `data/` ausgeschlossen)
- `DOWNLOAD_URL` zeigt auf das öffentliche Update-Repo (war: `example.com`-Placeholder)
- VERSION von `0.1.0-dev` auf `1.0.0`

### Stand der vorigen Phasen
- A1–A5: VG-Integration (Vollgeschoss-Berechnung Art. 83 Abs. 7 BayBO)
- A6: Lizenz-Workflow mit SHA256-Whitelist auf GitHub Pages
- A7: Vorgänger-VG-Tool als archiviert markiert
- B1–B3: TypeScript-Migration via JSDoc + `tsc --checkJs`

## [0.1.0-dev] — 2026-05-12

### Hinzugefügt
- Phase-0-Skelett: Verzeichnisstruktur, klassische Scripts mit `window.GF.*`-Namespace
- Lizenzsystem aus VG-Tool übernommen, ID-Präfix auf `GF-` umgestellt
- Update-Mechanismus (`update.bat` + `update.ps1`) 1:1 aus VG-Tool
- Plan-Datei und SPEC.md angelegt
- Test-Runner (`test.html`) mit ersten Unit-Tests für `util`, `polygon`, `region`, `projekt`, `lizenz`
- Stubs für PDF-Loading, Region/Geschoss/Polygon-Verwaltung, Projekt-Speicherung, Export
- Auto-Recovery via IndexedDB (Wrapper)

### Bekannte Einschränkungen (Phase 0)
- `lib/pdf.min.js`, `lib/pdf.worker.min.js`, `lib/fflate.min.js` müssen manuell besorgt werden (`lib/README.md`)
- `GF.projekt.speichere/lade` und `GF.export.aufmassprotokoll` sind Stubs (Phase 4/5)
- Keine UI für PDF-Anzeige (Phase 1)
