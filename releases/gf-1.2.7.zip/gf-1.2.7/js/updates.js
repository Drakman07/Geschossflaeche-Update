// @ts-check
// Update-Check fuer FlaechenKlar.
// Prueft zuerst Whitelist (Wartung aktiv?), dann Versions-Datei.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  /** @param {string} id @returns {HTMLElement | null} */
  function $(id) { return document.getElementById(id); }

  /** @param {string} msg @param {string} [kind] */
  function showToast(msg, kind) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast aktiv' + (kind ? ' ' + kind : '');
    clearTimeout(/** @type {any} */ (showToast)._t);
    /** @type {any} */ (showToast)._t = setTimeout(function () { t.classList.remove('aktiv'); }, 4500);
  }

  /**
   * Vergleicht zwei Versions-Strings. Nimmt nur den numerischen Prefix
   * "x.y.z" — ein Pre-Release-Suffix wie "-dev" oder "-rc1" wird ignoriert
   * (sonst wuerden Number("0-dev") = NaN unbemerkt zu 0 kollabieren).
   * Liefert -1 wenn a<b, 0 wenn gleich, 1 wenn a>b.
   * @param {string} a
   * @param {string} b
   * @returns {-1 | 0 | 1}
   */
  function vergleiche(a, b) {
    var as = teile(a), bs = teile(b);
    for (var i = 0; i < 3; i++) {
      if (as[i] < bs[i]) return -1;
      if (as[i] > bs[i]) return  1;
    }
    return 0;
  }

  /**
   * @param {string} v
   * @returns {[number, number, number]}
   */
  function teile(v) {
    var m = String(v).trim().match(/^(\d+)\.(\d+)\.(\d+)/);
    return m ? [+m[1], +m[2], +m[3]] : [0, 0, 0];
  }

  /** @param {string} neueVersion */
  function zeigeUpdateModal(neueVersion) {
    var bd = $('updateBackdrop');
    var body = $('updateBody');
    var titel = $('updateTitel');
    var dl = $('updateDownload');
    var btnSpaeter = $('updateSpaeter');
    if (!bd || !body) return;
    if (titel) titel.textContent = 'Update verfügbar';
    // Kein manueller Download: Update laeuft ausschliesslich ueber update.bat.
    if (dl) dl.style.display = 'none';
    if (btnSpaeter) btnSpaeter.textContent = 'Später';
    // Statisches HTML mit Platzhalter-Spans; Versions-Strings werden per
    // textContent eingesetzt (Defense-in-Depth gegen kuenftige Server-Daten-XSS).
    body.innerHTML =
      '<p>Es ist eine neue Version verfügbar:</p>'
    + '<p><strong>Aktuell installiert:</strong> <span data-rolle="lokal"></span><br>'
    + '<strong>Verfügbar:</strong> <span data-rolle="fern"></span></p>'
    + '<p><strong>So installieren Sie das Update:</strong></p>'
    + '<ol style="margin:6px 0 10px 18px; padding:0; line-height:1.5;">'
    + '<li>Schließen Sie diese App (Browser-Tab schließen).</li>'
    + '<li>Öffnen Sie den Programm-Ordner im Datei-Explorer.</li>'
    + '<li>Doppelklicken Sie <code>update.bat</code> — das Update laedt und installiert sich selbst.</li>'
    + '<li>Ihre gemeindespezifischen Daten (Wappen, Lizenz) bleiben unverändert.</li>'
    + '</ol>'
    + '<p style="font-size:12px; color:var(--text-muted);">Fehlt <code>update.bat</code> oder klappt das Update nicht, wenden Sie sich bitte an den Anbieter — er spielt die neue Version für Sie ein.</p>';
    var lok = body.querySelector('[data-rolle="lokal"]');
    if (lok) lok.textContent = String((global.GF && global.GF.VERSION) || '?');
    var fern = body.querySelector('[data-rolle="fern"]');
    if (fern) fern.textContent = String(neueVersion);
    bd.classList.add('aktiv');
  }

  function zeigeWartungAbgelaufenModal() {
    var bd = $('updateBackdrop');
    var body = $('updateBody');
    var titel = $('updateTitel');
    var dl = $('updateDownload');
    var btnSpaeter = $('updateSpaeter');
    if (!bd || !body) return;
    if (titel) titel.textContent = 'Wartungsvertrag abgelaufen';
    if (dl) dl.style.display = 'none';
    if (btnSpaeter) btnSpaeter.textContent = 'Schließen';
    body.innerHTML =
      '<p><strong>Ihr Wartungsvertrag für Software-Updates ist abgelaufen.</strong></p>'
    + '<p>Ihre aktuelle Programmversion laeuft unbegrenzt weiter. '
    + 'Um neue Versionen zu erhalten, erneuern Sie bitte Ihren Wartungsvertrag beim Anbieter.</p>';
    bd.classList.add('aktiv');
  }

  function zeigeDemoModal() {
    var bd = $('updateBackdrop');
    var body = $('updateBody');
    var titel = $('updateTitel');
    var dl = $('updateDownload');
    var btnSpaeter = $('updateSpaeter');
    if (!bd || !body) return;
    if (titel) titel.textContent = 'Demo-Version';
    if (dl) dl.style.display = 'none';
    if (btnSpaeter) btnSpaeter.textContent = 'Schließen';
    body.innerHTML =
      '<p><strong>Diese Installation ist eine Demo-Version.</strong></p>'
    + '<p>Updates sind nur für lizenzierte Installationen verfügbar.</p>';
    bd.classList.add('aktiv');
  }

  function schliesseUpdateModal() {
    var bd = $('updateBackdrop');
    if (bd) bd.classList.remove('aktiv');
  }

  /** @type {AbortController | null} */
  var laufenderRequest = null;

  function pruefe() {
    if (!global.GF || !global.GF.lizenz || !global.GF.lizenz.pruefeWhitelist) {
      showToast('Lizenz-Modul nicht geladen.', 'warn');
      return;
    }
    var btn = /** @type {HTMLButtonElement | null} */ ($('btnUpdate'));
    if (btn) btn.disabled = true;
    showToast('Prüfe Wartungs-Status ...');

    global.GF.lizenz.pruefeWhitelist().then(function (lz) {
      if (!lz.ok) {
        if (lz.grund === 'netzwerk') {
          showToast('Update-Server nicht erreichbar. Internet prüfen.', 'warn');
        } else if (lz.grund === 'kaputt') {
          showToast('Update-Server lieferte ungültige Daten.', 'warn');
        } else if (lz.modus === 'demo') {
          zeigeDemoModal();
        } else {
          zeigeWartungAbgelaufenModal();
        }
        if (btn) btn.disabled = false;
        return;
      }
      starteVersionCheck(btn);
    });
  }

  /** @param {HTMLButtonElement | null} btn */
  function starteVersionCheck(btn) {
    var url = global.GF && global.GF.VERSION_CHECK_URL;
    if (!url) {
      showToast('Update-URL nicht konfiguriert.', 'warn');
      if (btn) btn.disabled = false;
      return;
    }
    if (laufenderRequest) {
      try { laufenderRequest.abort(); } catch (e) {}
      laufenderRequest = null;
    }

    var ctrl = (typeof AbortController === 'function') ? new AbortController() : null;
    laufenderRequest = ctrl;
    var timer = setTimeout(function () {
      if (ctrl) { try { ctrl.abort(); } catch (e) {} }
    }, 8000);

    showToast('Suche nach Updates ...');

    /** @type {RequestInit} */
    var fetchOpts = { cache: 'no-store' };
    if (ctrl) fetchOpts.signal = ctrl.signal;

    fetch(url + (url.indexOf('?') < 0 ? '?' : '&') + 't=' + Date.now(), fetchOpts)
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(function (txt) {
        var zeilen = String(txt).trim().split(/\r?\n/);
        var fern = (zeilen[0] || '').trim().split(/\s+/)[0];
        // Strikt x.y.z (kein Pre-Release-Suffix). Konsistent mit update.ps1.
        if (!/^\d+\.\d+\.\d+$/.test(fern)) {
          throw new Error('ungültiges Versionsformat: "' + fern + '"');
        }
        var cmp = vergleiche((global.GF && global.GF.VERSION) || '0.0.0', fern);
        if (cmp >= 0) {
          showToast('Du nutzt die aktuelle Version (' + (global.GF && global.GF.VERSION) + ').', 'success');
        } else {
          zeigeUpdateModal(fern);
        }
      })
      .catch(function (err) {
        var name = err && err.name;
        if (name === 'AbortError') {
          showToast('Update-Prüfung abgebrochen (Zeitüberschreitung). Verbindung prüfen.', 'warn');
        } else {
          showToast('Update-Prüfung fehlgeschlagen — keine Internetverbindung?', 'danger');
        }
        console.warn('[gf-updates]', err);
      })
      .then(function () {
        clearTimeout(timer);
        if (laufenderRequest === ctrl) laufenderRequest = null;
        if (btn) btn.disabled = false;
      });
  }

  function init() {
    // btnUpdate gibt es ab Hilfe-Menue nicht mehr — Update-Aufruf erfolgt
    // ueber GF.updates.pruefe() aus js/hilfe.js.
    var spaeter = $('updateSpaeter');
    if (spaeter) spaeter.addEventListener('click', schliesseUpdateModal);
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.updates = { pruefe: pruefe, vergleiche: vergleiche };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
