# ===================================================================
#  FlaechenKlar Start-Launcher (PowerShell)
#  -------------------------------------------------------------------
#  Wird von FlaechenKlar.bat aufgerufen. Ablauf:
#    0. Staged Bootstrap-Zwillinge (X.neu -> X) uebernehmen (best effort,
#       still) -- eigene Naht, siehe UebernehmeNeu weiter unten.
#    1. update.ps1 -NurPruefen als eigener Prozess starten (Exit-Code
#       auswerten) -- dieselbe Pruef-Naht wie der manuelle Weg, keine
#       zweite Lizenz-/Versionslogik hier.
#    2. Exit-Code 10 (Update verfuegbar+berechtigt) -> changelog.json
#       laden (best effort, rein Anzeige), Dialog zeigen: eigenes
#       WinForms-Fenster (Versionen als Abschnitte, scrollbar), bei
#       Fehler eine kurze MessageBox ohne Punkte.
#    3. Ja -> update.bat sichtbar ausfuehren (bestehende UX/Meldungen),
#       warten. Nein oder alles andere -> ohne Ruecksprache weiter.
#    4. Tool oeffnen (start.html -> index.html?start=fk).
#
#  Netzwerkfehler/Timeout an jeder Stelle sind KEIN Fehlerfall fuer den
#  Start: das Tool bleibt eine Offline-Anwendung und darf nie haengen
#  bleiben oder den Start blockieren.
#
#  Exit-Codes -- FlaechenKlar.bat wertet sie aus und oeffnet bei allem
#  ungleich 0 das Tool ersatzweise selbst:
#     0  = Tool wurde geoeffnet (auch wenn das Update uebersprungen wurde)
#     3  = Tool liess sich auf keinem Weg oeffnen
#     4  = unerwarteter Fehler, Tool liess sich auch danach nicht oeffnen
#     5  = Fehler im Vorschau-Modus (-DialogVorschau, siehe unten)
# ===================================================================

param([switch]$NurFinalize, [switch]$DialogVorschau, [string]$VorschauLokal = '0.0.0')

$ErrorActionPreference = 'Stop'

$installDir = $PSScriptRoot

# --- Self-Replace-Finalizer -------------------------------------------------
# Staged Bootstrap-Zwillinge (X.neu) uebernehmen, solange das Ziel NICHT als
# Prozess laeuft. launcher.ps1.neu bleibt bewusst aussen vor (dieses Skript
# laeuft gerade) - die uebernimmt FlaechenKlar.bat vor dem Start. Alles
# best-effort und still: ein Fehler darf den Start nie blockieren.
function UebernehmeNeu {
    param([string[]]$Namen)
    foreach ($name in $Namen) {
        try {
            $neu = Join-Path $installDir ($name + '.neu')
            if ((Test-Path -LiteralPath $neu) -and ((Get-Item -LiteralPath $neu).Length -gt 0)) {
                Move-Item -LiteralPath $neu -Destination (Join-Path $installDir $name) -Force
            }
        } catch { }
    }
}
# FlaechenKlar.bat nur uebernehmen, wenn sie NICHT gerade laeuft. Seit die
# .bat blockierend auf diesen Launcher wartet, parkt cmd.exe die ganze Zeit
# in ihrer Aufrufzeile; ein Tausch hier wuerde cmd im neuen Inhalt am alten
# Byte-Offset weiterlesen lassen (gemessen: Rest der Datei faellt aus, die
# Exit-Code-Auswertung und der Ersatzweg entfallen). Die laufende .bat
# setzt FK_BAT_LAEUFT und tauscht ihren Zwilling selbst - als allerletzte
# Anweisung, gefolgt von einem Neustart.
$eigene = @('update.ps1', 'update.bat')
if (-not $env:FK_BAT_LAEUFT) { $eigene = @('FlaechenKlar.bat') + $eigene }
UebernehmeNeu -Namen $eigene

if ($NurFinalize) { exit 0 }

# --- TLS 1.2 erzwingen (nur PS 5.1 / .NET Framework relevant) ------------
# Gleiche Naht wie in update.ps1: PS 5.1 startet sonst mit TLS 1.0, der
# Update-Server spricht nur TLS 1.2+. Unter PowerShell 7 wirkungslos, aber
# unschaedlich (IWR/IRM nutzen dort HttpClient und ignorieren dieses Flag).
# Hier betrifft es nur Changelog und Versionsanzeige (beide best effort);
# try/catch bleibt bewusst still schluckend - der Start darf nie blockieren.
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$updatePs1    = Join-Path $installDir 'update.ps1'
$updateBat    = Join-Path $installDir 'update.bat'
$startHtml    = Join-Path $installDir 'start.html'
$versionDatei = Join-Path $installDir 'version.txt'
$changelogUrl = 'https://download.flaechenklar.de/changelog.json'
$versionUrl   = 'https://download.flaechenklar.de/version.txt'

# Merker fuer den trap weiter unten: steht das Tool schon offen, darf ein
# spaeterer Fehler es nicht ein zweites Mal aufmachen.
$script:toolOffen = $false

# --- Tool oeffnen -----------------------------------------------------------
# Mehrstufig und garantiert wurffrei. Frueher war das ein nacktes
# Start-Process an drei ungeschuetzten Aufrufstellen: fehlte die
# .html-Zuordnung oder war der Standardbrowser per Richtlinie gesperrt,
# starb das Skript unter $ErrorActionPreference = 'Stop' terminierend --
# und der Kunde sah gar nichts. Jede Stufe ist deshalb einzeln gekapselt;
# die Funktion wirft nie, sondern meldet per Rueckgabewert, ob das Tool
# offen ist.
function OeffneTool {
    $ziel = $startHtml
    if (-not (Test-Path -LiteralPath $ziel)) {
        $ziel = Join-Path $installDir 'index.html'
    }
    if (-not (Test-Path -LiteralPath $ziel)) {
        Write-Host ('FEHLER: Weder start.html noch index.html gefunden in ' + $installDir)
        return $false
    }

    # Stufe 1: Dateizuordnung fuer .html (Normalfall).
    try {
        Start-Process -FilePath $ziel -ErrorAction Stop
        $script:toolOffen = $true
        return $true
    } catch {
        Write-Host ('Stufe 1 (Dateizuordnung) fehlgeschlagen: ' + $_.Exception.Message)
    }

    # Stufe 2: URL-Handler. Greift auch ohne .html-Zuordnung, weil url.dll
    # den fuer http hinterlegten Standardbrowser benutzt.
    try {
        Start-Process -FilePath 'rundll32.exe' `
            -ArgumentList ('url.dll,FileProtocolHandler "' + $ziel + '"') -ErrorAction Stop
        $script:toolOffen = $true
        return $true
    } catch {
        Write-Host ('Stufe 2 (url.dll) fehlgeschlagen: ' + $_.Exception.Message)
    }

    # Stufe 3: Standardbrowser ueber die Registry aufloesen und direkt mit
    # dem Dateipfad aufrufen.
    try {
        $progId = (Get-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice' -ErrorAction Stop).ProgId
        $cmd = (Get-ItemProperty -Path ('Registry::HKEY_CLASSES_ROOT\' + $progId + '\shell\open\command') -ErrorAction Stop).'(default)'
        $m = [regex]::Match($cmd, '^\s*"([^"]+)"')
        if (-not $m.Success) { $m = [regex]::Match($cmd, '^\s*(\S+)') }
        if ($m.Success) {
            Start-Process -FilePath $m.Groups[1].Value `
                -ArgumentList ('"' + $ziel + '"') -ErrorAction Stop
            $script:toolOffen = $true
            return $true
        }
        Write-Host 'Stufe 3 (Standardbrowser): Befehlszeile nicht lesbar.'
    } catch {
        Write-Host ('Stufe 3 (Standardbrowser) fehlgeschlagen: ' + $_.Exception.Message)
    }

    # Stufe 4: bekannte Browser ueber die App-Paths der Registry probieren.
    foreach ($exe in @('msedge.exe', 'chrome.exe', 'firefox.exe')) {
        try {
            Start-Process -FilePath $exe -ArgumentList ('"' + $ziel + '"') -ErrorAction Stop
            $script:toolOffen = $true
            return $true
        } catch { }
    }

    Write-Host 'FEHLER: Kein Weg gefunden, das Tool zu oeffnen (Stufen 1-4 erschoepft).'
    return $false
}

# Fehlermeldung, die der Kunde auch dann sieht, wenn er nur auf die .bat
# doppelklickt: Konsolenzeile (landet im Start-Protokoll) plus MessageBox.
function MeldeStartFehler {
    param([string]$Text)
    Write-Host ''
    Write-Host ('FEHLER: ' + $Text)
    # FlaechenKlar.bat reicht den tatsaechlichen Protokollpfad per
    # FK_STARTLOG durch. Ohne das stuende hier "im Programmordner", obwohl
    # die .bat bei nicht beschreibbarem Ordner nach %TEMP% ausgewichen sein
    # kann - der Kunde suchte dann an der falschen Stelle.
    $protokoll = $env:FK_STARTLOG
    if (-not $protokoll) { $protokoll = Join-Path $installDir 'FlaechenKlar-Start.log' }
    Write-Host ('Protokoll: ' + $protokoll)
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $hinweis = $Text + "`n`nEinzelheiten stehen in:`n" + $protokoll +
            "`n`nBitte senden Sie diese Datei an info@flaechenklar.de."
        [System.Windows.Forms.MessageBox]::Show(
            $hinweis, 'FlaechenKlar', [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    } catch { }
}

# Gemeinsame Ausstiegsnaht: alle drei Stellen, die frueher blank
# "OeffneTool; exit 0" gemacht haben, laufen jetzt hierueber.
function OeffneUndBeende {
    if (OeffneTool) { exit 0 }
    MeldeStartFehler 'Das Tool liess sich nicht oeffnen.'
    exit 3
}

# Letztes Netz: jeder terminierende Fehler ab hier landet als Text im
# Start-Protokoll, und das Tool wird trotzdem noch geoeffnet.
trap {
    # Ein trap gilt fuer den ganzen Scope, also auch fuer den Finalizer-Block
    # weiter oben. Ohne diese Zeile wuerde ein -NurFinalize-Lauf bei einem
    # Fehler dort das Tool oeffnen und 3 oder 4 liefern - die Zusicherung
    # "finalize-only startet nichts" haengt daran.
    if ($NurFinalize) { exit 0 }
    Write-Host ''
    Write-Host ('UNERWARTETER FEHLER: ' + $_.Exception.Message)
    try { Write-Host ('  ' + $_.InvocationInfo.PositionMessage) } catch { }
    if ($DialogVorschau) { exit 5 }
    if ($script:toolOffen) { exit 0 }
    if (OeffneTool) { exit 0 }
    MeldeStartFehler 'Das Tool liess sich nach einem unerwarteten Fehler nicht oeffnen.'
    exit 4
}


# --- Vorbereitung: Changelog-Aufbereitung (Funktionen) ------------------
# Steht VOR Schritt 1, weil der Vorschau-Modus (-DialogVorschau) diese
# Funktionen ohne Update-Pruefung braucht. Netz gibt es erst in Schritt 2.
# Reine Anzeige: eine leere oder unlesbare version.txt darf den Start
# nicht in den trap schicken (dort entfiele die Update-Pruefung).
$lokal = '0.0.0'
try {
    if (Test-Path $versionDatei) {
        $gelesen = [string](Get-Content $versionDatei -First 1)
        if ($gelesen.Trim() -ne '') { $lokal = $gelesen.Trim() }
    }
} catch { }

# Nicht mehr als 5 Versionen im Dialog. Frueher galt "8 Punkte": die
# Punkte in changelog.json sind seit 1.5.4 ganze Absaetze (300-1000
# Zeichen), in einer MessageBox ohne Breite und ohne Scrollen ergab das
# eine Textsaeule von 1300 px Hoehe. Das eigene Fenster unten scrollt,
# darum zaehlt jetzt die Version, nicht der Punkt. Was darueber liegt,
# wird als eine Zeile "sowie N aeltere Versionen" genannt.
$MAX_VERSIONEN = 5

function VersionsTeile([string]$v) {
    $m = [regex]::Match($v, '^(\d+)\.(\d+)\.(\d+)')
    if ($m.Success) {
        return @([int]$m.Groups[1].Value, [int]$m.Groups[2].Value, [int]$m.Groups[3].Value)
    }
    return @(0, 0, 0)
}

function VersionGroesserAls([string]$a, [string]$b) {
    $ta = VersionsTeile $a
    $tb = VersionsTeile $b
    for ($i = 0; $i -lt 3; $i++) {
        if ($ta[$i] -gt $tb[$i]) { return $true }
        if ($ta[$i] -lt $tb[$i]) { return $false }
    }
    return $false
}

# Reine Datenaufbereitung, ohne Netz: Liste aus changelog.json ->
# @(@{ Version; Datum; Punkte }) absteigend, nur neuer als $Lokal,
# gekappt auf $MAX_VERSIONEN; Aeltere = Zahl der weggelassenen Versionen.
function WaehleVersionen([string]$Lokal, [object[]]$Liste) {
    $versionen = @()
    $aeltere = 0
    $neuere = @($Liste | Where-Object { ($null -ne $_) -and (VersionGroesserAls ([string]$_.version) $Lokal) })
    # Sortierschluessel aus VersionsTeile statt [version]$_.version: ein
    # Eintrag wie "1.5.8-beta" oder "2" wuerde sonst die ganze Liste werfen.
    $neuere = @($neuere | Sort-Object -Property @{ Expression = { [version]((VersionsTeile ([string]$_.version)) -join '.') } } -Descending)
    foreach ($eintrag in $neuere) {
        if ($versionen.Count -ge $MAX_VERSIONEN) { $aeltere++; continue }
        $punkte = @()
        foreach ($p in @($eintrag.punkte)) {
            if (($p -is [string]) -and ($p.Trim() -ne '')) { $punkte += $p.Trim() }
        }
        if ($punkte.Count -eq 0) { continue }
        $versionen += @{
            Version = [string]$eintrag.version
            Datum   = [string]$eintrag.datum
            Punkte  = $punkte
        }
    }
    return @{ Versionen = $versionen; Aeltere = $aeltere }
}

function FormatiereDatum([string]$Iso) {
    try {
        return [datetime]::ParseExact($Iso, 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture).ToString('dd.MM.yyyy')
    } catch {
        return $Iso.Trim()
    }
}

# --- Vorbereitung: Dialog (Funktionen) ----------------------------------
# Eigenes WinForms-Fenster statt MessageBox: feste Breite, Versionen als
# Abschnitte mit Datum, jeder Punkt ein Absatz mit haengendem Einzug,
# senkrecht scrollbar. Die Datei bleibt ASCII (Test
# tools/test-launcher-startfehler.js), Umlaute entstehen deshalb ueber
# [char]-Codes. Liefert $true fuer "Jetzt aktualisieren", sonst $false.
# Wirft bei fehlendem WinForms; der Aufrufer faellt dann auf die
# MessageBox ohne Punkte zurueck.
function ZeigeUpdateDialog([string]$NeueVersion, [string]$Lokal, [object[]]$Versionen, [int]$Aeltere) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    # Variablennamen sind in PowerShell nicht case-sensitiv: $ae und $AE
    # waeren dieselbe Variable, daher $aeGross.
    $ae = [char]0xE4; $ue = [char]0xFC; $aeGross = [char]0xC4; $punktZeichen = [char]0x2022

    $navy    = [System.Drawing.Color]::FromArgb(15, 45, 90)
    $teal    = [System.Drawing.Color]::FromArgb(30, 165, 150)
    $grau    = [System.Drawing.Color]::FromArgb(90, 90, 90)
    $schwarz = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $weiss   = [System.Drawing.Color]::White

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Fl' + $ae + 'chenKlar Update'
    $form.StartPosition = 'CenterScreen'
    $form.Size = New-Object System.Drawing.Size(740, 620)
    # Breite 700: darunter laufen Hinweistext und Knoepfe im Fuss ineinander.
    $form.MinimumSize = New-Object System.Drawing.Size(700, 420)
    # Ohne Owner kann das Fenster hinter der Konsole landen (Fokus-Schutz
    # von Windows); TopMost holt es nach vorn, der Dialog ist ohnehin modal.
    $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $form.BackColor = $weiss
    $form.MaximizeBox = $false
    $form.ShowIcon = $false

    # Kopf
    $kopf = New-Object System.Windows.Forms.Panel
    $kopf.Dock = 'Top'; $kopf.Height = 78; $kopf.BackColor = $navy
    $titel = New-Object System.Windows.Forms.Label
    $titel.Text = 'Neue Version ' + $NeueVersion + ' verf' + $ue + 'gbar'
    $titel.ForeColor = $weiss
    $titel.Font = New-Object System.Drawing.Font('Segoe UI', 15, [System.Drawing.FontStyle]::Bold)
    $titel.AutoSize = $true
    $titel.Location = New-Object System.Drawing.Point(20, 14)
    $unterzeile = New-Object System.Windows.Forms.Label
    $standText = ''
    if ($Versionen.Count -gt 0) {
        $stand = FormatiereDatum ([string]$Versionen[0].Datum)
        if ($stand -ne '') { $standText = '     Stand: ' + $stand }
    }
    $unterzeile.Text = 'Installiert: ' + $Lokal + $standText
    $unterzeile.ForeColor = [System.Drawing.Color]::FromArgb(200, 215, 235)
    $unterzeile.AutoSize = $true
    $unterzeile.Location = New-Object System.Drawing.Point(22, 48)
    $kopf.Controls.AddRange(@($titel, $unterzeile))

    # Fuss
    $fuss = New-Object System.Windows.Forms.Panel
    $fuss.Dock = 'Bottom'; $fuss.Height = 74
    $fuss.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
    $knopfJa = New-Object System.Windows.Forms.Button
    $knopfJa.Text = 'Jetzt aktualisieren'
    $knopfJa.Size = New-Object System.Drawing.Size(190, 38)
    $knopfJa.BackColor = $teal; $knopfJa.ForeColor = $weiss
    $knopfJa.FlatStyle = 'Flat'; $knopfJa.FlatAppearance.BorderSize = 0
    $knopfJa.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $knopfJa.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $knopfNein = New-Object System.Windows.Forms.Button
    $knopfNein.Text = 'Sp' + $ae + 'ter'
    $knopfNein.Size = New-Object System.Drawing.Size(110, 38)
    $knopfNein.FlatStyle = 'Flat'
    $knopfNein.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(180, 180, 180)
    $knopfNein.DialogResult = [System.Windows.Forms.DialogResult]::No
    $hinweis = New-Object System.Windows.Forms.Label
    $hinweis.Text = 'Ihre Daten (Wappen, Lizenz, Projekte) bleiben erhalten.' + "`n" +
        'Ohne Update l' + $ae + 'uft Ihre Version unver' + $ae + 'ndert weiter.'
    $hinweis.ForeColor = $grau
    $hinweis.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $hinweis.AutoSize = $true
    $hinweis.Location = New-Object System.Drawing.Point(20, 18)
    $fuss.Controls.AddRange(@($hinweis, $knopfJa, $knopfNein))
    $knopfJa.Location = New-Object System.Drawing.Point(($fuss.ClientSize.Width - $knopfJa.Width - 20), 18)
    $knopfNein.Location = New-Object System.Drawing.Point(($knopfJa.Left - $knopfNein.Width - 12), 18)
    $knopfJa.Anchor = 'Bottom,Right'; $knopfNein.Anchor = 'Bottom,Right'
    $hinweis.Anchor = 'Bottom,Left'
    $form.AcceptButton = $knopfJa
    $form.CancelButton = $knopfNein

    # Inhalt
    $text = New-Object System.Windows.Forms.RichTextBox
    $text.Dock = 'Fill'; $text.ReadOnly = $true; $text.BorderStyle = 'None'
    $text.BackColor = $weiss; $text.ScrollBars = 'Vertical'
    $text.DetectUrls = $false; $text.TabStop = $false
    $form.Controls.AddRange(@($text, $kopf, $fuss))

    $schriftVersion = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
    $schriftFett    = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $schriftNormal  = New-Object System.Drawing.Font('Segoe UI', 10)
    $schriftKlein   = New-Object System.Drawing.Font('Segoe UI', 9)

    $schreibe = {
        param([string]$Inhalt, [System.Drawing.Font]$Schrift, [System.Drawing.Color]$Farbe, [int]$Einzug, [int]$Haengend)
        $text.SelectionStart = $text.TextLength
        $text.SelectionLength = 0
        $text.SelectionFont = $Schrift
        $text.SelectionColor = $Farbe
        $text.SelectionIndent = $Einzug
        $text.SelectionHangingIndent = $Haengend
        $text.SelectionRightIndent = 16
        $text.AppendText($Inhalt)
    }

    & $schreibe "`n" $schriftKlein $grau 20 0
    foreach ($v in $Versionen) {
        & $schreibe ('Version ' + $v.Version) $schriftVersion $navy 20 0
        $datum = FormatiereDatum ([string]$v.Datum)
        if ($datum -ne '') { & $schreibe ('   ' + $datum) $schriftKlein $grau 20 0 }
        & $schreibe "`n" $schriftKlein $grau 20 0
        foreach ($p in $v.Punkte) {
            & $schreibe ([string]$punktZeichen + '  ') $schriftNormal $teal 24 16
            # Kurzer Vorspann (bis 80 Zeichen, endet mit Punkt oder
            # Doppelpunkt) fett - reine Anzeige, changelog.json bleibt.
            $m = [regex]::Match($p, '^(.{3,80}?[.:])\s(.*)$', [System.Text.RegularExpressions.RegexOptions]::Singleline)
            if ($m.Success) {
                & $schreibe ($m.Groups[1].Value + ' ') $schriftFett $schwarz 24 16
                & $schreibe ($m.Groups[2].Value + "`n`n") $schriftNormal $schwarz 24 16
            } else {
                & $schreibe ($p + "`n`n") $schriftNormal $schwarz 24 16
            }
        }
    }
    if ($Aeltere -gt 0) {
        $wort = 'Versionen'
        if ($Aeltere -eq 1) { $wort = 'Version' }
        & $schreibe ('sowie ' + $Aeltere + ' ' + $ae + 'ltere ' + $wort + ' mit weiteren Verbesserungen.' + "`n") $schriftKlein $grau 20 0
    }
    if ($Versionen.Count -eq 0 -and $Aeltere -eq 0) {
        & $schreibe ('Die ' + $aeGross + 'nderungen dieser Version stehen in der ' + $aeGross + 'nderungshistorie.' + "`n") $schriftNormal $schwarz 20 0
    }
    $text.SelectionStart = 0; $text.SelectionLength = 0
    $form.Add_Shown({ $knopfJa.Focus() })

    $antwort = $form.ShowDialog()
    $form.Dispose()
    return ($antwort -eq [System.Windows.Forms.DialogResult]::Yes)
}

# Rueckfall ohne Punkte, wenn das Fenster nicht gebaut werden kann (z.B.
# WinForms gesperrt): dieselbe Frage, aber kurz, damit nichts wieder zur
# Textsaeule wird.
function ZeigeUpdateMessageBox([string]$NeueVersion, [string]$Lokal) {
    Add-Type -AssemblyName System.Windows.Forms
    $text = 'FlaechenKlar ' + $NeueVersion + ' ist verfuegbar (installiert: ' + $Lokal + ').' +
        "`n`nJetzt aktualisieren?"
    $antwort = [System.Windows.Forms.MessageBox]::Show(
        $text, 'FlaechenKlar Update', [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question)
    return ($antwort -eq [System.Windows.Forms.DialogResult]::Yes)
}

# --- Vorschau fuer Entwicklung und Release-Pruefung ----------------------
# launcher.ps1 -DialogVorschau [-VorschauLokal 1.5.3]: zeigt den Dialog
# aus changelog.json neben dem Skript (sonst vom Server), ohne Update-
# Pruefung, ohne Update, ohne das Tool zu oeffnen. Antwort landet auf der
# Konsole. Fuer den Screenshot-Nachweis vor einem Release gedacht.
if ($DialogVorschau) {
    $liste = $null
    $lokaleDatei = Join-Path $installDir 'changelog.json'
    if (Test-Path -LiteralPath $lokaleDatei) {
        $liste = Get-Content -LiteralPath $lokaleDatei -Raw -Encoding UTF8 | ConvertFrom-Json
    } else {
        $liste = Invoke-RestMethod -Uri $changelogUrl -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    }
    $auswahl = WaehleVersionen $VorschauLokal @($liste)
    $neueste = $VorschauLokal
    if ($auswahl.Versionen.Count -gt 0) { $neueste = $auswahl.Versionen[0].Version }
    $ja = ZeigeUpdateDialog $neueste $VorschauLokal $auswahl.Versionen $auswahl.Aeltere
    $antwortText = 'Nein'
    if ($ja) { $antwortText = 'Ja' }
    Write-Host ('Vorschau: Antwort = ' + $antwortText + ', Versionen = ' + $auswahl.Versionen.Count + ', aeltere = ' + $auswahl.Aeltere)
    exit 0
}

Write-Host ('launcher.ps1 gestartet in ' + $installDir)

if (-not (Test-Path $updatePs1)) {
    # Unvollstaendige Installation -- Start nicht blockieren.
    Write-Host 'Hinweis: update.ps1 fehlt, Update-Pruefung wird uebersprungen.'
    OeffneUndBeende
}

# --- Schritt 1: Pruefung als eigener Prozess (NICHT per & aufrufen --
# update.ps1 beendet sich selbst per exit; im selben Prozess aufgerufen
# wuerde das den Launcher mitbeenden, bevor er reagieren kann). --------
$exitCode = 0
$protOut = Join-Path $env:TEMP ('fk-pruef-out-' + $PID + '.txt')
$protErr = Join-Path $env:TEMP ('fk-pruef-err-' + $PID + '.txt')
try {
    $argStr = '-NoProfile -ExecutionPolicy Bypass -File "' + $updatePs1 + '" -NurPruefen'
    # -NoNewWindow statt -WindowStyle Hidden: PowerShell 5.1 laesst die
    # Umleitung nur so zu (-WindowStyle verlangt UseShellExecute, Redirect
    # verbietet es). Dadurch landen die Klartextmeldungen von update.ps1
    # (TLS-Fehler, Wartungsserver nicht erreichbar) im Start-Protokoll
    # statt im Nichts.
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argStr `
        -NoNewWindow -Wait -PassThru `
        -RedirectStandardOutput $protOut -RedirectStandardError $protErr
    $exitCode = $proc.ExitCode
} catch {
    Write-Host ('Update-Pruefung nicht ausfuehrbar: ' + $_.Exception.Message)
    $exitCode = 0
} finally {
    foreach ($datei in @($protOut, $protErr)) {
        try {
            if (Test-Path -LiteralPath $datei) {
                Get-Content -LiteralPath $datei | ForEach-Object {
                    if ($_ -ne '') { Write-Host ('  [pruefung] ' + $_) }
                }
                Remove-Item -LiteralPath $datei -ErrorAction SilentlyContinue
            }
        } catch { }
    }
}
Write-Host ('Update-Pruefung Exit-Code: ' + $exitCode)

if ($exitCode -ne 10) {
    OeffneUndBeende
}

# --- Schritt 2: Changelog vom Server laden (best effort, reine Anzeige) --
$versionen = @()
$aeltere = 0
try {
    $changelog = Invoke-RestMethod -Uri $changelogUrl -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    $auswahl = WaehleVersionen $lokal @($changelog)
    $versionen = $auswahl.Versionen
    $aeltere = $auswahl.Aeltere
} catch {
    # Changelog ist reine Anzeige -- Ladefehler darf den Dialog nicht verhindern.
}

$neueVersion = '?'
try {
    $remote = Invoke-WebRequest -Uri $versionUrl -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    $neueVersion = (($remote.Content -split "`r?`n")[0]).Trim()
} catch {
    # Reine Anzeige -- update.ps1 hat die Verfuegbarkeit bereits per Exit-Code 10 belegt.
}

# --- Schritt 3: Dialog zeigen, bei Ja update.bat ------------------------
# Ab hier in try/finally: ein Fehler in Add-Type/Dialog/Start-Process
# (z.B. fehlendes update.bat) darf OeffneUndBeende nicht verhindern -- sonst
# bliebe der Start komplett aus, statt nur das Update zu ueberspringen.
try {
    $ja = $false
    try {
        $ja = ZeigeUpdateDialog $neueVersion $lokal $versionen $aeltere
    } catch {
        Write-Host ('Update-Fenster nicht darstellbar, MessageBox stattdessen: ' + $_.Exception.Message)
        $ja = ZeigeUpdateMessageBox $neueVersion $lokal
    }
    $antwortText = 'Nein'
    if ($ja) { $antwortText = 'Ja' }
    Write-Host ('Update-Dialog: ' + $antwortText)

    if ($ja -and (Test-Path $updateBat)) {
        # Sichtbares Fenster: Kunde soll "Update erfolgreich" lesen koennen.
        # update.bat statt update.ps1 direkt -- uebernimmt die vorhandene
        # Konsolen-UX (Banner, Abschlussmeldung, Tastendruck) unveraendert.
        Start-Process -FilePath $updateBat -Wait
    }
} catch {
    Write-Host ('Update-Dialog uebersprungen: ' + $_.Exception.Message)
} finally {
    OeffneUndBeende
}
