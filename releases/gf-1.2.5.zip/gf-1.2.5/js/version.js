// @ts-check
// Versions- und Vertriebs-Konstanten fuer FlaechenKlar.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern: GF wird ueber alle Dateien hinweg
  // inkrementell aufgebaut.
  global.GF = global.GF || {};

  // Aktuelle Version dieses Builds.
  global.GF.VERSION = '1.2.5';

  // Build-Datum dieses Releases im Format YYYY-MM-DD.
  global.GF.BUILD_DATUM = '2026-07-04';

  // URL, die beim "Auf Updates pruefen"-Klick abgerufen wird.
  // Inhalt der Datei muss in Zeile 1 die Versionsnummer "x.y.z" enthalten.
  // Custom-Domain (download.flaechenklar.de), NICHT *.github.io: Letztere
  // 301-redirectet ohne Access-Control-Allow-Origin, wodurch der fetch()
  // aus der lokal geoeffneten index.html (Origin "null") an CORS scheitert
  // ("Update-Server nicht erreichbar"). Die Custom-Domain liefert ACAO "*"
  // ohne Redirect. Siehe CHANGELOG 1.2.1.
  global.GF.VERSION_CHECK_URL = 'https://download.flaechenklar.de/version.txt';

  // URL, die im Update-Modal als "Download"-Link aufgemacht wird
  // (Fallback, falls update.bat fehlt).
  global.GF.DOWNLOAD_URL = 'https://download.flaechenklar.de/releases/';
})(typeof window !== 'undefined' ? window : globalThis);
