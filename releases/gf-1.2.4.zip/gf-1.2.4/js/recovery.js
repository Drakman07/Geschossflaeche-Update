// @ts-check
// js/recovery.js — Auto-Recovery via IndexedDB.
// Schreibt alle 30 Sek einen Snapshot des aktuellen Projekt-Objekts,
// damit nach Crash/Browser-Neustart der Zustand wiederhergestellt werden kann.
// Der primaere Speicher bleibt die .gfproj-Datei; IndexedDB ist nur Notfall-Sicherung.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.recovery = GF.recovery || /** @type {GfRecoveryModule} */ ({});

  var DB_NAME      = 'gf-recovery';
  var DB_VERSION   = 1;
  var STORE        = 'snapshot';
  var SNAPSHOT_KEY = 'current';
  var INTERVAL_MS  = 30000;
  var MAX_AGE_MS   = 7 * 24 * 60 * 60 * 1000;   // 7 Tage

  var intervalHandle = null;

  /**
   * @returns {Promise<IDBDatabase>}
   */
  function oeffneDb() {
    return new Promise(function (resolve, reject) {
      var idb = /** @type {any} */ (global).indexedDB;
      if (!idb) {
        reject(new Error('IndexedDB nicht verfügbar'));
        return;
      }
      var req = idb.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror   = function () { reject(req.error); };
    });
  }

  /**
   * Baut ein vollstaendiges Snapshot-Objekt: Projekt-Daten + PDF-Binaries +
   * Viewport + aktive Auswahl. pdfDoc-Instanzen koennen nicht serialisiert
   * werden, deshalb holen wir das Quell-Binary via pdfDoc.getData() und
   * speichern das als Uint8Array (structured-clone-faehig).
   */
  /**
   * @param {GfStateFields} state
   * @returns {Promise<any>}
   */
  function snapshotErzeugen(state) {
    /** @type {any[]} */
    var pdfsSer = [];
    var kette = Promise.resolve();
    (state.pdfs || []).forEach(function (p) {
      kette = kette.then(function () {
        if (!p.pdfDoc || typeof p.pdfDoc.getData !== 'function') return;
        return p.pdfDoc.getData().then(function (data) {
          pdfsSer.push({
            id: p.id,
            dateiName: p.dateiName,
            containerPfad: p.containerPfad,
            originalDateiName: p.originalDateiName,
            anzahlSeiten: p.anzahlSeiten,
            binary: data
          });
        });
      });
    });
    return kette.then(function () {
      return {
        schemaVersion: 2,
        datum: new Date().toISOString(),
        appVersion: (GF.VERSION || '0.0.0'),
        projekt: state.projekt,
        pdfs: pdfsSer,
        aktivePdfId: state.aktivePdfId,
        aktuelleSeite: state.aktuelleSeite,
        aktivesGeschossId: state.aktivesGeschossId,
        aktiveRegionId: state.aktiveRegionId,
        viewport: state.viewport
      };
    });
  }

  /**
   * @param {GfStateFields} state
   * @returns {Promise<void>}
   */
  function schreibeSnapshot(state) {
    return snapshotErzeugen(state).then(function (snap) {
      return oeffneDb().then(function (db) {
        return new Promise(function (resolve, reject) {
          var tx = db.transaction(STORE, 'readwrite');
          tx.objectStore(STORE).put(snap, SNAPSHOT_KEY);
          tx.oncomplete = function () { db.close(); resolve(); };
          tx.onerror    = function () { db.close(); reject(tx.error); };
        });
      });
    });
  }

  /**
   * @returns {Promise<any | null>}
   */
  function leseSnapshot() {
    return oeffneDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readonly');
        var req = tx.objectStore(STORE).get(SNAPSHOT_KEY);
        req.onsuccess = function () { db.close(); resolve(req.result || null); };
        req.onerror   = function () { db.close(); reject(req.error); };
      });
    });
  }

  /**
   * @returns {Promise<void>}
   */
  function loescheSnapshot() {
    return oeffneDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).delete(SNAPSHOT_KEY);
        tx.oncomplete = function () { db.close(); resolve(); };
        tx.onerror    = function () { db.close(); reject(tx.error); };
      });
    });
  }

  GF.recovery.start = function () {
    if (intervalHandle) return;
    intervalHandle = setInterval(function () {
      if (!GF.state.projekt || !GF.state.ungespeicherteAenderungen) return;
      schreibeSnapshot(GF.state).catch(function (e) {
        console.warn('[gf-recovery] Snapshot-Schreiben fehlgeschlagen:', e);
      });
    }, INTERVAL_MS);
  };

  // Manueller Snapshot, z. B. bei beforeunload — synchron-naehe.
  GF.recovery.snapshotJetzt = function () { return schreibeSnapshot(GF.state); };

  GF.recovery.stop = function () {
    if (intervalHandle) { clearInterval(intervalHandle); intervalHandle = null; }
  };

  /** Wird beim App-Start aufgerufen. Liefert Snapshot oder null. */
  GF.recovery.pruefeBeimStart = function () {
    return leseSnapshot().then(function (snap) {
      if (!snap || !snap.datum) return null;
      var alter = Date.now() - Date.parse(snap.datum);
      if (alter > MAX_AGE_MS) {
        loescheSnapshot();
        return null;
      }
      // Snapshots im alten Format (vor Schema 2) wurden ohne PDF-Binaries
      // gespeichert -> Restore waere unvollstaendig, also stillschweigend
      // verwerfen statt einen Dialog zu zeigen, der nichts bewirkt.
      if (!snap.schemaVersion || snap.schemaVersion < 2) {
        console.info('[gf-recovery] Alter Snapshot (Schema ' + (snap.schemaVersion || 1) + ') verworfen — Restore-Format inkompatibel.');
        loescheSnapshot();
        return null;
      }
      return snap;
    }).catch(function (e) {
      console.warn('[gf-recovery] Lesen fehlgeschlagen:', e);
      return null;
    });
  };

  GF.recovery.loesche = loescheSnapshot;

  // Test-Hooks
  GF.recovery._intern = {
    schreibe: schreibeSnapshot,
    lese: leseSnapshot,
    INTERVAL_MS: INTERVAL_MS,
    MAX_AGE_MS: MAX_AGE_MS
  };

})(typeof window !== 'undefined' ? window : globalThis);
