// @ts-check
// js/geschoss.js — Geschoss-Verwaltung.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.geschoss = GF.geschoss || /** @type {GfGeschossModule} */ ({});

  /**
   * @param {string} [bezeichnung]
   * @param {number} [reihenfolge]
   * @returns {Geschoss}
   */
  GF.geschoss.erzeuge = function (bezeichnung, reihenfolge) {
    return {
      id: GF.util.uuid(),
      bezeichnung: bezeichnung || 'Geschoss',
      reihenfolge: (typeof reihenfolge === 'number') ? reihenfolge : 0
    };
  };

  /**
   * @param {Geschoss | null | undefined} g
   * @param {string} neu
   */
  GF.geschoss.umbenenne = function (g, neu) {
    if (!g) return;
    g.bezeichnung = String(neu || '');
  };

  /**
   * @param {Geschoss[]} liste
   * @returns {Geschoss[]}
   */
  GF.geschoss.sortiereNachReihenfolge = function (liste) {
    return liste.slice().sort(function (a, b) { return a.reihenfolge - b.reihenfolge; });
  };

})(typeof window !== 'undefined' ? window : globalThis);
