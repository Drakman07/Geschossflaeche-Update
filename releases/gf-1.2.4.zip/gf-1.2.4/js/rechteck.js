// @ts-check
// js/rechteck.js — Rechteck-Werkzeug: aus zwei Gegenecken ein achsparalleles
// 4-Punkt-Polygon (reine Geometrie, maus-event-unabhaengig testbar).

(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {any} */ (global.GF = global.GF || {});
  GF.rechteck = GF.rechteck || {};

  /**
   * Baut aus zwei Gegenecken (PDF-pt) ein achsparalleles Rechteck als 4 Punkte
   * im Uhrzeigersinn (Reihenfolge der Eingabe egal).
   * @param {Punkt} e1
   * @param {Punkt} e2
   * @returns {Punkt[]}
   */
  GF.rechteck.ausEcken = function (e1, e2) {
    var xMin = Math.min(e1.x, e2.x), xMax = Math.max(e1.x, e2.x);
    var yMin = Math.min(e1.y, e2.y), yMax = Math.max(e1.y, e2.y);
    return [
      { x: xMin, y: yMin },
      { x: xMax, y: yMin },
      { x: xMax, y: yMax },
      { x: xMin, y: yMax }
    ];
  };

})(typeof window !== 'undefined' ? window : globalThis);
