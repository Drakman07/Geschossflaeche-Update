// @ts-check
// js/vg-validierung.js — Eingabe-Parsing und Plausi-Check fuer VG-Modul.
// Akzeptiert Komma als Dezimaltrenner (DE-Konvention).
// Gibt { eingabe, fehler } zurueck; wirft nicht.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  var MAX_LAENGE    = 500;
  var MAX_KNIESTOCK = 10;
  var MAX_FLAECHE   = 1000;

  /** @type {GfVgFeldDef[]} */
  var FELDER = [
    { key: 'L_B',       label: 'Gebaeudebreite (L_B)',          pflicht: true,  min: 0,    minStrikt: true,  max: MAX_LAENGE,    einheit: 'm' },
    { key: 'L_L',       label: 'Gebaeudelaenge (L_L)',          pflicht: true,  min: 0,    minStrikt: true,  max: MAX_LAENGE,    einheit: 'm' },
    { key: 'h_KL',      label: 'Kniestock links (h_KL)',        pflicht: true,  min: 0,                       max: MAX_KNIESTOCK, einheit: 'm' },
    { key: 'h_KR',      label: 'Kniestock rechts (h_KR)',       pflicht: true,  min: 0,                       max: MAX_KNIESTOCK, einheit: 'm' },
    { key: 'alpha_L',   label: 'Dachneigung links (alpha_L)',   pflicht: true,  min: 0,    minStrikt: true,  max: 90, maxStrikt: true, einheit: '°' },
    { key: 'alpha_R',   label: 'Dachneigung rechts (alpha_R)',  pflicht: true,  min: 0,    minStrikt: true,  max: 90, maxStrikt: true, einheit: '°' },
    { key: 'A_kleiner', label: 'Abzug < 2,30 m (A_kleiner)',    pflicht: false, min: 0,                       max: MAX_FLAECHE,   einheit: 'm²' },
    { key: 'A_groesser',label: 'Abzug >= 2,30 m (A_groesser)',  pflicht: false, min: 0,                       max: MAX_FLAECHE,   einheit: 'm²' },
    // Anrechnungs-Grenzhoehe (kommunale Satzung). Leer -> 0 -> berechne() nutzt Default 2,30.
    { key: 'grenzhoehe', label: 'Anrechnungs-Grenzhoehe',       pflicht: false, min: 0.5,                     max: 3.0,           einheit: 'm' }
  ];

  var MAX_GAUBEN = 5;

  /**
   * @param {any} roh
   * @returns {number}
   */
  function parseZahl(roh) {
    if (roh === null || roh === undefined) return NaN;
    var s = String(roh).trim();
    if (s === '') return NaN;
    s = s.replace(',', '.');
    var n = Number(s);
    return isFinite(n) ? n : NaN;
  }

  /**
   * @param {any} roh Rohes Form-Objekt mit gleichen keys wie VgEingaben.
   * @returns {{eingabe: VgEingaben, fehler: string[]}}
   */
  function parseEingabe(roh) {
    /** @type {any} */
    var eingabe = {};
    /** @type {string[]} */
    var fehler = [];

    FELDER.forEach(function (f) {
      var rohwert = roh[f.key];
      var leer = rohwert === undefined || rohwert === null || String(rohwert).trim() === '';

      if (leer) {
        if (f.pflicht) {
          fehler.push(f.label + ' ist Pflichtfeld.');
          eingabe[f.key] = NaN;
        } else {
          eingabe[f.key] = 0;
        }
        return;
      }

      var n = parseZahl(rohwert);
      if (isNaN(n)) {
        fehler.push(f.label + ': "' + rohwert + '" ist keine gueltige Zahl.');
        eingabe[f.key] = NaN;
        return;
      }

      if (f.min !== undefined) {
        var minOk = f.minStrikt ? n > f.min : n >= f.min;
        if (!minOk) {
          fehler.push(f.label + ' muss ' + (f.minStrikt ? '>' : '≥') + ' ' + f.min.toFixed(2).replace('.', ',') + (f.einheit ? ' ' + f.einheit : '') + ' sein.');
        }
      }
      if (f.max !== undefined) {
        var maxOk = f.maxStrikt ? n < f.max : n <= f.max;
        if (!maxOk) {
          fehler.push(f.label + ' muss ' + (f.maxStrikt ? '<' : '≤') + ' ' + f.max.toFixed(2).replace('.', ',') + (f.einheit ? ' ' + f.einheit : '') + ' sein.');
        }
      }

      eingabe[f.key] = n;
    });

    eingabe.gauben_links  = parseGauben(roh.gauben_links,  'links',  fehler, eingabe.L_L);
    eingabe.gauben_rechts = parseGauben(roh.gauben_rechts, 'rechts', fehler, eingabe.L_L);

    return { eingabe: eingabe, fehler: fehler };
  }

  /**
   * @param {any} rohListe
   * @param {'links' | 'rechts'} seitenLabel
   * @param {string[]} fehler
   * @param {number} L_L
   * @returns {Gaube[]}
   */
  function parseGauben(rohListe, seitenLabel, fehler, L_L) {
    if (!Array.isArray(rohListe)) return [];
    /** @type {Gaube[]} */
    var ergebnis = [];
    var sumB = 0;

    for (var idx = 0; idx < rohListe.length; idx++) {
      var roh = rohListe[idx] || {};
      var b_raw  = roh.b;
      var a_raw  = roh.a;
      var o_raw  = roh.ortgang;

      var leer = (b_raw === undefined || String(b_raw).trim() === '')
              && (a_raw === undefined || String(a_raw).trim() === '')
              && (o_raw === undefined || String(o_raw).trim() === '');
      if (leer) continue;

      var nr = idx + 1;
      var b = parseZahl(b_raw);
      var a = parseZahl(a_raw);
      var o = (o_raw === undefined || String(o_raw).trim() === '') ? NaN : parseZahl(o_raw);

      if (b_raw !== undefined && String(b_raw).trim() !== '' && (isNaN(b) || b < 0 || b > MAX_LAENGE)) {
        fehler.push('Gaube ' + seitenLabel + ' #' + nr + ' Breite: ungültiger Wert "' + b_raw + '" (0…' + MAX_LAENGE + ' m).');
      }
      if (a_raw !== undefined && String(a_raw).trim() !== '' && (isNaN(a) || a < 0 || a > MAX_LAENGE)) {
        fehler.push('Gaube ' + seitenLabel + ' #' + nr + ' Traufabstand: ungültiger Wert "' + a_raw + '" (0…' + MAX_LAENGE + ' m).');
      }
      if (!isNaN(o) && (o < 0 || o > MAX_LAENGE)) {
        fehler.push('Gaube ' + seitenLabel + ' #' + nr + ' Ortgangabstand: ungültiger Wert "' + o_raw + '" (0…' + MAX_LAENGE + ' m).');
      }

      if ((b_raw === undefined || String(b_raw).trim() === '') && a_raw !== undefined && String(a_raw).trim() !== '') {
        fehler.push('Gaube ' + seitenLabel + ' #' + nr + ': Breite fehlt.');
      }

      ergebnis.push({
        b: isFinite(b) ? b : 0,
        a: isFinite(a) ? a : 0,
        ortgang: isFinite(o) ? o : NaN
      });

      if (isFinite(b) && b > 0) sumB += b;
    }

    if (ergebnis.length > MAX_GAUBEN) {
      fehler.push('Maximal ' + MAX_GAUBEN + ' Gauben pro Seite ('
        + seitenLabel + ' hat ' + ergebnis.length + ').');
    }
    if (isFinite(L_L) && sumB > L_L) {
      fehler.push('Summe der Gaubenbreiten ' + seitenLabel + ' ('
        + sumB.toLocaleString('de-DE', { maximumFractionDigits: 2 })
        + ' m) ist größer als die Gebäudelänge L_L ('
        + L_L.toLocaleString('de-DE', { maximumFractionDigits: 2 }) + ' m).');
    }

    return ergebnis;
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.Vollgeschoss = GF.Vollgeschoss || /** @type {GfVollgeschossModule} */ ({});
  GF.Vollgeschoss.validierung = {
    parseEingabe: parseEingabe,
    parseZahl: parseZahl,
    FELDER: FELDER,
    MAX_GAUBEN: MAX_GAUBEN
  };

})(typeof window !== 'undefined' ? window : globalThis);
