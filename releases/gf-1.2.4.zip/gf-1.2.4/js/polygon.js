// @ts-check
// js/polygon.js — Polygon-Werkzeug: Zeichnen, Snap, Flaeche, Kanten-Editor.
// Hier: Algorithmen, die unabhaengig von Maus-Events testbar sind.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.polygon = GF.polygon || /** @type {GfPolygonModule} */ ({});

  // ---- Flaechenberechnung (Shoelace) ----

  /**
   * Berechnet Polygonflaeche in m^2 aus Punkten in PDF-Koordinaten (pt).
   * @param {Punkt[]} punkte (mindestens 3, geschlossen impliziert)
   * @param {number} ptProMeter Kalibrierungsverhaeltnis aus region.kalibrierung
   * @returns {number} Flaeche in m^2
   */
  GF.polygon.berechneFlaeche = function (punkte, ptProMeter) {
    if (!Array.isArray(punkte) || punkte.length < 3) {
      throw new Error('Polygon braucht mindestens 3 Punkte');
    }
    if (!isFinite(ptProMeter) || ptProMeter <= 0) {
      throw new Error('Maßstab nicht gesetzt');
    }
    var summe = 0;
    for (var i = 0; i < punkte.length; i++) {
      var j = (i + 1) % punkte.length;
      summe += punkte[i].x * punkte[j].y;
      summe -= punkte[j].x * punkte[i].y;
    }
    var fQuadratPt = Math.abs(summe) / 2;
    return fQuadratPt / (ptProMeter * ptProMeter);
  };

  /**
   * Pruefung auf Selbstueberschneidung.
   * @param {Punkt[]} punkte
   * @param {boolean} [closed=true] geschlossenes Polygon mit Schlusskante (n-1)->0.
   *   Live-Vorschau MUSS false uebergeben, sonst wird die noch nicht existierende
   *   Schlusskante mitgeprueft.
   * @returns {boolean}
   */
  GF.polygon.hatSelbstueberschneidung = function (punkte, closed) {
    if (closed === undefined) closed = true;
    var n = punkte.length;
    if (n < 4) return false;
    var anzahlKanten = closed ? n : n - 1;
    for (var i = 0; i < anzahlKanten; i++) {
      var a1 = punkte[i];
      var a2 = punkte[(i + 1) % n];
      for (var j = i + 2; j < anzahlKanten; j++) {
        // Im geschlossenen Polygon teilen sich erste und letzte Kante den Startpunkt
        if (closed && i === 0 && j === n - 1) continue;
        var b1 = punkte[j];
        var b2 = punkte[(j + 1) % n];
        if (GF.util.segmenteSchneidenSich(a1, a2, b1, b2)) return true;
      }
    }
    return false;
  };

  // ---- Kanten-Editor (Option 1 aus Plan §6.1) ----

  /**
   * Aendert die Laenge der Kante (kantenIndex -> kantenIndex+1) auf neuesMassMeter,
   * indem der zweite Endpunkt entlang der bestehenden Richtung verschoben wird.
   * Alle anderen Punkte bleiben fix.
   *
   * Wirft, wenn die Ausgangskante Laenge 0 hat (keine eindeutige Richtung).
   * @param {Polygon} poly
   * @param {number} kantenIndex
   * @param {number} neuesMassMeter
   * @param {number} ptProMeter
   */
  GF.polygon.editKante = function (poly, kantenIndex, neuesMassMeter, ptProMeter) {
    if (!poly || !poly.punkte || poly.punkte.length < 3) {
      throw new Error('Polygon ungültig');
    }
    if (!isFinite(neuesMassMeter) || neuesMassMeter <= 0) {
      throw new Error('Neues Mass muss > 0 sein');
    }
    if (!isFinite(ptProMeter) || ptProMeter <= 0) {
      throw new Error('Maßstab nicht gesetzt');
    }
    var n = poly.punkte.length;
    var p1 = poly.punkte[kantenIndex];
    var p2 = poly.punkte[(kantenIndex + 1) % n];
    var dx = p2.x - p1.x;
    var dy = p2.y - p1.y;
    var alteLaengePt = Math.sqrt(dx * dx + dy * dy);
    if (alteLaengePt === 0) {
      throw new Error('Kante hat Länge 0 — keine Richtung definiert');
    }
    var neueLaengePt = neuesMassMeter * ptProMeter;
    var skalar = neueLaengePt / alteLaengePt;
    p2.x = p1.x + dx * skalar;
    p2.y = p1.y + dy * skalar;
  };

  // ---- Snap ----

  GF.polygon.snap = GF.polygon.snap || /** @type {GfPolygonSnap} */ ({});

  /**
   * Maus auf naechstem Vektor-Endpunkt einrasten, wenn Toleranz unterschritten.
   * @param {Punkt} maus
   * @param {GfKDTreeInstance | null} kdTree
   * @param {number} toleranzPt
   * @returns {Punkt}
   */
  GF.polygon.snap.aufEndpunkt = function (maus, kdTree, toleranzPt) {
    if (!kdTree) return maus;
    var naechster = kdTree.findeNaechsten(maus);
    if (!naechster) return maus;
    var d = GF.util.abstand2D(maus, naechster);
    return d < toleranzPt ? { x: naechster.x, y: naechster.y, snapped: true } : maus;
  };

  /**
   * Rechtwinkel-Snap: schraenkt naechstePos auf 0/90/180/270 zur letzten Kante ein,
   * wenn Winkelabweichung kleiner als toleranzGrad.
   * @param {Punkt | null} letzter
   * @param {Punkt | null} naechster
   * @param {number} toleranzGrad
   * @returns {Punkt | null}
   */
  GF.polygon.snap.aufRechtwinkel = function (letzter, naechster, toleranzGrad) {
    if (!letzter || !naechster) return naechster;
    var dx = naechster.x - letzter.x;
    var dy = naechster.y - letzter.y;
    var winkel = Math.atan2(dy, dx) * 180 / Math.PI;   // -180 .. 180
    var richtungen = [0, 90, 180, -90, -180];
    var beste = null, bestDist = Infinity;
    for (var i = 0; i < richtungen.length; i++) {
      var d = Math.abs(winkel - richtungen[i]);
      if (d > 180) d = 360 - d;
      if (d < bestDist) { bestDist = d; beste = richtungen[i]; }
    }
    if (bestDist > toleranzGrad) return naechster;
    var distanz = Math.sqrt(dx * dx + dy * dy);
    var rad = beste * Math.PI / 180;
    return {
      x: letzter.x + distanz * Math.cos(rad),
      y: letzter.y + distanz * Math.sin(rad),
      snapped: true
    };
  };

})(typeof window !== 'undefined' ? window : globalThis);
