// @ts-check
/* =====================================================================
 * lizenz.js — Whitelist-basierte Update-Autorisierung (FlaechenKlar)
 * ---------------------------------------------------------------------
 * Identisch zum VG-Tool, nur ID-Praefix "GF-" und eigene Allowlist-URL.
 *
 *   1. Jede Auslieferung enthaelt data/lizenz.js mit Gemeinde-ID
 *      (Format GF-XX-YYYY-NNN). data/ wird bei Updates nie ueberschrieben.
 *
 *   2. Beim Update-Klick wird die ID via SHA256 gehasht und gegen
 *      allowlist.json (gh-pages) geprueft. Hash drin -> Wartung aktiv.
 *
 *   3. Bei FEHLENDER data/lizenz.js laeuft die App im 14-Tage-Demo-Modus
 *      (Wasserzeichen im Protokoll, Banner mit Countdown, Updates blockiert).
 *
 * Sicherheits-Annahme: Die Whitelist ist oeffentlich, enthaelt aber nur
 * Hashes. Aus einem Hash kann die ID nicht rekonstruiert werden.
 * ===================================================================== */

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  var STORAGE_DEMO_START = 'gf.lizenz.demo.start';   // ISO-Datum
  var DEMO_TAGE          = 14;
  var ALLOWLIST_URL      = 'https://download.flaechenklar.de/allowlist.json';
  /** @type {'GF-'} */
  var ID_PRAEFIX         = 'GF-';

  /**
   * @param {string} id
   * @returns {HTMLElement | null}
   */
  function $(id) { return document.getElementById(id); }

  // ---- ID + Hashing ----

  /**
   * Liefert die Gemeinde-ID aus data/lizenz.js (window.GF_LIZENZ) oder null.
   * @returns {string | null}
   */
  function holeID() {
    var id = (global.GF_LIZENZ && typeof global.GF_LIZENZ.id === 'string')
      ? global.GF_LIZENZ.id
      : null;
    if (!id) return null;
    if (id.indexOf(ID_PRAEFIX) !== 0) {
      console.warn('[gf-lizenz] ID hat unerwartetes Praefix, erwartet "' + ID_PRAEFIX + '":', id);
      return null;
    }
    return id;
  }

  /**
   * @param {ArrayBuffer} buf
   * @returns {string}
   */
  function hexFromBytes(buf) {
    var u8 = new Uint8Array(buf);
    var s = '';
    for (var i = 0; i < u8.length; i++) {
      s += u8[i].toString(16).padStart(2, '0');
    }
    return s;
  }

  /**
   * SHA256(text) als Hex-String.
   * @param {string} text
   * @returns {Promise<string>}
   */
  function sha256Hex(text) {
    var anyGlobal = /** @type {any} */ (global);
    if (!anyGlobal.crypto || !anyGlobal.crypto.subtle) {
      return Promise.reject(new Error('Web-Crypto nicht verfügbar'));
    }
    var enc = new TextEncoder();
    return anyGlobal.crypto.subtle.digest('SHA-256', enc.encode(String(text)))
      .then(hexFromBytes);
  }

  // ---- Whitelist-Pruefung ----

  /**
   * Rueckgabe (Promise):
   *   { ok:true,  modus:'voll' }                    – ID in Whitelist
   *   { ok:false, modus:'demo' }                    – keine ID (Demo-Modus)
   *   { ok:false, modus:'voll', grund:'unbekannt' } – ID NICHT in Whitelist
   *   { ok:false, grund:'netzwerk' }                – Server nicht erreichbar
   *   { ok:false, grund:'kaputt' }                  – Antwort nicht parsebar
   */
  /**
   * @param {{fetcher?: (url: string) => Promise<any>}} [opts]
   * @returns {Promise<LizenzPruefResultat>}
   */
  function pruefeWhitelist(opts) {
    opts = opts || {};
    var id = holeID();
    if (!id) {
      return Promise.resolve(/** @type {LizenzPruefResultat} */ ({ ok: false, modus: 'demo' }));
    }
    var doFetch = opts.fetcher || function (url) {
      return fetch(url, { cache: 'no-store' }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      });
    };
    return sha256Hex(id).then(function (hash) {
      return doFetch(ALLOWLIST_URL).then(function (al) {
        if (!al || !Array.isArray(al.hashes)) {
          return /** @type {LizenzPruefResultat} */ ({ ok: false, grund: 'kaputt' });
        }
        // Jeder Eintrag muss ein 64-Zeichen-Hex-String sein (SHA256 in Hex).
        // Schuetzt vor versehentlich verfaelschten Listen ([null, 123, "ok"]),
        // die sonst zu stillem indexOf-Miss fuehren wuerden.
        var alleHex = al.hashes.every(function (h) {
          return typeof h === 'string' && /^[0-9a-f]{64}$/.test(h);
        });
        if (!alleHex) {
          return /** @type {LizenzPruefResultat} */ ({ ok: false, grund: 'kaputt' });
        }
        var enthalten = al.hashes.indexOf(hash) >= 0;
        return enthalten
          ? /** @type {LizenzPruefResultat} */ ({ ok: true,  modus: 'voll' })
          : /** @type {LizenzPruefResultat} */ ({ ok: false, modus: 'voll', grund: 'unbekannt' });
      });
    }).catch(function () {
      return /** @type {LizenzPruefResultat} */ ({ ok: false, grund: 'netzwerk' });
    });
  }

  // ---- Demo-Tage (LocalStorage) ----

  function setzeDemoStartFallsLeer() {
    try {
      var v = localStorage.getItem(STORAGE_DEMO_START);
      if (!v) localStorage.setItem(STORAGE_DEMO_START, new Date().toISOString());
    } catch (e) { /* privater Modus / Quota — ignorieren */ }
  }

  function tageVerbleibend() {
    try {
      var start = localStorage.getItem(STORAGE_DEMO_START);
      if (!start) return 0;
      var startMs = Date.parse(start);
      if (isNaN(startMs)) return 0;
      var dayMs = 24 * 60 * 60 * 1000;
      var verbraucht = Math.floor((Date.now() - startMs) / dayMs);
      return Math.max(0, DEMO_TAGE - verbraucht);
    } catch (e) { return 0; }
  }

  function demoAbgelaufen() {
    var start = null;
    try { start = localStorage.getItem(STORAGE_DEMO_START); } catch (e) {}
    if (!start) return false;
    return tageVerbleibend() <= 0;
  }

  // ---- UI: Demo-Banner Countdown ----

  function aktualisiereDemoBanner() {
    var b = $('demoBanner');
    if (!b) return;
    if (holeID()) {
      b.classList.remove('aktiv');
      b.classList.remove('warn');
      b.classList.remove('abgelaufen');
      return;
    }
    var tage = tageVerbleibend();
    var span = b.querySelector('[data-rolle="tage"]');
    if (span) span.textContent = String(tage);
    b.classList.add('aktiv');
    if (tage <= 0) {
      b.classList.add('warn');
      b.classList.add('abgelaufen');
      var info = b.querySelector('.demo-banner-info');
      if (info) {
        info.innerHTML = '<strong>Demo abgelaufen</strong> — '
          + '<span class="demo-banner-hint">für Voll-Lizenz Anbieter kontaktieren. Aufmaßprotokolle erhalten weiterhin das Wasserzeichen.</span>';
      }
    } else {
      b.classList.remove('abgelaufen');
      if (tage <= 3) b.classList.add('warn'); else b.classList.remove('warn');
    }
  }

  // ---- Init ----

  function init() {
    if (holeID()) return;
    setzeDemoStartFallsLeer();
    aktualisiereDemoBanner();
  }

  // ---- Public API ----

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.lizenz = {
    holeID: holeID,
    sha256Hex: sha256Hex,
    pruefeWhitelist: pruefeWhitelist,
    tageVerbleibend: tageVerbleibend,
    demoAbgelaufen: demoAbgelaufen,
    aktualisiereDemoBanner: aktualisiereDemoBanner,
    DEMO_TAGE: DEMO_TAGE,
    ALLOWLIST_URL: ALLOWLIST_URL,
    ID_PRAEFIX: ID_PRAEFIX,
    _setzeDemoStartFallsLeer: setzeDemoStartFallsLeer
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
