// @ts-check
// js/hilfe.js — Hilfe-Modal + Click-Handler fuer die 4 Menue-Eintraege.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  /** @param {string} id @returns {HTMLElement | null} */
  function $(id) { return document.getElementById(id); }

  function oeffneHilfe() {
    var bd = $('hilfeBackdrop');
    var inhalt = $('hilfeUeberInhalt');
    if (inhalt) { inhalt.hidden = true; inhalt.innerHTML = ''; }
    if (bd) bd.classList.add('aktiv');
  }

  function schliesseHilfe() {
    var bd = $('hilfeBackdrop');
    if (bd) bd.classList.remove('aktiv');
  }

  function zeigeUeber() {
    var inhalt = $('hilfeUeberInhalt');
    if (!inhalt) return;
    var GFns = global.GF || /** @type {any} */ ({});
    var lizenzId = (GFns.lizenz && GFns.lizenz.holeID) ? GFns.lizenz.holeID() : null;
    var demo = !lizenzId;
    var zeilen = [
      '<strong>Version:</strong> ' + (GFns.VERSION || '?'),
      '<strong>Build-Datum:</strong> ' + (GFns.BUILD_DATUM || '?'),
      '<strong>Lizenz:</strong> ' + (demo ? 'Demo-Version (keine Lizenz)' : escapeHtml(lizenzId))
    ];
    inhalt.innerHTML = zeilen.join('<br>');
    inhalt.hidden = false;
  }

  /** @param {string} s @returns {string} */
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function aufUpdatePruefen() {
    schliesseHilfe();
    if (global.GF && global.GF.updates && global.GF.updates.pruefe) {
      global.GF.updates.pruefe();
    }
  }

  function oeffneDiagnose() {
    schliesseHilfe();
    if (global.GF && global.GF.diagnose && global.GF.diagnose._oeffneModal) {
      global.GF.diagnose._oeffneModal();
    }
  }

  function oeffneBenutzerhandbuch() {
    schliesseHilfe();
    window.open('docs/BENUTZERHANDBUCH.html', '_blank', 'noopener');
  }

  function init() {
    var btn = $('btnHilfe');
    if (btn) btn.addEventListener('click', oeffneHilfe);

    var s = $('hilfeSchliessen');
    if (s) s.addEventListener('click', schliesseHilfe);

    var hU = $('hilfeUpdate');
    if (hU) hU.addEventListener('click', aufUpdatePruefen);

    var hD = $('hilfeDiagnose');
    if (hD) hD.addEventListener('click', oeffneDiagnose);

    var hH = $('hilfeHandbuch');
    if (hH) hH.addEventListener('click', oeffneBenutzerhandbuch);

    var hUe = $('hilfeUeber');
    if (hUe) hUe.addEventListener('click', zeigeUeber);

    // Klick auf Backdrop schliesst
    var bd = $('hilfeBackdrop');
    if (bd) bd.addEventListener('click', function (ev) {
      if (ev.target === bd) schliesseHilfe();
    });
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.hilfe = { oeffne: oeffneHilfe, schliesse: schliesseHilfe };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
