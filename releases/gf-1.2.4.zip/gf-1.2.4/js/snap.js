// js/snap.js — Snap-Index-Orchestrierung (v1.2 Assistiertes Messen).
// Baut aus den Vektor-Eckpunkten (GF.pdf.snapPunkte) einen Grid-Index (KDTree)
// und kapselt die px<->pt-Toleranz + Verfuegbarkeits-Logik. Das eigentliche
// Einrasten macht GF.polygon.snap.aufEndpunkt (reine Geometrie).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.snap = GF.snap || /** @type {GfSnapModule} */ ({});

  // Bildschirm-Radius (px) fuer das magnetische Einrasten.
  GF.snap.RADIUS_PX = 12;

  // v1.2 Detailgrad-Cap: Obergrenze fuer Vektor-Ecken pro Seite. Darueber wird der
  // KDTree NICHT gebaut (Bauzeit + Speicher waeren unverhaeltnismaessig) und der
  // Magnet still abgeschaltet — Zeichnen/Maßstab bleiben unberuehrt. Bbox-Filter +
  // Distanz-Dezimierung in pdf-vektor.js druecken selbst extreme Outline-Plaene auf
  // ~60–70k (ein KDTree davon baut in ~12 ms); dieser Cap ist nur noch die Ruecklage
  // fuer pathologische Plaene, die danach IMMER NOCH ueberbordend detailreich sind.
  GF.snap.MAX_VERTICES = 150000;

  /**
   * Baut den Snap-Index aus extrahierten Punkten/Kanten. Leer -> null. Ueber dem
   * Detailgrad-Cap -> Skip-Markierung (kdTree null, uebersprungen true), sonst
   * KDTree. Rein (ohne pdf.js testbar).
   * @param {{vertices:any[], kanten:any[]}|null} res
   * @returns {{kdTree:any, kanten:any[], vertexAnzahl:number, uebersprungen?:boolean} | null}
   */
  GF.snap._ausPunkten = function (res) {
    if (!res || !res.vertices || !res.vertices.length) return null;
    var n = res.vertices.length;
    if (n > GF.snap.MAX_VERTICES) {
      return { kdTree: null, kanten: [], vertexAnzahl: n, uebersprungen: true };
    }
    return {
      kdTree: new GF.util.KDTree(res.vertices, 50),
      kanten: res.kanten || [],
      vertexAnzahl: n
    };
  };

  /**
   * Baut den Snap-Index (KDTree der Vektor-Ecken) fuer eine Seite.
   * @param {any} pdfDoc
   * @param {number} seite
   * @returns {Promise<{kdTree:any, kanten:any[], vertexAnzahl:number, uebersprungen?:boolean} | null>}
   */
  GF.snap.baue = function (pdfDoc, seite) {
    if (!GF.pdf || !GF.pdf.snapPunkte) return Promise.resolve(null);
    return GF.pdf.snapPunkte(pdfDoc, seite).then(GF.snap._ausPunkten);
  };

  // Bildschirm-px -> PDF-pt-Toleranz beim aktuellen Zoom.
  GF.snap.toleranzPt = function (px, zoom) {
    if (!isFinite(zoom) || zoom <= 0) return px;
    return px / zoom;
  };

  /**
   * Naechster Snap-Punkt (oder der unveraenderte Punkt, wenn nichts in Toleranz).
   * @param {Punkt} pdfPt
   * @param {{kdTree:any}|null} idx  (= GF.state.snapIndex)
   * @param {number} px   Bildschirm-Toleranz
   * @param {number} zoom aktueller Viewport-Zoom
   * @returns {Punkt}
   */
  GF.snap.naechster = function (pdfPt, idx, px, zoom) {
    if (!idx || !idx.kdTree || !GF.polygon || !GF.polygon.snap) return pdfPt;
    return GF.polygon.snap.aufEndpunkt(pdfPt, idx.kdTree, GF.snap.toleranzPt(px, zoom));
  };

  /**
   * Magnet verfuegbar? Nur bei Vektor-PDF (>=0.3) + aufgebautem Index + snapAktiv.
   * @returns {boolean}
   */
  GF.snap.verfuegbar = function () {
    var s = GF.state;
    if (!s) return false;
    return s.snapAktiv === true
        && typeof s.vektorAnteil === 'number' && s.vektorAnteil >= 0.3
        && !!s.snapIndex;
  };

})(typeof window !== 'undefined' ? window : globalThis);
