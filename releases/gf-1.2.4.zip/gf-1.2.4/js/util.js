// @ts-check
// js/util.js — Geometrie- und Format-Helfer.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.util = GF.util || /** @type {GfUtilModule} */ ({});

  // ---- Zahlen-Formatierung (deutsch: Komma als Dezimaltrenner) ----

  /**
   * Parst einen deutschen Zahlen-String (Komma als Dezimal).
   * @param {string | number} s
   * @returns {number} NaN bei ungueltigem Input.
   */
  GF.util.parseZahlDE = function (s) {
    if (typeof s !== 'string') s = String(s);
    var t = s.trim();
    if (t === '') return NaN;
    if (t.indexOf(',') >= 0) {
      // Deutsche Schreibweise: Punkte sind Tausender-Trenner, Komma ist Dezimal.
      // z.B. "1.234,56" -> 1234.56
      t = t.replace(/\./g, '').replace(',', '.');
    }
    // Ohne Komma: Punkt (falls vorhanden) wird als Dezimaltrenner akzeptiert,
    // damit "8.92" auch funktioniert (typische Eingabe aus US-CAD-Exporten).
    var n = Number(t);
    return isFinite(n) ? n : NaN;
  };

  /**
   * Formatiert eine Zahl in deutscher Schreibweise (Komma).
   * @param {number} n
   * @param {number} [stellen=2]
   * @returns {string} "—" bei NaN/Infinity.
   */
  GF.util.formatZahlDE = function (n, stellen) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    var st = (typeof stellen === 'number') ? stellen : 2;
    // Pre-Round mit Math.round: macht "5 immer auf" engine-unabhaengig
    // deterministisch (toFixed selbst macht in manchen Engines Banker's-
    // Rounding). Storage bleibt davon unberuehrt (siehe app.js * 1000).
    var faktor = Math.pow(10, st);
    return (Math.round(n * faktor) / faktor).toFixed(st).replace('.', ',');
  };

  // ---- Geometrie ----

  /**
   * Euklidischer Abstand zwischen zwei 2D-Punkten.
   * @param {Punkt} a
   * @param {Punkt} b
   * @returns {number}
   */
  GF.util.abstand2D = function (a, b) {
    var dx = b.x - a.x;
    var dy = b.y - a.y;
    return Math.sqrt(dx * dx + dy * dy);
  };

  /**
   * Liefert true wenn Strecken (a1,a2) und (b1,b2) sich echt schneiden
   * (Beruehrung in Endpunkten zaehlt nicht als Schnitt).
   * @param {Punkt} a1
   * @param {Punkt} a2
   * @param {Punkt} b1
   * @param {Punkt} b2
   * @returns {boolean}
   */
  GF.util.segmenteSchneidenSich = function (a1, a2, b1, b2) {
    function kreuz(p1, p2, p3) {
      return (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
    }
    var d1 = kreuz(b1, b2, a1);
    var d2 = kreuz(b1, b2, a2);
    var d3 = kreuz(a1, a2, b1);
    var d4 = kreuz(a1, a2, b2);
    if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
        ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
      return true;
    }
    return false;
  };

  // ---- Spatial Index per Grid-Hash (statt KD-Tree — einfacher und schnell genug) ----

  GF.util.KDTree = /** @type {GfKDTreeConstructor} */ (/** @type {any} */ (
    /**
     * @this {GfKDTreeInstance}
     * @param {Punkt[]} [punkte]
     * @param {number} [gridSize=50]
     */
    function KDTree(punkte, gridSize) {
      this._punkte = (punkte || []).slice();
      this._gridSize = gridSize || 50;          // 50 pt-Buckets
      this._grid = Object.create(null);
      var self = this;
      this._punkte.forEach(function (p, idx) {
        var key = self._bucket(p.x, p.y);
        (self._grid[key] = self._grid[key] || []).push(idx);
      });
    }
  ));

  GF.util.KDTree.prototype._bucket = function (x, y) {
    return Math.floor(x / this._gridSize) + ',' + Math.floor(y / this._gridSize);
  };

  /**
   * Liefert den naechstgelegenen Punkt innerhalb maxRadius (in PDF-Pt).
   * Ohne maxRadius wird ein gridSize-Radius angenommen.
   * Liefert null wenn nichts in Reichweite.
   * @param {Punkt} q
   * @param {number} [maxRadius]
   * @returns {Punkt | null}
   */
  GF.util.KDTree.prototype.findeNaechsten = function (q, maxRadius) {
    var g = this._gridSize;
    var maxR = (typeof maxRadius === 'number' && maxRadius > 0) ? maxRadius : g;
    var range = Math.max(1, Math.ceil(maxR / g));
    var qbx = Math.floor(q.x / g);
    var qby = Math.floor(q.y / g);
    var best = null, bestD = Infinity;
    var maxDsq = maxR * maxR;

    for (var dx = -range; dx <= range; dx++) {
      for (var dy = -range; dy <= range; dy++) {
        var key = (qbx + dx) + ',' + (qby + dy);
        var arr = this._grid[key];
        if (!arr) continue;
        for (var i = 0; i < arr.length; i++) {
          var p = this._punkte[arr[i]];
          var d = (p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y);
          if (d < bestD && d <= maxDsq) {
            bestD = d;
            best = p;
          }
        }
      }
    }
    return best;
  };

  GF.util.KDTree.prototype.anzahl = function () { return this._punkte.length; };

  // ---- HTML-Escape (gegen Sonderzeichen in Benutzereingaben) ----

  /**
   * @param {any} s
   * @returns {string}
   */
  GF.util.esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  // ---- UUID (RFC4122 v4) ----

  /**
   * @returns {string}
   */
  GF.util.uuid = function () {
    if (global.crypto && typeof global.crypto.randomUUID === 'function') {
      return global.crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0;
      var v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  };

})(typeof window !== 'undefined' ? window : globalThis);
