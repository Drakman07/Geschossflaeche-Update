// @ts-check
// js/pdf-loader.js — PDF laden, pdf.js initialisieren, Vektor-Anteil bestimmen.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  /**
   * Bei file://-Aufruf scheitert pdf.worker.js am CORS-Check. Workaround:
   * workerSrc leeren — pdf.js faellt auf Main-Thread zurueck.
   * @returns {boolean} false wenn pdfjsLib fehlt.
   */
  function konfigurierePdfJs() {
    if (!global.pdfjsLib) {
      console.warn('[gf-pdf] pdfjsLib nicht geladen — lib/pdf.min.js fehlt?');
      return false;
    }
    if (global.location && global.location.protocol === 'file:') {
      global.pdfjsLib.GlobalWorkerOptions.workerSrc = '';
    } else {
      global.pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
    }
    return true;
  }

  /**
   * Laedt ein File-Objekt als pdf.js-Dokument.
   * @param {File | Blob} file
   * @returns {Promise<any>}
   */
  GF.pdf.lade = function (file) {
    return new Promise(function (resolve, reject) {
      if (!konfigurierePdfJs()) {
        reject(new Error('pdf.js-Library nicht verfügbar'));
        return;
      }
      var fr = new FileReader();
      fr.onload = function () {
        var arr = new Uint8Array(/** @type {ArrayBuffer} */ (fr.result));
        global.pdfjsLib.getDocument({ data: arr }).promise
          .then(resolve)
          .catch(function (e) {
            reject(new Error('PDF konnte nicht gelesen werden: ' + (e && e.message || e)));
          });
      };
      fr.onerror = function () { reject(fr.error); };
      fr.readAsArrayBuffer(/** @type {File} */ (file));
    });
  };

  /**
   * Rohzaehlung der Operator-Typen einer Seite.
   * @param {any} pdfDoc pdf.js-Dokument
   * @param {number} seite 1-basiert
   * @returns {Promise<PdfStatistik>}
   */
  GF.pdf.statistik = function (pdfDoc, seite) {
    return pdfDoc.getPage(seite).then(function (page) {
      // Blattflaeche aus der MediaBox (PDF-User-Space, pt^2). Das Verhaeltnis
      // Bild/Blatt ist skaleninvariant, daher reicht der User-Space.
      var view = page.view || [0, 0, 0, 0];
      var blattFlaeche = Math.abs((view[2] - view[0]) * (view[3] - view[1]));
      return page.getOperatorList().then(function (opList) {
        return _analysiere(opList.fnArray, opList.argsArray, global.pdfjsLib.OPS, blattFlaeche);
      });
    });
  };

  /**
   * Heuristik: Anteil Vektor-Operatoren am gewichteten Gesamtinhalt.
   * 1.0 = reines Vektor-PDF, &lt;0.3 = ueberwiegend Raster.
   * @param {any} pdfDoc
   * @param {number} seite
   * @returns {Promise<number>}
   */
  GF.pdf.vektorAnteil = function (pdfDoc, seite) {
    return GF.pdf.statistik(pdfDoc, seite).then(function (s) {
      return _berechneAnteil(s);
    });
  };

  /**
   * @param {number[]} fnArray
   * @param {any} OPS
   * @returns {PdfStatistik}
   */
  function _zaehleOps(fnArray, OPS) {
    var vektor = 0, bild = 0, andere = 0;
    var vektorOps = [
      OPS.moveTo, OPS.lineTo, OPS.curveTo, OPS.curveTo2, OPS.curveTo3,
      OPS.closePath, OPS.rectangle, OPS.fill, OPS.stroke, OPS.fillStroke,
      OPS.eoFill, OPS.eoFillStroke, OPS.closeStroke, OPS.closeFillStroke
    ];
    var bildOps = [
      OPS.paintImageXObject, OPS.paintImageMaskXObject,
      OPS.paintInlineImageXObject, OPS.paintJpegXObject,
      OPS.paintImageXObjectRepeat, OPS.paintImageMaskXObjectRepeat
    ];
    for (var i = 0; i < fnArray.length; i++) {
      var op = fnArray[i];
      if (vektorOps.indexOf(op) >= 0) vektor++;
      else if (bildOps.indexOf(op) >= 0) bild++;
      else andere++;
    }
    return { vektor: vektor, bild: bild, andere: andere, summe: fnArray.length };
  }

  // CTM-Komposition wie pdf.js Util.transform (n zuerst), identisch zu pdf-vektor.js.
  function _matMul(m, n) {
    return [
      m[0] * n[0] + m[2] * n[1],
      m[1] * n[0] + m[3] * n[1],
      m[0] * n[2] + m[2] * n[3],
      m[1] * n[2] + m[3] * n[3],
      m[0] * n[4] + m[2] * n[5] + m[4],
      m[1] * n[4] + m[3] * n[5] + m[5]
    ];
  }

  /**
   * Analysiert eine Operatorliste: Vektor/Bild-Zaehlung PLUS vom Raster
   * gedeckter Blattflaechen-Anteil. Fuehrt die CTM (save/restore/transform) mit
   * und summiert je Bild-Op die gedeckte Flaeche = |det(CTM)| (pdf.js zeichnet
   * jedes Bild ins Einheitsquadrat, der aktuelle CTM gibt seine Blattflaeche).
   * pdf.js 3.x kodiert Pfade als OPS.constructPath (Sub-Ops im argsArray) — daher
   * zaehlt constructPath als Vektor-Beleg. Ohne pdf.js testbar (OPS als schlichtes
   * Zahlen-Objekt, argsArray parallel zu fnArray).
   * Hinweis: in Form-XObjects (paintFormXObjectBegin) eingebettete Bilder werden
   * mit ihrem Form-Matrix-Offset nicht erfasst — fuer direkte Scans (paintImage
   * unter save/transform/restore) ist die Flaeche exakt; Kalibrier-Check am echten
   * Scan (s. Plan, Verifikation Schritt 1).
   * @param {number[]} fnArray
   * @param {any[]} argsArray
   * @param {any} OPS
   * @param {number} blattFlaeche  Blattflaeche in pt^2 (>0)
   * @returns {PdfStatistik}
   */
  function _analysiere(fnArray, argsArray, OPS, blattFlaeche) {
    var vektorOps = [
      OPS.moveTo, OPS.lineTo, OPS.curveTo, OPS.curveTo2, OPS.curveTo3,
      OPS.closePath, OPS.rectangle, OPS.fill, OPS.stroke, OPS.fillStroke,
      OPS.eoFill, OPS.eoFillStroke, OPS.closeStroke, OPS.closeFillStroke,
      OPS.constructPath
    ];
    var bildOps = [
      OPS.paintImageXObject, OPS.paintImageMaskXObject,
      OPS.paintInlineImageXObject, OPS.paintJpegXObject,
      OPS.paintImageXObjectRepeat, OPS.paintImageMaskXObjectRepeat
    ];
    var vektor = 0, bild = 0, andere = 0, summeBild = 0;
    var ctm = [1, 0, 0, 1, 0, 0], stack = [];
    for (var i = 0; i < fnArray.length; i++) {
      var op = fnArray[i];
      if (op === OPS.save) {
        stack.push(ctm.slice());
      } else if (op === OPS.restore) {
        if (stack.length) ctm = stack.pop();
      } else if (op === OPS.transform) {
        var a = argsArray && argsArray[i];
        if (a && a.length >= 6) ctm = _matMul(ctm, [a[0], a[1], a[2], a[3], a[4], a[5]]);
      } else if (bildOps.indexOf(op) >= 0) {
        bild++;
        summeBild += Math.abs(ctm[0] * ctm[3] - ctm[1] * ctm[2]);
      } else if (vektorOps.indexOf(op) >= 0) {
        vektor++;
      } else {
        andere++;
      }
    }
    var bildFlaeche = (blattFlaeche > 0) ? (summeBild / blattFlaeche) : 0;
    if (!(bildFlaeche > 0)) bildFlaeche = 0;
    if (bildFlaeche > 1) bildFlaeche = 1;
    return {
      vektor: vektor, bild: bild, andere: andere, summe: fnArray.length,
      bildFlaeche: bildFlaeche, bildFlaecheAbs: summeBild
    };
  }

  /**
   * Vektor-Anteil aus der Statistik. v1.2: FLAECHENBASIERT statt Operator-Quote.
   * `anteil = 1 - bildFlaeche` — der Anteil des Blatts, der NICHT von Raster
   * gedeckt ist. Voll-Scan (Bild ~100 %) -> ~0 (Sperre greift, egal wie reich das
   * Vektor-Overlay aus Rahmen/Legende/Schriftfeld ist). Reiner Vektorplan -> ~1.
   * Kleines eingebettetes Logo/Foto -> nahe 1 (kein Fehlalarm). Leere Seite
   * (kein Vektor, kein Bild) -> 0. Loest die alte Op-Quote ab, die ab ~86
   * Overlay-Ops faelschlich ueber 0,3 kippte.
   * @param {PdfStatistik} s
   * @returns {number}
   */
  function _berechneAnteil(s) {
    var bf = (s && typeof s.bildFlaeche === 'number' && isFinite(s.bildFlaeche)) ? s.bildFlaeche : 0;
    if ((s && s.vektor || 0) === 0 && bf === 0) return 0;   // nichts Maßhaltiges
    var a = 1 - bf;
    return a < 0 ? 0 : (a > 1 ? 1 : a);
  }

  GF.pdf.konfigurierePdfJs = konfigurierePdfJs;
  GF.pdf._zaehleOps = _zaehleOps;           // Test-Hook (Roh-Op-Zaehlung)
  GF.pdf._analysiere = _analysiere;         // Test-Hook (v1.2 flaechenbasiert)
  GF.pdf._berechneAnteil = _berechneAnteil; // Test-Hook

})(typeof window !== 'undefined' ? window : globalThis);
