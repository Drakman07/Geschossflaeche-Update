// @ts-check
// js/pdf-renderer.js — Layer-Caching-Renderer fuer PDF auf Canvas.
//
// Pattern:
//   1. preRender(pdfDoc, seite, renderScale=3.0) -> rendert die Seite EINMAL
//      auf einen Offscreen-Canvas in hoher Aufloesung.
//   2. zeichne(cache, sichtbarerCanvas, viewport) -> uebertraegt einen Ausschnitt
//      via drawImage mit Zoom/Pan. Sehr schnell, da pdf.js nicht neu rendert.
//
// Viewport-Modell:
//   viewport.zoom  – Verhaeltnis pixel/pt (1.0 = 1 PDF-Punkt = 1 Pixel)
//   viewport.panX  – PDF-Koordinate (pt) der linken oberen Sichtfenster-Ecke
//   viewport.panY  – PDF-Koordinate (pt) der linken oberen Sichtfenster-Ecke

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  var DEFAULT_RENDER_SCALE = 3.0;   // 3x ueberabtastung -> scharfer Zoom bis ca. 300%

  /**
   * Rendert pdfDoc/seite einmal in renderScale auf einen Offscreen-Canvas.
   * @param {any} pdfDoc
   * @param {number} seite
   * @param {number} [renderScale=3.0]
   * @returns {Promise<PdfCache>}
   */
  GF.pdf.preRender = function (pdfDoc, seite, renderScale) {
    var rs = renderScale || DEFAULT_RENDER_SCALE;
    return pdfDoc.getPage(seite).then(function (page) {
      var vpBase = page.getViewport({ scale: 1 });
      var vp = page.getViewport({ scale: rs });
      var canvas = document.createElement('canvas');
      canvas.width  = Math.ceil(vp.width);
      canvas.height = Math.ceil(vp.height);
      var ctx = /** @type {CanvasRenderingContext2D} */ (canvas.getContext('2d'));
      return page.render({ canvasContext: ctx, viewport: vp }).promise.then(function () {
        return {
          canvas: canvas,
          breitePt: vpBase.width,
          hoehePt: vpBase.height,
          renderScale: rs
        };
      });
    });
  };

  /**
   * Zeichnet den Cache auf den sichtbaren Canvas mit aktuellem Viewport.
   * Macht KEINE pdf.js-Renderung — nur drawImage.
   * @param {PdfCache | null} cache
   * @param {HTMLCanvasElement} sichtbarerCanvas
   * @param {Viewport} viewport
   */
  GF.pdf.zeichne = function (cache, sichtbarerCanvas, viewport) {
    var ctx = /** @type {CanvasRenderingContext2D} */ (sichtbarerCanvas.getContext('2d'));
    var W = sichtbarerCanvas.width;
    var H = sichtbarerCanvas.height;

    ctx.save();
    ctx.fillStyle = '#fafafa';
    ctx.fillRect(0, 0, W, H);

    if (!cache || !cache.canvas) {
      ctx.restore();
      return;
    }

    var z  = viewport.zoom;
    var rs = cache.renderScale;

    // Quell-Region im Offscreen-Canvas (Pixel)
    var sx = viewport.panX * rs;
    var sy = viewport.panY * rs;
    var sw = (W / z) * rs;
    var sh = (H / z) * rs;

    // Ziel-Region im sichtbaren Canvas. Muss VOR dem Clipping bestimmt werden,
    // weil sx/sy danach auf 0 geclippt werden — dadurch ginge der Margin verloren.
    var destX = sx < 0 ? -sx * z / rs : 0;
    var destY = sy < 0 ? -sy * z / rs : 0;

    // Source-Region auf gueltigen Cache-Bereich beschneiden
    if (sx < 0) { sw += sx; sx = 0; }
    if (sy < 0) { sh += sy; sy = 0; }
    if (sx + sw > cache.canvas.width)  sw = cache.canvas.width  - sx;
    if (sy + sh > cache.canvas.height) sh = cache.canvas.height - sy;

    var destW = sw * z / rs;
    var destH = sh * z / rs;

    if (sw > 0 && sh > 0) {
      ctx.drawImage(cache.canvas, sx, sy, sw, sh, destX, destY, destW, destH);
    }
    ctx.restore();
  };

  /**
   * Berechnet Viewport-Anfangswerte (Fit-to-Window).
   * @param {PdfCache} cache
   * @param {HTMLCanvasElement} sichtbarerCanvas
   * @returns {Viewport}
   */
  GF.pdf.fitViewport = function (cache, sichtbarerCanvas) {
    var W = sichtbarerCanvas.width  || 800;
    var H = sichtbarerCanvas.height || 600;
    var zX = W / cache.breitePt;
    var zY = H / cache.hoehePt;
    var z = Math.min(zX, zY) * 0.95;   // leichter Rand
    // Zentriert: panX so, dass (breitePt*z) zentriert in W liegt
    var sichtPtX = W / z;
    var sichtPtY = H / z;
    return {
      zoom: z,
      panX: (cache.breitePt - sichtPtX) / 2,
      panY: (cache.hoehePt - sichtPtY) / 2
    };
  };

  /**
   * Verschiebt den Viewport beim Zoom so, dass der Punkt unter der Maus
   * an Ort und Stelle bleibt.
   * @param {number} mausCanvasX
   * @param {number} mausCanvasY
   * @param {number} altZoom
   * @param {number} neuZoom
   * @param {{x: number, y: number}} panAlt
   * @returns {{x: number, y: number}}
   */
  GF.pdf.zoomUmPunkt = function (mausCanvasX, mausCanvasY, altZoom, neuZoom, panAlt) {
    // Mausposition in PDF-Koordinaten ist invariant.
    var mausPdfX = panAlt.x + mausCanvasX / altZoom;
    var mausPdfY = panAlt.y + mausCanvasY / altZoom;
    return {
      x: mausPdfX - mausCanvasX / neuZoom,
      y: mausPdfY - mausCanvasY / neuZoom
    };
  };

  /**
   * Compat-Stub fuer alte render-API.
   * @param {any} pdfDoc
   * @param {number} seite
   * @param {HTMLCanvasElement} canvas
   * @param {Viewport} [viewport]
   * @returns {Promise<void>}
   */
  GF.pdf.render = function (pdfDoc, seite, canvas, viewport) {
    return GF.pdf.preRender(pdfDoc, seite, 1.0).then(function (cache) {
      canvas.width  = cache.canvas.width;
      canvas.height = cache.canvas.height;
      GF.pdf.zeichne(cache, canvas, { zoom: 1.0, panX: 0, panY: 0 });
    });
  };

  GF.pdf.DEFAULT_RENDER_SCALE = DEFAULT_RENDER_SCALE;

})(typeof window !== 'undefined' ? window : globalThis);
