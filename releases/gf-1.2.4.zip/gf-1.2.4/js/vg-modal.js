// @ts-check
// js/vg-modal.js — Controller fuer Vollgeschoss-Beurteilungs-Modal.
// Live-Berechnung mit 300 ms Debounce, dynamische Gauben-Listen,
// Plausi-Check gegen Polygon-Flaeche, Speichern in geschoss.vollgeschoss.
//
// Oeffentliche API:
//   GF.VgModal.oeffne(geschossId, projekt)
//   GF.VgModal.schliesse()
//   GF.VgModal.istOffen()

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});

  // --- DOM-Hilfen ---
  /**
   * Element-Helper. Liefert `any`, damit Aufrufer direkt `.value`/`.disabled`/
   * etc. ohne Cast nutzen kann (UI-Code, kein Type-Sicherheits-Gewinn durch
   * strikte Typisierung der einzelnen `<input>`/`<select>`-Elemente).
   * @param {string} id
   * @returns {any}
   */
  function $(id) { return document.getElementById(id); }
  /** @param {any} s @returns {string} */
  function esc(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;' }[c];
    });
  }

  // --- State ---
  var aktivesGeschossId = null;
  var aktivesProjekt = null;
  var vergleichPolygonId = null;     // optional: Polygon-ID fuer Plausi-Check
  var gaubenLinks = [];               // [{b: '2,50', a: '0,80'}, ...] roh als Strings
  var gaubenRechts = [];
  var debounceHandle = null;
  var letztesErgebnis = null;         // letzte erfolgreiche Berechnung (fuer Speichern)
  var letzteEingabe = null;
  var letzteFehler = [];
  var manuellA230Override = null;     // manuell korrigierte Flaeche >= 2,30 m (m²) oder null

  // --- Public API ---
  GF.VgModal = {
    oeffne: oeffne,
    schliesse: schliesse,
    istOffen: function () {
      var bd = $('vgBackdrop');
      return !!(bd && bd.classList.contains('aktiv'));
    }
  };

  function oeffne(geschossId, projekt) {
    if (!projekt) projekt = GF.state.projekt;
    if (!projekt) return;
    var g = findeGeschoss(projekt, geschossId);
    if (!g) return;

    aktivesGeschossId = geschossId;
    aktivesProjekt = projekt;

    var titel = $('vgGeschossName');
    if (titel) titel.textContent = g.bezeichnung || 'Geschoss';

    // Bestehende VG-Daten laden, sonst leer
    var vg = g.vollgeschoss;
    manuellA230Override = null;
    if (vg && vg.eingaben) {
      setzeFelderAusEingaben(vg.eingaben);
      if (typeof vg.eingaben.A_2_30_override === 'number' && isFinite(vg.eingaben.A_2_30_override)) {
        manuellA230Override = vg.eingaben.A_2_30_override;
      }
      if (vg.kommentar) $('vgKommentar').value = vg.kommentar;
      if (vg.plausibilitaet && vg.plausibilitaet.polygonId) {
        vergleichPolygonId = vg.plausibilitaet.polygonId;
      }
    } else {
      leereFelder();
    }

    // Anrechnungs-Grenzhoehe vorbelegen: gespeicherte Berechnung > Projekt-
    // Metadata > 2,30. Das Feld ist nie leer — der Wert gilt projektweit.
    var ghVor = (vg && vg.eingaben && typeof vg.eingaben.grenzhoehe === 'number'
                 && isFinite(vg.eingaben.grenzhoehe) && vg.eingaben.grenzhoehe > 0)
      ? vg.eingaben.grenzhoehe
      : ((projekt.metadata && typeof projekt.metadata.grenzhoeheAnrechnung === 'number'
          && isFinite(projekt.metadata.grenzhoeheAnrechnung))
        ? projekt.metadata.grenzhoeheAnrechnung : 2.3);
    var ghFeld = $('vgGrenzhoehe');
    if (ghFeld) ghFeld.value = GF.util.formatZahlDE(ghVor, 2);

    fuelleVergleichDropdown(projekt, g);
    aktualisiereVergleichInfo();
    rendereGaubenListen();
    berechneUndRendere();

    var bd = $('vgBackdrop');
    bd.classList.add('aktiv');
    bd.classList.add('vg-aktiv');
    setzeMinimiertZustand(istMinimiert());
    positioniereModal();
    setTimeout(function () { $('vgLB') && $('vgLB').focus(); }, 50);
  }

  function schliesse() {
    var bd = $('vgBackdrop');
    if (bd) { bd.classList.remove('aktiv'); bd.classList.remove('vg-aktiv'); }
    aktivesGeschossId = null;
    aktivesProjekt = null;
    vergleichPolygonId = null;
    gaubenLinks = [];
    gaubenRechts = [];
    letztesErgebnis = null;
    letzteEingabe = null;
    letzteFehler = [];
    manuellA230Override = null;
    if (debounceHandle) { clearTimeout(debounceHandle); debounceHandle = null; }
  }

  // --- Geschoss-Helper ---
  function findeGeschoss(projekt, id) {
    if (!projekt || !projekt.geschosse) return null;
    for (var i = 0; i < projekt.geschosse.length; i++) {
      if (projekt.geschosse[i].id === id) return projekt.geschosse[i];
    }
    return null;
  }

  // --- Felder lesen/schreiben ---
  function leereFelder() {
    ['vgLB','vgLL','vgHKL','vgHKR','vgAlphaL','vgAlphaR','vgAKleiner','vgAGroesser','vgKommentar']
      .forEach(function (id) { var el = $(id); if (el) el.value = ''; });
    gaubenLinks = [];
    gaubenRechts = [];
  }

  // Befuellt die VG-Modal-Eingabefelder mit einer gespeicherten Berechnung.
  // num() und ortgangAusZahl() geben absichtlich 3 Stellen zurueck (voller
  // Storage-Wert): User darf eine bestehende 1,234 weiter verfeinern ohne
  // Praezisions-Verlust beim Re-Edit. Analog zu den Edit-Vorbelegungs-
  // Carve-Outs in app.js (kantenEditInput, flaecheModalAngesetzt).
  // ang() bleibt bei 1 Stelle, weil Winkel in Grad keine sub-Zehntel-
  // Praezision brauchen.
  function setzeFelderAusEingaben(e) {
    function num(n) { return (n == null || isNaN(n)) ? '' : GF.util.formatZahlDE(n, 3); }
    function ang(n) { return (n == null || isNaN(n)) ? '' : GF.util.formatZahlDE(n, 1); }
    $('vgLB').value = num(e.L_B);
    $('vgLL').value = num(e.L_L);
    $('vgHKL').value = num(e.h_KL);
    $('vgHKR').value = num(e.h_KR);
    $('vgAlphaL').value = ang(e.alpha_L);
    $('vgAlphaR').value = ang(e.alpha_R);
    $('vgAKleiner').value = num(e.A_kleiner);
    $('vgAGroesser').value = num(e.A_groesser);
    function ortgangAusZahl(v) { return (v == null || isNaN(v)) ? '' : GF.util.formatZahlDE(v, 3); }
    gaubenLinks  = (e.gauben_links  || []).map(function (g) { return { b: num(g.b), a: num(g.a), ortgang: ortgangAusZahl(g.ortgang) }; });
    gaubenRechts = (e.gauben_rechts || []).map(function (g) { return { b: num(g.b), a: num(g.a), ortgang: ortgangAusZahl(g.ortgang) }; });
  }

  function leseRoheEingaben() {
    return {
      L_B: $('vgLB').value,
      L_L: $('vgLL').value,
      h_KL: $('vgHKL').value,
      h_KR: $('vgHKR').value,
      alpha_L: $('vgAlphaL').value,
      alpha_R: $('vgAlphaR').value,
      A_kleiner: $('vgAKleiner').value,
      A_groesser: $('vgAGroesser').value,
      grenzhoehe: $('vgGrenzhoehe') ? $('vgGrenzhoehe').value : '',
      gauben_links: gaubenLinks.slice(),
      gauben_rechts: gaubenRechts.slice()
    };
  }

  // Sind alle VG-Eingabefelder leer? Wird im speichere()-Pfad genutzt:
  // wenn ja, deutet das auf "User will VG-Berechnung entfernen" hin und
  // wir delegieren an zuruecksetze() (impliziter Reset mit Bestaetigung).
  // Die Grenzhoehe zaehlt bewusst NICHT mit — sie ist immer vorbefuellt
  // und wuerde den Leer-Check sonst dauerhaft blockieren.
  function alleEingabefelderLeer() {
    var roh = leseRoheEingaben();
    function leer(v) { return v == null || String(v).trim() === ''; }
    var basisLeer = leer(roh.L_B) && leer(roh.L_L)
                 && leer(roh.h_KL) && leer(roh.h_KR)
                 && leer(roh.alpha_L) && leer(roh.alpha_R)
                 && leer(roh.A_kleiner) && leer(roh.A_groesser);
    var gaubenLeer = (gaubenLinks || []).length === 0
                  && (gaubenRechts || []).length === 0;
    return basisLeer && gaubenLeer;
  }

  // --- Vergleichs-Polygon ---
  function fuelleVergleichDropdown(projekt, geschoss) {
    var sel = $('vgVergleichPolygon');
    if (!sel) return;
    sel.innerHTML = '';
    var polys = (projekt.polygone || []).filter(function (p) { return p.geschossId === geschoss.id; });
    if (polys.length === 0) {
      var opt = document.createElement('option');
      opt.value = '';
      opt.textContent = '— kein Polygon —';
      sel.appendChild(opt);
      sel.disabled = true;
      vergleichPolygonId = null;
      return;
    }
    sel.disabled = false;
    // groesstes als Default
    polys.sort(function (a, b) { return (b.flaecheAngesetztQM || 0) - (a.flaecheAngesetztQM || 0); });
    if (!vergleichPolygonId || !polys.some(function (p) { return p.id === vergleichPolygonId; })) {
      vergleichPolygonId = polys[0].id;
    }
    polys.forEach(function (p) {
      var opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.bezeichnung + ' (' + GF.util.formatZahlDE(p.flaecheAngesetztQM || 0, 2) + ' m²)';
      if (p.id === vergleichPolygonId) opt.selected = true;
      sel.appendChild(opt);
    });
  }

  function holeVergleichPolygon() {
    if (!aktivesProjekt || !vergleichPolygonId) return null;
    for (var i = 0; i < aktivesProjekt.polygone.length; i++) {
      if (aktivesProjekt.polygone[i].id === vergleichPolygonId) return aktivesProjekt.polygone[i];
    }
    return null;
  }

  function aktualisiereVergleichInfo() {
    var info = $('vgVergleichInfo');
    var plausi = $('vgPlausi');
    if (!info) return;
    var p = holeVergleichPolygon();
    if (!p) {
      info.textContent = '—';
      info.classList.remove('abw');
      if (plausi) plausi.hidden = true;
      return;
    }
    var fl = p.flaecheAngesetztQM || 0;
    info.textContent = 'Polygonfläche ' + GF.util.formatZahlDE(fl, 2) + ' m²';

    if (letztesErgebnis && fl > 0 && letztesErgebnis.A_G_geometrie > 0) {
      // Polygon ist die offizielle A_G; verglichen wird mit L_B * L_L (Rechteck-Modell
      // fuer A_2,30). Bei groesserer Abweichung sind die VG-Eingaben vermutlich
      // nicht stimmig zum Polygon.
      var abw = Math.abs(letztesErgebnis.A_G_geometrie - fl) / fl * 100;
      if (abw > 5) {
        info.classList.add('abw');
        if (plausi) {
          plausi.hidden = false;
          plausi.textContent = 'L_B × L_L weicht um '
            + GF.util.formatZahlDE(abw, 1) + ' % von der Polygonfläche ab. Eingaben prüfen.';
        }
      } else {
        info.classList.remove('abw');
        if (plausi) plausi.hidden = true;
      }
    } else {
      info.classList.remove('abw');
      if (plausi) plausi.hidden = true;
    }
  }

  // --- Gauben-Listen ---
  function rendereGaubenListen() {
    rendereGaubenListe('vgGaubenLinks', gaubenLinks, 'links');
    rendereGaubenListe('vgGaubenRechts', gaubenRechts, 'rechts');
  }

  function rendereGaubenListe(hostId, liste, seite) {
    var host = $(hostId);
    if (!host) return;
    if (liste.length === 0) {
      host.innerHTML = '<p class="vg-hint" style="margin:0;">Keine Gauben.</p>';
      return;
    }
    var html = '';
    liste.forEach(function (g, idx) {
      html += '<div class="vg-gauben-zeile" data-seite="' + seite + '" data-idx="' + idx + '">'
            +   '<span class="vg-gauben-nr">G' + (idx + 1) + '</span>'
            +   '<input type="text" inputmode="decimal" data-feld="b" value="' + esc(g.b || '') + '" placeholder="Breite b (m) *">'
            +   '<input type="text" inputmode="decimal" data-feld="a" value="' + esc(g.a || '') + '" placeholder="Trauf-Abstand a (m) *">'
            +   '<input type="text" inputmode="decimal" data-feld="ortgang" value="' + esc(g.ortgang || '') + '" placeholder="Ortgang (m)">'
            +   '<button type="button" class="vg-gauben-del" data-aktion="del" title="Gaube löschen">×</button>'
            + '</div>';
    });
    host.innerHTML = html;
  }

  function gaubeHinzu(seite) {
    var liste = (seite === 'links') ? gaubenLinks : gaubenRechts;
    if (liste.length >= 5) { return; }
    liste.push({ b: '', a: '', ortgang: '' });
    rendereGaubenListe(seite === 'links' ? 'vgGaubenLinks' : 'vgGaubenRechts', liste, seite);
    triggerBerechnung();
  }

  function gaubeWeg(seite, idx) {
    var liste = (seite === 'links') ? gaubenLinks : gaubenRechts;
    liste.splice(idx, 1);
    rendereGaubenListe(seite === 'links' ? 'vgGaubenLinks' : 'vgGaubenRechts', liste, seite);
    triggerBerechnung();
  }

  // --- Berechnung + Rendering ---
  function triggerBerechnung() {
    // Jede Geometrie-/Gauben-/Grenzhoehen-Aenderung verwirft eine zuvor manuell
    // angesetzte Flaeche >= 2,30 m (wie beim Polygon: Kanten-Edit loescht die
    // Flaechenkorrektur). Die Override-Bestaetigung selbst ruft berechneUndRendere
    // direkt auf — nicht diesen Pfad — und bleibt damit erhalten.
    manuellA230Override = null;
    if (debounceHandle) clearTimeout(debounceHandle);
    debounceHandle = setTimeout(berechneUndRendere, 300);
  }

  function berechneUndRendere() {
    debounceHandle = null;
    if (!aktivesGeschossId) return;

    var roh = leseRoheEingaben();
    var parse = GF.Vollgeschoss.validierung.parseEingabe(roh);
    letzteEingabe = parse.eingabe;
    letzteFehler = parse.fehler;

    rendereFehler(parse.fehler);

    // Wenn Pflichtfelder fehlen oder Validation-Fehler: Platzhalter zeichnen
    var pflichtOk = ['L_B','L_L','h_KL','h_KR','alpha_L','alpha_R'].every(function (k) {
      var n = parse.eingabe[k];
      return typeof n === 'number' && isFinite(n);
    });
    if (!pflichtOk || parse.fehler.length > 0) {
      rendereDiagrammPlatzhalter();
      rendereHeroNeutral();
      letztesErgebnis = null;
      aktualisiereVergleichInfo();
      return;
    }

    try {
      // Polygonflaeche aus aktuell gewaehltem Vergleichs-Polygon als A_G uebergeben.
      // So zeigt das Aufmassblatt durchgaengig dieselbe Grundflaeche wie das Polygon.
      var p = holeVergleichPolygon();
      var eingabeFuerBerechnung = parse.eingabe;
      if (p && typeof p.flaecheAngesetztQM === 'number' && p.flaecheAngesetztQM > 0) {
        eingabeFuerBerechnung = Object.assign({}, parse.eingabe, { A_G_polygon: p.flaecheAngesetztQM });
      }
      // Manuelle Korrektur der Flaeche >= 2,30 m durchreichen (parseEingabe
      // strippt unbekannte Felder, daher hier nach dem Parsen injizieren).
      if (typeof manuellA230Override === 'number' && isFinite(manuellA230Override)) {
        eingabeFuerBerechnung = Object.assign({}, eingabeFuerBerechnung, { A_2_30_override: manuellA230Override });
      }
      var erg = GF.Vollgeschoss.berechne(eingabeFuerBerechnung);
      letztesErgebnis = erg;
      rendereDiagramme(parse.eingabe, erg);
      rendereHero(erg);
      rendereWarnungen(erg.warnungen || []);
      aktualisiereVergleichInfo();
    } catch (e) {
      console.error('[vg-modal] Berechnung fehlgeschlagen:', e);
      rendereFehler([String(e.message || e)]);
      letztesErgebnis = null;
    }
  }

  function rendereDiagramme(eingabe, ergebnis) {
    var diag = GF.Vollgeschoss.diagramm;
    var geom = GF.Vollgeschoss.geometrie;

    var qs = $('vgSvgQuerschnitt');
    if (qs) diag.renderQuerschnitt(qs, geom.querschnitt(eingabe, ergebnis));

    var gr = $('vgSvgGrundriss');
    if (gr) diag.renderGrundriss(gr, geom.grundriss(eingabe, ergebnis));

    var aL = $('vgSvgAufrissL');
    if (aL) diag.renderAufriss(aL, geom.aufriss('links',  eingabe, ergebnis));
    var aR = $('vgSvgAufrissR');
    if (aR) diag.renderAufriss(aR, geom.aufriss('rechts', eingabe, ergebnis));
  }

  function rendereDiagrammPlatzhalter() {
    var diag = GF.Vollgeschoss.diagramm;
    ['vgSvgQuerschnitt','vgSvgGrundriss'].forEach(function (id) {
      var el = $(id); if (el) diag.renderPlatzhalter(el, 'Pflichtfelder ergänzen', 400, 240);
    });
    ['vgSvgAufrissL','vgSvgAufrissR'].forEach(function (id) {
      var el = $(id); if (el) diag.renderPlatzhalter(el, '—', 400, 200);
    });
  }

  function rendereHero(erg) {
    var pille = $('vgHeroPille');
    var icon = $('vgHeroIcon');
    var text = $('vgHeroText');
    if (pille) pille.classList.remove('ok','nein','neutral');
    if (erg.vollgeschoss) {
      if (pille) pille.classList.add('ok');
      if (icon) icon.textContent = '✓';
      if (text) text.textContent = 'Ist Vollgeschoss · ' + formatProzent(erg.anteil_2_30) + ' ≥ 2,30 m';
    } else {
      if (pille) pille.classList.add('nein');
      if (icon) icon.textContent = '✗';
      if (text) text.textContent = 'Kein Vollgeschoss · ' + formatProzent(erg.anteil_2_30) + ' ≥ 2,30 m';
    }
    setText('vgStatAG',     GF.util.formatZahlDE(erg.A_G, 2) + ' m²');
    setText('vgStatA230',   GF.util.formatZahlDE(erg.A_2_30, 2) + ' m²');
    rendereA230Steuerung(erg);
    setText('vgStatZdF',    GF.util.formatZahlDE(erg.zweidrittel_flaeche, 2) + ' m²');
    setText('vgStatAnteil', formatProzent(erg.anteil_2_30));
    setText('vgStatBm',     GF.util.formatZahlDE(erg.Bm, 2) + ' m');

    // Anrechenbare Flaeche nur zeigen, wenn die Satzungs-Grenzhoehe abweicht
    var rowAanr = $('vgRowAanr');
    if (rowAanr) {
      var ghErg = (typeof erg.grenzhoehe === 'number' && isFinite(erg.grenzhoehe)) ? erg.grenzhoehe : 2.3;
      if (Math.abs(ghErg - 2.3) > 1e-9 && typeof erg.A_anrechenbar === 'number') {
        rowAanr.hidden = false;
        setText('vgStatAanrLabel', 'A ≥ ' + GF.util.formatZahlDE(ghErg, 2) + ' m (anrechenbar)');
        setText('vgStatAanr', GF.util.formatZahlDE(erg.A_anrechenbar, 2) + ' m²');
      } else {
        rowAanr.hidden = true;
      }
    }
  }

  function rendereHeroNeutral() {
    var pille = $('vgHeroPille');
    var icon = $('vgHeroIcon');
    var text = $('vgHeroText');
    if (pille) { pille.classList.remove('ok','nein'); pille.classList.add('neutral'); }
    if (icon) icon.textContent = '…';
    if (text) text.textContent = 'Eingaben für Ergebnis ergänzen';
    ['vgStatAG','vgStatA230','vgStatZdF','vgStatAnteil','vgStatBm'].forEach(function (id) { setText(id, '—'); });
    var rowAanr = $('vgRowAanr');
    if (rowAanr) rowAanr.hidden = true;
    // A>=2,30-Korrektur-Steuerung verstecken (kein gueltiges Ergebnis)
    var a230Wert = $('vgStatA230'); if (a230Wert) { a230Wert.hidden = false; a230Wert.classList.remove('korrigiert'); }
    var a230BE = $('vgBtnA230Edit'); if (a230BE) a230BE.hidden = true;
    var a230BR = $('vgBtnA230Reset'); if (a230BR) a230BR.hidden = true;
    var a230Box = $('vgA230Edit'); if (a230Box) a230Box.hidden = true;
  }

  function rendereWarnungen(warnungen) {
    var host = $('vgWarnungen');
    if (!host) return;
    if (!warnungen || warnungen.length === 0) { host.hidden = true; host.innerHTML = ''; return; }
    host.hidden = false;
    host.innerHTML = '<strong>⚠ Warnungen:</strong><ul>' +
      warnungen.map(function (w) { return '<li>' + esc(w) + '</li>'; }).join('') + '</ul>';
  }

  function rendereFehler(fehler) {
    var host = $('vgFehler');
    if (!host) return;
    if (!fehler || fehler.length === 0) { host.hidden = true; host.innerHTML = ''; return; }
    host.hidden = false;
    host.innerHTML = '<strong>Eingaben prüfen:</strong><ul>' +
      fehler.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>';
  }

  function setText(id, t) { var el = $(id); if (el) el.textContent = t; }
  function formatProzent(anteil) {
    if (anteil == null) return '—';
    return GF.util.formatZahlDE(anteil * 100, 1) + ' %';
  }

  // --- Manuelle Korrektur der Flaeche >= 2,30 m ---
  // Inline in der Ergebnistabelle, analog zur Flaechenkorrektur beim Polygon
  // (app.js). Der Override liegt in manuellA230Override, zieht durch die
  // Live-Berechnung (berechneUndRendere) und wird bei jeder Geometrie-Aenderung
  // verworfen (triggerBerechnung). Der gemessene Wert bleibt in A_2_30_gemessen.

  // Blendet Edit-/Reset-Knopf passend zum Ergebnis ein und markiert den Wert.
  function rendereA230Steuerung(erg) {
    var wert = $('vgStatA230');
    var be = $('vgBtnA230Edit');
    var br = $('vgBtnA230Reset');
    var box = $('vgA230Edit');
    var manuell = !!(erg && erg.A_2_30_manuell);
    if (wert) { wert.hidden = false; wert.classList.toggle('korrigiert', manuell); }
    // Edit-Box nur sichtbar, solange aktiv editiert wird (durch oeffneA230Edit gesetzt).
    if (box && box.hidden === false) return;
    if (be) be.hidden = false;            // editierbar, sobald ein Ergebnis vorliegt
    if (br) br.hidden = !manuell;         // Reset nur bei aktiver Korrektur
  }

  function oeffneA230Edit() {
    if (!letztesErgebnis) return;
    var box = $('vgA230Edit');
    var inp = $('vgA230Input');
    if (!box || !inp) return;
    // Vorbelegung mit aktuellem Wert, 3 Stellen (voller Wert wie flaecheModal).
    inp.value = GF.util.formatZahlDE(letztesErgebnis.A_2_30, 3);
    var wert = $('vgStatA230'); if (wert) wert.hidden = true;
    var be = $('vgBtnA230Edit'); if (be) be.hidden = true;
    var br = $('vgBtnA230Reset'); if (br) br.hidden = true;
    box.hidden = false;
    setTimeout(function () { inp.focus(); inp.select(); }, 20);
  }

  function abbrecheA230Edit() {
    var box = $('vgA230Edit'); if (box) box.hidden = true;
    var wert = $('vgStatA230'); if (wert) wert.hidden = false;
    if (letztesErgebnis) rendereA230Steuerung(letztesErgebnis);
  }

  function bestaetigeA230() {
    var inp = $('vgA230Input');
    if (!inp) return;
    var v = GF.util.parseZahlDE(inp.value);
    if (!isFinite(v) || v <= 0) {
      showToast('Bitte gültige Fläche eingeben (> 0).', 'fehler');
      return;
    }
    manuellA230Override = Math.round(v * 1000) / 1000;
    var box = $('vgA230Edit'); if (box) box.hidden = true;
    var wert = $('vgStatA230'); if (wert) wert.hidden = false;
    if (GF.projekt && GF.projekt.historieEintrag && aktivesProjekt) {
      var g = findeGeschoss(aktivesProjekt, aktivesGeschossId);
      GF.projekt.historieEintrag(aktivesProjekt, 'Fläche ≥ 2,30 m manuell angesetzt',
        (g ? g.bezeichnung + ': ' : '') + GF.util.formatZahlDE(manuellA230Override, 2) + ' m²');
    }
    berechneUndRendere();
  }

  function setzeA230Zurueck() {
    if (manuellA230Override == null) { abbrecheA230Edit(); return; }
    manuellA230Override = null;
    if (GF.projekt && GF.projekt.historieEintrag && aktivesProjekt) {
      var g = findeGeschoss(aktivesProjekt, aktivesGeschossId);
      GF.projekt.historieEintrag(aktivesProjekt, 'Manuelle Korrektur ≥ 2,30 m zurückgesetzt',
        (g ? g.bezeichnung : ''));
    }
    var box = $('vgA230Edit'); if (box) box.hidden = true;
    var wert = $('vgStatA230'); if (wert) wert.hidden = false;
    berechneUndRendere();
  }

  // --- Speichern ---
  function speichere() {
    if (!aktivesGeschossId || !aktivesProjekt) return;
    // Letzte Berechnung durchziehen (kein Debounce-Lag)
    if (debounceHandle) { clearTimeout(debounceHandle); berechneUndRendere(); }

    // Wenn der User alle Eingabefelder geleert hat: das ist die intuitive
    // Geste fuer "VG-Berechnung entfernen". Bei bestehendem vollgeschoss-
    // Block an zuruecksetze() delegieren (mit dessen Bestaetigung-Dialog);
    // ohne bestehenden Block einfach Modal schliessen.
    if (alleEingabefelderLeer()) {
      var gLeer = findeGeschoss(aktivesProjekt, aktivesGeschossId);
      if (gLeer && gLeer.vollgeschoss) {
        zuruecksetze();
      } else {
        schliesse();
      }
      return;
    }

    if (letzteFehler && letzteFehler.length > 0) {
      // Modal-Fehler-Banner ist sichtbar; Speichern blockieren
      showToast('Bitte Eingaben prüfen (' + letzteFehler.length + ' Fehler).', 'fehler');
      return;
    }
    if (!letztesErgebnis || !letzteEingabe) {
      showToast('Pflichtfelder fehlen.', 'fehler');
      return;
    }

    var g = findeGeschoss(aktivesProjekt, aktivesGeschossId);
    if (!g) { schliesse(); return; }

    var jetzt = new Date().toISOString();
    var sb = GF.state.projekt && GF.state.projekt.metadata
      ? (GF.state.projekt.metadata.sachbearbeiter || '') : '';

    var plausi = null;
    var p = holeVergleichPolygon();
    if (p) {
      var fl = p.flaecheAngesetztQM || 0;
      // Abweichung: L_B * L_L (Rechteck-Modell) gegen Polygon. A_G == Polygon, daher
      // bringt der Vergleich A_G vs. Polygon nichts.
      var ageom = (letztesErgebnis.A_G_geometrie || 0);
      var abw = fl > 0 && ageom > 0 ? Math.abs(ageom - fl) / fl * 100 : 0;
      plausi = {
        polygonId: p.id,
        polygonFlaeche: fl,
        abweichungProzent: Math.round(abw * 1000) / 1000
      };
    }

    g.vollgeschoss = {
      durchgefuehrt: true,
      berechnetAm: jetzt,
      berechnetVon: sb,
      eingaben: {
        L_B: letzteEingabe.L_B,
        L_L: letzteEingabe.L_L,
        h_KL: letzteEingabe.h_KL,
        h_KR: letzteEingabe.h_KR,
        alpha_L: letzteEingabe.alpha_L,
        alpha_R: letzteEingabe.alpha_R,
        gauben_links: letzteEingabe.gauben_links.map(function (x) {
          var o = { b: x.b, a: x.a };
          if (isFinite(x.ortgang)) o.ortgang = x.ortgang;
          return o;
        }),
        gauben_rechts: letzteEingabe.gauben_rechts.map(function (x) {
          var o = { b: x.b, a: x.a };
          if (isFinite(x.ortgang)) o.ortgang = x.ortgang;
          return o;
        }),
        A_kleiner: letzteEingabe.A_kleiner || 0,
        A_groesser: letzteEingabe.A_groesser || 0,
        // Effektiv verwendete Grenzhoehe (aus berechne(), nie 0/leer)
        grenzhoehe: letztesErgebnis.grenzhoehe
      },
      ergebnis: {
        X1: letztesErgebnis.X1,
        X2: letztesErgebnis.X2,
        Bm: letztesErgebnis.Bm,
        A_G: letztesErgebnis.A_G,
        A_G_geometrie: letztesErgebnis.A_G_geometrie,
        A_G_quelle: letztesErgebnis.A_G_quelle,
        A_2_30: letztesErgebnis.A_2_30,
        A_2_30_gemessen: letztesErgebnis.A_2_30_gemessen,
        A_2_30_manuell: letztesErgebnis.A_2_30_manuell,
        zweidrittel_flaeche: letztesErgebnis.zweidrittel_flaeche,
        anteil_2_30: letztesErgebnis.anteil_2_30,
        vollgeschoss: letztesErgebnis.vollgeschoss,
        differenz: letztesErgebnis.differenz,
        grenzhoehe: letztesErgebnis.grenzhoehe,
        A_anrechenbar: letztesErgebnis.A_anrechenbar,
        X1_anr: letztesErgebnis.X1_anr,
        X2_anr: letztesErgebnis.X2_anr,
        Bm_anr: letztesErgebnis.Bm_anr,
        warnungen: (letztesErgebnis.warnungen || []).slice()
      },
      plausibilitaet: plausi,
      kommentar: ($('vgKommentar').value || '').trim()
    };

    // Manuelle Korrektur der Flaeche >= 2,30 m in die Eingaben uebernehmen, damit
    // sie beim Laden und beim Grenzhoehen-Nachzug erhalten bleibt (nur wenn der
    // Override tatsaechlich gegriffen hat, d.h. Abweichung > 0,005 m²).
    if (manuellA230Override != null && letztesErgebnis.A_2_30_manuell) {
      g.vollgeschoss.eingaben.A_2_30_override = manuellA230Override;
    }

    // Grenzhoehe gilt projektweit: Metadata aktualisieren und bei Aenderung
    // alle anderen gespeicherten VG-Blocks aus ihren Eingaben nachrechnen
    // (deterministisch — die Eingaben liegen im Block).
    var ghNeu = letztesErgebnis.grenzhoehe;
    var ghAlt = (aktivesProjekt.metadata && typeof aktivesProjekt.metadata.grenzhoeheAnrechnung === 'number'
                 && isFinite(aktivesProjekt.metadata.grenzhoeheAnrechnung))
      ? aktivesProjekt.metadata.grenzhoeheAnrechnung : 2.3;
    if (aktivesProjekt.metadata) aktivesProjekt.metadata.grenzhoeheAnrechnung = ghNeu;
    var nachgezogen = 0, nachzugFehler = 0;
    if (Math.abs(ghNeu - ghAlt) > 1e-9) {
      var nz = wendeGrenzhoeheAn(aktivesProjekt, ghNeu, aktivesGeschossId);
      nachgezogen = nz.nachgezogen;
      nachzugFehler = nz.fehlgeschlagen;
    }

    if (GF.projekt && GF.projekt.historieEintrag) {
      GF.projekt.historieEintrag(aktivesProjekt,
        letztesErgebnis.vollgeschoss ? 'Vollgeschoss: ja' : 'Vollgeschoss: nein',
        'Geschoss: ' + g.bezeichnung + ' · Anteil ' + formatProzent(letztesErgebnis.anteil_2_30));
    }

    GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
    schliesse();

    // Sidebar aktualisieren (wenn vom app.js exponiert)
    if (GF.app && GF.app.aktualisiereGeschossListe) GF.app.aktualisiereGeschossListe();
    if (GF.app && GF.app.aktualisiereToolbar) GF.app.aktualisiereToolbar();
    showToast('Vollgeschoss-Beurteilung gespeichert.'
      + (nachgezogen > 0
        ? ' Grenzhöhe ' + GF.util.formatZahlDE(ghNeu, 2) + ' m auf '
          + nachgezogen + ' weitere VG-Berechnung(en) angewendet.'
        : ''), 'success');
    if (nachzugFehler > 0) {
      showToast(nachzugFehler + ' weitere VG-Berechnung(en) konnten mit der neuen Grenzhöhe '
        + 'nicht nachgezogen werden — bitte diese Geschosse öffnen und erneut speichern.', 'warn');
    }
  }

  // Wendet die projektweite Anrechnungs-Grenzhoehe auf alle anderen
  // gespeicherten VG-Blocks an (Neuberechnung aus deren Eingaben).
  // Liefert die Anzahl der nachgezogenen Berechnungen.
  function wendeGrenzhoeheAn(projekt, gh, ausserGeschossId) {
    var n = 0, fehler = 0;
    (projekt.geschosse || []).forEach(function (g) {
      if (!g || g.id === ausserGeschossId) return;
      var vg = g.vollgeschoss;
      if (!vg || vg.durchgefuehrt !== true || !vg.eingaben || !vg.ergebnis) return;
      var e = Object.assign({}, vg.eingaben, { grenzhoehe: gh });
      // Polygon-A_G wie beim urspruenglichen Speichern rekonstruieren
      if (vg.plausibilitaet && vg.plausibilitaet.polygonId) {
        var fl = 0;
        for (var i = 0; i < (projekt.polygone || []).length; i++) {
          if (projekt.polygone[i].id === vg.plausibilitaet.polygonId) {
            fl = projekt.polygone[i].flaecheAngesetztQM || 0;
            break;
          }
        }
        if (!(fl > 0)) fl = vg.plausibilitaet.polygonFlaeche || 0;
        if (fl > 0) e.A_G_polygon = fl;
      }
      try {
        var erg = GF.Vollgeschoss.berechne(e);
        vg.eingaben.grenzhoehe = gh;
        vg.ergebnis = {
          X1: erg.X1,
          X2: erg.X2,
          Bm: erg.Bm,
          A_G: erg.A_G,
          A_G_geometrie: erg.A_G_geometrie,
          A_G_quelle: erg.A_G_quelle,
          A_2_30: erg.A_2_30,
          A_2_30_gemessen: erg.A_2_30_gemessen,
          A_2_30_manuell: erg.A_2_30_manuell,
          zweidrittel_flaeche: erg.zweidrittel_flaeche,
          anteil_2_30: erg.anteil_2_30,
          vollgeschoss: erg.vollgeschoss,
          differenz: erg.differenz,
          grenzhoehe: erg.grenzhoehe,
          A_anrechenbar: erg.A_anrechenbar,
          X1_anr: erg.X1_anr,
          X2_anr: erg.X2_anr,
          Bm_anr: erg.Bm_anr,
          warnungen: (erg.warnungen || []).slice()
        };
        n++;
      } catch (ex) {
        fehler++;
        console.warn('[vg-modal] Grenzhoehen-Nachzug fehlgeschlagen für "'
          + g.bezeichnung + '":', ex);
      }
    });
    return { nachgezogen: n, fehlgeschlagen: fehler };
  }

  function zuruecksetze() {
    if (!aktivesGeschossId || !aktivesProjekt) return;
    if (!global.confirm('VG-Beurteilung für dieses Geschoss löschen?')) return;
    var g = findeGeschoss(aktivesProjekt, aktivesGeschossId);
    if (!g) return;
    delete g.vollgeschoss;
    if (GF.projekt && GF.projekt.historieEintrag) {
      GF.projekt.historieEintrag(aktivesProjekt, 'Vollgeschoss-Beurteilung geloescht',
        'Geschoss: ' + g.bezeichnung);
    }
    GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
    schliesse();
    if (GF.app && GF.app.aktualisiereGeschossListe) GF.app.aktualisiereGeschossListe();
    showToast('VG-Beurteilung geloescht.', 'success');
  }

  function showToast(msg, kind) {
    if (GF.app && GF.app.showToast) { GF.app.showToast(msg, kind); return; }
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast aktiv' + (kind ? ' ' + kind : '');
    setTimeout(function () { t.className = 'toast'; }, 3000);
  }

  // --- Modal-Position + Drag + Minimieren ---
  var POS_KEY = 'gf.vgModal.position';
  var MIN_KEY = 'gf.vgModal.minimiert';

  function istMinimiert() {
    try { return localStorage.getItem(MIN_KEY) === '1'; } catch (e) { return false; }
  }
  function speichereMinimiert(min) {
    try { localStorage.setItem(MIN_KEY, min ? '1' : '0'); } catch (e) {}
  }
  function setzeMinimiertZustand(min) {
    var bd = $('vgBackdrop');
    if (!bd) return;
    var btn = $('vgBtnMinimieren');
    if (min) {
      bd.classList.add('vg-minimiert');
      if (btn) { btn.textContent = '▢'; btn.title = 'Maximieren'; }
    } else {
      bd.classList.remove('vg-minimiert');
      if (btn) { btn.textContent = '−'; btn.title = 'Minimieren — Plan unten sichtbar machen'; }
    }
    // Nach Zustandwechsel Position neu clampen (sonst kann minimiertes Modal ausserhalb landen)
    positioniereModal();
  }
  function toggleMinimieren() {
    var min = !($('vgBackdrop') && $('vgBackdrop').classList.contains('vg-minimiert'));
    speichereMinimiert(min);
    setzeMinimiertZustand(min);
  }

  function positioniereModal() {
    var modal = /** @type {HTMLElement | null} */ (document.querySelector('#vgBackdrop .modal-vg'));
    if (!modal) return;
    var w = modal.offsetWidth || 1100;
    var h = modal.offsetHeight || 700;
    var vw = window.innerWidth;
    var vh = window.innerHeight;

    var pos = null;
    try {
      var saved = localStorage.getItem(POS_KEY);
      if (saved) pos = JSON.parse(saved);
    } catch (e) { /* ignore */ }

    var x, y;
    if (pos && typeof pos.x === 'number' && typeof pos.y === 'number') {
      x = pos.x;
      y = pos.y;
    } else {
      x = Math.max(8, (vw - w) / 2);
      y = Math.max(8, (vh - h) / 2);
    }
    // Clamp ins sichtbare Viewport
    x = Math.max(8, Math.min(x, vw - Math.min(w, vw) - 8));
    y = Math.max(8, Math.min(y, vh - Math.min(h, vh) - 8));
    modal.style.left = x + 'px';
    modal.style.top  = y + 'px';
  }

  function speicherePosition(x, y) {
    try { localStorage.setItem(POS_KEY, JSON.stringify({ x: x, y: y })); } catch (e) {}
  }

  /** @type {{offsetX: number, offsetY: number, modal: HTMLElement} | null} */
  var dragState = null;
  /** @param {MouseEvent} e */
  function startDrag(e) {
    var modal = /** @type {HTMLElement | null} */ (document.querySelector('#vgBackdrop .modal-vg'));
    if (!modal) return;
    // Nicht auf interaktiven Elementen draggen (select, button, input, label)
    var t = /** @type {Element | null} */ (e.target);
    if (t && t.closest('select, button, input, textarea, label')) return;
    // Nur primaere Maustaste
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault();
    var rect = modal.getBoundingClientRect();
    dragState = {
      offsetX: e.clientX - rect.left,
      offsetY: e.clientY - rect.top,
      modal: modal
    };
    modal.style.transition = 'none';
  }
  function moveDrag(e) {
    if (!dragState) return;
    var modal = dragState.modal;
    var w = modal.offsetWidth;
    var h = modal.offsetHeight;
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var x = e.clientX - dragState.offsetX;
    var y = e.clientY - dragState.offsetY;
    // Clamp so dass mindestens ein Streifen sichtbar bleibt
    x = Math.max(40 - w, Math.min(x, vw - 40));
    y = Math.max(0, Math.min(y, vh - 40));
    modal.style.left = x + 'px';
    modal.style.top  = y + 'px';
  }
  function endDrag() {
    if (!dragState) return;
    var modal = dragState.modal;
    var x = parseFloat(modal.style.left) || 0;
    var y = parseFloat(modal.style.top)  || 0;
    speicherePosition(x, y);
    dragState = null;
  }

  // --- Wiring (einmal bei DOM-Ready) ---
  function wire() {
    var bd = $('vgBackdrop');
    if (!bd) return;

    // Eingabe-Felder -> Trigger Berechnung
    var felder = bd.querySelectorAll('input[data-vg-feld]');
    Array.prototype.forEach.call(felder, function (inp) {
      inp.addEventListener('input', triggerBerechnung);
      inp.addEventListener('change', triggerBerechnung);
    });

    // Kommentar: kein Trigger noetig
    var komm = $('vgKommentar');
    if (komm) komm.addEventListener('input', function () { /* nur lokal speichern beim Speichern */ });

    // Vergleichs-Polygon-Dropdown
    var sel = $('vgVergleichPolygon');
    if (sel) sel.addEventListener('change', function () {
      vergleichPolygonId = sel.value || null;
      // Polygonwechsel aendert A_G fuer die Berechnung -> neu rechnen.
      berechneUndRendere();
    });

    // Gauben-Listen (Event-Delegation pro Host)
    ['vgGaubenLinks', 'vgGaubenRechts'].forEach(function (hostId) {
      var host = $(hostId);
      if (!host) return;
      host.addEventListener('input', function (e) {
        var z = e.target.closest('.vg-gauben-zeile');
        if (!z) return;
        var seite = z.getAttribute('data-seite');
        var idx = parseInt(z.getAttribute('data-idx'), 10);
        var feld = e.target.getAttribute('data-feld');
        var liste = (seite === 'links') ? gaubenLinks : gaubenRechts;
        if (liste[idx] && feld) {
          liste[idx][feld] = e.target.value;
          triggerBerechnung();
        }
      });
      host.addEventListener('click', function (e) {
        if (e.target.getAttribute('data-aktion') === 'del') {
          var z = e.target.closest('.vg-gauben-zeile');
          if (!z) return;
          var seite = z.getAttribute('data-seite');
          var idx = parseInt(z.getAttribute('data-idx'), 10);
          gaubeWeg(seite, idx);
        }
      });
    });

    var btnGL = $('vgGaubeLinksPlus');
    if (btnGL) btnGL.addEventListener('click', function () { gaubeHinzu('links'); });
    var btnGR = $('vgGaubeRechtsPlus');
    if (btnGR) btnGR.addEventListener('click', function () { gaubeHinzu('rechts'); });

    // Footer-Buttons
    var btnOk = $('btnVgOk');
    if (btnOk) btnOk.addEventListener('click', speichere);
    var btnAbb = $('btnVgAbbrechen');
    if (btnAbb) btnAbb.addEventListener('click', schliesse);
    var btnReset = $('btnVgZuruecksetzen');
    if (btnReset) btnReset.addEventListener('click', zuruecksetze);

    // A>=2,30-Korrektur (inline in der Ergebnistabelle)
    var a230Edit = $('vgBtnA230Edit');
    if (a230Edit) a230Edit.addEventListener('click', oeffneA230Edit);
    var a230Ok = $('vgBtnA230Ok');
    if (a230Ok) a230Ok.addEventListener('click', bestaetigeA230);
    var a230Cancel = $('vgBtnA230Cancel');
    if (a230Cancel) a230Cancel.addEventListener('click', abbrecheA230Edit);
    var a230Reset = $('vgBtnA230Reset');
    if (a230Reset) a230Reset.addEventListener('click', setzeA230Zurueck);
    var a230Inp = $('vgA230Input');
    if (a230Inp) a230Inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); bestaetigeA230(); }
      else if (e.key === 'Escape') { e.preventDefault(); abbrecheA230Edit(); }
    });

    // Backdrop-Click schliesst nur wenn mousedown UND mouseup beide direkt
    // auf dem Backdrop landen. Verhindert versehentliches Schliessen, wenn
    // der User Text in einem Input markiert und beim Loslassen die Maus
    // ausserhalb des Modals landet — Browser feuert dann einen click mit
    // dem gemeinsamen Vorfahr (Backdrop) als Target.
    var bdMousedownAuf = null;
    bd.addEventListener('mousedown', function (e) { bdMousedownAuf = e.target; });
    bd.addEventListener('click', function (e) {
      if (e.target === bd && bdMousedownAuf === bd) schliesse();
      bdMousedownAuf = null;
    });

    // Minimieren / Schliessen-Buttons im Modal-Header
    var btnMin = $('vgBtnMinimieren');
    if (btnMin) btnMin.addEventListener('click', function (e) {
      e.stopPropagation();
      toggleMinimieren();
    });
    var btnX = $('vgBtnSchliessen');
    if (btnX) btnX.addEventListener('click', function (e) {
      e.stopPropagation();
      schliesse();
    });

    // Drag-Handle: Modal-Head
    var head = bd.querySelector('.modal-head');
    if (head) head.addEventListener('mousedown', startDrag);
    document.addEventListener('mousemove', moveDrag);
    document.addEventListener('mouseup', endDrag);
    window.addEventListener('blur', endDrag);
    window.addEventListener('resize', function () {
      // Nach Resize: clamp ggf. erneut
      if (bd.classList.contains('aktiv')) positioniereModal();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wire);
  } else {
    wire();
  }

})(typeof window !== 'undefined' ? window : globalThis);
