// @ts-check
// js/region.js — Plan-Regionen + Massstabskalibrierung.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.region = GF.region || /** @type {GfRegionModule} */ ({});

  // Norm-Massstaebe in pt/m (1 m bei Massstab 1:N entspricht 1000/N mm = 1000/N * 2.834645 pt)
  // pt/m = 72000 / (25.4 * N). v1.2: gaengige Zwischen-Maßstaebe (1:25/75/150/250)
  // ergaenzt, damit auch Detail-/Teilplaene Belege liefern. Bewusst keine
  // inflationaere Liste — sonst findet plausibilitaet() immer einen "naechsten"
  // Maßstab und die Falsch-Treffer-Quote steigt.
  GF.region.NORM_MASSSTAB = {
    '1:25':  113.386,
    '1:50':   56.692,
    '1:75':   37.795,
    '1:100':  28.346,
    '1:150':  18.898,
    '1:200':  14.173,
    '1:250':  11.339,
    '1:500':   5.669,
    '1:1000':  2.835
  };

  /**
   * @param {string} pdfId
   * @param {number} seite
   * @param {Ausschnitt} ausschnitt
   * @param {string} [bezeichnung]
   * @returns {Region}
   */
  GF.region.erzeuge = function (pdfId, seite, ausschnitt, bezeichnung) {
    return {
      id: GF.util.uuid(),
      pdfId: pdfId,
      seite: seite,
      bezeichnung: bezeichnung || '',
      geschossId: null,
      ausschnitt: ausschnitt,    // {x, y, breite, hoehe} in PDF-Koordinaten
      kalibrierung: null
    };
  };

  /**
   * ptProMeter aus zwei Punkten + Sollmass.
   * @param {Punkt} p1
   * @param {Punkt} p2
   * @param {number} sollMeter
   * @returns {number}
   */
  GF.region.berechneMassstab = function (p1, p2, sollMeter) {
    if (!isFinite(sollMeter) || sollMeter <= 0) throw new Error('Sollmass muss > 0 sein');
    var d = GF.util.abstand2D(p1, p2);
    if (d === 0) throw new Error('Punkte sind identisch (Distanz 0)');
    return d / sollMeter;
  };

  /**
   * ptProMeter aus direkt eingegebenem Massstab 1:N.
   * Gilt nur fuer masshaltige Vektor-PDFs: 1 m real = 1000/N mm auf
   * Papier, 1 mm = 72/25.4 pt (PDF-Punkt = 1/72 Zoll).
   * @param {number} n - Massstabszahl N aus "1:N", ganzzahlig >= 1
   * @returns {number}
   */
  GF.region.ptProMeterAusMassstab = function (n) {
    if (!isFinite(n) || n < 1) throw new Error('Massstab muss eine Zahl >= 1 sein');
    return 72000 / (25.4 * n);
  };

  /**
   * Prozentuale Abweichung vom naechsten Norm-Massstab.
   * @param {number} ptProMeter
   * @returns {RegionPlausibilitaet}
   */
  GF.region.plausibilitaet = function (ptProMeter) {
    var beste = null;
    var besteAbw = Infinity;
    var keys = Object.keys(GF.region.NORM_MASSSTAB);
    for (var i = 0; i < keys.length; i++) {
      var norm = GF.region.NORM_MASSSTAB[keys[i]];
      var abw = Math.abs(ptProMeter - norm) / norm * 100;
      if (abw < besteAbw) { besteAbw = abw; beste = keys[i]; }
    }
    /** @type {'plausibel' | 'hinweis' | 'warnung'} */
    var stufe;
    // v1.2: 'plausibel'-Tor von 0,5 % auf 1,0 % geweitet. CAD-Export-Rundung +
    // auf 2 Nachkommastellen gerundeter Maßtext sprengen 0,5 % (bei 1:100 = ±0,14
    // pt/m) zu leicht. ≥3-Belege-Schwelle + Median in massstabVorschlag/Belege
    // bleiben als Gegengewicht gegen Falsch-Treffer.
    if (besteAbw < 1.0)      stufe = 'plausibel';
    else if (besteAbw < 3.0) stufe = 'hinweis';
    else                     stufe = 'warnung';
    return { naechsterNormMassstab: beste, abweichungProzent: besteAbw, stufe: stufe };
  };

  // v1.3: Schwelle, ab der eine Direkteingabe als von der Planbemaßung abweichend
  // gilt (Prozent). 2 % Skala = ~4 % Flaeche — fuer die Beitragsgrundlage relevant.
  GF.region.SCHWELLE_DIREKT_BEMASSUNG_PROZENT = 2.0;

  /**
   * Effektive Maßstabszahl N aus pt/m (Umkehrung von ptProMeterAusMassstab).
   * @param {number} ptProMeter
   * @returns {number|null}
   */
  GF.region.massstabAusPtProMeter = function (ptProMeter) {
    if (!isFinite(ptProMeter) || ptProMeter <= 0) return null;
    return Math.round(72000 / (25.4 * ptProMeter));
  };

  /**
   * v1.3: Gleicht einen direkt eingegebenen Maßstab (pt/m) gegen die aus der
   * Planbemaßung gemessene Skala ab. Pure Funktion, DOM-frei. Urteilt nur bei
   * >=3 Belegen (sonst 'unbekannt'), damit der haeufige massstabsgetreue Normalfall
   * nie faelschlich gewarnt wird.
   * @param {number} ptProMeterDirekt
   * @param {{ptProMeter:number,anzahlBelege:number}|null|undefined} gemessen
   * @param {number} [schwelleProzent]
   * @returns {{status:('unbekannt'|'bestaetigt'|'abweichung'),abweichungProzent:number,gemessenPtProMeter:(number|null),gemessenNormMassstab:(string|null)}}
   */
  GF.region.direktBelegAbgleich = function (ptProMeterDirekt, gemessen, schwelleProzent) {
    var schwelle = (typeof schwelleProzent === 'number' && schwelleProzent >= 0)
      ? schwelleProzent : GF.region.SCHWELLE_DIREKT_BEMASSUNG_PROZENT;
    if (!gemessen || !(gemessen.ptProMeter > 0) || (gemessen.anzahlBelege || 0) < 3
        || !isFinite(ptProMeterDirekt) || ptProMeterDirekt <= 0) {
      return { status: 'unbekannt', abweichungProzent: 0, gemessenPtProMeter: null, gemessenNormMassstab: null };
    }
    var abw = Math.abs(ptProMeterDirekt - gemessen.ptProMeter) / gemessen.ptProMeter * 100;
    var norm = GF.region.plausibilitaet(gemessen.ptProMeter);
    return {
      status: abw >= schwelle ? 'abweichung' : 'bestaetigt',
      abweichungProzent: abw,
      gemessenPtProMeter: gemessen.ptProMeter,
      gemessenNormMassstab: norm ? norm.naechsterNormMassstab : null
    };
  };

})(typeof window !== 'undefined' ? window : globalThis);
