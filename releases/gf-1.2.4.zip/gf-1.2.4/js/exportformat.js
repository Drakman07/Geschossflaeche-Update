// js/exportformat.js — Format-Writer-Registry + CSV/JSON-Writer (v1.2).
// Writer kennen NUR das Export-Datenmodell (GF.exportdaten.baue), nie den
// State. Ein RIWA-Writer kann spaeter per GF.exportformat.registriere(...)
// ohne Umbau angedockt werden (js/exportformat-riwa.js, folgt mit Format-Spez).
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {any} */ (global.GF = global.GF || {});
  GF.exportformat = GF.exportformat || {};

  /** @type {Array<{id:string,label:string,extension:string,mime:string,schreibe:Function}>} */
  var writers = [];

  // Registriert (oder ersetzt bei gleicher id) einen Writer.
  GF.exportformat.registriere = function (w) {
    for (var i = 0; i < writers.length; i++) {
      if (writers[i].id === w.id) { writers[i] = w; return; }
    }
    writers.push(w);
  };
  // Liste fuer die UI-Auswahl.
  GF.exportformat.liste = function () {
    return writers.map(function (w) {
      return { id: w.id, label: w.label, extension: w.extension };
    });
  };
  GF.exportformat.get = function (id) {
    for (var i = 0; i < writers.length; i++) if (writers[i].id === id) return writers[i];
    return null;
  };

  // ---- Helfer ----

  function num(n, stellen) {
    return GF.util.formatZahlDE(n, (stellen == null) ? 2 : stellen);
  }

  // Eine CSV-Textzelle Excel-DE-sicher quoten + gegen Formel-Injection schuetzen.
  function csvText(v) {
    var t = (v == null) ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(t)) t = "'" + t;                 // Formel-Injection neutralisieren
    if (/[;"\n\r]/.test(t) || /^\s|\s$/.test(t)) {            // quoten wenn noetig
      t = '"' + t.replace(/"/g, '""') + '"';
    }
    return t;
  }

  function dateiname(modell, ext) {
    var basis = (modell.projekt.projekt_name || 'Aufmass').replace(/[\\/:*?"<>|]/g, '_').trim();
    if (!basis) basis = 'Aufmass';
    var datum = (modell.erzeugt.am_iso || '').slice(0, 10) || '0000-00-00';
    return basis + '_Fachdaten_' + datum + '.' + ext;
  }

  function machBlob(text, mime) {
    return (typeof Blob !== 'undefined') ? new Blob([text], { type: mime }) : null;
  }

  // ---- CSV-Writer (Excel-DE: BOM, Semikolon-Trenner, Komma-Dezimal, CRLF) ----

  function baueCsvText(modell) {
    var EOL = '\r\n';
    var rows = [];
    function row(cells) { rows.push(cells.join(';')); }
    var p = modell.projekt, e = modell.erzeugt;

    // Meta-Block (2-spaltig), durch Leerzeile von der Tabelle getrennt.
    row([csvText('Feld'), csvText('Wert')]);
    row([csvText('Aktenzeichen'), csvText(p.aktenzeichen)]);
    row([csvText('Bauvorhaben'), csvText(p.bauvorhaben)]);
    row([csvText('Kommune'), csvText(p.kommune)]);
    row([csvText('Sachbearbeiter'), csvText(p.sachbearbeiter)]);
    row([csvText('Bauherr'), csvText(p.bauherr.name)]);
    row([csvText('Anrechnungsmodus'), csvText(p.vg_anrechnung_modus)]);
    row([csvText('Grenzhöhe Anrechnung [m]'), num(p.grenzhoehe_anrechnung_m, 2)]);
    row([csvText('Erstellt am'), csvText(e.am_iso)]);
    row([csvText('Tool'), csvText(e.tool + ' ' + e.tool_version + (e.demo ? ' (Demo)' : ''))]);
    row([]);

    // Geschoss-Tabelle (eine Zeile je Geschoss + Summenzeile).
    row([csvText('Nr'), csvText('Geschoss'), csvText('Quelle-PDF'),
         csvText('Grundfläche [m²]'), csvText('Anrechenbar [m²]'),
         csvText('Anrechnung'), csvText('Grenzhöhe [m]'), csvText('Manuell')]);
    (modell.geschosse || []).forEach(function (g) {
      row([
        String(g.nr),
        csvText(g.bezeichnung),
        csvText(g.quelle_pdf),
        num(g.polygon_flaeche_qm, 2),
        num(g.anrechenbare_flaeche_qm, 2),
        csvText(g.anrechnung),
        num(g.grenzhoehe_m, 2),
        csvText(g.manuell_korrigiert ? 'ja' : 'nein')
      ]);
    });
    row([csvText('Summe'), '', '',
         num(modell.summe.gesamt_polygon_qm, 2),
         num(modell.summe.gesamt_anrechenbar_qm, 2), '', '', '']);

    return '﻿' + rows.join(EOL) + EOL;
  }

  GF.exportformat.registriere({
    id: 'csv',
    label: 'CSV (Excel)',
    extension: 'csv',
    mime: 'text/csv;charset=utf-8',
    schreibe: function (modell) {
      var text = baueCsvText(modell);
      return {
        dateiname: dateiname(modell, 'csv'),
        mime: 'text/csv;charset=utf-8',
        text: text,
        blob: machBlob(text, 'text/csv;charset=utf-8')
      };
    }
  });

  // ---- JSON-Writer (verlustfrei, native Zahlen mit Punkt-Dezimal) ----

  GF.exportformat.registriere({
    id: 'json',
    label: 'JSON',
    extension: 'json',
    mime: 'application/json',
    schreibe: function (modell) {
      var text = JSON.stringify(modell, null, 2);
      return {
        dateiname: dateiname(modell, 'json'),
        mime: 'application/json',
        text: text,
        blob: machBlob(text, 'application/json')
      };
    }
  });

})(typeof window !== 'undefined' ? window : globalThis);
