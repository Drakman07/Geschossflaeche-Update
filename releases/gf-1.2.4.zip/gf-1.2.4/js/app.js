// @ts-check
// js/app.js — Bootstrap, UI-Wiring, Event-Handler.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});

  /**
   * Element-Helper. Liefert `any`, damit Aufrufer direkt `.value`/`.disabled`/
   * `.style`/etc. ohne Cast nutzen kann (UI-Wiring-Code).
   * @param {string} id
   * @returns {any}
   */
  function $(id) { return document.getElementById(id); }

  // ---- Toast-Hilfe ----
  /**
   * @param {string} msg
   * @param {string} [kind]
   * @param {number} [dauerMs]
   */
  function showToast(msg, kind, dauerMs) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast aktiv' + (kind ? ' ' + kind : '');
    clearTimeout(/** @type {any} */ (showToast)._t);
    /** @type {any} */ (showToast)._t = setTimeout(function () { t.classList.remove('aktiv'); }, dauerMs || 4500);
  }

  // ---- Header / Footer ----
  function setzeVersion() {
    var el = $('versionInfo');
    if (el && GF.VERSION) {
      el.textContent = 'Version ' + GF.VERSION + ' · ' + (GF.BUILD_DATUM || '');
    }
  }

  function setzeKommune() {
    if (!global.GF_KOMMUNE) return;
    var k = global.GF_KOMMUNE;
    var name = $('kommunenName');
    if (name) name.textContent = k.name || '';
    var wappen = $('wappenLogo');
    if (wappen && k.wappenPfad) {
      wappen.src = k.wappenPfad;
      wappen.style.display = '';
    }
  }

  function setzeLibStatus() {
    var el = $('libStatusKurz');
    if (!el) return;
    var s = [
      'pdf.js:'   + (global.pdfjsLib ? '✓' : '✗'),
      'jsPDF:'    + (global.jspdf && global.jspdf.jsPDF ? '✓' : '✗'),
      'fflate:'   + (global.fflate ? '✓' : '✗')
    ];
    el.textContent = 'Libs: ' + s.join(' · ');
  }

  // ---- Recovery beim Start ----
  function pruefeRecovery() {
    if (!GF.recovery || !GF.recovery.pruefeBeimStart) return;
    GF.recovery.pruefeBeimStart().then(function (snap) {
      if (!snap) return;
      var datumLes = new Date(snap.datum).toLocaleString('de-DE');
      var ok = global.confirm(
        'Beim letzten Mal wurde ein Projekt nicht gespeichert.\n' +
        'Soll der Stand von ' + datumLes + ' wiederhergestellt werden?'
      );
      if (!ok) {
        GF.recovery.loesche();
        return;
      }
      stellSnapshotWiederHer(snap).then(function () {
        showToast('Stand vom ' + datumLes + ' wiederhergestellt.', 'success');
      }).catch(function (e) {
        console.error('[gf-app] Restore-Fehler:', e);
        showToast('Wiederherstellung fehlgeschlagen: ' + (e.message || e), 'danger');
      });
    });
  }

  function stellSnapshotWiederHer(snap) {
    if (!global.pdfjsLib) {
      return Promise.reject(new Error('pdf.js nicht geladen'));
    }
    GF.pdf.konfigurierePdfJs();

    var pdfsRestored = [];
    var kette = Promise.resolve();
    var serPdfs = snap.pdfs || [];

    serPdfs.forEach(function (serPdf) {
      kette = kette.then(function () {
        if (!serPdf.binary) return;
        // Wichtig: Kopie der Bytes, weil getDocument den TypedArray konsumieren kann
        var bytes = new Uint8Array(serPdf.binary);
        return global.pdfjsLib.getDocument({ data: bytes }).promise.then(function (doc) {
          pdfsRestored.push({
            id: serPdf.id,
            dateiName: serPdf.dateiName,
            containerPfad: serPdf.containerPfad || serPdf.dateiName,
            originalDateiName: serPdf.originalDateiName,
            pdfDoc: doc,
            anzahlSeiten: serPdf.anzahlSeiten || doc.numPages
          });
        });
      });
    });

    return kette.then(function () {
      GF.state.update(function (s) {
        s.projekt = snap.projekt || null;
        s.pdfs = pdfsRestored;
        s.aktivePdfId = snap.aktivePdfId || (pdfsRestored[0] ? pdfsRestored[0].id : null);
        s.aktuelleSeite = snap.aktuelleSeite || 1;
        s.aktivesGeschossId = snap.aktivesGeschossId || null;
        s.aktiveRegionId = snap.aktiveRegionId || null;
        s.pdfCache = null;
        s.vektorAnteil = null;
        // Stand kommt aus dem Snapshot -> als "noch nicht gespeichert" markieren,
        // damit der Save-Reminder weiterhin wirkt.
        s.ungespeicherteAenderungen = true;
      });
      aktualisiereGeschossListe();

      // Wenn eine aktive Seite im Snapshot war: rendern + dann Viewport explizit setzen
      if (GF.state.aktivePdfId && pdfsRestored.length > 0) {
        return zeigeSeite(GF.state.aktuelleSeite || 1).then(function () {
          if (snap.viewport) {
            GF.state.update(function (s) { s.viewport = snap.viewport; });
            redraw();
          }
        });
      }
      return Promise.resolve();
    });
  }

  // ============================================================
  // PDF laden + anzeigen
  // ============================================================

  function frageAnzeigeName(originalName, alterName, kontext) {
    var vorschlag = (alterName || originalName).replace(/\.pdf$/i, '');
    var prefix = kontext ? '[' + kontext + '] ' : '';
    var eingabe = global.prompt(
      prefix + 'Wie soll diese PDF im Tool angezeigt werden?\n' +
      '(z. B. "Laerchenstr. 18 EG" — kürzer als Dateinamen)\n\n' +
      'Original: ' + originalName,
      vorschlag
    );
    if (eingabe === null) return null;     // Abbrechen
    var t = eingabe.trim();
    return t || vorschlag;
  }

  /** Laedt mehrere PDFs nacheinander (eine Promise-Kette). */
  function ladePdfDateien(dateien) {
    var arr = Array.prototype.slice.call(dateien || []);
    if (arr.length === 0) return Promise.resolve();
    if (!global.pdfjsLib) {
      showToast('pdf.js-Library fehlt — siehe lib/README.md.', 'danger');
      return Promise.resolve();
    }
    var kette = Promise.resolve();
    arr.forEach(function (file, idx) {
      kette = kette.then(function () {
        return ladePdfEinzeln(file, idx + 1, arr.length);
      });
    });
    return kette;
  }

  function ladePdfEinzeln(file, idx, gesamt) {
    var batchInfo = gesamt > 1 ? (idx + ' von ' + gesamt) : null;
    showToast('Lade ' + file.name + (batchInfo ? ' (' + batchInfo + ')' : '') + ' …');
    return GF.pdf.lade(file).then(function (pdfDoc) {
      var anzeige = frageAnzeigeName(file.name, null, batchInfo);
      if (anzeige === null) {
        // Bei Batch: nur diese PDF abbrechen, naechste laeuft weiter.
        showToast('Übersprungen: ' + file.name, 'warn');
        return null;
      }
      // Sicherstellen, dass ein Projekt existiert, BEVOR die PDF in den State
      // wandert. Sonst leben PDFs im State, waehrend state.projekt null bleibt,
      // und alle nachfolgenden Operationen (Loeschen, Speichern, Polygon-
      // Zeichnen, VG-Beurteilung) fallen still durch ihre projekt-Guards.
      GF.projekt.sorgeFuerProjekt();
      var neueId = GF.util.uuid();
      GF.state.update(function (s) {
        s.pdfs.push({
          id: neueId,
          dateiName: anzeige,
          originalDateiName: file.name,
          pdfDoc: pdfDoc,
          anzahlSeiten: pdfDoc.numPages
        });
        s.aktivePdfId = neueId;
        s.aktuelleSeite = 1;
        s.pdfCache = null;
        s.vektorAnteil = null;
        // Geladene PDF ist eine echte Aenderung am Projekt -> Save-Reminder
        // und Sicherheitsabfrage bei "Neu"/"Oeffnen" greifen jetzt korrekt.
        s.ungespeicherteAenderungen = true;
      });
      return zeigeSeite(1).then(function () {
        showToast('PDF geladen: ' + anzeige, 'success');
      });
    }).catch(function (e) {
      console.error('[gf-app] PDF-Lade-Fehler:', e);
      showToast('Konnte ' + file.name + ' nicht laden: ' + (e.message || e), 'danger');
    });
  }

  function benennePdfUm(pdfId) {
    var pdf = GF.state.findPdf(pdfId);
    if (!pdf) return;
    var neu = frageAnzeigeName(pdf.originalDateiName || pdf.dateiName, pdf.dateiName);
    if (neu === null) return;
    GF.state.update(function () { pdf.dateiName = neu; });
    aktualisiereToolbar();
    showToast('Umbenannt: ' + neu);
  }

  function loeschePdf(pdfId) {
    var s = GF.state;
    var pdf = s.findPdf(pdfId);
    // Defensiv: falls eine PDF im State liegt aber noch kein Projekt-Objekt
    // existiert (z. B. nach altem Bug-Stand vor v1.0.1), legen wir hier eines an.
    if (pdf && !s.projekt) GF.projekt.sorgeFuerProjekt();
    if (!pdf || !s.projekt) {
      console.warn('[gf-app] loeschePdf abgebrochen: pdf=' + !!pdf + ', projekt=' + !!s.projekt);
      return;
    }

    // Was geht mit verloren?
    var regionen = s.projekt.planRegionen.filter(function (r) { return r.pdfId === pdfId; });
    var regionIds = regionen.map(function (r) { return r.id; });
    var polygone = s.projekt.polygone.filter(function (p) { return regionIds.indexOf(p.regionId) >= 0; });

    var msg = 'PDF "' + (pdf.dateiName || pdf.originalDateiName) + '" aus dem Projekt entfernen?';
    if (regionen.length || polygone.length) {
      msg += '\n\nDamit gehen auch verloren:';
      if (regionen.length) msg += '\n  · ' + regionen.length + ' Region(en)';
      if (polygone.length) msg += '\n  · ' + polygone.length + ' Polygon(e)';
    }
    if (!global.confirm(msg)) return;

    // Aus state und projekt entfernen
    s.pdfs = s.pdfs.filter(function (p) { return p.id !== pdfId; });
    s.projekt.planRegionen = s.projekt.planRegionen.filter(function (r) { return r.pdfId !== pdfId; });
    s.projekt.polygone     = s.projekt.polygone.filter(function (p) { return regionIds.indexOf(p.regionId) < 0; });
    if (Array.isArray(s.projekt.pdfs)) {
      s.projekt.pdfs = s.projekt.pdfs.filter(function (p) { return p.id !== pdfId; });
    }

    GF.projekt.historieEintrag(s.projekt, 'PDF entfernt',
      (pdf.dateiName || pdf.originalDateiName) +
      (regionen.length ? ' · ' + regionen.length + ' Region(en)' : '') +
      (polygone.length ? ' · ' + polygone.length + ' Polygon(e)' : ''));

    var aktivWegGefallen = (s.aktivePdfId === pdfId);
    var naechste = s.pdfs[0] ? s.pdfs[0].id : null;

    GF.state.update(function (st) {
      if (aktivWegGefallen) {
        st.aktivePdfId = naechste;
        st.aktuelleSeite = 1;
        st.pdfCache = null;
        st.vektorAnteil = null;
      }
      if (regionIds.indexOf(st.aktiveRegionId) >= 0) st.aktiveRegionId = null;
      // aktivesPolygonId pruefen — Polygon evtl. mitgeloescht
      if (st.aktivesPolygonId &&
          !st.projekt.polygone.some(function (p) { return p.id === st.aktivesPolygonId; })) {
        st.aktivesPolygonId = null;
      }
      st.ungespeicherteAenderungen = true;
    });

    aktualisiereToolbar();
    aktualisiereGeschossListe();

    if (aktivWegGefallen && naechste) {
      zeigeSeite(1);
    } else if (!naechste) {
      // Keine PDFs mehr — Canvas leeren
      var c = $('planCanvas');
      if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height);
      redraw();
    } else {
      redraw();
    }

    showToast('PDF entfernt: ' + (pdf.dateiName || pdf.originalDateiName), 'success');
  }

  function wechsleZuPdf(pdfId) {
    if (!pdfId || pdfId === GF.state.aktivePdfId) return Promise.resolve();
    var pdf = GF.state.findPdf(pdfId);
    if (!pdf) return Promise.resolve();
    GF.state.update(function (s) {
      s.aktivePdfId = pdfId;
      s.aktuelleSeite = 1;
      s.pdfCache = null;
      s.vektorAnteil = null;
    });
    return zeigeSeite(1).then(function () {
      showToast('Aktive PDF: ' + pdf.dateiName);
    });
  }

  // true, wenn die Vektor-Analyse der aktuellen Seite fehlschlug -> Maßstab-
  // Direkteingabe nicht verfuegbar (Referenzstrecke noetig). Pro Seite zurueckgesetzt.
  var vektorAnalyseFehler = false;

  function zeigeSeite(seite) {
    var pdf = GF.state.aktivesPdf();
    if (!pdf) return Promise.resolve();
    var doc = pdf.pdfDoc;
    if (seite < 1) seite = 1;
    if (seite > doc.numPages) seite = doc.numPages;

    // Vektor-Anteil der vorigen Seite verwerfen, bis die neue Seite analysiert
    // ist (sonst greift die Scan-Sperre auf einen stale Wert). null = "laeuft".
    GF.state.update(function (s) { s.vektorAnteil = null; s.snapIndex = null; s.massketten = null; s.massBelege = null; s.gemesseneSkala = null; });
    vektorAnalyseFehler = false;

    // Auffaellige Ladeanzeige fuer die (blockierende) Render-Phase + Badge auf "wird geprueft".
    zeigeLaden('Plan wird vorbereitet …');
    zeigeVektorBadge(null, null);

    return GF.pdf.preRender(doc, seite, GF.pdf.DEFAULT_RENDER_SCALE).then(function (cache) {
      // Fit-Viewport berechnen anhand aktueller Canvas-Groesse
      passeCanvasGroesseAn();
      var canvas = $('planCanvas');
      var fit = GF.pdf.fitViewport(cache, canvas);

      GF.state.update(function (s) {
        s.pdfCache = cache;
        s.aktuelleSeite = seite;
        s.viewport = fit;
      });
      redraw();
      // Plan ist sichtbar — Overlay weg. Vektor-Pruefung laeuft im Hintergrund weiter
      // (Badge zeigt solange "wird geprueft"), blockiert die Ansicht nicht mehr.
      versteckeLaden();

      // Vektor-Anteil asynchron, blockiert nicht
      GF.pdf.vektorAnteil(doc, seite).then(function (a) {
        GF.state.update(function (s) { s.vektorAnteil = a; });
        // War die Methodenwahl waehrend der Analyse offen, Sperre jetzt aktualisieren.
        if (massMethodeOffen) zeigeMassstabMethode();
        if (a < 0.3) {
          zeigeVektorBadge(a);   // Scan: keine Phase 2 -> Badge sofort fertig
          showToast(
            'Hinweis: PDF besteht überwiegend aus Rasterbildern (gescannt). ' +
            'Vermessung mit Toleranz ±1-2%.',
            'warn'
          );
        } else {
          // v1.2: Vektor-PDF -> Phase 2b (Magnet + Maßketten) laeuft im Hintergrund.
          // Badge zeigt solange "· wird vorbereitet …" (Parallel-Arbeiten-Politur).
          zeigeVektorBadge(a, 'vorbereiten');
          baueSnapFuerSeite(doc, seite);
        }
      }).catch(function (e) {
        // Analyse warf (z. B. defekte Seite): vektorAnteil bleibt null, die
        // Direkteingabe bleibt fail-closed gesperrt. Merker setzen, damit der
        // Methoden-Hinweis den Fehler statt "wird analysiert" zeigt, und Nutzer
        // informieren — sonst haengt das Panel still in "wird analysiert".
        console.warn('[gf-app] Vektor-Analyse fehlgeschlagen:', e);
        vektorAnalyseFehler = true;
        if (massMethodeOffen) zeigeMassstabMethode();
        showToast('PDF-Analyse fehlgeschlagen — Maßstab-Direkteingabe nicht verfügbar. Bitte Strecke messen.', 'warn');
      });

    }).catch(function (e) { versteckeLaden(); throw e; });
  }

  // anteil: null = Analyse laeuft, sonst [0..1]. status (nur Vektor/gemischt):
  // 'vorbereiten' (Phase 2b laeuft) | 'magnet-aus' (Detailgrad-Cap) | 'fertig'/null.
  function zeigeVektorBadge(anteil, status) {
    var b = $('vektorBadge');
    var grp = $('vektorGruppe');
    if (!b || !grp) return;
    grp.hidden = false;
    var t = GF.massstabUi.badgeText(anteil, status);
    b.textContent = t.text;
    b.className = t.klasse;
    b.title = t.title;
  }

  // Lade-Overlay (PDF-Aufbereitung). Deckt die blockierende preRender-Phase ab,
  // damit der Nutzer bei grossen Plaenen sieht, dass das Tool arbeitet.
  function zeigeLaden(text) {
    var ov = $('ladeOverlay'); if (!ov) return;
    var t = $('ladeText'); if (t && text) t.textContent = text;
    ov.classList.add('aktiv');
  }
  function versteckeLaden() {
    var ov = $('ladeOverlay'); if (ov) ov.classList.remove('aktiv');
  }

  // v1.2: Snap-Index (Vektor-Ecken) + Maßketten fuer die Seite aufbauen und in den
  // State legen. Nur fuer die noch aktuelle Seite uebernehmen (Race-Schutz beim
  // schnellen Blaettern). Fehler werden geschluckt — der Magnet ist optional.
  var magnetCapGemeldet = Object.create(null);   // Cap-Hinweis pro Seite nur einmal
  function baueSnapFuerSeite(doc, seite) {
    if (!GF.snap || !GF.snap.baue) return;
    GF.snap.baue(doc, seite).then(function (idx) {
      if (GF.state.aktuelleSeite !== seite) return;
      GF.state.update(function (s) { s.snapIndex = idx; });
      // v1.2: Badge-Phase-2-Status aktualisieren (Magnet fertig bzw. per Cap aus).
      zeigeVektorBadge(GF.state.vektorAnteil, (idx && idx.uebersprungen) ? 'magnet-aus' : 'fertig');
      // Detailgrad-Cap gegriffen -> Magnet aus, einmal kurz informieren.
      // Maßketten/Maßstab laufen unten trotzdem weiter (eigene Logik).
      if (idx && idx.uebersprungen && !magnetCapGemeldet[seite]) {
        magnetCapGemeldet[seite] = true;
        showToast('Magnet deaktiviert: Plan sehr detailreich ('
          + GF.util.formatZahlDE(idx.vertexAnzahl, 0) + ' Vektorpunkte). '
          + 'Zeichnen und Maßstab bleiben möglich.', 'warn');
      }
      if (!GF.pdf || !GF.pdf.findeMassketten) return;
      // Maßketten im selben Lauf — Belege cachen (s.massBelege), damit der Vorschlag
      // auch den parallel arbeitenden Sachbearbeiter spaeter noch trifft.
      return GF.pdf.findeMassketten(doc, seite).then(function (mk) {
        if (GF.state.aktuelleSeite !== seite) return;
        var kanten = (idx && idx.kanten) || [];
        var belege = GF.pdf.massstabBelege ? GF.pdf.massstabBelege(mk, kanten) : null;
        var gemessen = GF.pdf.gemesseneSkala ? GF.pdf.gemesseneSkala(mk, kanten) : null;
        GF.state.update(function (s) { s.massketten = mk; s.massBelege = belege; s.gemesseneSkala = gemessen; });
        vielleichtMassstabVorschlag();
      });
    }).catch(function (e) { console.warn('[gf-snap/massketten] fehlgeschlagen:', e); });
  }

  // v1.2: Liefert die Planbemaßung einen plausiblen Maßstab UND ist die aktive
  // Region noch unkalibriert, einen Beleg-Dialog anbieten. Nie automatisch setzen
  // (Mensch entscheidet) — der Dialog zeigt die Belege, uebernimmt erst per Klick.
  var massVorschlagGezeigt = Object.create(null);   // pro Region-Id einmal pro Sitzung
  var aktuellerMassVorschlag = null;                // { region, vorschlag }

  // v1.2 Politur: liest die in baueSnapFuerSeite gecachten Belege (GF.state.massBelege),
  // damit der Vorschlag auch nachtraeglich greift (Region erst nach der Analyse aktiviert).
  function vielleichtMassstabVorschlag() {
    var r = findeAktiveRegion();
    if (!r) return;
    if (r.kalibrierung && r.kalibrierung.ptProMeter) return;   // schon kalibriert
    if (massVorschlagGezeigt[r.id]) return;
    var v = GF.state.massBelege;
    if (!v) {
      // Belege noch nicht da -> Phase 2 laeuft evtl. noch -> still warten.
      // Phase 2 fertig (massketten !== null) aber 0 Belege bei Vektor-PDF (Bemaßung
      // evtl. als Grafik/Outline statt Text) -> einmal pro Region Hinweis auf manuelle
      // Kalibrierung. Bei Scan (vektorAnteil < 0,3) still: dort greift die Scan-Sperre.
      if (GF.state.massketten !== null) {
        var anteil = GF.state.vektorAnteil;
        if (typeof anteil === 'number' && anteil >= 0.3) {
          massVorschlagGezeigt[r.id] = true;
          showToast('Maßstab nicht automatisch erkennbar (Bemaßung evtl. als Grafik). '
            + 'Bitte über „Maßstab kalibrieren" manuell setzen.', 'warn');
        }
      }
      return;
    }
    massVorschlagGezeigt[r.id] = true;
    zeigeMassBanner(r, v);
  }

  // v1.2 Politur: nicht-blockierendes Banner oben im canvasHost (deckt den Plan
  // nicht ab) statt eines Modals — der Sachbearbeiter arbeitet parallel weiter.
  function zeigeMassBanner(region, v) {
    var banner = $('massBanner');
    if (!banner) return;
    aktuellerMassVorschlag = { region: region, vorschlag: v };
    var t = GF.massstabUi.bannerText(v, region);
    var txt = $('massBannerText');
    if (txt) txt.textContent = t.text;
    banner.classList.toggle('mass-banner-unsicher', t.unsicher);
    banner.hidden = false;
  }

  function uebernehmeMassVorschlag() {
    if (!aktuellerMassVorschlag || !aktuellerMassVorschlag.region) { schliesseMassVorschlag(); return; }
    var region = aktuellerMassVorschlag.region;
    var v = aktuellerMassVorschlag.vorschlag;
    var avgAbw = 0;
    for (var i = 0; i < v.belege.length; i++) avgAbw += v.belege[i].abweichungProzent;
    avgAbw = v.belege.length ? (avgAbw / v.belege.length) : 0;
    region.kalibrierung = {
      punkt1: null, punkt2: null, abstandMeter: null,
      ptProMeter: v.ptProMeter,
      quelle: 'massketten',
      abweichungVonNormProzent: avgAbw,
      normMassstab: v.normMassstab
    };
    GF.projekt.historieEintrag(GF.state.projekt, 'Maßstab aus Planbemaßung übernommen',
      ((GF.state.findGeschoss(region.geschossId) || {}).bezeichnung || region.bezeichnung || 'Region')
      + ' / ' + v.normMassstab + ' (' + v.anzahlBelege + ' Belege)');
    GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
    showToast('Maßstab ' + v.normMassstab + ' übernommen (' + GF.util.formatZahlDE(v.ptProMeter, 2)
      + ' pt/m, ' + v.anzahlBelege + ' Belege). Tipp: ein Maß zur Kontrolle nachmessen.', 'success', 7000);
    if (typeof vielleichtUebernehmen === 'function') vielleichtUebernehmen(region, v.ptProMeter);
    schliesseMassVorschlag();
    aktualisiereGeschossListe();
    redraw();
  }

  function schliesseMassVorschlag() {
    var banner = $('massBanner');
    if (banner) banner.hidden = true;
    aktuellerMassVorschlag = null;
  }

  function wireMassVorschlag() {
    var ok = $('btnMassBannerOk');
    var ab = $('btnMassBannerVerwerfen');
    if (ok) ok.addEventListener('click', uebernehmeMassVorschlag);
    if (ab) ab.addEventListener('click', schliesseMassVorschlag);
  }

  // ============================================================
  // Canvas-Groesse + Redraw
  // ============================================================

  function passeCanvasGroesseAn() {
    var host = $('canvasHost');
    var canvas = $('planCanvas');
    if (!host || !canvas) return false;
    var r = host.getBoundingClientRect();
    var w = Math.max(100, Math.floor(r.width));
    var h = Math.max(100, Math.floor(r.height));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
      return true;
    }
    return false;
  }

  function redraw() {
    var canvas = $('planCanvas');
    if (!canvas || !GF.state.pdfCache) return;
    GF.pdf.zeichne(GF.state.pdfCache, canvas, GF.state.viewport);
    zeichneOverlay(canvas);
    aktualisiereToolbar();
    aktualisiereStatusleiste();
  }

  // ---- Overlay: Plan-Regionen + Temp-Rechteck waehrend Region-Drag ----

  function pdfZuCanvas(pdfX, pdfY) {
    var vp = GF.state.viewport;
    return { x: (pdfX - vp.panX) * vp.zoom, y: (pdfY - vp.panY) * vp.zoom };
  }
  function canvasZuPdf(canvasX, canvasY) {
    var vp = GF.state.viewport;
    return { x: vp.panX + canvasX / vp.zoom, y: vp.panY + canvasY / vp.zoom };
  }

  function normalisiereRechteck(p1, p2) {
    return {
      x: Math.min(p1.x, p2.x),
      y: Math.min(p1.y, p2.y),
      breite: Math.abs(p2.x - p1.x),
      hoehe:  Math.abs(p2.y - p1.y)
    };
  }

  // Hitboxen — werden in jedem zeichneOverlay-Aufruf neu befuellt.
  var kantenLabelHitboxen = [];
  var eckpunktHitboxen = [];

  function zeichneOverlay(canvas) {
    var s = GF.state;
    var ctx = canvas.getContext('2d');
    kantenLabelHitboxen = [];
    eckpunktHitboxen = [];

    if (s.projekt && s.aktivePdfId) {
      var regionen = s.projekt.planRegionen.filter(function (r) {
        return r.pdfId === s.aktivePdfId && r.seite === s.aktuelleSeite;
      });
      regionen.forEach(function (r) { zeichneRegion(ctx, r); });

      // Polygone fuer Regionen auf der aktuellen Seite
      var aktuelleRegionIds = regionen.map(function (r) { return r.id; });
      var polygone = s.projekt.polygone.filter(function (p) {
        return aktuelleRegionIds.indexOf(p.regionId) >= 0;
      });
      polygone.forEach(function (p) { zeichnePolygon(ctx, p); });
      // Kanten-Labels und Eckpunkt-Marker nur im Plan-Modus
      if (GF.state.aktivesWerkzeug === 'pan') {
        polygone.forEach(function (p) { zeichneKantenLabels(ctx, p); });
        // Eckpunkt-Marker nur fuer das aktive Polygon (sonst optische Ueberlast)
        var ap = polygone.filter(function (p) { return p.id === s.aktivesPolygonId; })[0];
        if (ap) zeichneEckpunktMarker(ctx, ap);
      }
    }

    // Polygon-Live waehrend Zeichnung
    if (GF.state.aktivesWerkzeug === 'polygon' && polygonPunkte.length > 0) {
      zeichnePolygonLive(ctx);
    }

    // Rechteck-Live-Vorschau (eigener Modul-State)
    if (GF.state.aktivesWerkzeug === 'rechteck' && rechteckEcke1) {
      zeichneRechteckLive(ctx);
    }

    // Massstab-Linie waehrend Kalibrierung
    if (GF.state.aktivesWerkzeug === 'massstab' && massPunkt1) {
      var endPdf = massPunkt2 || massMaus || massPunkt1;
      zeichneMassstabLinie(ctx, massPunkt1, endPdf, !massPunkt2);
    }

    // Temp-Rechteck waehrend des Region-Drags
    if (regionDragAktiv && regionStartPdf && regionAktuellPdf) {
      var tmp = normalisiereRechteck(regionStartPdf, regionAktuellPdf);
      var c = pdfZuCanvas(tmp.x, tmp.y);
      var z = s.viewport.zoom;
      ctx.save();
      ctx.fillStyle = 'rgba(15, 45, 90, 0.15)';
      ctx.strokeStyle = '#0F2D5A';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 4]);
      ctx.fillRect(c.x, c.y, tmp.breite * z, tmp.hoehe * z);
      ctx.strokeRect(c.x, c.y, tmp.breite * z, tmp.hoehe * z);
      ctx.restore();
    }
  }

  function zeichnePolygon(ctx, p) {
    if (!p.punkte || p.punkte.length < 3) return;
    var s = GF.state;
    var farbe = p.farbeOverlay || '#7f8c8d';
    var aktiv = (p.id === s.aktivesPolygonId);
    var deckkraft = (typeof p.deckkraft === 'number') ? p.deckkraft : 0.5;
    if (aktiv) deckkraft = Math.min(1, deckkraft + 0.15);

    // Fill mit konfigurierbarer Deckkraft, Stroke immer voll sichtbar
    ctx.save();
    ctx.beginPath();
    p.punkte.forEach(function (pt, i) {
      var c = pdfZuCanvas(pt.x, pt.y);
      if (i === 0) ctx.moveTo(c.x, c.y);
      else         ctx.lineTo(c.x, c.y);
    });
    ctx.closePath();
    if (deckkraft > 0) {
      ctx.globalAlpha = deckkraft;
      ctx.fillStyle = farbe;
      ctx.fill();
      ctx.globalAlpha = 1.0;
    }
    ctx.strokeStyle = farbe;
    ctx.lineWidth = aktiv ? 2.5 : 1.5;
    ctx.stroke();

    // Label im geometrischen Mittel
    var cx = 0, cy = 0;
    p.punkte.forEach(function (pt) {
      var c = pdfZuCanvas(pt.x, pt.y);
      cx += c.x; cy += c.y;
    });
    cx /= p.punkte.length; cy /= p.punkte.length;
    var label = p.bezeichnung + '  ·  ' + GF.util.formatZahlDE(p.flaecheAngesetztQM, 2) + ' m²';
    ctx.font = 'bold 12px Segoe UI, Arial';
    var metrik = ctx.measureText(label);
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(cx - metrik.width/2 - 5, cy - 9, metrik.width + 10, 18);
    ctx.fillStyle = farbe;
    ctx.fillText(label, cx - metrik.width/2, cy + 4);
    ctx.restore();
  }

  // Zeichnet pro Kante ein klickbares Maß-Label und sammelt die Hitbox.
  function zeichneKantenLabels(ctx, p) {
    if (!p.punkte || p.punkte.length < 3) return;
    var region = GF.state.findRegion(p.regionId);
    if (!region || !region.kalibrierung || !region.kalibrierung.ptProMeter) return;
    var ptProM = region.kalibrierung.ptProMeter;
    var n = p.punkte.length;

    ctx.save();
    ctx.font = '11px Segoe UI, Arial';
    for (var i = 0; i < n; i++) {
      var p1 = p.punkte[i];
      var p2 = p.punkte[(i + 1) % n];
      var midPdf = { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 };
      var dx = p2.x - p1.x, dy = p2.y - p1.y;
      var laengeM = Math.sqrt(dx * dx + dy * dy) / ptProM;
      if (laengeM < 0.001) continue;
      var text = GF.util.formatZahlDE(laengeM, 2) + ' m';
      var c = pdfZuCanvas(midPdf.x, midPdf.y);
      var w = ctx.measureText(text).width;
      var pad = 4, h = 16;
      var bx = c.x - w / 2 - pad;
      var by = c.y - h / 2;

      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 1;
      ctx.fillRect(bx, by, w + 2 * pad, h);
      ctx.strokeRect(bx, by, w + 2 * pad, h);
      ctx.fillStyle = '#7c3a07';
      ctx.fillText(text, c.x - w / 2, c.y + 4);

      kantenLabelHitboxen.push({
        polygonId: p.id, kantenIndex: i,
        x: bx, y: by, w: w + 2 * pad, h: h
      });
    }
    ctx.restore();
  }

  function findeKantenLabel(canvasX, canvasY) {
    for (var i = kantenLabelHitboxen.length - 1; i >= 0; i--) {
      var hb = kantenLabelHitboxen[i];
      if (canvasX >= hb.x && canvasX <= hb.x + hb.w &&
          canvasY >= hb.y && canvasY <= hb.y + hb.h) {
        return hb;
      }
    }
    return null;
  }

  // Eckpunkt-Marker fuer das aktive Polygon (zum Verschieben einzelner Punkte).
  function zeichneEckpunktMarker(ctx, p) {
    if (!p.punkte || p.punkte.length < 3) return;
    ctx.save();
    for (var i = 0; i < p.punkte.length; i++) {
      var c = pdfZuCanvas(p.punkte[i].x, p.punkte[i].y);
      // Aussenring (dunkler) + Innenkreis (weiss) — gut sichtbar auf jedem Hintergrund
      ctx.beginPath();
      ctx.arc(c.x, c.y, 6, 0, 2 * Math.PI);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.strokeStyle = '#0F2D5A';
      ctx.lineWidth = 2;
      ctx.stroke();
      // Innen-Punkt
      ctx.beginPath();
      ctx.arc(c.x, c.y, 2, 0, 2 * Math.PI);
      ctx.fillStyle = '#0F2D5A';
      ctx.fill();

      eckpunktHitboxen.push({
        polygonId: p.id, punktIndex: i, x: c.x, y: c.y, radius: 9
      });
    }
    ctx.restore();
  }

  function findeEckpunkt(canvasX, canvasY) {
    for (var i = eckpunktHitboxen.length - 1; i >= 0; i--) {
      var hb = eckpunktHitboxen[i];
      var dx = canvasX - hb.x;
      var dy = canvasY - hb.y;
      if (dx * dx + dy * dy <= hb.radius * hb.radius) return hb;
    }
    return null;
  }

  function zeichnePolygonLive(ctx) {
    if (polygonPunkte.length === 0) return;
    ctx.save();

    // Fester Teil (bereits gesetzte Punkte) — Pfad
    function pfadFix() {
      ctx.beginPath();
      polygonPunkte.forEach(function (pt, i) {
        var c = pdfZuCanvas(pt.x, pt.y);
        if (i === 0) ctx.moveTo(c.x, c.y);
        else         ctx.lineTo(c.x, c.y);
      });
    }

    // Halo + Vordergrund fuer den festen Teil
    pfadFix();
    ctx.lineWidth = 5;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.setLineDash([]);
    ctx.stroke();
    pfadFix();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#0F2D5A';
    ctx.setLineDash([8, 4]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Live-Linie zur Maus — separat, mit Farbwechsel bei 90°-Snap
    if (polygonMaus) {
      var letzter = polygonPunkte[polygonPunkte.length - 1];
      var clL = pdfZuCanvas(letzter.x, letzter.y);
      var cm  = pdfZuCanvas(polygonMaus.x, polygonMaus.y);
      // Halo
      ctx.beginPath();
      ctx.moveTo(clL.x, clL.y); ctx.lineTo(cm.x, cm.y);
      ctx.lineWidth = 5;
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.setLineDash([]);
      ctx.stroke();
      // Vordergrund: magenta bei Vektor-Magnet, gruen bei 90°-Snap, sonst blau-gestrichelt
      ctx.beginPath();
      ctx.moveTo(clL.x, clL.y); ctx.lineTo(cm.x, cm.y);
      ctx.lineWidth = 2.5;
      if (vektorSnapAktiv) {
        ctx.strokeStyle = '#1EA596';
        ctx.setLineDash([]);
      } else if (winkelSnapAktiv) {
        ctx.strokeStyle = '#10b981';
        ctx.setLineDash([]);
      } else {
        ctx.strokeStyle = '#0F2D5A';
        ctx.setLineDash([8, 4]);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Vektor-Magnet: Magenta-Ring auf der eingerasteten CAD-Ecke + Label.
      if (vektorSnapAktiv) {
        ctx.beginPath();
        ctx.arc(cm.x, cm.y, 8, 0, 2 * Math.PI);
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#1EA596';
        ctx.stroke();
        ctx.font = 'bold 11px Segoe UI, Arial';
        var tV = 'Endpunkt';
        var wV = ctx.measureText(tV).width;
        ctx.fillStyle = 'rgba(30, 165, 150, 0.95)';
        ctx.fillRect(cm.x + 10, cm.y - 22, wV + 8, 16);
        ctx.fillStyle = '#fff';
        ctx.fillText(tV, cm.x + 14, cm.y - 10);
      } else if (winkelSnapAktiv) {
        // Kleines ⊥-Symbol oberhalb der Maus wenn 90°-Snap greift
        ctx.font = 'bold 11px Segoe UI, Arial';
        var text = '⊥ 90°';
        var w = ctx.measureText(text).width;
        ctx.fillStyle = 'rgba(16, 185, 129, 0.95)';
        ctx.fillRect(cm.x + 10, cm.y - 22, w + 8, 16);
        ctx.fillStyle = '#fff';
        ctx.fillText(text, cm.x + 14, cm.y - 10);
      }
    }

    // Punkt-Marker
    polygonPunkte.forEach(function (pt, idx) {
      var c = pdfZuCanvas(pt.x, pt.y);
      ctx.beginPath();
      ctx.arc(c.x, c.y, 4, 0, 2 * Math.PI);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = idx === 0 ? '#10b981' : '#0F2D5A';   // Startpunkt gruen
      ctx.stroke();
    });

    // Startpunkt-Highlight wenn Polygon schliessbar
    if (polygonPunkte.length >= 3) {
      var c0 = pdfZuCanvas(polygonPunkte[0].x, polygonPunkte[0].y);
      ctx.beginPath();
      ctx.arc(c0.x, c0.y, 10, 0, 2 * Math.PI);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Live-Flaechen-Anzeige bei 3+ Punkten
    if (polygonPunkte.length >= 3) {
      var s = GF.state;
      var r = null;
      for (var i = 0; i < s.projekt.planRegionen.length; i++) {
        if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
      }
      if (r && r.kalibrierung) {
        try {
          var f = GF.polygon.berechneFlaeche(polygonPunkte, r.kalibrierung.ptProMeter);
          // Live-Vorschau: noch kein Schlusssegment vorhanden -> closed=false
          var ueb = GF.polygon.hatSelbstueberschneidung(polygonPunkte, false);
          var letzter = polygonPunkte[polygonPunkte.length - 1];
          var cL = pdfZuCanvas(letzter.x, letzter.y);
          var t = ueb
            ? '⚠ Selbstüberschneidung'
            : GF.util.formatZahlDE(f, 2) + ' m² (' + polygonPunkte.length + ' Punkte)';
          ctx.font = '600 12px Segoe UI, Arial';
          var metrik = ctx.measureText(t);
          ctx.fillStyle = ueb ? 'rgba(254,226,226,0.95)' : 'rgba(255,255,255,0.92)';
          ctx.fillRect(cL.x + 10, cL.y - 22, metrik.width + 12, 20);
          ctx.fillStyle = ueb ? '#b91c1c' : '#0F2D5A';
          ctx.fillText(t, cL.x + 16, cL.y - 8);
        } catch (e) { /* still <3 effective points etc. */ }
      }
    }

    ctx.restore();
  }

  function zeichneMassstabLinie(ctx, p1, p2, gestrichelt) {
    var c1 = pdfZuCanvas(p1.x, p1.y);
    var c2 = pdfZuCanvas(p2.x, p2.y);
    // Bei aktivem Winkel-Snap UND wenn das die Live-Linie ist (gestrichelt=true):
    // gruene durchgezogene Linie statt orange-gestrichelt — visuelles Snap-Signal.
    var snapAnzeige = !!(gestrichelt && winkelSnapAktiv);
    ctx.save();
    ctx.lineWidth = 2;
    if (snapAnzeige) {
      ctx.strokeStyle = '#10b981';
      ctx.setLineDash([]);
    } else {
      ctx.strokeStyle = '#d97706';
      if (gestrichelt) ctx.setLineDash([6, 4]);
    }
    ctx.beginPath();
    ctx.moveTo(c1.x, c1.y);
    ctx.lineTo(c2.x, c2.y);
    ctx.stroke();
    // Endpunkt-Marker
    var markerFarbe = snapAnzeige ? '#10b981' : '#d97706';
    [c1, c2].forEach(function (pt) {
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 5, 0, 2 * Math.PI);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.setLineDash([]);
      ctx.strokeStyle = markerFarbe;
      ctx.stroke();
    });
    // Kleines ⊥-Label am zweiten Endpunkt wenn Snap greift
    if (snapAnzeige) {
      ctx.font = 'bold 11px Segoe UI, Arial';
      var text = '⊥ 90°';
      var w = ctx.measureText(text).width;
      ctx.fillStyle = 'rgba(16, 185, 129, 0.95)';
      ctx.fillRect(c2.x + 10, c2.y - 22, w + 8, 16);
      ctx.fillStyle = '#fff';
      ctx.fillText(text, c2.x + 14, c2.y - 10);
    }
    ctx.restore();
  }

  function zeichneRegion(ctx, region) {
    var s = GF.state;
    var c = pdfZuCanvas(region.ausschnitt.x, region.ausschnitt.y);
    var w = region.ausschnitt.breite * s.viewport.zoom;
    var h = region.ausschnitt.hoehe  * s.viewport.zoom;
    var aktiv = region.id === s.aktiveRegionId;
    ctx.save();
    ctx.fillStyle = aktiv ? 'rgba(15, 45, 90, 0.10)' : 'rgba(80, 80, 80, 0.06)';
    ctx.strokeStyle = aktiv ? '#0F2D5A' : '#666';
    ctx.lineWidth = aktiv ? 2 : 1;
    ctx.fillRect(c.x, c.y, w, h);
    ctx.strokeRect(c.x, c.y, w, h);
    // Label inkl. Kalibrierungs-Status
    var label = region.bezeichnung || '?';
    if (region.kalibrierung) {
      label += '  · ' + (region.kalibrierung.normMassstab || (GF.util.formatZahlDE(region.kalibrierung.ptProMeter, 2) + ' pt/m'));
    }
    ctx.font = 'bold 12px Segoe UI, Arial';
    var pad = 4;
    var metrik = ctx.measureText(label);
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillRect(c.x + pad, c.y + pad, metrik.width + 6, 16);
    ctx.fillStyle = aktiv ? '#0F2D5A' : '#333';
    ctx.fillText(label, c.x + pad + 3, c.y + pad + 12);
    // Gespeicherte Kalibrierungs-Punkte als kleine Marker zeigen
    // (kann ueber den Toggle in der Werkzeug-Sidebar ausgeblendet werden)
    if (region.kalibrierung && region.kalibrierung.punkt1 && region.kalibrierung.punkt2 &&
        GF.state.massstabSichtbar !== false) {
      zeichneMassstabLinie(ctx, region.kalibrierung.punkt1, region.kalibrierung.punkt2, false);
    }
    ctx.restore();
  }

  function aktualisiereToolbar() {
    var s = GF.state;
    var pdf = s.aktivesPdf();
    var hatPdfs = s.pdfs.length > 0;

    // Lade-Button-Text wechselt: bei leerem State "PDF laden",
    // bei mindestens einem geladenen "+ PDF" (additiv).
    var lbl = $('lblPdfLaden');
    if (lbl) lbl.textContent = hatPdfs ? '+ PDF' : 'PDF laden';

    var info = $('pdfDateiInfo');
    if (info) info.hidden = hatPdfs;

    var btnRen = $('btnPdfUmbenennen');
    if (btnRen) btnRen.hidden = !hatPdfs;

    var btnLoe = $('btnPdfLoeschen');
    if (btnLoe) btnLoe.hidden = !hatPdfs;

    var sel = $('pdfSelect');
    if (sel) {
      sel.hidden = !hatPdfs;
      // Optionen nur neu aufbauen, wenn sich Liste ODER Anzeigename geaendert hat
      var signatur = s.pdfs.map(function (p) { return p.id + ':' + (p.dateiName || ''); }).join('|');
      if (sel.dataset.signatur !== signatur) {
        sel.innerHTML = '';
        s.pdfs.forEach(function (p) {
          var opt = document.createElement('option');
          opt.value = p.id;
          opt.textContent = p.dateiName;
          sel.appendChild(opt);
        });
        sel.dataset.signatur = signatur;
      }
      if (s.aktivePdfId) sel.value = s.aktivePdfId;
    }

    var anzahl = pdf ? pdf.anzahlSeiten : 0;
    $('seiteAktuell').textContent = s.aktuelleSeite;
    $('seiteGesamt').textContent = anzahl;
    $('seitenNav').hidden = anzahl <= 0;
    $('zoomGroup').hidden = !s.pdfCache;
    $('zoomAnzeige').textContent = Math.round((s.viewport.zoom || 0) * 100);

    var emptyState = $('emptyState');
    if (emptyState) emptyState.style.display = pdf ? 'none' : '';

    var btnPrev = $('btnSeitePrev');
    var btnNext = $('btnSeiteNext');
    if (btnPrev) btnPrev.disabled = s.aktuelleSeite <= 1;
    if (btnNext) btnNext.disabled = s.aktuelleSeite >= anzahl;

    // Speichern aktivieren, sobald ein Projekt existiert
    var btnSp = $('btnSpeichern');
    if (btnSp) {
      btnSp.disabled = !s.projekt;
      // Visueller Hinweis auf ungespeicherte Aenderungen
      if (s.projekt && s.ungespeicherteAenderungen) {
        btnSp.classList.add('ungespeichert');
        btnSp.textContent = 'Speichern *';
      } else {
        btnSp.classList.remove('ungespeichert');
        btnSp.textContent = 'Speichern';
      }
    }
    var btnPD = $('btnProjektdaten');
    if (btnPD) btnPD.disabled = !s.projekt;

    var btnPr = $('btnProtokoll');
    if (btnPr) {
      // Protokoll geht erst wenn ein Projekt MIT mindestens einem Polygon existiert
      var hatPolygone = s.projekt && s.projekt.polygone && s.projekt.polygone.length > 0;
      btnPr.disabled = !hatPolygone;
    }
  }

  // ============================================================
  // Maus-Events
  // ============================================================

  function wireFileInput() {
    var input = $('pdfInput');
    if (!input) return;
    input.addEventListener('change', function (e) {
      var files = e.target.files;
      if (files && files.length > 0) ladePdfDateien(files);
      input.value = '';   // damit dieselben Dateien nochmal geladen werden koennen
    });

    var gfInp = $('gfprojInput');
    if (gfInp) {
      gfInp.addEventListener('change', function (e) {
        var files = e.target.files;
        if (files && files.length > 0) ladeProjektDatei(files[0]);
        gfInp.value = '';
      });
    }
  }

  // ============================================================
  // Projekt-Speichern / -Laden (.gfproj-ZIP)
  // ============================================================

  // Speichert das aktuelle Projekt als .gfproj-Datei (Browser-Download).
  // Falls noch kein Projektname gesetzt: window.prompt() fuer Eingabe.
  //
  // Ablauf-Reihenfolge ist wichtig: showSaveFilePicker MUSS direkt nach
  // dem User-Klick aufgerufen werden, sonst expired die transient user
  // activation (5-Sekunden-Budget) und der Browser blockt den Dialog.
  // Deshalb erst Ziel waehlen (Picker auf), dann erst die teuren
  // Async-Schritte (PDF-Binaerdaten lesen, ZIP bauen).
  function speichereProjekt() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Kein Projekt zum Speichern vorhanden.', 'warn');
      return Promise.resolve(false);
    }

    // Projektname sicherstellen
    var name = (s.projekt.metadata && s.projekt.metadata.projektName || '').trim();
    if (!name || name === '(neu)') {
      var eingabe = global.prompt(
        'Projektname (wird der Dateiname):',
        'Bauantrag-' + new Date().toISOString().slice(0, 10)
      );
      if (eingabe === null) return Promise.resolve(false);   // Abbruch
      eingabe = eingabe.trim();
      if (!eingabe) {
        showToast('Projektname darf nicht leer sein.', 'warn');
        return Promise.resolve(false);
      }
      s.projekt.metadata.projektName = eingabe;
      name = eingabe;
    }

    var dateiName = name.replace(/[\\/:*?"<>|]/g, '_') + '.zip';

    // Save-Ziel ZUERST waehlen (User-Activation ist hier noch frisch).
    return waehleSaveZiel(dateiName).then(function (ziel) {
      if (!ziel) return false;   // User hat im Picker abgebrochen

      // Container-Pfade frisch vergeben (stabil und konsistent zur aktuellen Reihenfolge).
      // dateiName = Anzeigename des Users, getrennt vom ZIP-Eintragspfad.
      s.pdfs.forEach(function (p, idx) {
        p.containerPfad = 'plan-' + (idx + 1) + '.pdf';
      });

      // PDF-Binaerdaten aus den geladenen pdfDocs holen
      var pdfBinaer = Object.create(null);
      var kette = Promise.resolve();
      s.pdfs.forEach(function (p) {
        var cPfad = p.containerPfad;
        kette = kette.then(function () {
          if (!p.pdfDoc || typeof p.pdfDoc.getData !== 'function') {
            throw new Error('Keine PDF-Binary für "' + cPfad + '" verfügbar (pdfDoc fehlt).');
          }
          return p.pdfDoc.getData().then(function (bytes) {
            pdfBinaer[cPfad] = bytes;
          });
        });
      });

      return kette.then(function () {
        // projekt.pdfs synchron mit aktuellem state.
        //   dateiName     = Anzeigename (vom User editierbar)
        //   containerPfad = ZIP-Eintragsname (plan-1.pdf, ...)
        s.projekt.pdfs = s.pdfs.map(function (p) {
          return {
            id: p.id,
            dateiName: p.dateiName,
            containerPfad: p.containerPfad,
            originalDateiName: p.originalDateiName || p.dateiName,
            groesseBytes: pdfBinaer[p.containerPfad].length,
            anzahlSeiten: p.anzahlSeiten,
            vektorAnteil: p.vektorAnteil || null
          };
        });

        GF.projekt.historieEintrag(s.projekt, 'Projekt gespeichert',
          s.pdfs.length + ' PDF(s), ' + s.projekt.polygone.length + ' Polygon(e)');

        return GF.projekt.speichere(s.projekt, pdfBinaer);
      }).then(function (blob) {
        return schreibeAnZiel(ziel, blob, dateiName).then(function (gespeichert) {
          if (!gespeichert) return false;
          GF.state.update(function (st) { st.ungespeicherteAenderungen = false; });
          if (GF.recovery && GF.recovery.loesche) GF.recovery.loesche();
          aktualisiereToolbar();
          showToast('Projekt gespeichert: ' + dateiName, 'success');
          return true;
        });
      });
    }).catch(function (err) {
      console.error('[gf-save]', err);
      showToast('Speichern fehlgeschlagen: ' + err.message, 'danger', 8000);
      return false;
    });
  }

  // Liefert den Container-internen Dateinamen einer geladenen PDF.
  // Stabil ueber Sessions hinweg, damit das gleiche pdf.id immer denselben Eintrag bekommt.
  function projektPdfDateiName(pdfEntry) {
    var s = GF.state;
    var idx = s.pdfs.indexOf(pdfEntry);
    if (idx < 0) idx = s.pdfs.length;
    return 'plan-' + (idx + 1) + '.pdf';
  }

  function datenBlobDownload(blob, dateiName) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = dateiName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
  }

  // ---- Letzter-Speicherort merken (IndexedDB, getrennt vom Recovery-Store) ----
  // FileSystemFileHandle ist structured-cloneable -> wir koennen ihn direkt speichern
  // und beim naechsten Save als startIn-Hinweis fuer den Save-Dialog wiederverwenden.
  var SAVE_DB_NAME = 'gf-savehandle';
  var SAVE_STORE   = 'handles';
  var SAVE_KEY     = 'last';

  function oeffneSaveDb() {
    return new Promise(function (resolve, reject) {
      if (!global.indexedDB) { reject(new Error('keine IndexedDB')); return; }
      var req = global.indexedDB.open(SAVE_DB_NAME, 1);
      req.onerror = function () { reject(req.error); };
      req.onsuccess = function () { resolve(req.result); };
      req.onupgradeneeded = function () {
        try { req.result.createObjectStore(SAVE_STORE); } catch (e) {}
      };
    });
  }

  function holeLetztenSaveHandle() {
    return oeffneSaveDb().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(SAVE_STORE, 'readonly');
          var st = tx.objectStore(SAVE_STORE);
          var req = st.get(SAVE_KEY);
          req.onsuccess = function () { resolve(req.result || null); };
          req.onerror = function () { resolve(null); };
        } catch (e) { resolve(null); }
      });
    }).catch(function () { return null; });
  }

  function speichereSaveHandle(handle) {
    return oeffneSaveDb().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(SAVE_STORE, 'readwrite');
          tx.objectStore(SAVE_STORE).put(handle, SAVE_KEY);
          tx.oncomplete = function () { resolve(); };
          tx.onerror    = function () { resolve(); };
        } catch (e) { resolve(); }
      });
    }).catch(function () { return null; });
  }

  // Fragt den User nach dem Speicherort und liefert ein Ziel, an das der Blob
  // spaeter geschrieben werden kann. MUSS direkt nach dem User-Klick aufgerufen
  // werden, sonst expired die transient user activation (5-Sekunden-Budget) und
  // showSaveFilePicker faellt auf den anchor-Download zurueck (= Downloads-Ordner
  // ohne Dialog). Die teuren Schritte (ZIP/PDF-Bau) MUESSEN nach diesem Aufruf
  // passieren, nicht davor.
  //
  // Liefert Promise<null | SaveZiel> mit:
  //   null                                  -> User-Abbruch im Picker
  //   { kind: 'handle', handle }            -> User hat Speicherort gewaehlt
  //   { kind: 'download' }                  -> Picker nicht verfuegbar (Firefox,
  //                                            file://-Aufruf), beim Schreiben
  //                                            wird auf anchor-Download zurueckgefallen
  function waehleSaveZiel(dateiName) {
    if (typeof global.showSaveFilePicker !== 'function') {
      // Kein Save-Picker verfuegbar -> beim Schreiben Browser-Standard-Download
      return Promise.resolve({ kind: 'download' });
    }
    var endung = (dateiName.match(/\.[^.]+$/) || ['.zip'])[0].toLowerCase();
    var fileTypes;
    if (endung === '.pdf') {
      fileTypes = [{ description: 'PDF', accept: { 'application/pdf': ['.pdf'] } }];
    } else {
      fileTypes = [{ description: 'FlächenKlar Projekt (ZIP-Container)', accept: { 'application/zip': ['.zip'] } }];
    }

    return holeLetztenSaveHandle().then(function (letzterHandle) {
      var options = { suggestedName: dateiName, types: fileTypes };
      // startIn kann ein FileSystemHandle oder eine well-known location sein.
      // Bei File-Handle oeffnet der Dialog im Parent-Ordner. Falls der Handle
      // nicht mehr existiert: Browser ignoriert ihn meist und nimmt Default.
      options.startIn = letzterHandle || 'documents';
      return global.showSaveFilePicker(options).then(function (handle) {
        return { kind: 'handle', handle: handle };
      }).catch(function (err) {
        if (err && err.name === 'AbortError') return null;
        // Eventuell ist ein veralteter Handle das Problem: nochmal ohne startIn=handle versuchen
        if (letzterHandle && err && (err.name === 'TypeError' || err.name === 'NotFoundError')) {
          return global.showSaveFilePicker({
            suggestedName: dateiName, types: fileTypes, startIn: 'documents'
          }).then(function (handle) {
            return { kind: 'handle', handle: handle };
          }).catch(function (err2) {
            if (err2 && err2.name === 'AbortError') return null;
            console.warn('[gf-save] Picker zweiter Versuch fehlgeschlagen, Fallback auf Download:', err2);
            return { kind: 'download' };
          });
        }
        console.warn('[gf-save] showSaveFilePicker fehlgeschlagen, Fallback auf Download:', err);
        return { kind: 'download' };
      });
    });
  }

  // Schreibt blob an das durch waehleSaveZiel() ermittelte Ziel. Darf beliebig
  // spaeter aufgerufen werden (User-Activation egal — Handle ist schon vergeben).
  // Liefert Promise<boolean> — true bei Erfolg, false bei Abbruch / null-Ziel.
  function schreibeAnZiel(ziel, blob, dateiName) {
    if (!ziel) return Promise.resolve(false);
    if (ziel.kind === 'download') {
      datenBlobDownload(blob, dateiName);
      return Promise.resolve(true);
    }
    if (ziel.kind === 'handle') {
      return ziel.handle.createWritable().then(function (writable) {
        return writable.write(blob).then(function () { return writable.close(); });
      }).then(function () {
        // Handle merken fuer den naechsten Save — Fehler ignorieren.
        return speichereSaveHandle(ziel.handle).catch(function () {});
      }).then(function () { return true; }).catch(function (err) {
        console.error('[gf-save] Schreiben in Handle fehlgeschlagen, Fallback auf Download:', err);
        datenBlobDownload(blob, dateiName);
        return true;
      });
    }
    return Promise.resolve(false);
  }

  // Oeffnet eine .gfproj-Datei und ersetzt das aktuelle Projekt damit.
  function ladeProjektDatei(file) {
    var s = GF.state;
    if (s.projekt && s.ungespeicherteAenderungen) {
      if (!global.confirm(
        'Das aktuelle Projekt hat ungespeicherte Änderungen. ' +
        'Beim Öffnen gehen sie verloren.\n\nTrotzdem fortfahren?'
      )) return Promise.resolve(false);
    }

    var status = $('appStartStatus');
    if (status) status.textContent = 'Öffne ' + file.name + ' …';

    return GF.projekt.lade(file).then(function (ergebnis) {
      var projekt = ergebnis.projekt;
      var pdfBinaer = ergebnis.pdfBinaer;

      // PDFs durch pdf.js parsen, in state.pdfs einsetzen.
      // dateiName = Anzeigename (User-editierbar), containerPfad = ZIP-Eintrag.
      var pdfMetaInProjekt = projekt.pdfs || [];
      var kette = Promise.resolve();
      var pdfEintraege = [];
      pdfMetaInProjekt.forEach(function (meta) {
        var cPfad = meta.containerPfad || meta.dateiName;
        var bytes = pdfBinaer[cPfad];
        kette = kette.then(function () {
          // pdf.js braucht ein FRISCHES Uint8Array — sonst meckert es spaeter
          // ueber "detached buffer" wenn getData() aufgerufen wird.
          var kopie = new Uint8Array(bytes);
          return global.pdfjsLib.getDocument({ data: kopie }).promise.then(function (doc) {
            pdfEintraege.push({
              id: meta.id,
              dateiName: meta.dateiName,
              containerPfad: cPfad,
              originalDateiName: meta.originalDateiName || meta.dateiName,
              anzahlSeiten: doc.numPages,
              vektorAnteil: meta.vektorAnteil || null,
              pdfDoc: doc
            });
          });
        });
      });

      return kette.then(function () {
        // Bestehenden State komplett verwerfen
        GF.state.update(function (st) {
          st.projekt = projekt;
          st.pdfs = pdfEintraege;
          st.aktivePdfId = pdfEintraege[0] ? pdfEintraege[0].id : null;
          st.aktuelleSeite = 1;
          st.aktivesGeschossId = null;
          st.aktiveRegionId = null;
          st.aktivesPolygonId = null;
          st.pdfCache = null;
          st.viewport = { zoom: 1.0, panX: 0, panY: 0 };
          st.ungespeicherteAenderungen = false;
        });
        aktualisiereToolbar();
        aktualisiereGeschossListe();

        if (pdfEintraege.length > 0) {
          return zeigeSeite(1);
        }
        return null;
      }).then(function () {
        if (status) status.textContent = 'Projekt geladen: ' + file.name;
        showToast('Projekt geöffnet: ' + (projekt.metadata.projektName || file.name) +
                  ' (' + pdfEintraege.length + ' PDF, ' + projekt.polygone.length + ' Polygon).',
                  'success', 6000);
        return true;
      });
    }).catch(function (err) {
      console.error('[gf-open]', err);
      if (status) status.textContent = 'Bereit.';
      showToast('Öffnen fehlgeschlagen: ' + err.message, 'danger', 9000);
      return false;
    });
  }

  function oeffneProjektDialog() {
    var inp = $('gfprojInput');
    if (inp) inp.click();
  }

  function wireProjektButtons() {
    var btnN = $('btnNeu');
    if (btnN) btnN.addEventListener('click', neuesProjekt);
    var btnS = $('btnSpeichern');
    if (btnS) btnS.addEventListener('click', function () { speichereProjekt(); });
    var btnO = $('btnOeffnen');
    if (btnO) btnO.addEventListener('click', oeffneProjektDialog);
    var btnPD = $('btnProjektdaten');
    if (btnPD) btnPD.addEventListener('click', oeffneProjektdaten);
  }

  // Verwirft das aktuelle Projekt und stellt den Tool-Start-Zustand wieder her.
  // Fragt bei ungespeicherten Aenderungen vorher nach.
  function neuesProjekt() {
    var s = GF.state;
    if (s.projekt && s.ungespeicherteAenderungen) {
      if (!global.confirm(
        'Das aktuelle Projekt hat ungespeicherte Änderungen. ' +
        'Beim Anlegen eines neuen Projekts gehen sie verloren.\n\nTrotzdem fortfahren?'
      )) return;
    }
    // Laufende Tool-Aktionen abbrechen
    if (typeof abbrecheEckpunktDrag === 'function' && aktiverPunktDrag) abbrecheEckpunktDrag();
    if (typeof abbrecheKantenEdit === 'function' && $('kantenEdit') && !$('kantenEdit').hidden) abbrecheKantenEdit();

    GF.state.update(function (st) {
      st.projekt = null;
      st.pdfs = [];
      st.aktivePdfId = null;
      st.aktuelleSeite = 1;
      st.aktivesGeschossId = null;
      st.aktiveRegionId = null;
      st.aktivesPolygonId = null;
      st.pdfCache = null;
      st.vektorAnteil = null;
      st.viewport = { zoom: 1.0, panX: 0, panY: 0 };
      st.ungespeicherteAenderungen = false;
    });

    // Canvas leeren (sonst bleibt das alte Bild stehen)
    var canvas = $('planCanvas');
    if (canvas) canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);

    // Recovery-Snapshot loeschen — wir starten frisch
    if (GF.recovery && GF.recovery.loesche) GF.recovery.loesche();

    aktualisiereToolbar();
    aktualisiereGeschossListe();
    aktualisiereCursor();
    redraw();

    var status = $('appStartStatus');
    if (status) status.textContent = 'Bereit. PDF laden, um zu beginnen.';
    showToast('Neues Projekt — PDF laden, um zu beginnen.');
  }

  // ============================================================
  // Projektdaten-Modal (Bauherr, Bauvorhaben, Adresse, ...)
  // ============================================================

  // Felder im Modal -> Schluessel in projekt.metadata
  var PD_FELDER = {
    pdProjektName:        'projektName',
    pdProjektNummer:      'projektNummer',
    pdBauvorhaben:        'bauvorhaben',
    pdBauortStrasse:      'bauortStrasse',
    pdBauortPLZ:          'bauortPLZ',
    pdBauortOrt:          'bauortOrt',
    pdFlurnummer:         'flurnummer',
    pdGemarkung:          'gemarkung',
    pdBauherr:            'bauherr',
    pdBauherrStrasse:     'bauherrAnschriftStrasse',
    pdBauherrPLZ:         'bauherrAnschriftPLZ',
    pdBauherrOrt:         'bauherrAnschriftOrt',
    pdBauherrPKNr:        'bauherrPKNr',
    pdSachbearbeiter:     'sachbearbeiter',
    pdZusatzinfo:         'zusatzinfo'
  };

  var SACHBEARBEITER_LS_KEY = 'gf.sachbearbeiter';

  function oeffneProjektdaten() {
    if (!GF.state.projekt) {
      showToast('Erst ein Projekt anlegen (PDF laden) oder öffnen.', 'warn');
      return;
    }
    var meta = GF.state.projekt.metadata || {};
    Object.keys(PD_FELDER).forEach(function (id) {
      var el = $(id);
      if (!el) return;
      var key = PD_FELDER[id];
      var wert = meta[key];
      // Sachbearbeiter vorbelegen aus LocalStorage, wenn im Projekt leer
      if (key === 'sachbearbeiter' && !wert) {
        try { wert = localStorage.getItem(SACHBEARBEITER_LS_KEY) || ''; } catch (e) { wert = ''; }
      }
      el.value = wert || '';
    });
    $('pdFehler').hidden = true;
    $('projektdatenBackdrop').classList.add('aktiv');
    setTimeout(function () {
      var inp = $('pdProjektName');
      if (inp) inp.focus();
    }, 30);
  }

  function abbrecheProjektdaten() {
    $('projektdatenBackdrop').classList.remove('aktiv');
  }

  function uebernehmeProjektdaten() {
    var meta = GF.state.projekt && GF.state.projekt.metadata;
    if (!meta) { abbrecheProjektdaten(); return; }

    var name = ($('pdProjektName').value || '').trim();
    if (!name) {
      var fehler = $('pdFehler');
      fehler.textContent = 'Projektname ist Pflichtfeld.';
      fehler.hidden = false;
      $('pdProjektName').focus();
      return;
    }

    // Alle Felder uebernehmen
    Object.keys(PD_FELDER).forEach(function (id) {
      var el = $(id);
      if (!el) return;
      meta[PD_FELDER[id]] = (el.value || '').trim();
    });

    // Sachbearbeiter in LocalStorage merken (komfortabel beim naechsten Projekt)
    if (meta.sachbearbeiter) {
      try { localStorage.setItem(SACHBEARBEITER_LS_KEY, meta.sachbearbeiter); } catch (e) {}
    }

    GF.projekt.historieEintrag(GF.state.projekt, 'Projektdaten geändert', '');
    GF.state.markiereGeaendert();
    aktualisiereToolbar();
    abbrecheProjektdaten();
    showToast('Projektdaten übernommen.', 'success');
  }

  function wireProjektdaten() {
    var ok = $('btnProjektdatenOk');
    var ab = $('btnProjektdatenAbbrechen');
    if (ok) ok.addEventListener('click', uebernehmeProjektdaten);
    if (ab) ab.addEventListener('click', abbrecheProjektdaten);
  }

  // ---- Maßstab-Linien-Toggle (Anzeige-Setting, LocalStorage) ----
  var MASS_VISIBLE_LS_KEY = 'gf.massstabSichtbar';

  function wireMassstabToggle() {
    var inp = $('massstabToggle');
    if (!inp) return;
    // Initial aus LocalStorage holen
    try {
      var gespeichert = localStorage.getItem(MASS_VISIBLE_LS_KEY);
      if (gespeichert === '0' || gespeichert === 'false') {
        GF.state.update(function (s) { s.massstabSichtbar = false; });
      }
    } catch (e) {}
    inp.checked = (GF.state.massstabSichtbar !== false);
    inp.addEventListener('change', function () {
      var sichtbar = inp.checked;
      GF.state.update(function (s) { s.massstabSichtbar = sichtbar; });
      try { localStorage.setItem(MASS_VISIBLE_LS_KEY, sichtbar ? '1' : '0'); } catch (e) {}
      redraw();
    });
  }

  // ============================================================
  // Aufmassprotokoll erzeugen
  // ============================================================

  function oeffneProtokollModal() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Erst ein Projekt anlegen.', 'warn');
      return;
    }
    // Sanity-Checks: Projektname + mindestens ein Polygon
    var meta = s.projekt.metadata || /** @type {ProjektMetadata} */ ({});
    if (!meta.projektName || meta.projektName === '(neu)') {
      showToast('Bitte zuerst Projektdaten ausfüllen (mindestens Projektname).', 'warn', 7000);
      oeffneProjektdaten();
      return;
    }
    if (!s.projekt.polygone || s.projekt.polygone.length === 0) {
      showToast('Noch keine Polygone gezeichnet — Protokoll wäre leer.', 'warn');
      return;
    }
    $('ppAufmassblatt').checked = true;
    $('ppBerechnung').checked = true;
    $('ppKantenmasse').checked = true;
    // Rechenweg ist opt-in — je Export bewusst neu entscheiden, kein Sticky-Haekchen.
    $('ppRechenweg').checked = false;
    $('ppFehler').hidden = true;
    // Kantenmaß-Checkbox nur aktiv wenn Berechnungsdarstellung an ist
    aktualisiereKantenmasseEnabled();
    var info = $('ppInfo');
    if (info) {
      var ist = istDemoModus();
      info.hidden = !ist;
      if (ist) info.textContent = 'Hinweis: Lizenz im Demo-Modus — das PDF erhält ein diagonales Wasserzeichen.';
    }
    $('protokollBackdrop').classList.add('aktiv');
  }

  function abbrecheProtokollModal() {
    $('protokollBackdrop').classList.remove('aktiv');
  }

  function istDemoModus() {
    // Vollversion liegt vor, wenn eine Lizenz-ID hinterlegt ist (data/lizenz.js).
    // Die echte Whitelist-Pruefung erfolgt in Phase 6 — fuer das Wasserzeichen
    // reicht der ID-Check, weil die Whitelist-Datei selbst kontrolliert wird.
    if (GF.lizenz && typeof GF.lizenz.holeID === 'function') {
      try { return !GF.lizenz.holeID(); } catch (e) { return true; }
    }
    return true;
  }

  // Wandelt das #wappenLogo-Element (falls geladen) in eine PNG-DataURL um.
  function wappenAlsDataUrl() {
    var img = /** @type {HTMLImageElement | null} */ (document.getElementById('wappenLogo'));
    if (!img || !img.complete || img.naturalWidth === 0) return null;
    try {
      var c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      var ctx = /** @type {CanvasRenderingContext2D} */ (c.getContext('2d'));
      ctx.drawImage(img, 0, 0);
      return c.toDataURL('image/png');
    } catch (e) {
      console.warn('[gf-export] Wappen konnte nicht extrahiert werden:', e);
      return null;
    }
  }

  function aktualisiereKantenmasseEnabled() {
    var b = $('ppBerechnung');
    var k = $('ppKantenmasse');
    if (b && k) k.disabled = !b.checked;
  }

  function erzeugeProtokoll() {
    var s = GF.state;
    if (!s.projekt) return;
    var enthaltAufmassblatt = $('ppAufmassblatt').checked;
    var enthaltBerechnung   = $('ppBerechnung').checked;
    var enthaltKantenmasse  = enthaltBerechnung && $('ppKantenmasse').checked;
    var enthaltRechenweg    = $('ppRechenweg').checked;
    if (!enthaltAufmassblatt && !enthaltBerechnung) {
      var f = $('ppFehler');
      f.textContent = 'Mindestens einen Inhalt auswählen.';
      f.hidden = false;
      return;
    }

    var basisName = (s.projekt.metadata.projektName || 'Aufmaß').replace(/[\\/:*?"<>|]/g, '_');
    var dateiName = basisName + '_Aufmassprotokoll.pdf';

    // btn + status muessen im aeusseren Scope leben, damit der finale .then()
    // sie reseten kann — auch wenn die UI erst nach dem Picker-Erfolg disabled wird.
    var btn    = $('btnProtokollErzeugen');
    var status = $('appStartStatus');

    // Save-Ziel ZUERST waehlen (User-Activation ist hier noch frisch).
    // Anschliessend rendert starteExport das PDF asynchron — das dauert bei
    // grossen Projekten mehrere Sekunden und wuerde sonst die Activation
    // verbrauchen, sodass der Picker auf Downloads-Fallback faellt.
    return waehleSaveZiel(dateiName).then(function (ziel) {
      if (!ziel) return false;   // User-Abbruch im Picker

      if (btn)    { btn.disabled = true; btn.textContent = 'Erstelle …'; }
      if (status) status.textContent = 'Erzeuge Aufmaßprotokoll …';

      var opt = {
        enthaltAufmassblatt: enthaltAufmassblatt,
        enthaltBerechnung:   enthaltBerechnung,
        enthaltKantenmasse:  enthaltKantenmasse,
        enthaltRechenweg:    enthaltRechenweg,
        demoMode:            istDemoModus(),
        wappenDataUrl:       wappenAlsDataUrl()
      };

      return GF.export.starteExport(s.projekt, s.pdfs, opt).then(function (blob) {
        // null = User hat den Anrechnungs-Dialog abgebrochen — kein Fehler.
        if (!blob) return false;
        return schreibeAnZiel(ziel, blob, dateiName).then(function (gespeichert) {
          if (gespeichert) {
            GF.projekt.historieEintrag(s.projekt, 'Aufmaßprotokoll erstellt',
              (enthaltAufmassblatt ? 'Aufmaßblatt' : '') +
              (enthaltAufmassblatt && enthaltBerechnung ? ' + ' : '') +
              (enthaltBerechnung ? 'Berechnungsdarstellung' : ''));
            GF.state.markiereGeaendert();
            showToast('Aufmaßprotokoll erstellt: ' + dateiName, 'success', 6000);
            abbrecheProtokollModal();
          }
          return gespeichert;
        });
      });
    }).catch(function (err) {
      console.error('[gf-export]', err);
      var f = $('ppFehler');
      f.textContent = 'Erstellen fehlgeschlagen: ' + err.message;
      f.hidden = false;
    }).then(function () {
      if (btn) { btn.disabled = false; btn.textContent = 'PDF erstellen'; }
      if (status) status.textContent = 'Bereit.';
    });
  }

  // Strukturierter Fachverfahren-Export (CSV/JSON). Nutzt dasselbe
  // VG-Anrechnungs-Modell wie das PDF (GF.ExportDialog), serialisiert aber das
  // maschinenlesbare Datenmodell (GF.exportdaten -> GF.exportformat) statt eines PDF.
  function erzeugeDatenexport() {
    var s = GF.state;
    if (!s.projekt) return;
    if (!GF.exportdaten || !GF.exportformat) {
      showToast('Datenexport-Module nicht geladen.', 'error');
      return;
    }
    var sel = $('exFormat');
    var writer = (sel && GF.exportformat.get(sel.value)) || GF.exportformat.get('csv');
    if (!writer) { showToast('Kein Export-Format verfügbar.', 'error'); return; }
    var enthaltKanten = !!($('exKanten') && $('exKanten').checked);

    function fertige(modus) {
      try {
        var modell = GF.exportdaten.baue(s.projekt, s.pdfs, {
          vgAnrechnung: modus,
          enthaltKanten: enthaltKanten,
          demoMode: istDemoModus()
        });
        var res = writer.schreibe(modell);
        if (res.blob) datenBlobDownload(res.blob, res.dateiname);
        GF.projekt.historieEintrag(s.projekt, 'Datenexport erstellt', writer.label + ' · ' + res.dateiname);
        GF.state.markiereGeaendert();
        showToast('Datenexport erstellt: ' + res.dateiname, 'success', 6000);
        abbrecheProtokollModal();
      } catch (err) {
        console.error('[gf-exportdaten]', err);
        var f = $('ppFehler');
        if (f) { f.textContent = 'Datenexport fehlgeschlagen: ' + err.message; f.hidden = false; }
      }
    }

    // Nur fragen, wenn es VG-Geschosse mit Wahlmoeglichkeit gibt — sonst 'voll'
    // (bzw. die im Projekt gespeicherte Wahl).
    var vg = (GF.ExportDialog && GF.ExportDialog.sammleVgGeschosse)
      ? GF.ExportDialog.sammleVgGeschosse(s.projekt) : [];
    if (vg.length > 0 && GF.ExportDialog && GF.ExportDialog.oeffne) {
      GF.ExportDialog.oeffne(s.projekt, function (modus) {
        if (!modus) return;   // Abbruch im Anrechnungs-Dialog
        fertige(modus);
      });
    } else {
      var modus = (s.projekt.metadata && s.projekt.metadata.vgAnrechnung === 'anteilig')
        ? 'anteilig' : 'voll';
      fertige(modus);
    }
  }

  function wireProtokoll() {
    var btn = $('btnProtokoll');
    if (btn) btn.addEventListener('click', oeffneProtokollModal);
    var ok = $('btnProtokollErzeugen');
    var ab = $('btnProtokollAbbrechen');
    if (ok) ok.addEventListener('click', erzeugeProtokoll);
    if (ab) ab.addEventListener('click', abbrecheProtokollModal);

    // Datenexport (CSV/JSON): Format-Auswahl befuellen + Button verdrahten.
    var fmtSel = $('exFormat');
    if (fmtSel && GF.exportformat) {
      fmtSel.innerHTML = '';
      GF.exportformat.liste().forEach(function (w) {
        var o = document.createElement('option');
        o.value = w.id;
        o.textContent = w.label;
        fmtSel.appendChild(o);
      });
    }
    var dx = $('btnDatenexport');
    if (dx) dx.addEventListener('click', erzeugeDatenexport);

    var b = $('ppBerechnung');
    if (b) b.addEventListener('change', aktualisiereKantenmasseEnabled);
    // Der ausfuehrliche Rechenweg je Region erscheint auf der Berechnungsdarstellung.
    // Wird "Rechenweg anzeigen" gehakt, MUSS diese Seite mitlaufen, sonst ist das
    // Haekchen praktisch wirkungslos (nur die triviale Aufmassblatt-Zeile bliebe).
    var rw = $('ppRechenweg');
    if (rw && b) rw.addEventListener('change', function () {
      if (rw.checked && !b.checked) {
        b.checked = true;
        aktualisiereKantenmasseEnabled();
      }
    });
  }

  // Strg+S / Strg+O global. Nur aktiv wenn KEIN Eingabefeld fokussiert ist.
  // preventDefault() unterdrueckt den Browser-eigenen "Webseite speichern" / "Datei oeffnen".
  function wireTastenkuerzel() {
    global.addEventListener('keydown', function (e) {
      var key = e.key && e.key.toLowerCase();
      var modifier = e.ctrlKey || e.metaKey;
      if (!modifier) return;
      if (istEingabeAktiv()) return;
      if (key === 's') {
        e.preventDefault();
        if (GF.state.projekt) speichereProjekt();
      } else if (key === 'o') {
        e.preventDefault();
        oeffneProjektDialog();
      }
    });
  }

  // v1.2: Werkzeug-Tasten (H/R/M/P), Zoom (+/-), letzten Polygon-Punkt zurueck (Backspace).
  // Nur ohne fokussiertes Eingabefeld und ohne Strg/Cmd/Alt; nicht waehrend das
  // Tastenkuerzel-Overlay offen ist.
  function wireWerkzeugTasten() {
    global.addEventListener('keydown', function (e) {
      if (istEingabeAktiv()) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      var kb = $('kuerzelBackdrop');
      if (kb && kb.classList.contains('aktiv')) return;
      var k = e.key;
      if (GF.state.pdfs.length > 0) {
        var werkzeug = ({ h: 'pan', r: 'region', m: 'massstab', p: 'polygon',
                          k: 'rechteck' })[k.toLowerCase()];
        if (werkzeug) { e.preventDefault(); setzeWerkzeug(werkzeug); return; }
        if (k === '+' || k === '=') { e.preventDefault(); zoomMitFaktor(1.25, null, null); return; }
        if (k === '-' || k === '_') { e.preventDefault(); zoomMitFaktor(1 / 1.25, null, null); return; }
      }
      if ((k === 'Backspace' || k === 'Delete')
          && GF.state.aktivesWerkzeug === 'polygon'
          && polygonPunkte.length > 0) {
        e.preventDefault();
        polygonPunkte.pop();
        if (polygonPunkte.length === 0) polygonMaus = null;
        winkelSnapAktiv = false;
        vektorSnapAktiv = false;
        redraw();
      }
    });
  }

  // v1.2: '?' oder der Hilfe-Button oeffnet das Tastenkuerzel-Overlay;
  // Esc / Schliessen-Button / Klick auf den Hintergrund schliesst es.
  function wireKuerzel() {
    var backdrop = $('kuerzelBackdrop');
    function oeffne()    { if (backdrop) backdrop.classList.add('aktiv'); }
    function schliesse() { if (backdrop) backdrop.classList.remove('aktiv'); }
    var btnOpen = $('btnKuerzel');
    var btnClose = $('btnKuerzelSchliessen');
    if (btnOpen)  btnOpen.addEventListener('click', oeffne);
    if (btnClose) btnClose.addEventListener('click', schliesse);
    if (backdrop) backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) schliesse();
    });
    global.addEventListener('keydown', function (e) {
      if (e.key === '?' && !istEingabeAktiv()) {
        e.preventDefault();
        if (backdrop && backdrop.classList.contains('aktiv')) schliesse();
        else oeffne();
      }
    });
  }

  function wireDragDrop() {
    var host = $('canvasHost');
    var overlay = $('dropOverlay');
    if (!host || !overlay) return;
    var counter = 0;
    host.addEventListener('dragenter', function (e) {
      var types = (e.dataTransfer && e.dataTransfer.types) || [];
      var hatFiles = Array.prototype.indexOf.call(types, 'Files') >= 0;
      if (!hatFiles) return;
      counter++;
      overlay.classList.add('aktiv');
    });
    host.addEventListener('dragleave', function () {
      counter--;
      if (counter <= 0) {
        counter = 0;
        overlay.classList.remove('aktiv');
      }
    });
    host.addEventListener('dragover', function (e) {
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    });
    host.addEventListener('drop', function (e) {
      e.preventDefault();
      counter = 0;
      overlay.classList.remove('aktiv');
      var files = (e.dataTransfer && e.dataTransfer.files) || [];
      // file.type ist auf manchen Windows-Browsern leer / "application/octet-stream".
      // Fallback: Dateiendung pruefen.
      // .zip hat Vorrang: ein einzelnes Projekt-File ersetzt den State.
      // Die Tool-Erkennung passiert spaeter ueber projekt.json + containerFormat.
      var zips = Array.prototype.filter.call(files, function (f) {
        return /\.zip$/i.test(f.name) || /\.gfproj$/i.test(f.name);
      });
      if (zips.length > 0) {
        if (zips.length > 1) {
          showToast('Mehrere ZIP-Dateien — nur die erste wird geoeffnet.', 'warn');
        }
        ladeProjektDatei(zips[0]);
        return;
      }
      var pdfs = Array.prototype.filter.call(files, function (f) {
        return (f.type === 'application/pdf') || /\.pdf$/i.test(f.name);
      });
      if (pdfs.length === 0) {
        showToast('Nur PDF- oder .zip-Dateien werden unterstuetzt.', 'warn');
        return;
      }
      if (pdfs.length < files.length) {
        showToast('Nicht unterstuetzte Dateien wurden ignoriert.', 'warn');
      }
      ladePdfDateien(pdfs);
    });
  }

  // ============================================================
  // Werkzeug-Auswahl (Pan / Region / Massstab / Polygon)
  // ============================================================

  function setzeWerkzeug(name) {
    var aktiv = GF.state.aktivesWerkzeug;
    if (aktiv === name) return;
    // Werkzeug-Wechsel raeumt laufende Aktionen auf
    if (regionDragAktiv) {
      regionDragAktiv = false;
      regionStartPdf = null;
      regionAktuellPdf = null;
    }
    resetMass();
    resetPolygon();
    resetRechteck();
    winkelSnapAktiv = false;
    // Kanten-Edit-Panel schliessen, falls offen
    if ($('kantenEdit') && !$('kantenEdit').hidden) abbrecheKantenEdit();
    // Laufenden Eckpunkt-Drag abbrechen (Punkt auf Originalpos zurueck)
    if (aktiverPunktDrag) abbrecheEckpunktDrag();

    // Vorpruefung beim Aktivieren bestimmter Werkzeuge
    if (name === 'massstab') {
      if (!starteMassstab()) return;     // bricht ab wenn keine Region aktiv
    }
    if (name === 'polygon') {
      if (!startePolygonWerkzeug()) return;
    }
    if (name === 'rechteck')  { if (!starteRechteckWerkzeug())  return; }

    GF.state.update(function (s) { s.aktivesWerkzeug = name; });
    aktualisiereWerkzeugUI();
    aktualisiereCursor();
    redraw();

    // Fokus vom Werkzeug-Button wegnehmen, damit Tastatur-Events (ESC/Enter)
    // sauber am window-Listener ankommen und nicht der Button selbst reagiert.
    var ae = /** @type {HTMLElement | null} */ (document.activeElement);
    if (ae && typeof ae.blur === 'function') {
      ae.blur();
    }
  }

  function aktualisiereWerkzeugUI() {
    var liste = $('werkzeugListe');
    if (!liste) return;
    var aktiv = GF.state.aktivesWerkzeug;
    liste.querySelectorAll('.wkz').forEach(function (b) {
      if (b.dataset.werkzeug === aktiv) b.classList.add('aktiv');
      else b.classList.remove('aktiv');
    });
  }

  function aktualisiereCursor() {
    var canvas = $('planCanvas');
    if (!canvas) return;
    canvas.classList.remove('region-mode', 'massstab-mode', 'polygon-mode', 'panning', 'space-pan');
    canvas.style.cursor = '';                 // inline-Cursor vom Kanten-Hover wegraeumen
    if (spaceGehalten) {
      canvas.classList.add('space-pan');
      return;
    }
    if (GF.state.aktivesWerkzeug === 'region')   canvas.classList.add('region-mode');
    if (GF.state.aktivesWerkzeug === 'massstab') canvas.classList.add('massstab-mode');
    // Polygon und Rechteck teilen sich die Fadenkreuz-Cursor-Klasse.
    if (GF.state.aktivesWerkzeug === 'polygon'
     || GF.state.aktivesWerkzeug === 'rechteck') canvas.classList.add('polygon-mode');
  }

  // ---- Space-Hold = temporaerer Pan-Modus (CAD-Konvention) ----
  var spaceGehalten = false;
  var altGehalten = false;   // v1.2: Alt haelt den Vektor-Magnet temporaer aus

  function istEingabeAktiv() {
    var t = /** @type {HTMLElement | null} */ (document.activeElement);
    return !!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable));
  }

  function wireSpacePan() {
    global.addEventListener('keydown', function (e) {
      if ((e.key === ' ' || e.code === 'Space') && !spaceGehalten && !istEingabeAktiv()) {
        spaceGehalten = true;
        e.preventDefault();
        aktualisiereCursor();
      }
    });
    global.addEventListener('keyup', function (e) {
      if (e.key === ' ' || e.code === 'Space') {
        if (spaceGehalten) {
          spaceGehalten = false;
          aktualisiereCursor();
        }
      }
    });
    // Falls Fokus den Browser verlaesst, Space als "losgelassen" werten
    global.addEventListener('blur', function () {
      if (spaceGehalten) { spaceGehalten = false; aktualisiereCursor(); }
    });

    // v1.2: Alt gedrueckt halten -> Vektor-Magnet temporaer aus (kein preventDefault,
    // damit Browser-Shortcuts unberuehrt bleiben; e.altKey wird zusaetzlich direkt gelesen).
    global.addEventListener('keydown', function (e) {
      if (e.key === 'Alt') altGehalten = true;
    });
    global.addEventListener('keyup', function (e) {
      if (e.key === 'Alt') altGehalten = false;
    });
    global.addEventListener('blur', function () { altGehalten = false; });
  }

  function wireWerkzeug() {
    var liste = $('werkzeugListe');
    if (liste) {
      liste.addEventListener('click', function (e) {
        var btn = e.target.closest && e.target.closest('.wkz');
        if (!btn || btn.disabled) return;
        setzeWerkzeug(btn.dataset.werkzeug);
      });
    }
  }

  // ============================================================
  // Geschoss-Verwaltung
  // ============================================================

  function frageGeschossName(vorbelegung) {
    var eingabe = global.prompt(
      'Bezeichnung des Geschosses:\n(z. B. "Kellergeschoss", "EG", "1. OG", "Dachgeschoss")',
      vorbelegung || ''
    );
    if (eingabe === null) return null;
    var t = eingabe.trim();
    return t || null;
  }

  function legeGeschossAn() {
    var name = frageGeschossName('');
    if (!name) return;
    var projekt = GF.projekt.sorgeFuerProjekt();
    var maxReihenfolge = projekt.geschosse.reduce(function (m, g) {
      return Math.max(m, g.reihenfolge);
    }, 0);
    var neu = GF.geschoss.erzeuge(name, maxReihenfolge + 1);
    projekt.geschosse.push(neu);
    GF.projekt.historieEintrag(projekt, 'Geschoss angelegt', name);
    GF.state.update(function (s) {
      s.aktivesGeschossId = neu.id;
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    showToast('Geschoss angelegt: ' + name, 'success');
  }

  function benenneGeschossUm(id) {
    var g = GF.state.findGeschoss(id);
    if (!g) return;
    var neu = frageGeschossName(g.bezeichnung);
    if (!neu) return;
    GF.state.update(function () {
      GF.geschoss.umbenenne(g, neu);
      GF.state.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();   // Labels in Region-Overlays aktualisieren
  }

  function loescheGeschoss(id) {
    var g = GF.state.findGeschoss(id);
    if (!g) return;
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var regionen = projekt.planRegionen.filter(function (r) { return r.geschossId === id; });
    var polygone = projekt.polygone   .filter(function (p) { return p.geschossId === id; });
    var hinweis = 'Geschoss "' + g.bezeichnung + '" wirklich löschen?';
    if (regionen.length || polygone.length) {
      hinweis += '\n\nAuch ' + regionen.length + ' Region(en) und ' + polygone.length + ' Polygon(e) werden geloescht.';
    }
    if (!global.confirm(hinweis)) return;
    // Cascading delete
    projekt.planRegionen = projekt.planRegionen.filter(function (r) { return r.geschossId !== id; });
    projekt.polygone    = projekt.polygone   .filter(function (p) { return p.geschossId !== id; });
    projekt.geschosse   = projekt.geschosse  .filter(function (g0) { return g0.id !== id; });
    GF.projekt.historieEintrag(projekt, 'Geschoss geloescht', g.bezeichnung);
    GF.state.update(function (s) {
      if (s.aktivesGeschossId === id) s.aktivesGeschossId = null;
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();
  }

  function aktivierteGeschoss(id) {
    GF.state.update(function (s) { s.aktivesGeschossId = id; });
    aktualisiereGeschossListe();
    // Wenn das Geschoss Regionen hat: zur ersten Region springen (PDF + Seite
    // umschalten falls noetig). Sonst nur State setzen.
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var regionen = projekt.planRegionen.filter(function (r) { return r.geschossId === id; });
    if (regionen.length === 0) return;
    var ersteRegion = regionen[0];
    // Springen nur wenn wir nicht eh schon dort sind
    if (ersteRegion.pdfId !== GF.state.aktivePdfId || ersteRegion.seite !== GF.state.aktuelleSeite ||
        ersteRegion.id !== GF.state.aktiveRegionId) {
      springZuRegion(ersteRegion.id);
    }
  }

  function aktualisiereGeschossListe() {
    var ul = $('geschossListe');
    if (!ul) return;
    var projekt = GF.state.projekt;
    var geschosse = projekt ? GF.geschoss.sortiereNachReihenfolge(projekt.geschosse) : [];
    var esc = GF.util.esc;

    if (geschosse.length === 0) {
      ul.innerHTML = '<li class="sb-empty">— noch keine Geschosse —</li>';
      return;
    }

    var html = '';
    geschosse.forEach(function (g) {
      var aktiv = (g.id === GF.state.aktivesGeschossId);
      var regionen = projekt.planRegionen.filter(function (r) { return r.geschossId === g.id; });
      var polygone = projekt.polygone   .filter(function (p) { return p.geschossId === g.id; });
      html += '<li class="gs ' + (aktiv ? 'aktiv' : '') + '" data-geschoss-id="' + esc(g.id) + '">'
            +   '<div class="gs-header">'
            +     '<span class="gs-name" title="' + esc(g.bezeichnung) + '">' + esc(g.bezeichnung) + '</span>'
            +     '<span class="gs-count">'
            +       (regionen.length ? regionen.length + 'R ' : '')
            +       (polygone.length ? polygone.length + 'P' : '')
            +     '</span>'
            +     '<button type="button" class="gs-btn" data-aktion="umbenennen" title="Geschoss umbenennen">✎</button>'
            +     '<button type="button" class="gs-btn" data-aktion="loeschen"   title="Geschoss komplett loeschen">🗑</button>'
            +   '</div>';

      // VG-Bereich (vor Region-Subliste)
      var maxReihenfolge = -Infinity;
      for (var ri = 0; ri < geschosse.length; ri++) {
        if (geschosse[ri].reihenfolge > maxReihenfolge) maxReihenfolge = geschosse[ri].reihenfolge;
      }
      var istOberstes = (g.reihenfolge === maxReihenfolge);
      var vg = g.vollgeschoss;
      var vgKlasse = 'gs-vg' + (istOberstes ? '' : ' gs-vg-inaktiv');
      if (vg && vg.durchgefuehrt) {
        var anteilPct = (vg.ergebnis && vg.ergebnis.anteil_2_30 != null)
          ? GF.util.formatZahlDE(vg.ergebnis.anteil_2_30 * 100, 1) + ' %'
          : '–';
        var istVg = vg.ergebnis && vg.ergebnis.vollgeschoss;
        var vgKls  = istVg ? 'ok' : 'nein';
        var vgText = (istVg ? 'Vollgeschoss' : 'Kein Vollgeschoss') + ' (' + anteilPct + ')';
        html += '<div class="' + vgKlasse + '">'
              +   '<div class="gs-vg-zeile">'
              +     '<span class="gs-vg-label">VG</span>'
              +     '<span class="gs-vg-status ' + vgKls + '">' + esc(vgText) + '</span>'
              +     '<button type="button" class="gs-vg-bearbeiten" data-aktion="vg-aufrufen" title="VG-Beurteilung bearbeiten">Bearbeiten</button>'
              +   '</div>'
              + '</div>';
      } else {
        var titleAttr = istOberstes
          ? 'Vollgeschoss-Beurteilung starten'
          : 'Vollgeschoss-Prüfung üblicherweise nur für DG / oberstes Geschoss';
        html += '<div class="' + vgKlasse + '" title="' + esc(titleAttr) + '">'
              +   '<div class="gs-vg-zeile">'
              +     '<span class="gs-vg-label">VG</span>'
              +     '<span class="gs-vg-status gs-vg-leer"></span>'
              +     '<button type="button" class="gs-vg-aufrufen" data-aktion="vg-aufrufen">Aufrufen</button>'
              +   '</div>'
              + '</div>';
      }

      if (regionen.length > 0) {
        html += '<ul class="region-subliste">';
        regionen.forEach(function (r, idx) {
          var pdf = GF.state.findPdf(r.pdfId);
          var pdfName = pdf ? pdf.dateiName : '?';
          var aktivR = (r.id === GF.state.aktiveRegionId);
          var kal = r.kalibrierung;
          var kalLabel = '';
          var kalKlasse = 'rg-kal-fehlt';
          if (kal) {
            // Label: bei uebernommen zeigt das ⇆-Praefix den uebertragenen
            // Charakter; die Farbcodierung kommt einheitlich aus der Abweichung,
            // damit Quell- und uebernommene Region bei identischem ptProMeter
            // garantiert denselben Status zeigen.
            var massText = kal.normMassstab || (GF.util.formatZahlDE(kal.ptProMeter, 2) + ' pt/m');
            if (kal.quelle === 'massstab_direkt') {
              // Direkt eingegeben = vom Nutzer behauptet, NICHT gemessen. Neutrale
              // Farbe + "(direkt)"-Zusatz statt gruen, das eine geprüfte Kalibrierung
              // suggerieren wuerde. abweichungVonNormProzent ist hier konstruktiv 0
              // und damit kein Qualitaetssignal.
              kalLabel = massText + ' (direkt)';
              kalKlasse = 'rg-kal-direkt';
            } else if (kal.quelle === 'übernommen' && kal.direktUrsprung) {
              // Von einer ungeprüften Direkteingabe uebernommen -> ebenfalls neutral.
              kalLabel = '⇆ ' + massText + ' (direkt)';
              kalKlasse = 'rg-kal-direkt';
            } else {
              kalLabel = (kal.quelle === 'übernommen') ? ('⇆ ' + massText) : massText;
              kalKlasse = 'rg-kal-ok';
              if (kal.abweichungVonNormProzent > 3) kalKlasse = 'rg-kal-warn';
              else if (kal.abweichungVonNormProzent > 0.5) kalKlasse = 'rg-kal-hinweis';
            }
          } else {
            kalLabel = 'Maßstab ✗';
          }
          var polysProRegion = projekt.polygone.filter(function (pp) { return pp.regionId === r.id; });
          html += '<li class="region-item ' + (aktivR ? 'aktiv' : '') + '" data-region-id="' + esc(r.id) + '" title="Zur Region springen">'
                +   '<span class="rg-marker">▭</span>'
                +   '<span class="rg-name">' + (idx + 1) + ') ' + esc(pdfName) + ' · S.' + r.seite + '</span>'
                +   '<span class="rg-kal ' + kalKlasse + '">' + esc(kalLabel) + '</span>'
                +   '<button type="button" class="gs-btn" data-aktion="region-loeschen" title="Nur diese Region loeschen">🗑</button>'
                + '</li>';
          if (polysProRegion.length > 0) {
            html += '<ul class="polygon-subliste">';
            polysProRegion.forEach(function (pp) {
              var aktivP = (pp.id === GF.state.aktivesPolygonId);
              var farbe = pp.farbeOverlay || '#7f8c8d';
              var deckkraft = (typeof pp.deckkraft === 'number') ? pp.deckkraft : 0.5;
              var dProzent = Math.round(deckkraft * 100);
              var manuell = pp.manuelleKorrektur === true;
              var fAngesetzt = GF.util.formatZahlDE(pp.flaecheAngesetztQM, 2);
              var fGemessen  = GF.util.formatZahlDE(pp.flaecheGemessenQM, 2);
              var flaecheTitel = manuell
                ? 'Manuell angesetzt: ' + fAngesetzt + ' m² (gemessen ' + fGemessen + ' m²). Klick auf ✎ zum Anpassen.'
                : 'Gemessene Fläche: ' + fAngesetzt + ' m². Klick auf ✎ um manuell zu überschreiben.';
              html += '<li class="polygon-item ' + (aktivP ? 'aktiv' : '') + '" data-polygon-id="' + esc(pp.id) + '" title="Polygon aktivieren">'
                    +   '<span class="pg-swatch" style="background:' + farbe + '" title="Klick: Farbe aendern"></span>'
                    +   '<span class="pg-name">' + esc(pp.bezeichnung) + '</span>'
                    +   '<span class="pg-flaeche' + (manuell ? ' korrigiert' : '') + '" title="' + esc(flaecheTitel) + '">' + fAngesetzt + ' m²</span>'
                    +   (manuell ? '<span class="pg-gemessen" title="aus Polygon-Geometrie">(gem. ' + fGemessen + ')</span>' : '')
                    +   '<button type="button" class="pg-edit-flaeche" data-aktion="flaeche-edit" title="' + (manuell ? 'Flaechenkorrektur bearbeiten' : 'Flaeche manuell ueberschreiben') + '">✎</button>'
                    +   '<button type="button" class="pg-deckkraft" data-aktion="deckkraft" title="Transparenz: ' + dProzent + ' %. Klick wechselt 0/25/50/75/100.">' + dProzent + '%</button>'
                    +   '<button type="button" class="gs-btn" data-aktion="polygon-loeschen" title="Polygon loeschen">🗑</button>'
                    + '</li>';
            });
            html += '</ul>';
          }
        });
        html += '</ul>';
      }
      html += '</li>';
    });
    ul.innerHTML = html;
  }

  function loescheRegion(rid) {
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var r = null;
    for (var i = 0; i < projekt.planRegionen.length; i++) {
      if (projekt.planRegionen[i].id === rid) { r = projekt.planRegionen[i]; break; }
    }
    if (!r) return;

    var polygone = projekt.polygone.filter(function (p) { return p.regionId === rid; });
    var hinweis = 'Diese Plan-Region wirklich löschen?';
    if (polygone.length) hinweis += '\n\nAuch ' + polygone.length + ' Polygon(e) in dieser Region werden geloescht.';
    if (!global.confirm(hinweis)) return;

    projekt.planRegionen = projekt.planRegionen.filter(function (x) { return x.id !== rid; });
    projekt.polygone    = projekt.polygone   .filter(function (p) { return p.regionId !== rid; });

    GF.projekt.historieEintrag(projekt, 'Region geloescht',
      'Geschoss: ' + (GF.state.findGeschoss(r.geschossId) || {}).bezeichnung);

    GF.state.update(function (s) {
      if (s.aktiveRegionId === rid) s.aktiveRegionId = null;
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();
    showToast('Region geloescht.', 'success');
  }

  function springZuRegion(rid) {
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var r = null;
    for (var i = 0; i < projekt.planRegionen.length; i++) {
      if (projekt.planRegionen[i].id === rid) { r = projekt.planRegionen[i]; break; }
    }
    if (!r) return;

    function aktiviere() {
      GF.state.update(function (s) {
        s.aktiveRegionId = rid;
        s.aktivesGeschossId = r.geschossId;
      });
      aktualisiereGeschossListe();
      redraw();
      // v1.2 Politur: unkalibrierte Region aktiviert -> ggf. Maßstab-Banner (Belege-Cache).
      vielleichtMassstabVorschlag();
    }

    var pdfWechsel = (r.pdfId !== GF.state.aktivePdfId);
    var seiteWechsel = (r.seite !== GF.state.aktuelleSeite);

    if (pdfWechsel) {
      wechsleZuPdf(r.pdfId).then(function () {
        return seiteWechsel ? zeigeSeite(r.seite) : Promise.resolve();
      }).then(aktiviere);
    } else if (seiteWechsel) {
      zeigeSeite(r.seite).then(aktiviere);
    } else {
      aktiviere();
    }
  }

  function wireGeschosse() {
    $('btnGeschossNeu').addEventListener('click', legeGeschossAn);

    var ul = $('geschossListe');
    ul.addEventListener('click', function (e) {
      // Polygon-Eintrag-Aktion zuerst (am tiefsten)
      var polyItem = e.target.closest && e.target.closest('.polygon-item');
      if (polyItem) {
        var pid = polyItem.dataset.polygonId;
        var polyBtn = e.target.closest && e.target.closest('.gs-btn');
        if (polyBtn) {
          e.stopPropagation();
          if (polyBtn.dataset.aktion === 'polygon-loeschen') loeschePolygon(pid);
          return;
        }
        // Deckkraft-Button: Transparenz zyklisch wechseln
        if (e.target.classList && e.target.classList.contains('pg-deckkraft')) {
          e.stopPropagation();
          aenderePolygonDeckkraft(pid);
          return;
        }
        // Farb-Swatch: Farbe aendern
        if (e.target.classList && e.target.classList.contains('pg-swatch')) {
          e.stopPropagation();
          aenderePolygonFarbe(pid);
          return;
        }
        // ✎-Button: Flaechen-Korrektur-Modal oeffnen
        if (e.target.classList && e.target.classList.contains('pg-edit-flaeche')) {
          e.stopPropagation();
          oeffneFlaechenKorrektur(pid);
          return;
        }
        e.stopPropagation();
        aktivierePolygon(pid);
        return;
      }
      // Region-Eintrag-Aktion zuerst pruefen (er liegt INNER li.gs)
      var regionItem = e.target.closest && e.target.closest('.region-item');
      if (regionItem) {
        var rid = regionItem.dataset.regionId;
        var regBtn = e.target.closest && e.target.closest('.gs-btn');
        if (regBtn) {
          e.stopPropagation();
          if (regBtn.dataset.aktion === 'region-loeschen') loescheRegion(rid);
          return;
        }
        e.stopPropagation();
        springZuRegion(rid);
        return;
      }

      // Geschoss-Aktion
      var li = e.target.closest && e.target.closest('li.gs');
      if (!li) return;
      var id = li.dataset.geschossId;

      // VG-Aufrufen / Bearbeiten
      var vgBtn = e.target.closest && e.target.closest('[data-aktion="vg-aufrufen"]');
      if (vgBtn) {
        e.stopPropagation();
        if (GF.VgModal && GF.VgModal.oeffne) GF.VgModal.oeffne(id, GF.state.projekt);
        return;
      }

      var aktBtn = e.target.closest && e.target.closest('.gs-btn');
      if (aktBtn) {
        e.stopPropagation();
        var aktion = aktBtn.dataset.aktion;
        if (aktion === 'umbenennen') benenneGeschossUm(id);
        else if (aktion === 'loeschen') loescheGeschoss(id);
        return;
      }
      aktivierteGeschoss(id);
    });
  }

  // ============================================================
  // Polygon-Werkzeug (Aussenkontur klicken)
  // ============================================================

  var polygonPunkte = [];        // gesammelte Punkte (PDF-Koord)
  var polygonMaus   = null;      // aktuelle Maus (PDF-Koord) fuer Live-Linie

  // v1.2 Rechteck-Werkzeug: zwei Gegenecken in PDF-pt. rechteckEcke1 = gesetzte
  // erste Ecke, rechteckEcke2Live = aktuelle Maus fuer die Live-Vorschau.
  var rechteckEcke1 = null;       // {x,y} in PDF-pt oder null
  var rechteckEcke2Live = null;   // {x,y} Live-Vorschau oder null
  function resetRechteck() { rechteckEcke1 = null; rechteckEcke2Live = null; }

  // v1.2: Gemeinsame Vorbedingungen fuer die Zeichen-Werkzeuge (Polygon, Rechteck):
  // Projekt vorhanden -> aktive Region -> Region gefunden ->
  // Maßstab kalibriert -> Region auf der aktuell sichtbaren PDF/Seite. Bei Verstoß
  // den passenden Hinweis-Toast zeigen und false liefern; sonst true.
  function pruefeZeichenVorbedingungen() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Bitte erst eine Plan-Region anlegen.', 'warn');
      return false;
    }
    if (!s.aktiveRegionId) {
      showToast('Bitte erst eine Region in der Sidebar aktivieren.', 'warn');
      return false;
    }
    var r = null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
    }
    if (!r) return false;
    if (!r.kalibrierung || !r.kalibrierung.ptProMeter) {
      showToast('Region hat noch keinen Maßstab — bitte erst kalibrieren.', 'warn');
      return false;
    }
    if (r.pdfId !== s.aktivePdfId || r.seite !== s.aktuelleSeite) {
      showToast('Aktive Region liegt auf anderer PDF/Seite — bitte erst dorthin springen.', 'warn');
      return false;
    }
    return true;
  }

  function startePolygonWerkzeug() {
    if (!pruefeZeichenVorbedingungen()) return false;
    resetPolygon();
    showToast('Außenkontur klicken. Doppelklick / Enter / Klick auf Startpunkt = schließen. ' +
              'CAD-Ecken fangen magnetisch (teal), rechte Winkel rasten auf 90° ein (grün) — Shift halten zeichnet frei (kein Snap). ' +
              'Pannen: Mausrad-Klick + Ziehen.', null, 11000);
    return true;
  }

  // v1.2: Start-Funktionen der drei neuen Zeichen-Werkzeuge. Jede prueft zuerst die
  // gemeinsamen Vorbedingungen, setzt ihren Vorschau-State zurueck und zeigt einen
  // kurzen Aktivierungs-Hinweis. Rueckgabe false haelt setzeWerkzeug an (kein Wechsel).
  function starteRechteckWerkzeug() {
    if (!pruefeZeichenVorbedingungen()) return false;
    resetRechteck();
    showToast('Rechteck: erste Ecke klicken, dann die Gegenecke.', 'info', 4000);
    return true;
  }

  // Winkel-Snap-Status fuer Live-Vorschau (gruene Linie wenn 90°/0° greift)
  var winkelSnapAktiv = false;
  var WINKEL_SNAP_TOLERANZ = 0.5;     // Grad (v1.2-Test: von 2 auf 0,5 reduziert)
  var WINKEL_SNAP_MIN_LAENGE = 5;     // Pixel auf Canvas — sehr kurze Striche nicht snappen

  // v1.2: Vektor-Magnet-Status fuer die Live-Vorschau (Magenta wenn auf CAD-Ecke).
  var vektorSnapAktiv = false;

  // Rastet einen Punkt magnetisch auf die naechste CAD-Vektor-Ecke ein, wenn der
  // Magnet verfuegbar ist und weder Alt noch Shift gehalten wird. Reiner Assist — der
  // Mensch setzt jeden Punkt selbst (keine Konturerkennung). Setzt vektorSnapAktiv.
  function vielleichtVektorSnap(pdfPt, shiftKey) {
    vektorSnapAktiv = false;
    if (altGehalten || shiftKey) return pdfPt;
    if (!GF.snap || !GF.snap.verfuegbar || !GF.snap.verfuegbar()) return pdfPt;
    var snapped = GF.snap.naechster(pdfPt, GF.state.snapIndex, GF.snap.RADIUS_PX, GF.state.viewport.zoom);
    if (snapped && snapped.snapped) { vektorSnapAktiv = true; return snapped; }
    return pdfPt;
  }

  // Wendet zuerst den Vektor-Magnet, dann (falls nicht eingerastet) den 90°-Snap an.
  // shiftKey unterdrueckt BEIDE Snaps (frei zeichnen); Alt unterdrueckt nur den Vektor-Magnet.
  function vielleichtWinkelSnap(pdfPt, shiftKey) {
    // Vektor-Magnet zuerst — ein harter CAD-Ankerpunkt gewinnt (auch beim 1. Punkt).
    var v = vielleichtVektorSnap(pdfPt, shiftKey);
    if (v && v.snapped) return v;
    if (shiftKey) return pdfPt;
    if (polygonPunkte.length === 0) return pdfPt;
    var letzter = polygonPunkte[polygonPunkte.length - 1];
    var dx = pdfPt.x - letzter.x;
    var dy = pdfPt.y - letzter.y;
    var laengePt = Math.sqrt(dx * dx + dy * dy);
    var laengeCanvas = laengePt * GF.state.viewport.zoom;
    if (laengeCanvas < WINKEL_SNAP_MIN_LAENGE) return pdfPt;
    var s = GF.polygon.snap.aufRechtwinkel(letzter, pdfPt, WINKEL_SNAP_TOLERANZ);
    return s;   // hat .snapped Property wenn gesnappt
  }

  // Prueft, ob ein PDF-Punkt innerhalb des Ausschnitt-Rechtecks einer Region liegt.
  // Gibt true zurueck, wenn keine Region uebergeben wird oder die Region keinen
  // Ausschnitt definiert (defensiv — kein false-Reject).
  function pdfPunktInRegion(pdfPt, region) {
    if (!region || !region.ausschnitt) return true;
    var a = region.ausschnitt;
    return pdfPt.x >= a.x && pdfPt.x <= a.x + a.breite
        && pdfPt.y >= a.y && pdfPt.y <= a.y + a.hoehe;
  }

  function findeAktiveRegion() {
    var s = GF.state;
    if (!s.projekt || !s.aktiveRegionId) return null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) return s.projekt.planRegionen[i];
    }
    return null;
  }

  // Findet eine andere Region als die aktive, in deren Ausschnitt der Punkt liegt.
  // Genutzt fuer praezisere Hinweis-Texte ("Region X aktivieren?").
  function findeRegionFuerPdfPunkt(pdfPt) {
    var s = GF.state;
    if (!s.projekt) return null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      var r = s.projekt.planRegionen[i];
      if (r.pdfId !== s.aktivePdfId || r.seite !== s.aktuelleSeite) continue;
      if (pdfPunktInRegion(pdfPt, r)) return r;
    }
    return null;
  }

  function polygonKlick(canvasX, canvasY, shiftKey) {
    // Nahe dem Startpunkt? -> Polygon schliessen
    if (polygonPunkte.length >= 3) {
      var startCanvas = pdfZuCanvas(polygonPunkte[0].x, polygonPunkte[0].y);
      var dx = canvasX - startCanvas.x;
      var dy = canvasY - startCanvas.y;
      if (Math.sqrt(dx * dx + dy * dy) < 10) {
        schliessePolygon();
        return;
      }
    }
    // Doppelklick-Effekt: zweiter Click sehr nah am letzten Punkt -> ignorieren
    if (polygonPunkte.length > 0) {
      var letzter = polygonPunkte[polygonPunkte.length - 1];
      var lc = pdfZuCanvas(letzter.x, letzter.y);
      var dxL = canvasX - lc.x;
      var dyL = canvasY - lc.y;
      if (Math.sqrt(dxL * dxL + dyL * dyL) < 3) return;
    }
    var pdfPt = canvasZuPdf(canvasX, canvasY);
    pdfPt = vielleichtWinkelSnap(pdfPt, shiftKey);

    // Region-Grenze hart durchsetzen: Polygon-Punkte muessen innerhalb der
    // aktiven Region liegen, damit Polygone keiner falschen Region zugeordnet
    // werden (Daten-Integritaet beim Aufmassprotokoll). Hinweistext ist
    // praeziser, wenn der Klick zufaellig in einer anderen Region landet.
    var aktiveRegion = findeAktiveRegion();
    if (aktiveRegion && !pdfPunktInRegion(pdfPt, aktiveRegion)) {
      var andere = findeRegionFuerPdfPunkt(pdfPt);
      var hinweis;
      if (andere) {
        hinweis = 'Punkt liegt in Region "' + (andere.bezeichnung || '?')
          + '", aktiv ist aber "' + (aktiveRegion.bezeichnung || '?')
          + '". Erst die richtige Region in der Sidebar aktivieren.';
      } else {
        hinweis = 'Punkt liegt ausserhalb der aktiven Region "'
          + (aktiveRegion.bezeichnung || '?')
          + '". Bitte innerhalb des Region-Rechtecks klicken.';
      }
      showToast(hinweis, 'warn', 5000);
      return;
    }

    polygonPunkte.push({ x: pdfPt.x, y: pdfPt.y });
    polygonMaus = { x: pdfPt.x, y: pdfPt.y };
    winkelSnapAktiv = false;     // nach Klick zuruecksetzen, naechster mousemove setzt neu
    redraw();
  }

  function polygonMausBewegung(canvasX, canvasY, shiftKey) {
    var pdfPt = canvasZuPdf(canvasX, canvasY);
    pdfPt = vielleichtWinkelSnap(pdfPt, shiftKey);
    polygonMaus = { x: pdfPt.x, y: pdfPt.y };
    winkelSnapAktiv = !!pdfPt.snapped && !vektorSnapAktiv;
    redraw();
  }

  function abbrechePolygon() {
    if (polygonPunkte.length > 0) showToast('Polygon abgebrochen.');
    resetPolygon();
    redraw();
  }

  // ============================================================
  // v1.2 Rechteck-Werkzeug (zwei Gegenecken -> achsparalleles Polygon)
  // ============================================================

  function rechteckKlick(cx, cy) {
    var pdfPt = canvasZuPdf(cx, cy);
    if (GF.snap.verfuegbar()) pdfPt = vielleichtVektorSnap(pdfPt);
    var region = findeAktiveRegion();
    if (!region || !pdfPunktInRegion(pdfPt, region)) {
      showToast('Punkt liegt außerhalb der aktiven Region.', 'warn', 3000);
      return;
    }
    if (!rechteckEcke1) {
      rechteckEcke1 = { x: pdfPt.x, y: pdfPt.y };
      redraw();
      return;
    }
    // Zweite Ecke: entartetes Rechteck (< 10 pt Seite) verwerfen
    if (Math.abs(pdfPt.x - rechteckEcke1.x) < 10 || Math.abs(pdfPt.y - rechteckEcke1.y) < 10) {
      showToast('Rechteck zu klein.', 'warn', 2500);
      return;
    }
    polygonPunkte = GF.rechteck.ausEcken(rechteckEcke1, pdfPt);
    resetRechteck();
    schliessePolygon();   // bestehender Pfad: Bezeichnung-Prompt, Flaeche, push, Werkzeug->pan
  }

  function rechteckMausBewegung(cx, cy) {
    if (!rechteckEcke1) return;
    rechteckEcke2Live = canvasZuPdf(cx, cy);
    redraw();
  }

  // Live-Vorschau des aufgezogenen Rechtecks (Halo + gestrichelte Navy-Kontur).
  function zeichneRechteckLive(ctx) {
    if (!rechteckEcke1 || !rechteckEcke2Live) return;
    var ecken = GF.rechteck.ausEcken(rechteckEcke1, rechteckEcke2Live);
    ctx.save();
    ctx.beginPath();
    for (var i = 0; i < ecken.length; i++) {
      var c = pdfZuCanvas(ecken[i].x, ecken[i].y);
      if (i === 0) ctx.moveTo(c.x, c.y); else ctx.lineTo(c.x, c.y);
    }
    ctx.closePath();
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.stroke();
    ctx.lineWidth = 1.5; ctx.strokeStyle = '#0F2D5A'; ctx.setLineDash([6, 4]); ctx.stroke();
    ctx.restore();
  }

  function schliessePolygon() {
    if (polygonPunkte.length < 3) {
      showToast('Polygon braucht mindestens 3 Punkte.', 'warn');
      return;
    }
    if (GF.polygon.hatSelbstueberschneidung(polygonPunkte)) {
      if (!global.confirm(
        'Das Polygon hat eine Selbstüberschneidung — die Flächenberechnung ist dann nicht korrekt.\n\n' +
        'Trotzdem speichern? (Empfohlen: Abbrechen und Polygon neu zeichnen.)'
      )) return;
    }
    var bez = global.prompt(
      'Bezeichnung des Polygons:\n(z. B. "Hauptgebäude", "Garage", "Nebengebäude", "Anbau")',
      'Hauptgebäude'
    );
    if (bez === null) return;
    bez = bez.trim() || 'Hauptgebäude';
    speicherePolygon(bez);
  }

  function speicherePolygon(bezeichnung) {
    var s = GF.state;
    var r = null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
    }
    if (!r) return;

    var flaeche;
    try {
      flaeche = GF.polygon.berechneFlaeche(polygonPunkte, r.kalibrierung.ptProMeter);
    } catch (e) {
      showToast('Flächenberechnung fehlgeschlagen: ' + e.message, 'danger');
      return;
    }

    var polygon = {
      id: GF.util.uuid(),
      geschossId: r.geschossId,
      regionId: r.id,
      bezeichnung: bezeichnung,
      punkte: polygonPunkte.map(function (p) { return { x: p.x, y: p.y }; }),
      flaecheGemessenQM: flaeche,
      flaecheAngesetztQM: flaeche,
      manuelleKorrektur: false,
      korrekturKommentar: '',
      farbeOverlay: farbeFuerPolygon(bezeichnung),
      deckkraft: 0.5   // 0 / 0.25 / 0.5 / 0.75 / 1.0 — per Sidebar wechselbar
    };

    s.projekt.polygone.push(polygon);
    GF.projekt.historieEintrag(s.projekt, 'Polygon angelegt',
      bezeichnung + ' / ' + GF.util.formatZahlDE(flaeche, 2) + ' m^2');

    GF.state.update(function (s2) {
      s2.aktivesPolygonId = polygon.id;
      s2.ungespeicherteAenderungen = true;
    });
    resetPolygon();
    setzeWerkzeug('pan');
    aktualisiereGeschossListe();
    redraw();
    showToast('Polygon angelegt: ' + bezeichnung + ' = ' +
              GF.util.formatZahlDE(flaeche, 2) + ' m^2', 'success', 6000);
  }

  function resetPolygon() {
    polygonPunkte = [];
    polygonMaus = null;
    winkelSnapAktiv = false;
    vektorSnapAktiv = false;
  }

  function farbeFuerPolygon(bezeichnung) {
    var b = (bezeichnung || '').toLowerCase();
    if (b.indexOf('garage') >= 0)       return '#3498DB';
    if (b.indexOf('nebengeb') >= 0)     return '#2ECC71';
    if (b.indexOf('anbau') >= 0)        return '#F39C12';
    if (b.indexOf('hauptgeb') >= 0 || !b) return '#E74C3C';
    return '#7f8c8d';
  }

  function loeschePolygon(pid) {
    var s = GF.state;
    if (!s.projekt) return;
    var p = null;
    for (var i = 0; i < s.projekt.polygone.length; i++) {
      if (s.projekt.polygone[i].id === pid) { p = s.projekt.polygone[i]; break; }
    }
    if (!p) return;
    if (!global.confirm('Polygon "' + p.bezeichnung + '" (' +
        GF.util.formatZahlDE(p.flaecheAngesetztQM, 2) + ' m^2) wirklich löschen?')) return;
    s.projekt.polygone = s.projekt.polygone.filter(function (x) { return x.id !== pid; });
    GF.projekt.historieEintrag(s.projekt, 'Polygon geloescht', p.bezeichnung);
    GF.state.update(function (st) {
      if (st.aktivesPolygonId === pid) st.aktivesPolygonId = null;
      st.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();
    showToast('Polygon geloescht.', 'success');
  }

  function aktivierePolygon(pid) {
    var poly = GF.state.findPolygon(pid);
    GF.state.update(function (s) { s.aktivesPolygonId = pid; });
    aktualisiereGeschossListe();
    redraw();
    // Wenn das Polygon auf einer anderen Seite / einem anderen PDF liegt,
    // automatisch dorthin springen.
    if (poly && poly.regionId) {
      var region = GF.state.findRegion(poly.regionId);
      if (region && (region.pdfId !== GF.state.aktivePdfId ||
                     region.seite !== GF.state.aktuelleSeite ||
                     region.id    !== GF.state.aktiveRegionId)) {
        springZuRegion(region.id);
      }
    }
  }

  function naechsteDeckkraft(d) {
    var stufen = [0, 0.25, 0.5, 0.75, 1.0];
    var ind = stufen.indexOf(Math.round((d || 0) * 4) / 4);
    if (ind < 0) ind = 2;
    return stufen[(ind + 1) % stufen.length];
  }

  function aenderePolygonDeckkraft(pid) {
    var s = GF.state;
    if (!s.projekt) return;
    var p = null;
    for (var i = 0; i < s.projekt.polygone.length; i++) {
      if (s.projekt.polygone[i].id === pid) { p = s.projekt.polygone[i]; break; }
    }
    if (!p) return;
    var alt = (typeof p.deckkraft === 'number') ? p.deckkraft : 0.5;
    p.deckkraft = naechsteDeckkraft(alt);
    GF.state.update(function (st) { st.ungespeicherteAenderungen = true; });
    aktualisiereGeschossListe();
    redraw();
  }

  function aenderePolygonFarbe(pid) {
    var s = GF.state;
    if (!s.projekt) return;
    var p = null;
    for (var i = 0; i < s.projekt.polygone.length; i++) {
      if (s.projekt.polygone[i].id === pid) { p = s.projekt.polygone[i]; break; }
    }
    if (!p) return;
    // Native Farbauswahl via temporaerem input[type=color]
    var inp = document.createElement('input');
    inp.type = 'color';
    inp.value = (p.farbeOverlay || '#7f8c8d').slice(0, 7);
    inp.style.position = 'fixed';
    inp.style.left = '-9999px';
    document.body.appendChild(inp);
    inp.addEventListener('change', function () {
      p.farbeOverlay = inp.value;
      GF.state.update(function (st) { st.ungespeicherteAenderungen = true; });
      aktualisiereGeschossListe();
      redraw();
      document.body.removeChild(inp);
    });
    inp.addEventListener('input', function () {
      // Live-Preview waehrend des Auswaehlens
      p.farbeOverlay = inp.value;
      redraw();
    });
    inp.click();
  }

  // ============================================================
  // Kanten-Edit (Klick auf ein Maß-Label im Plan-Modus)
  // ============================================================

  var kantenEditPolygonId = null;
  var kantenEditIndex     = -1;

  function oeffneKantenEdit(polygonId, kantenIndex) {
    var poly = GF.state.findPolygon(polygonId);
    if (!poly) return;
    var region = GF.state.findRegion(poly.regionId);
    if (!region || !region.kalibrierung || !region.kalibrierung.ptProMeter) {
      showToast('Region ist nicht kalibriert — bitte zuerst Maßstab setzen.', 'warn');
      return;
    }
    var n = poly.punkte.length;
    var p1 = poly.punkte[kantenIndex];
    var p2 = poly.punkte[(kantenIndex + 1) % n];
    var dx = p2.x - p1.x, dy = p2.y - p1.y;
    var laengeM = Math.sqrt(dx * dx + dy * dy) / region.kalibrierung.ptProMeter;

    kantenEditPolygonId = polygonId;
    kantenEditIndex     = kantenIndex;
    $('kantenEditNr').textContent     = (kantenIndex + 1) + ' / ' + n;
    $('kantenEditBisher').textContent = GF.util.formatZahlDE(laengeM, 2) + ' m';
    // Edit-Vorbelegung absichtlich mit 3 Stellen (voller Storage-Wert):
    // User darf eine bestehende 1,234 weiter verfeinern ohne Praezisions-Verlust.
    $('kantenEditInput').value        = GF.util.formatZahlDE(laengeM, 3);
    $('kantenEdit').hidden = false;
    setTimeout(function () {
      var inp = $('kantenEditInput');
      if (inp) { inp.focus(); inp.select(); }
    }, 30);
  }

  function abbrecheKantenEdit() {
    $('kantenEdit').hidden = true;
    kantenEditPolygonId = null;
    kantenEditIndex = -1;
  }

  function bestaetigeKantenEdit() {
    var v = GF.util.parseZahlDE($('kantenEditInput').value);
    if (!isFinite(v) || v <= 0) {
      showToast('Ungültiges Maß — bitte positive Zahl eingeben.', 'warn');
      return;
    }
    var poly = GF.state.findPolygon(kantenEditPolygonId);
    if (!poly) { abbrecheKantenEdit(); return; }
    var region = GF.state.findRegion(poly.regionId);
    if (!region || !region.kalibrierung) { abbrecheKantenEdit(); return; }

    try {
      GF.polygon.editKante(poly, kantenEditIndex, v, region.kalibrierung.ptProMeter);
    } catch (e) {
      showToast('Kanten-Edit fehlgeschlagen: ' + e.message, 'danger');
      return;
    }

    // Selbstueberschneidung nach dem Edit pruefen
    if (GF.polygon.hatSelbstueberschneidung(poly.punkte)) {
      if (!global.confirm(
        'Durch die Änderung überschneidet sich das Polygon nun selbst — die ' +
        'Flächenberechnung ist dann nicht korrekt.\n\nTrotzdem übernehmen?'
      )) {
        // Edit rueckgaengig machen ist hier nicht trivial, weil editKante in-place
        // mutiert. Pragmatisch: User soll Polygon neu zeichnen.
        showToast('Hinweis: Polygon hat jetzt eine Selbstüberschneidung.', 'warn');
      }
    }

    // Flaeche neu berechnen
    var neueFlaeche = GF.polygon.berechneFlaeche(poly.punkte, region.kalibrierung.ptProMeter);
    poly.flaecheGemessenQM = Math.round(neueFlaeche * 1000) / 1000;
    var hatteKorrektur = !!poly.manuelleKorrektur;
    poly.flaecheAngesetztQM = poly.flaecheGemessenQM;
    poly.manuelleKorrektur  = false;
    poly.korrekturKommentar = '';

    GF.projekt.historieEintrag(GF.state.projekt, 'Kantenmaß geändert',
      poly.bezeichnung + ' · Kante ' + (kantenEditIndex + 1) + ' → ' +
      GF.util.formatZahlDE(v, 2) + ' m · neue Fläche ' +
      GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²');

    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    abbrecheKantenEdit();
    redraw();
    if (hatteKorrektur) {
      showToast('Kante geändert. Frühere manuelle Flächenkorrektur wurde verworfen.', 'success', 7000);
    } else {
      showToast('Kante ' + (kantenEditIndex + 1) + ' = ' + GF.util.formatZahlDE(v, 2) +
                ' m · neue Fläche ' + GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²',
                'success');
    }
  }

  // ============================================================
  // Eckpunkt-Drag (Punkt eines aktiven Polygons verschieben)
  // ============================================================

  var aktiverPunktDrag = null;   // {polygonId, punktIndex, originalX, originalY}

  function starteEckpunktDrag(hit) {
    var poly = GF.state.findPolygon(hit.polygonId);
    if (!poly) return;
    var pp = poly.punkte[hit.punktIndex];
    aktiverPunktDrag = {
      polygonId: hit.polygonId,
      punktIndex: hit.punktIndex,
      originalX: pp.x,
      originalY: pp.y
    };
    var c = $('planCanvas');
    if (c) c.style.cursor = 'grabbing';
  }

  function bewegeEckpunktDrag(canvasX, canvasY) {
    if (!aktiverPunktDrag) return;
    var poly = GF.state.findPolygon(aktiverPunktDrag.polygonId);
    if (!poly) return;
    var pdfPt = canvasZuPdf(canvasX, canvasY);
    poly.punkte[aktiverPunktDrag.punktIndex].x = pdfPt.x;
    poly.punkte[aktiverPunktDrag.punktIndex].y = pdfPt.y;
    redraw();
  }

  function beendeEckpunktDrag() {
    if (!aktiverPunktDrag) return;
    var poly = GF.state.findPolygon(aktiverPunktDrag.polygonId);
    var idx  = aktiverPunktDrag.punktIndex;
    aktiverPunktDrag = null;
    var c = $('planCanvas');
    if (c) c.style.cursor = '';
    if (!poly) { redraw(); return; }
    var region = GF.state.findRegion(poly.regionId);
    if (!region || !region.kalibrierung) { redraw(); return; }

    // Selbstueberschneidungs-Check (nur Warn, kein Rollback)
    if (GF.polygon.hatSelbstueberschneidung(poly.punkte)) {
      showToast('Hinweis: Polygon hat jetzt eine Selbstüberschneidung — Fläche ggf. ungenau.', 'warn', 7000);
    }

    var f = GF.polygon.berechneFlaeche(poly.punkte, region.kalibrierung.ptProMeter);
    poly.flaecheGemessenQM = Math.round(f * 1000) / 1000;
    var hatteKorrektur = !!poly.manuelleKorrektur;
    poly.flaecheAngesetztQM = poly.flaecheGemessenQM;
    poly.manuelleKorrektur  = false;
    poly.korrekturKommentar = '';

    GF.projekt.historieEintrag(GF.state.projekt, 'Eckpunkt verschoben',
      poly.bezeichnung + ' · Punkt ' + (idx + 1) + ' · neue Fläche ' +
      GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²');
    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    redraw();
    if (hatteKorrektur) {
      showToast('Eckpunkt verschoben. Frühere manuelle Flächenkorrektur wurde verworfen.', 'success', 7000);
    } else {
      showToast('Eckpunkt verschoben. Neue Fläche: ' +
                GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²', 'success');
    }
  }

  function abbrecheEckpunktDrag() {
    if (!aktiverPunktDrag) return;
    var poly = GF.state.findPolygon(aktiverPunktDrag.polygonId);
    if (poly) {
      poly.punkte[aktiverPunktDrag.punktIndex].x = aktiverPunktDrag.originalX;
      poly.punkte[aktiverPunktDrag.punktIndex].y = aktiverPunktDrag.originalY;
    }
    aktiverPunktDrag = null;
    var c = $('planCanvas');
    if (c) c.style.cursor = '';
    redraw();
    showToast('Eckpunkt-Verschiebung abgebrochen.');
  }

  function wireKantenEdit() {
    var ok = $('btnKantenOk');
    var ab = $('btnKantenAbbrechen');
    var inp = $('kantenEditInput');
    if (ok) ok.addEventListener('click', bestaetigeKantenEdit);
    if (ab) ab.addEventListener('click', abbrecheKantenEdit);
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter')  { e.preventDefault(); bestaetigeKantenEdit(); }
      if (e.key === 'Escape') { e.preventDefault(); abbrecheKantenEdit();   }
    });
  }

  // ============================================================
  // Flaechen-Korrektur-Modal (manuell ueberschreiben mit Begruendung)
  // ============================================================

  var flaecheModalPolygonId = null;

  function oeffneFlaechenKorrektur(polygonId) {
    var poly = GF.state.findPolygon(polygonId);
    if (!poly) return;
    flaecheModalPolygonId = polygonId;
    $('flaecheModalName').textContent     = poly.bezeichnung;
    $('flaecheModalGemessen').textContent = GF.util.formatZahlDE(poly.flaecheGemessenQM, 2) + ' m²';
    // Edit-Vorbelegung absichtlich mit 3 Stellen (voller Storage-Wert):
    // User darf eine bestehende 1,234 weiter verfeinern ohne Praezisions-Verlust.
    $('flaecheModalAngesetzt').value      = GF.util.formatZahlDE(poly.flaecheAngesetztQM, 3);
    $('flaecheModalKommentar').value      = poly.korrekturKommentar || '';
    $('flaecheModalFehler').hidden = true;
    $('flaecheBackdrop').classList.add('aktiv');
    setTimeout(function () {
      var inp = $('flaecheModalAngesetzt');
      if (inp) { inp.focus(); inp.select(); }
    }, 30);
  }

  function abbrecheFlaechenKorrektur() {
    $('flaecheBackdrop').classList.remove('aktiv');
    flaecheModalPolygonId = null;
  }

  function zeigeFlaecheFehler(msg) {
    var el = $('flaecheModalFehler');
    el.textContent = msg;
    el.hidden = false;
  }

  function bestaetigeFlaechenKorrektur() {
    var poly = GF.state.findPolygon(flaecheModalPolygonId);
    if (!poly) { abbrecheFlaechenKorrektur(); return; }
    var v = GF.util.parseZahlDE($('flaecheModalAngesetzt').value);
    var k = $('flaecheModalKommentar').value.trim();
    if (!isFinite(v) || v <= 0) {
      zeigeFlaecheFehler('Bitte gültige Fläche eingeben (> 0).');
      return;
    }
    if (!k) {
      zeigeFlaecheFehler('Begründung ist Pflicht — wird im Aufmaßprotokoll vermerkt.');
      return;
    }
    var angesetzt = Math.round(v * 1000) / 1000;
    poly.flaecheAngesetztQM = angesetzt;
    poly.korrekturKommentar = k;
    // Abweichung > 0.005 m² ist die Schwelle (sonst koennten 142,37 vs. 142,37 unterschiedlich sein wegen Float)
    poly.manuelleKorrektur = Math.abs(angesetzt - poly.flaecheGemessenQM) > 0.005;

    GF.projekt.historieEintrag(GF.state.projekt, 'Fläche manuell angesetzt',
      poly.bezeichnung + ': ' + GF.util.formatZahlDE(angesetzt, 2) + ' m² (gemessen ' +
      GF.util.formatZahlDE(poly.flaecheGemessenQM, 2) + ' m²) · ' + k);

    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    redraw();
    abbrecheFlaechenKorrektur();
    showToast('Fläche angepasst: ' + GF.util.formatZahlDE(angesetzt, 2) + ' m²', 'success');
  }

  function flaecheZuruecksetzen() {
    var poly = GF.state.findPolygon(flaecheModalPolygonId);
    if (!poly) return;
    poly.flaecheAngesetztQM = poly.flaecheGemessenQM;
    poly.manuelleKorrektur  = false;
    poly.korrekturKommentar = '';
    GF.projekt.historieEintrag(GF.state.projekt, 'Flächenkorrektur zurückgesetzt',
      poly.bezeichnung + ' → gemessen ' + GF.util.formatZahlDE(poly.flaecheGemessenQM, 2) + ' m²');
    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    redraw();
    abbrecheFlaechenKorrektur();
    showToast('Fläche auf gemessenen Wert zurückgesetzt.', 'success');
  }

  function wireFlaechenKorrektur() {
    var ok  = $('btnFlaecheOk');
    var ab  = $('btnFlaecheAbbrechen');
    var rst = $('btnFlaecheZuruecksetzen');
    if (ok)  ok.addEventListener('click',  bestaetigeFlaechenKorrektur);
    if (ab)  ab.addEventListener('click',  abbrecheFlaechenKorrektur);
    if (rst) rst.addEventListener('click', flaecheZuruecksetzen);
    var inp = $('flaecheModalAngesetzt');
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); bestaetigeFlaechenKorrektur(); }
    });
  }

  // ============================================================
  // Massstab-Kalibrierung (Zwei-Klick)
  // ============================================================

  var massPunkt1 = null;       // erster Klick (PDF-Koord), null = noch keiner
  var massPunkt2 = null;       // zweiter Klick (PDF-Koord)
  var massMaus   = null;       // aktuelle Mauspos waehrend des Wartens auf 2. Klick

  function starteMassstab() {
    var r = aktiveRegionFuerKalibrierung();
    if (!r) return false;
    massPunkt1 = null;
    massPunkt2 = null;
    massMaus = null;
    zeigeMassstabMethode();
    return true;
  }

  function aktiveRegionFuerKalibrierung() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Bitte erst eine Plan-Region anlegen.', 'warn');
      return null;
    }
    if (!s.aktiveRegionId) {
      showToast('Bitte erst eine Region in der Sidebar aktivieren.', 'warn');
      return null;
    }
    var r = null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
    }
    if (!r) return null;
    if (r.pdfId !== s.aktivePdfId || r.seite !== s.aktuelleSeite) {
      showToast('Aktive Region liegt auf anderer PDF/Seite. Bitte erst dorthin springen.', 'warn');
      return null;
    }
    return r;
  }

  // Versucht 90°-Snap des aktuellen Punktes zur Massstab-Linie ab massPunkt1.
  function massWinkelSnap(pdfPt, shiftKey) {
    if (shiftKey || !massPunkt1) return pdfPt;
    var dx = pdfPt.x - massPunkt1.x;
    var dy = pdfPt.y - massPunkt1.y;
    var laengePt = Math.sqrt(dx * dx + dy * dy);
    var laengeCanvas = laengePt * GF.state.viewport.zoom;
    if (laengeCanvas < WINKEL_SNAP_MIN_LAENGE) return pdfPt;
    return GF.polygon.snap.aufRechtwinkel(massPunkt1, pdfPt, WINKEL_SNAP_TOLERANZ);
  }

  function massstabKlick(canvasX, canvasY, shiftKey) {
    if (massEingabeOffen) return;     // Eingabe-Panel offen -> Klicks ignorieren
    if (massMethodeOffen) return;     // Methodenwahl offen -> erst Methode waehlen
    var punkt = canvasZuPdf(canvasX, canvasY);
    if (!massPunkt1) {
      massPunkt1 = punkt;
      massMaus = punkt;
      showToast('Klick auf den ZWEITEN Punkt. Linie rastet bei 90°/0° zur Maus-Richtung ein (grün) — Shift unterdrückt das. ' +
                'Pannen: Mausrad-Klick + Ziehen, Zoomen: Mausrad-Drehen.', null, 11000);
      redraw();
      return;
    }
    var gesnappt = massWinkelSnap(punkt, shiftKey);
    massPunkt2 = { x: gesnappt.x, y: gesnappt.y };
    massMaus = massPunkt2;
    winkelSnapAktiv = false;
    var distanzPt = GF.util.abstand2D(massPunkt1, massPunkt2);
    if (distanzPt < 2) {
      showToast('Die zwei Punkte sind zu nah aneinander.', 'warn');
      resetMass();
      redraw();
      return;
    }
    redraw();
    zeigeMassEingabe(distanzPt);
  }

  function massstabMausBewegung(canvasX, canvasY, shiftKey) {
    if (!massPunkt1 || massPunkt2) return;
    var p = canvasZuPdf(canvasX, canvasY);
    var gesnappt = massWinkelSnap(p, shiftKey);
    massMaus = { x: gesnappt.x, y: gesnappt.y };
    winkelSnapAktiv = !!gesnappt.snapped;
    redraw();
  }

  // ---- Methodenwahl: Massstab direkt eingeben oder Strecke messen ----
  var massMethodeOffen = false;

  function zeigeMassstabMethode() {
    var panel = $('massstabMethode');
    if (!panel) return;
    // Scan-Sperre: bei Raster-PDFs (vektorAnteil < 0.3) hat die Direkteingabe
    // keine verlaessliche physische Basis -> deaktivieren, Zwei-Punkt anbieten.
    var anteil = GF.state.vektorAnteil;
    // null/undefined = Vektor-Analyse laeuft noch (oder schlug fehl): Direkt-
    // eingabe fail-closed sperren, sonst ist die Scan-Sperre per Race umgehbar.
    // Sobald die Analyse fertig ist, ruft zeigeSeite() dieses Panel neu auf.
    var analyseLaeuft = (anteil === null || anteil === undefined) && !vektorAnalyseFehler;
    var gesperrt = analyseLaeuft || vektorAnalyseFehler || anteil < 0.3;
    var hinweis = $('massstabMethodeHinweis');
    var nInput = $('massstabNInput');
    var nOk = $('btnMassstabNOk');
    var schnell = panel.querySelectorAll('#massstabSchnell button');
    for (var i = 0; i < schnell.length; i++) schnell[i].disabled = gesperrt;
    if (nInput) nInput.disabled = gesperrt;
    if (nOk) nOk.disabled = gesperrt;
    if (hinweis) {
      // Vier Zustaende, Schwellen 0.3/0.7 wie beim Vektor-Badge (zeigeVektorBadge):
      // Analyse laeuft / Scan (gesperrt) / gemischt / Vektor — letztere zwei mit
      // positiver Rueckmeldung samt erkanntem Anteil.
      var prozent = (analyseLaeuft || vektorAnalyseFehler) ? null : Math.round(anteil * 100);
      var text, klasse;
      if (vektorAnalyseFehler) {
        text = 'PDF-Analyse fehlgeschlagen — Direkteingabe nicht verfügbar. Bitte Strecke messen.';
        klasse = 'hint gesperrt';
      } else if (analyseLaeuft) {
        text = 'PDF wird noch analysiert — bitte kurz warten oder Strecke messen.';
        klasse = 'hint';
      } else if (anteil < 0.3) {
        text = 'Gescannter Plan erkannt (Vektor ' + prozent + ' %) — Direkteingabe nicht zuverlässig. Bitte Strecke messen.';
        klasse = 'hint gesperrt';
      } else if (anteil < 0.7) {
        text = 'Gemischtes PDF erkannt (Vektor ' + prozent + ' %) — Direkteingabe möglich, im Zweifel ein bekanntes Maß nachmessen.';
        klasse = 'hint mittel';
      } else {
        text = 'Vektor-PDF erkannt (Vektor ' + prozent + ' %) — bei unskaliertem Export maßstabsgetreu; das Tool gleicht den Nennmaßstab gegen die Bemaßung ab.';
        klasse = 'hint ok';
      }
      hinweis.textContent = text;
      hinweis.className = klasse;
    }
    if (nInput) nInput.value = '';
    panel.hidden = false;
    massMethodeOffen = true;
    if (!gesperrt && nInput) setTimeout(function () { nInput.focus(); }, 0);
  }

  function versteckeMassstabMethode() {
    var panel = $('massstabMethode');
    if (panel) panel.hidden = true;
    massMethodeOffen = false;
  }

  function starteZweipunktMessung() {
    versteckeMassstabMethode();
    showToast('Klick auf den ERSTEN Punkt einer bekannten Bemassung.');
  }

  function uebernehmeMassstabDirekt(n) {
    var r = aktiveRegionFuerKalibrierung();
    if (!r) { versteckeMassstabMethode(); setzeWerkzeug('pan'); return; }
    if (!isFinite(n) || n < 1 || n !== Math.floor(n)) {
      showToast('Ungültiger Maßstab. Ganze Zahl eingeben, z. B. "100" für 1:100.', 'warn');
      var inp = $('massstabNInput');
      if (inp) { inp.focus(); inp.select(); }
      return;
    }
    try {
      var ptProMeter = GF.region.ptProMeterAusMassstab(n);
      var label = (GF.state.findGeschoss(r.geschossId) || {}).bezeichnung || r.bezeichnung || 'Region';
      // v1.3: Direkteingabe gegen die aus der Bemaßung gemessene Skala abgleichen.
      // Faengt nicht-massstabsgetreue Vektor-PDFs (Fit-to-Page, Sammelblatt). Bei
      // <3 Belegen 'unbekannt' -> stilles Altverhalten (kein Fehlalarm im Normalfall).
      var abgleich = GF.region.direktBelegAbgleich(ptProMeter, GF.state.gemesseneSkala);

      if (abgleich.status === 'abweichung') {
        var effektiv = '1:' + GF.region.massstabAusPtProMeter(abgleich.gemessenPtProMeter);
        var uebernehmen = global.confirm(
          'Die Planbemaßung ergibt ' + effektiv + ', eingegeben wurde 1:' + n
          + ' (' + GF.util.formatZahlDE(abgleich.abweichungProzent, 1) + ' % Abweichung).\n'
          + 'Der Plan ist vermutlich nicht maßstabsgetreu exportiert — die Flächen würden falsch.\n\n'
          + 'OK = gemessenen Maßstab ' + effektiv + ' übernehmen (empfohlen)\n'
          + 'Abbrechen = 1:' + n + ' behalten');
        if (uebernehmen) {
          r.kalibrierung = {
            punkt1: null, punkt2: null, abstandMeter: null,
            ptProMeter: abgleich.gemessenPtProMeter,
            quelle: 'massketten',
            abweichungVonNormProzent: GF.region.plausibilitaet(abgleich.gemessenPtProMeter).abweichungProzent,
            normMassstab: effektiv
          };
          GF.projekt.historieEintrag(GF.state.projekt, 'Maßstab aus Bemaßung korrigiert',
            label + ' / Eingabe 1:' + n + ' -> ' + effektiv);
          showToast('Maßstab auf ' + effektiv + ' korrigiert (laut Planbemaßung). '
            + 'Plan war nicht maßstabsgetreu.', 'success', 8000);
        } else {
          r.kalibrierung = {
            punkt1: null, punkt2: null, abstandMeter: null,
            ptProMeter: ptProMeter,
            quelle: 'massstab_direkt',
            abweichungVonNormProzent: abgleich.abweichungProzent,
            normMassstab: '1:' + n
          };
          GF.projekt.historieEintrag(GF.state.projekt, 'Nennmaßstab trotz Bemaßungs-Abweichung behalten',
            label + ' / 1:' + n + ' (' + GF.util.formatZahlDE(abgleich.abweichungProzent, 1) + ' % vs. Bemaßung)');
          showToast('Maßstab 1:' + n + ' gesetzt — weicht ' + GF.util.formatZahlDE(abgleich.abweichungProzent, 1)
            + ' % von der Planbemaßung ab.', 'warn', 8000);
        }
      } else {
        r.kalibrierung = {
          punkt1: null, punkt2: null, abstandMeter: null,
          ptProMeter: ptProMeter,
          quelle: 'massstab_direkt',
          abweichungVonNormProzent: 0,
          normMassstab: '1:' + n
        };
        GF.projekt.historieEintrag(GF.state.projekt, 'Maßstab direkt eingegeben', label + ' / 1:' + n);
        showToast('Maßstab 1:' + n + ' gesetzt (' + GF.util.formatZahlDE(ptProMeter, 2) + ' pt/m)'
          + (abgleich.status === 'bestaetigt' ? ' — durch Planbemaßung bestätigt.'
             : '. Tipp: ein bekanntes Maß zur Kontrolle nachmessen.'), 'success');
      }
      GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
      vielleichtUebernehmen(r, r.kalibrierung.ptProMeter);
    } catch (e) {
      showToast('Maßstab-Eingabe fehlgeschlagen: ' + e.message, 'danger');
    }
    versteckeMassstabMethode();
    resetMass();
    setzeWerkzeug('pan');
    aktualisiereGeschossListe();
    redraw();
  }

  function wireMassstabMethode() {
    var panel = $('massstabMethode');
    if (!panel) return;
    var schnell = panel.querySelectorAll('#massstabSchnell button');
    for (var i = 0; i < schnell.length; i++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          uebernehmeMassstabDirekt(parseInt(btn.getAttribute('data-massstab'), 10));
        });
      })(schnell[i]);
    }
    var nInput = $('massstabNInput');
    var nOk = $('btnMassstabNOk');
    var strecke = $('btnMassstabStrecke');
    var ab = $('btnMassstabMethodeAbbrechen');
    function uebernehmeFreiesFeld() {
      var roh = (nInput ? nInput.value : '').trim();
      // Maßstabsnenner ist ganzzahlig; Punkt/Leerzeichen NUR als Tausender-
      // trenner in 3er-Gruppen ("1.000" -> 1000). Sonst ablehnen:
      // GF.util.parseZahlDE wuerde "1.000" als 1,0 lesen und still Maßstab 1:1
      // setzen (Flaechen um Faktor 1e6 falsch), "50.5" faelschlich als 505.
      var gueltig = /^\d+$/.test(roh) || /^\d{1,3}([.\s]\d{3})+$/.test(roh);
      uebernehmeMassstabDirekt(gueltig ? parseInt(roh.replace(/[.\s]/g, ''), 10) : NaN);
    }
    if (nOk) nOk.addEventListener('click', uebernehmeFreiesFeld);
    if (nInput) nInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); uebernehmeFreiesFeld(); }
      else if (e.key === 'Escape') { e.preventDefault(); versteckeMassstabMethode(); setzeWerkzeug('pan'); }
    });
    if (strecke) strecke.addEventListener('click', starteZweipunktMessung);
    if (ab) ab.addEventListener('click', function () {
      versteckeMassstabMethode();
      setzeWerkzeug('pan');
    });
  }

  // ---- Inline-Eingabe-Panel ----
  var massEingabeOffen = false;

  function zeigeMassEingabe(distanzPt) {
    var panel = $('massEingabe');
    var inp   = $('massEingabeInput');
    if (!panel || !inp) return;
    panel.hidden = false;
    massEingabeOffen = true;
    inp.value = '';
    inp.placeholder = 'z. B. 11,79  (PDF: ' + GF.util.formatZahlDE(distanzPt, 1) + ' pt)';
    setTimeout(function () { inp.focus(); inp.select(); }, 0);
  }

  function versteckeMassEingabe() {
    var panel = $('massEingabe');
    if (panel) panel.hidden = true;
    massEingabeOffen = false;
  }

  function uebernehmeMassEingabe() {
    var inp = $('massEingabeInput');
    var r = aktiveRegionFuerKalibrierung();
    if (!r) { abbrecheMassEingabe(); return; }
    if (!massPunkt1 || !massPunkt2) { abbrecheMassEingabe(); return; }
    var meter = GF.util.parseZahlDE(inp.value);
    if (!isFinite(meter) || meter <= 0) {
      showToast('Ungültige Eingabe. Zahl in Metern, z. B. "11,79".', 'warn');
      inp.focus();
      inp.select();
      return;
    }
    try {
      var ptProMeter = GF.region.berechneMassstab(massPunkt1, massPunkt2, meter);
      var pl = GF.region.plausibilitaet(ptProMeter);
      r.kalibrierung = {
        punkt1: { x: massPunkt1.x, y: massPunkt1.y },
        punkt2: { x: massPunkt2.x, y: massPunkt2.y },
        abstandMeter: meter,
        ptProMeter: ptProMeter,
        quelle: 'manuell_zweipunkt',
        abweichungVonNormProzent: pl.abweichungProzent,
        normMassstab: pl.naechsterNormMassstab
      };
      GF.projekt.historieEintrag(GF.state.projekt, 'Maßstab kalibriert',
        (GF.state.findGeschoss(r.geschossId) || {}).bezeichnung + ' / ' + pl.naechsterNormMassstab);
      GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
      zeigeKalibrierungsToast(pl, ptProMeter);
      vielleichtUebernehmen(r, ptProMeter);
    } catch (e) {
      showToast('Kalibrierung fehlgeschlagen: ' + e.message, 'danger');
    }
    versteckeMassEingabe();
    resetMass();
    setzeWerkzeug('pan');
    aktualisiereGeschossListe();
    redraw();
  }

  function abbrecheMassEingabe() {
    versteckeMassEingabe();
    resetMass();
    redraw();
    // Im Massstab-Modus bleiben, damit User direkt neu klicken kann
    if (GF.state.aktivesWerkzeug === 'massstab') {
      showToast('Abgebrochen. Klick auf neuen ERSTEN Punkt.');
    }
  }

  function wireMassEingabe() {
    var inp = $('massEingabeInput');
    var ok  = $('btnMassOk');
    var ab  = $('btnMassAbbrechen');
    if (!inp || !ok || !ab) return;
    ok.addEventListener('click', uebernehmeMassEingabe);
    ab.addEventListener('click', abbrecheMassEingabe);
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); uebernehmeMassEingabe(); }
      else if (e.key === 'Escape') { e.preventDefault(); abbrecheMassEingabe(); }
    });
  }

  function zeigeKalibrierungsToast(pl, ptProMeter) {
    var prozent = GF.util.formatZahlDE(pl.abweichungProzent, 2);
    var pt = GF.util.formatZahlDE(ptProMeter, 2);
    if (pl.stufe === 'plausibel') {
      showToast('Maßstab gespeichert: ' + pl.naechsterNormMassstab + ' (' + pt + ' pt/m).', 'success');
    } else if (pl.stufe === 'hinweis') {
      showToast('Maßstab gespeichert: ' + pt + ' pt/m. Hinweis: ' + prozent + ' % Abweichung vom Norm-Maßstab ' + pl.naechsterNormMassstab + '.', 'warn');
    } else {
      showToast('Maßstab gespeichert: ' + pt + ' pt/m. WARNUNG: ' + prozent + ' % Abweichung — bitte prüfen.', 'danger');
    }
  }

  function vielleichtUebernehmen(quellRegion, ptProMeter) {
    var s = GF.state;
    var allesAufSeite = s.projekt.planRegionen.filter(function (r) {
      return r.id !== quellRegion.id
          && r.pdfId === quellRegion.pdfId
          && r.seite === quellRegion.seite;
    });
    // Zwei Gruppen:
    //   - unkalibrierte:  echte Erst-Uebertragung — der User soll bestaetigen
    //   - uebernommene:   stehen schon auf einem aelteren ptProMeter aus einer
    //                     frueheren Uebernahme. Bei Re-Kalibrierung der Quelle
    //                     waere es widerspruechlich, sie auf altem Stand stehen
    //                     zu lassen. Deshalb hier automatisch mitziehen (ohne
    //                     erneute Nachfrage).
    var unkalibriert = allesAufSeite.filter(function (r) { return !r.kalibrierung; });
    var uebernommen  = allesAufSeite.filter(function (r) {
      return r.kalibrierung && r.kalibrierung.quelle === 'übernommen';
    });

    function setzeUebernommen(r) {
      r.kalibrierung = {
        punkt1: null,
        punkt2: null,
        abstandMeter: null,
        ptProMeter: ptProMeter,
        quelle: 'übernommen',
        // Herkunft mitfuehren: war die Quelle eine ungeprüfte Direkteingabe
        // (oder selbst von einer solchen uebernommen), bleibt auch die
        // uebernommene Region neutral statt gruen.
        direktUrsprung: quellRegion.kalibrierung.quelle === 'massstab_direkt'
                        || quellRegion.kalibrierung.direktUrsprung === true,
        abweichungVonNormProzent: quellRegion.kalibrierung.abweichungVonNormProzent,
        normMassstab: quellRegion.kalibrierung.normMassstab
      };
    }

    // 1) Frueher uebernommene Regionen werden automatisch mit aktualisiert,
    //    damit "Maßstab fuer alle uebernehmen" nicht jedes Mal erneut bestaetigt
    //    werden muss und alle Regionen denselben ptProMeter teilen.
    if (uebernommen.length > 0) {
      uebernommen.forEach(setzeUebernommen);
      GF.projekt.historieEintrag(s.projekt, 'Maßstab synchronisiert',
        uebernommen.length + ' Region(en) auf neuen Wert');
      showToast('Maßstab in ' + uebernommen.length
        + ' übernommener Region(en) automatisch mit aktualisiert.', 'success');
    }

    // 2) Erst-Uebertragung auf unkalibrierte Regionen — wie bisher per confirm.
    if (unkalibriert.length === 0) return;
    var frage = 'Soll dieser Maßstab auch für ' + unkalibriert.length +
      ' weitere unkalibrierte Region(en) auf der gleichen Seite übernommen werden?';
    if (!global.confirm(frage)) return;
    unkalibriert.forEach(setzeUebernommen);
    GF.projekt.historieEintrag(s.projekt, 'Maßstab übernommen',
      'auf ' + unkalibriert.length + ' weitere Region(en)');
    showToast('Maßstab auf ' + unkalibriert.length + ' weitere Region(en) übernommen.', 'success');
  }

  function resetMass() {
    massPunkt1 = null;
    massPunkt2 = null;
    massMaus = null;
    versteckeMassEingabe();
    versteckeMassstabMethode();
  }

  // ============================================================
  // Region-Rechteck-Tool
  // ============================================================

  var regionDragAktiv = false;
  var regionStartPdf = null;
  var regionAktuellPdf = null;

  function starteRegionDrag(canvasX, canvasY) {
    regionStartPdf = canvasZuPdf(canvasX, canvasY);
    regionAktuellPdf = { x: regionStartPdf.x, y: regionStartPdf.y };
    regionDragAktiv = true;
  }

  function bewegeRegionDrag(canvasX, canvasY) {
    if (!regionDragAktiv) return;
    regionAktuellPdf = canvasZuPdf(canvasX, canvasY);
    redraw();
  }

  function beendeRegionDrag() {
    if (!regionDragAktiv) return;
    regionDragAktiv = false;
    var rect = normalisiereRechteck(regionStartPdf, regionAktuellPdf);
    regionStartPdf = null;
    regionAktuellPdf = null;
    if (rect.breite < 10 || rect.hoehe < 10) {
      // zu klein, verwerfen
      redraw();
      return;
    }
    speichereNeueRegion(rect);
  }

  function speichereNeueRegion(rect) {
    var projekt = GF.projekt.sorgeFuerProjekt();
    if (projekt.geschosse.length === 0) {
      showToast('Bitte erst ein Geschoss anlegen (links im Sidebar "+").', 'warn');
      redraw();
      return;
    }
    var geschossId = GF.state.aktivesGeschossId;
    if (!geschossId) {
      // Frag den Sachbearbeiter, welches Geschoss
      var moeglich = projekt.geschosse.map(function (g, i) { return (i + 1) + ') ' + g.bezeichnung; }).join('\n');
      var wahl = global.prompt('Welchem Geschoss soll diese Region zugeordnet werden?\n\n' + moeglich + '\n\nNummer eingeben:');
      if (wahl === null) { redraw(); return; }
      var idx = parseInt(wahl, 10) - 1;
      if (isNaN(idx) || idx < 0 || idx >= projekt.geschosse.length) {
        showToast('Ungültige Auswahl.', 'warn');
        redraw();
        return;
      }
      geschossId = projekt.geschosse[idx].id;
    }
    var g = GF.state.findGeschoss(geschossId);
    var region = GF.region.erzeuge(GF.state.aktivePdfId, GF.state.aktuelleSeite, rect, g.bezeichnung);
    region.geschossId = geschossId;
    projekt.planRegionen.push(region);
    GF.projekt.historieEintrag(projekt, 'Plan-Region angelegt', g.bezeichnung);
    GF.state.update(function (s) {
      s.aktiveRegionId = region.id;
      s.aktivesGeschossId = geschossId;
      s.aktivesWerkzeug = 'pan';
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereWerkzeugUI();
    aktualisiereCursor();
    aktualisiereGeschossListe();
    redraw();
    showToast('Region angelegt für ' + g.bezeichnung, 'success');
    // v1.2: frisch angelegte (noch unkalibrierte) Region -> Maßstab-Banner anbieten,
    // sofern die Belege gecacht sind (Detektion lief schon beim Seiten-Aufbau).
    vielleichtMassstabVorschlag();
  }

  // ============================================================

  function wireToolbar() {
    $('pdfSelect').addEventListener('change', function (e) {
      wechsleZuPdf(e.target.value);
    });
    $('btnPdfUmbenennen').addEventListener('click', function () {
      if (GF.state.aktivePdfId) benennePdfUm(GF.state.aktivePdfId);
    });
    $('btnPdfLoeschen').addEventListener('click', function () {
      if (GF.state.aktivePdfId) {
        loeschePdf(GF.state.aktivePdfId);
      } else {
        showToast('Keine PDF zum Löschen ausgewählt.', 'warn');
      }
    });
    $('btnSeitePrev').addEventListener('click', function () {
      zeigeSeite(GF.state.aktuelleSeite - 1);
    });
    $('btnSeiteNext').addEventListener('click', function () {
      zeigeSeite(GF.state.aktuelleSeite + 1);
    });
    $('btnZoomIn').addEventListener('click', function () {
      zoomMitFaktor(1.25, null, null);
    });
    $('btnZoomOut').addEventListener('click', function () {
      zoomMitFaktor(1 / 1.25, null, null);
    });
    $('btnFit').addEventListener('click', function () {
      if (!GF.state.pdfCache) return;
      passeCanvasGroesseAn();
      var fit = GF.pdf.fitViewport(GF.state.pdfCache, $('planCanvas'));
      GF.state.update(function (s) { s.viewport = fit; });
      redraw();
    });
  }

  function zoomMitFaktor(faktor, mausX, mausY) {
    if (!GF.state.pdfCache) return;
    var alt = GF.state.viewport.zoom;
    var neu = Math.max(0.05, Math.min(20, alt * faktor));
    if (neu === alt) return;
    var canvas = $('planCanvas');
    var mx = (mausX !== null && mausX !== undefined) ? mausX : canvas.width / 2;
    var my = (mausY !== null && mausY !== undefined) ? mausY : canvas.height / 2;
    var neuerPan = GF.pdf.zoomUmPunkt(mx, my, alt, neu, {
      x: GF.state.viewport.panX,
      y: GF.state.viewport.panY
    });
    GF.state.update(function (s) {
      s.viewport = { zoom: neu, panX: neuerPan.x, panY: neuerPan.y };
    });
    redraw();
  }

  function wireCanvas() {
    var canvas = $('planCanvas');
    if (!canvas) return;

    // Wheel-Zoom
    canvas.addEventListener('wheel', function (e) {
      if (!GF.state.pdfCache) return;
      e.preventDefault();
      var rect = canvas.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;
      var faktor = e.deltaY < 0 ? 1.1 : (1 / 1.1);
      zoomMitFaktor(faktor, mx, my);
    }, { passive: false });

    // Drag-Pan (Maustaste 1 oder Mitteltaste)
    var panAktiv = false;
    var startX = 0, startY = 0;
    var startPanX = 0, startPanY = 0;
    var startZoom = 1;

    canvas.addEventListener('mousedown', function (e) {
      if (!GF.state.pdfCache) return;
      if (e.button !== 0 && e.button !== 1) return;
      var rect = canvas.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;

      // Space-halten ueberlagert das aktuelle Werkzeug: immer Pan.
      // Mittel-Klick (button 1) ebenfalls immer Pan.
      var forcePan = spaceGehalten || e.button === 1;

      // Eckpunkt-Drag (nur im Plan-Modus, hat Vorrang vor Kanten-Label)
      if (!forcePan && GF.state.aktivesWerkzeug === 'pan' && e.button === 0) {
        var ep = findeEckpunkt(mx, my);
        if (ep) {
          starteEckpunktDrag(ep);
          return;
        }
        var hit = findeKantenLabel(mx, my);
        if (hit) {
          oeffneKantenEdit(hit.polygonId, hit.kantenIndex);
          return;
        }
      }

      if (!forcePan && GF.state.aktivesWerkzeug === 'region' && e.button === 0) {
        starteRegionDrag(mx, my);
        return;
      }
      if (!forcePan && GF.state.aktivesWerkzeug === 'massstab' && e.button === 0) {
        massstabKlick(mx, my, e.shiftKey);
        return;
      }
      if (!forcePan && GF.state.aktivesWerkzeug === 'polygon' && e.button === 0) {
        polygonKlick(mx, my, e.shiftKey);
        return;
      }
      if (!forcePan && GF.state.aktivesWerkzeug === 'rechteck' && e.button === 0) {
        rechteckKlick(mx, my);
        return;
      }
      // Pan
      panAktiv = true;
      startX = e.clientX;
      startY = e.clientY;
      startPanX = GF.state.viewport.panX;
      startPanY = GF.state.viewport.panY;
      startZoom = GF.state.viewport.zoom;
      canvas.classList.add('panning');
    });

    global.addEventListener('mousemove', function (e) {
      var rect = canvas.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;
      mauspositionAnzeigen(mx, my);

      // Aktive Drags haben Vorrang vor Tool-Vorschauen
      if (regionDragAktiv) { bewegeRegionDrag(mx, my); return; }
      if (aktiverPunktDrag) { bewegeEckpunktDrag(mx, my); return; }

      if (panAktiv) {
        var dx = e.clientX - startX;
        var dy = e.clientY - startY;
        GF.state.update(function (s) {
          s.viewport = {
            zoom: startZoom,
            panX: startPanX - dx / startZoom,
            panY: startPanY - dy / startZoom
          };
        });
        redraw();
        return;
      }

      // Hover im Plan-Modus: Eckpunkt -> move, Kanten-Label -> pointer
      if (GF.state.aktivesWerkzeug === 'pan' && !spaceGehalten) {
        if (findeEckpunkt(mx, my))         canvas.style.cursor = 'move';
        else if (findeKantenLabel(mx, my)) canvas.style.cursor = 'pointer';
        else                               canvas.style.cursor = '';
      }

      // Tool-Vorschau (Massstab-Linie zur Maus)
      if (GF.state.aktivesWerkzeug === 'massstab' && massPunkt1 && !massPunkt2) {
        massstabMausBewegung(mx, my, e.shiftKey);
      }
      // Polygon-Live-Linie zur Maus
      if (GF.state.aktivesWerkzeug === 'polygon' && polygonPunkte.length > 0) {
        polygonMausBewegung(mx, my, e.shiftKey);
      }
      // Rechteck-Live-Vorschau
      if (GF.state.aktivesWerkzeug === 'rechteck') {
        rechteckMausBewegung(mx, my);
      }
    });

    // Doppelklick schliesst Polygon
    canvas.addEventListener('dblclick', function (e) {
      var wkz = GF.state.aktivesWerkzeug;
      if (wkz !== 'polygon') return;
      if (polygonPunkte.length < 3) return;
      e.preventDefault();
      schliessePolygon();
    });

    global.addEventListener('mouseup', function () {
      if (regionDragAktiv)  { beendeRegionDrag();  return; }
      if (aktiverPunktDrag) { beendeEckpunktDrag(); return; }
      if (!panAktiv) return;
      panAktiv = false;
      canvas.classList.remove('panning');
    });

    // Tastatur: ESC bricht laufende Aktionen ab, Enter schliesst Polygon,
    // Pfeiltasten pannen den Plan (analog Mittelmaus-/Space-Pan).
    global.addEventListener('keydown', function (e) {
      if (e.key === 'Enter'
          && GF.state.aktivesWerkzeug === 'polygon'
          && polygonPunkte.length >= 3 && !istEingabeAktiv()) {
        e.preventDefault();
        schliessePolygon();
        return;
      }

      // Pfeiltasten-Pan: gleiche Guards wie Mittelmaus-Pan (Plan geladen,
      // keine Eingabe fokussiert). Schrittweite in PDF-Koordinaten so
      // skaliert, dass der visuelle Sprung in Bildschirmpixel konstant
      // bleibt unabhaengig vom Zoom. Shift = 5x Schritt (CAD-Konvention).
      if ((e.key === 'ArrowUp'   || e.key === 'ArrowDown'
        || e.key === 'ArrowLeft' || e.key === 'ArrowRight')
          && GF.state.pdfs.length > 0
          && !istEingabeAktiv()) {
        e.preventDefault();
        var step = (e.shiftKey ? 200 : 40) / GF.state.viewport.zoom;
        GF.state.update(function (s) {
          if (e.key === 'ArrowLeft')  s.viewport.panX -= step;
          if (e.key === 'ArrowRight') s.viewport.panX += step;
          if (e.key === 'ArrowUp')    s.viewport.panY -= step;
          if (e.key === 'ArrowDown')  s.viewport.panY += step;
        });
        redraw();
        return;
      }

      if (e.key !== 'Escape') return;
      // 0) Eckpunkt-Drag aktiv -> Punkt auf Originalposition zurueck
      if (aktiverPunktDrag) {
        abbrecheEckpunktDrag();
        return;
      }
      // 0a0) Tastenkürzel-Overlay offen -> schließen
      if ($('kuerzelBackdrop') && $('kuerzelBackdrop').classList.contains('aktiv')) {
        $('kuerzelBackdrop').classList.remove('aktiv');
        return;
      }
      // 0a1) Maßstab-Banner offen -> verwerfen
      if ($('massBanner') && !$('massBanner').hidden) {
        schliesseMassVorschlag();
        return;
      }
      // 0a*) VG-Modal offen -> nur das schliessen (hoechste Modal-Prio nach Drag)
      if ($('vgBackdrop') && $('vgBackdrop').classList.contains('aktiv')) {
        if (GF.VgModal && GF.VgModal.schliesse) GF.VgModal.schliesse();
        return;
      }
      // 0a**) Anrechnungs-Dialog offen -> als Abbruch behandeln
      if ($('exportDialogBackdrop') && $('exportDialogBackdrop').classList.contains('aktiv')) {
        if (GF.ExportDialog && GF.ExportDialog.schliesse) GF.ExportDialog.schliesse();
        return;
      }
      // 0a) Flaechen-Korrektur-Modal offen -> nur das schliessen
      if ($('flaecheBackdrop') && $('flaecheBackdrop').classList.contains('aktiv')) {
        abbrecheFlaechenKorrektur();
        return;
      }
      // 0a2) Projektdaten-Modal offen -> nur das schliessen
      if ($('projektdatenBackdrop') && $('projektdatenBackdrop').classList.contains('aktiv')) {
        abbrecheProjektdaten();
        return;
      }
      // 0a3) Protokoll-Modal offen -> nur das schliessen
      if ($('protokollBackdrop') && $('protokollBackdrop').classList.contains('aktiv')) {
        abbrecheProtokollModal();
        return;
      }
      // 0b) Kanten-Edit-Panel offen -> nur das schliessen
      if (!$('kantenEdit').hidden) {
        abbrecheKantenEdit();
        return;
      }
      // 1) Eingabe-Panel offen -> nur das schliessen
      if (massEingabeOffen) {
        abbrecheMassEingabe();
        return;
      }
      // 2) Region-Drag aktiv -> abbrechen
      if (regionDragAktiv) {
        regionDragAktiv = false;
        regionStartPdf = null;
        regionAktuellPdf = null;
        redraw();
        return;
      }
      // 2a) Rechteck-Vorschau aktiv (eigener State) -> erste Ecke verwerfen
      if (rechteckEcke1) {
        resetRechteck();
        redraw();
        return;
      }
      // 3) Polygon-Zeichnung -> abbrechen
      if (polygonPunkte.length > 0) {
        abbrechePolygon();
        return;
      }
      // 4) Massstab gerade in der Klick-Phase -> Mass-State zuruecksetzen
      if (massPunkt1 || massPunkt2) {
        resetMass();
        redraw();
        return;
      }
      // 5) Sonst: Werkzeug zurueck auf Pan
      if (GF.state.aktivesWerkzeug !== 'pan') setzeWerkzeug('pan');
    });
  }

  function mauspositionAnzeigen(mx, my) {
    var el = $('mausPos');
    if (!el || !GF.state.pdfCache) return;
    var vp = GF.state.viewport;
    var pdfX = vp.panX + mx / vp.zoom;
    var pdfY = vp.panY + my / vp.zoom;
    el.textContent = 'PDF: ' +
      GF.util.formatZahlDE(pdfX, 1) + ' / ' +
      GF.util.formatZahlDE(pdfY, 1) + ' pt';
  }

  // v1.2 Statusleiste: werkzeugabhaengiger Kontext-Hinweis (links) +
  // Live-Werte beim Polygon-Zeichnen (rechts: Snap-Status, Kantenlaenge, Flaeche).
  function aktualisiereStatusleiste() {
    var kontextEl = $('statusKontext');
    var liveEl = $('statusLive');
    if (!kontextEl || !liveEl) return;
    var wkz = GF.state.aktivesWerkzeug;
    var hinweise = {
      pan:      'Plan verschieben — Mausrad-Klick + Ziehen, Drehen = Zoom',
      region:   'Region ziehen — Rechteck pro Geschoss aufziehen',
      massstab: 'Maßstab — 1:N eingeben oder Strecke messen',
      polygon:  'Außenkontur klicken · Enter schließt · Shift = frei',
      rechteck: 'Rechteck — erste Ecke, dann Gegenecke klicken'
    };
    kontextEl.textContent = (GF.state.pdfs.length > 0) ? (hinweise[wkz] || '') : '';

    var teile = [];
    if (wkz === 'polygon' && polygonPunkte.length > 0) {
      if (vektorSnapAktiv)      teile.push('<span class="live-snap">⊙ Endpunkt</span>');
      else if (winkelSnapAktiv) teile.push('<span class="live-snap">⊥ 90°</span>');
      var r = findeAktiveRegion();
      var ptProM = (r && r.kalibrierung) ? r.kalibrierung.ptProMeter : null;
      if (ptProM && polygonMaus) {
        var letzter = polygonPunkte[polygonPunkte.length - 1];
        var dx = polygonMaus.x - letzter.x, dy = polygonMaus.y - letzter.y;
        var kanteM = Math.sqrt(dx * dx + dy * dy) / ptProM;
        teile.push('<span class="live-wert">Kante <b>' + GF.util.formatZahlDE(kanteM, 2) + ' m</b></span>');
      }
      if (ptProM && polygonPunkte.length >= 3) {
        try {
          var f = GF.polygon.berechneFlaeche(polygonPunkte, ptProM);
          teile.push('<span class="live-wert">Fläche <b>' + GF.util.formatZahlDE(f, 2) + ' m²</b></span>');
        } catch (e) { /* <3 effektive Punkte etc. */ }
      }
    }
    liveEl.innerHTML = teile.join('');
  }

  // Resize → Canvas neu vermessen + Redraw (Viewport bleibt; Cache bleibt).
  function wireResize() {
    var resizeTimer = null;
    global.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () {
        if (passeCanvasGroesseAn()) redraw();
      }, 100);
    });
  }

  // ============================================================
  // Init
  // ============================================================

  function init() {
    setzeVersion();
    setzeKommune();
    setzeLibStatus();
    pruefeRecovery();
    if (GF.recovery && GF.recovery.start) GF.recovery.start();

    wireFileInput();
    wireDragDrop();
    wireToolbar();
    wireCanvas();
    wireResize();
    wireWerkzeug();
    wireGeschosse();
    wireSpacePan();
    wireMassEingabe();
    wireMassstabMethode();
    wireKantenEdit();
    wireFlaechenKorrektur();
    wireProjektButtons();
    wireProjektdaten();
    wireProtokoll();
    wireMassstabToggle();
    wireTastenkuerzel();
    wireWerkzeugTasten();
    wireKuerzel();
    wireMassVorschlag();

    // State -> Toolbar-Aktualisierung (insbesondere fuer Speichern-Button-Status)
    GF.state.subscribe(function () { aktualisiereToolbar(); });

    passeCanvasGroesseAn();
    aktualisiereToolbar();
    aktualisiereWerkzeugUI();
    aktualisiereGeschossListe();
    aktualisiereCursor();

    var status = $('appStartStatus');
    if (status) status.textContent = 'Bereit. PDF laden, um zu beginnen.';
  }

  // Expose-Punkte fuer Sub-Module (z. B. VG-Modal)
  GF.app = GF.app || {};
  GF.app.aktualisiereGeschossListe = aktualisiereGeschossListe;
  GF.app.aktualisiereToolbar = aktualisiereToolbar;
  GF.app.showToast = showToast;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})(typeof window !== 'undefined' ? window : globalThis);
