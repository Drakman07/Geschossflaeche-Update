// @ts-check
// js/diagnose.js — Diagnose-Bericht-Generator (anonymisiert, ohne Binaerdaten).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  /** @type {string[]} */
  var PII_FELDER = [
    'projektName',
    'bauherr',
    'bauherrAnschriftStrasse',
    'bauherrAnschriftPLZ',
    'bauherrAnschriftOrt',
    'bauherrPKNr',
    'sachbearbeiter',
    'bauortStrasse',
    'bauortPLZ',
    'bauortOrt',
    'flurnummer',
    'gemarkung'
  ];
  var REDACTED = '<redacted>';

  /**
   * @param {object | null | undefined} meta
   * @returns {object}
   */
  function anonymisiereMetadata(meta) {
    if (!meta || typeof meta !== 'object') return {};
    /** @type {Record<string, any>} */
    var out = {};
    for (var k in meta) {
      if (!Object.prototype.hasOwnProperty.call(meta, k)) continue;
      if (PII_FELDER.indexOf(k) >= 0 && meta[k]) {
        out[k] = REDACTED;
      } else {
        out[k] = meta[k];
      }
    }
    return out;
  }

  /**
   * Liefert Browser-/Umgebungs-Infos. Reiner Helper, keine Seiteneffekte.
   * @returns {object}
   */
  function sammleBrowser() {
    var nav = (typeof navigator !== 'undefined') ? navigator : /** @type {any} */ ({});
    var scr = (typeof screen !== 'undefined') ? screen : /** @type {any} */ ({});
    return {
      userAgent: nav.userAgent || '',
      sprache: nav.language || '',
      bildschirm: { breite: scr.width || 0, hoehe: scr.height || 0 },
      viewport: {
        breite: (typeof window !== 'undefined') ? window.innerWidth : 0,
        hoehe: (typeof window !== 'undefined') ? window.innerHeight : 0
      },
      pixelDichte: (typeof window !== 'undefined') ? window.devicePixelRatio : 1
    };
  }

  /**
   * Liefert ausgewaehlte localStorage-Keys (nur GF-eigene).
   * @returns {Record<string, string | null>}
   */
  function sammleLocalStorage() {
    /** @type {Record<string, string | null>} */
    var keys = { 'gf.lizenz.demo.start': null, 'gf.massstabSichtbar': null };
    try {
      for (var k in keys) {
        if (Object.prototype.hasOwnProperty.call(keys, k)) {
          keys[k] = localStorage.getItem(k);
        }
      }
    } catch (e) { /* private mode */ }
    return keys;
  }

  /**
   * @param {Projekt | null | undefined} projekt
   * @returns {object}
   */
  function sammleStats(projekt) {
    if (!projekt) return { leer: true };
    var polygone = projekt.polygone || [];
    var sumQM = 0;
    var mitVg = 0;
    for (var i = 0; i < polygone.length; i++) {
      var p = polygone[i];
      if (typeof p.flaeche === 'number') sumQM += p.flaeche;
    }
    var geschosse = projekt.geschosse || [];
    for (var j = 0; j < geschosse.length; j++) {
      if (geschosse[j].vollgeschoss) mitVg++;
    }
    return {
      anzahlPdfs: (projekt.pdfs || []).length,
      anzahlRegionen: (projekt.planRegionen || []).length,
      anzahlGeschosse: geschosse.length,
      anzahlPolygone: polygone.length,
      anzahlMitVgBerechnung: mitVg,
      summeFlaecheQM: Math.round(sumQM * 100) / 100
    };
  }

  /**
   * Liefert das Projekt-Snapshot OHNE PDF-Binaerdaten und ohne Wappen-Base64.
   * @param {Projekt | null | undefined} projekt
   * @returns {object | null}
   */
  function sammleSnapshot(projekt) {
    if (!projekt) return null;
    var pdfs = (projekt.pdfs || []).map(function (p) {
      return {
        id: p.id,
        dateiName: p.dateiName,
        originalDateiName: p.originalDateiName,
        containerPfad: p.containerPfad,
        anzahlSeiten: p.anzahlSeiten,
        vektorAnteil: p.vektorAnteil
        // KEIN p.binaer, KEIN p.pdfDoc
      };
    });
    return {
      schemaVersion: projekt.schemaVersion,
      appVersion: projekt.appVersion,
      einstellungen: projekt.einstellungen,
      pdfs: pdfs,
      planRegionen: projekt.planRegionen || [],
      geschosse: projekt.geschosse || [],
      polygone: projekt.polygone || []
    };
  }

  /**
   * @param {{tiefe?: 'minimal'|'standard'|'voll', projekt?: Projekt | null}} [opts]
   * @returns {object}
   */
  function erstelle(opts) {
    var o = opts || {};
    var tiefe = o.tiefe || 'voll';
    var projekt = (o.projekt !== undefined)
      ? o.projekt
      : (global.GF && global.GF.state && global.GF.state.projekt) || null;

    var versionInfo = global.GF || /** @type {any} */ ({});
    var lizenzId = (global.GF && global.GF.lizenz && global.GF.lizenz.holeID)
      ? global.GF.lizenz.holeID()
      : null;
    var demoStart = null;
    try { demoStart = localStorage.getItem('gf.lizenz.demo.start'); } catch (e) {}

    /** @type {Record<string, any>} */
    var out = {
      tool: 'FlaechenKlar',
      version: versionInfo.VERSION || '',
      buildDatum: versionInfo.BUILD_DATUM || '',
      diagnoseErstelltAm: new Date().toISOString(),
      tiefe: tiefe,
      lizenz: { id: lizenzId, demoModus: !lizenzId, demoStart: demoStart },
      browser: sammleBrowser(),
      localStorage: sammleLocalStorage()
    };

    if (tiefe === 'minimal') return out;

    out.projekt = {
      metadata: anonymisiereMetadata(projekt && projekt.metadata),
      stats: sammleStats(projekt)
    };

    if (tiefe === 'voll') {
      out.projekt.snapshot = sammleSnapshot(projekt);
    }

    return out;
  }

  /**
   * @param {object} bericht
   * @returns {string} Filename
   */
  function downloadAlsJson(bericht) {
    var jetzt = new Date();
    function pad(n) { return (n < 10 ? '0' : '') + n; }
    var dateiName = 'flaechenklar-diagnose-'
      + jetzt.getFullYear() + '-' + pad(jetzt.getMonth() + 1) + '-' + pad(jetzt.getDate())
      + '-' + pad(jetzt.getHours()) + pad(jetzt.getMinutes()) + pad(jetzt.getSeconds())
      + '.json';
    var json = JSON.stringify(bericht, null, 2);
    var blob = new Blob([json], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = dateiName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    return dateiName;
  }

  /** @param {string} id @returns {HTMLElement | null} */
  function $(id) { return document.getElementById(id); }

  function gewaehlteTiefe() {
    var radios = document.getElementsByName('diagnoseTiefe');
    for (var i = 0; i < radios.length; i++) {
      var r = /** @type {HTMLInputElement} */ (radios[i]);
      if (r.checked) {
        var v = r.value;
        if (v === 'minimal' || v === 'standard' || v === 'voll') return v;
      }
    }
    return 'voll';
  }

  function aktualisierePreview() {
    var ta = /** @type {HTMLTextAreaElement | null} */ ($('diagnosePreview'));
    if (!ta) return;
    var bericht = erstelle({ tiefe: gewaehlteTiefe() });
    ta.value = JSON.stringify(bericht, null, 2);
  }

  function oeffneModal() {
    var bd = $('diagnoseBackdrop');
    if (!bd) return;
    bd.classList.add('aktiv');
    aktualisierePreview();
  }

  function schliesseModal() {
    var bd = $('diagnoseBackdrop');
    if (bd) bd.classList.remove('aktiv');
  }

  function aufSpeichernKlick() {
    var bericht = erstelle({ tiefe: gewaehlteTiefe() });
    var datei = downloadAlsJson(bericht);
    schliesseModal();
    // Schreibt in das #toast-Element (geteilt mit updates.js).
    var t = $('toast');
    if (t) {
      t.textContent = 'Diagnose-Bericht gespeichert: ' + datei;
      t.className = 'toast aktiv success';
      clearTimeout(/** @type {any} */ (aufSpeichernKlick)._t);
      /** @type {any} */ (aufSpeichernKlick)._t = setTimeout(function () {
        t.classList.remove('aktiv');
      }, 4500);
    }
  }

  function initDiagnose() {
    var radios = document.getElementsByName('diagnoseTiefe');
    for (var i = 0; i < radios.length; i++) {
      radios[i].addEventListener('change', aktualisierePreview);
    }
    var abbr = $('diagnoseAbbrechen');
    if (abbr) abbr.addEventListener('click', schliesseModal);
    var save = $('diagnoseSpeichern');
    if (save) save.addEventListener('click', aufSpeichernKlick);
    var bd = $('diagnoseBackdrop');
    if (bd) bd.addEventListener('click', function (ev) {
      if (ev.target === bd) schliesseModal();
    });
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF & {diagnose: any}} */ (global.GF = global.GF || {});
  GF.diagnose = {
    erstelle: erstelle,
    downloadAlsJson: downloadAlsJson,
    _anonymisiereMetadata: anonymisiereMetadata,
    _oeffneModal: oeffneModal
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDiagnose);
  } else {
    initDiagnose();
  }
})(typeof window !== 'undefined' ? window : globalThis);
