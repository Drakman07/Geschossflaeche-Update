// js/pdf-massketten.js — Bemassungstexte (Maßketten) aus einem Vektor-PDF lesen
// und daraus konservativ einen Maßstab vorschlagen (v1.2). Reiner Vorschlag —
// der Mensch bestaetigt/setzt den Maßstab (kein Auto-Set, keine Konturerkennung).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  // Plausibles Maßfenster in Metern (Tuerbreite bis grosse Gebaeudekante).
  var MASS_MIN_M = 0.30;
  var MASS_MAX_M = 100;

  /**
   * Parst einen Text als Maßangabe (Meter) oder liefert NaN.
   * Akzeptiert reine Zahlen mit max. 2 Nachkommastellen (Komma ODER Punkt).
   * Filtert Werte ausserhalb des Maßfensters (z. B. Positionsnummern "2.1").
   * @param {string} str
   * @returns {number}
   */
  GF.pdf._parseMassText = function (str) {
    if (typeof str !== 'string') return NaN;
    var t = str.trim();
    // v1.2: optionale Einheit "m" tolerieren ("12,50 m" / "3,75m"). Reine Buchstaben
    // ("Raum") scheitern danach weiter an der strengen Ziffern-Regex.
    t = t.replace(/\s*m$/i, '').trim();
    if (!/^\d{1,3}([.,]\d{1,2})?$/.test(t)) return NaN;
    var n = GF.util.parseZahlDE(t);
    if (!isFinite(n) || n < MASS_MIN_M || n > MASS_MAX_M) return NaN;
    return n;
  };

  /**
   * Liest die Maßangaben einer Seite als {text, wertMeter, x, y} in Tool-pt.
   * @param {any} pdfDoc
   * @param {number} seite
   * @returns {Promise<Array<{text:string,wertMeter:number,x:number,y:number}>>}
   */
  GF.pdf.findeMassketten = function (pdfDoc, seite) {
    if (!pdfDoc) return Promise.resolve([]);
    return pdfDoc.getPage(seite).then(function (page) {
      var vp = page.getViewport({ scale: 1 });
      return page.getTextContent().then(function (tc) {
        var items = (tc && tc.items) || [];
        // Sichtbare Items normalisieren (Position + Texthoehe aus dem Transform).
        var norm = [];
        for (var i = 0; i < items.length; i++) {
          var it = items[i];
          var s = (it && typeof it.str === 'string') ? it.str : '';
          if (!s.trim()) continue;
          var tr = it.transform || [1, 0, 0, 1, 0, 0];
          norm.push({ str: s, x: tr[4], y: tr[5], h: Math.abs(it.height || tr[3] || 0), tr: tr });
        }

        var out = [];
        var seen = Object.create(null);
        function emit(wert, text, tr) {
          var p = vp.convertToViewportPoint(tr[4], tr[5]);
          var key = wert.toFixed(3) + '@' + p[0].toFixed(1) + ',' + p[1].toFixed(1);
          if (seen[key]) return;
          seen[key] = 1;
          out.push({ text: String(text).trim(), wertMeter: wert, x: p[0], y: p[1] });
        }

        // 1) Einzel-Items (wie bisher).
        for (var j = 0; j < norm.length; j++) {
          var w0 = GF.pdf._parseMassText(norm[j].str);
          if (!isNaN(w0)) emit(w0, norm[j].str, norm[j].tr);
        }

        // 2) Fragmentierte Zahlen: je nach PDF-Erzeuger wird "12,50" in mehrere
        //    Textitems zerlegt ("12" / "," / "50"). Benachbarte Items derselben
        //    Grundlinie (in Lese-Reihenfolge) zu 2er-/3er-Laeufen verketten und nur
        //    uebernehmen, wenn die strenge Maß-Regex (_parseMassText) greift.
        //    Reine Mehr-Erkennung — falsche Verkettungen fallen an der Regex durch;
        //    Einzelziffern wurden schon in (1) erfasst, der zusammengesetzte Wert
        //    kommt hier dazu. Position = erstes Fragment.
        for (var a = 0; a < norm.length; a++) {
          var combo = norm[a].str;
          var lineTol = Math.max(2, 0.6 * norm[a].h);
          for (var b = a + 1; b < norm.length && b <= a + 2; b++) {
            if (Math.abs(norm[b].y - norm[a].y) > lineTol) break;   // andere Zeile
            if (norm[b].x < norm[a].x - 1) break;                   // nicht rechts daneben
            combo += norm[b].str;
            var wc = GF.pdf._parseMassText(combo.replace(/\s+/g, ''));
            if (!isNaN(wc)) emit(wc, combo, norm[a].tr);
          }
        }

        return out;
      });
    });
  };

  /**
   * Schlaegt aus Maßketten + Vektor-Kanten einen Maßstab vor. Jede Maßangabe
   * wird mit der naechstgelegenen, laengen-plausiblen Kante verheiratet; nur
   * Treffer, die exakt (<0,5 %) auf einen Norm-Maßstab fallen, zaehlen. Der
   * Norm-Maßstab mit der groessten summierten Maßlinien-Laenge gewinnt — lange echte
   * Maßlinien schlagen viele kurze Zufallstreffer (Median der ptProMeter).
   * Liefert null, wenn weniger als 3 Belege konvergieren (fail-safe).
   * @param {Array<{wertMeter:number,x:number,y:number}>} massketten
   * @param {Array<{a:Punkt,b:Punkt}>} kanten   (Tool-pt, aus GF.pdf.snapPunkte)
   * @returns {{ptProMeter:number,anzahlBelege:number,normMassstab:string,stufe:string}|null}
   */
  GF.pdf.massstabVorschlag = function (massketten, kanten) {
    if (!Array.isArray(massketten) || !massketten.length) return null;
    if (!Array.isArray(kanten) || !kanten.length) return null;
    if (!GF.region || !GF.region.plausibilitaet) return null;

    var R = 60, R2 = R * R;            // Suchradius Text<->Maßlinien-Mitte (Tool-pt)
    var votes = Object.create(null);
    var gewicht = Object.create(null);   // summierte Maßlinien-Laenge je Norm (Gewinner-Kriterium)
    var cands = Object.create(null);

    for (var m = 0; m < massketten.length; m++) {
      var mk = massketten[m];
      if (!(mk.wertMeter > 0)) continue;
      var bestNorm = null, bestPp = 0, bestAbw = Infinity, bestLen = 0;
      for (var i = 0; i < kanten.length; i++) {
        var k = kanten[i];
        var mx = (k.a.x + k.b.x) / 2, my = (k.a.y + k.b.y) / 2;
        var ddx = mx - mk.x, ddy = my - mk.y;
        if (ddx * ddx + ddy * ddy > R2) continue;
        var dx = k.b.x - k.a.x, dy = k.b.y - k.a.y;
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 10) continue;
        var pp = len / mk.wertMeter;
        var pl = GF.region.plausibilitaet(pp);
        if (pl.stufe === 'plausibel' && pl.abweichungProzent < bestAbw) {
          bestAbw = pl.abweichungProzent;
          bestNorm = pl.naechsterNormMassstab;
          bestPp = pp;
          bestLen = len;
        }
      }
      if (bestNorm) {
        votes[bestNorm] = (votes[bestNorm] || 0) + 1;
        gewicht[bestNorm] = (gewicht[bestNorm] || 0) + bestLen;
        (cands[bestNorm] = cands[bestNorm] || []).push(bestPp);
      }
    }

    // Gewinner nach groesster summierter Maßlinien-Laenge; >=3 Belege bleibt Pflicht.
    var bestKey = null, bestGew = -1;
    var keys = Object.keys(gewicht);
    for (var j = 0; j < keys.length; j++) {
      if (gewicht[keys[j]] > bestGew) { bestGew = gewicht[keys[j]]; bestKey = keys[j]; }
    }
    var bestV = bestKey ? votes[bestKey] : 0;
    if (!bestKey || bestV < 3) return null;

    var arr = cands[bestKey].slice().sort(function (a, b) { return a - b; });
    var med = arr[Math.floor(arr.length / 2)];
    return { ptProMeter: med, anzahlBelege: bestV, normMassstab: bestKey, stufe: 'plausibel' };
  };

  /**
   * Wie massstabVorschlag, aber fuer den Beleg-Dialog (v1.2): liefert den
   * Gewinner-Norm-Maßstab MIT der Liste seiner Einzelbelege (Maßtext, Soll,
   * abgeleiteter pt/m, Abweichung) und einer Sicherheitsstufe. Schwelle gesenkt
   * — schon 1 Beleg oeffnet den Dialog; <3 Belege = 'unsicher'. Nie Auto-Set.
   * @param {Array<{text?:string,wertMeter:number,x:number,y:number}>} massketten
   * @param {Array<{a:Punkt,b:Punkt}>} kanten
   * @returns {{ptProMeter:number,normMassstab:string,anzahlBelege:number,stufe:string,belege:Array}|null}
   */
  GF.pdf.massstabBelege = function (massketten, kanten) {
    if (!Array.isArray(massketten) || !massketten.length) return null;
    if (!Array.isArray(kanten) || !kanten.length) return null;
    if (!GF.region || !GF.region.plausibilitaet) return null;

    var R = 60, R2 = R * R;
    var votes = Object.create(null);
    var gewicht = Object.create(null);   // summierte Maßlinien-Laenge je Norm (Gewinner-Kriterium)
    var belegeProNorm = Object.create(null);

    for (var m = 0; m < massketten.length; m++) {
      var mk = massketten[m];
      if (!(mk.wertMeter > 0)) continue;
      var bestNorm = null, bestPp = 0, bestAbw = Infinity, bestMitte = null, bestLen = 0;
      for (var i = 0; i < kanten.length; i++) {
        var k = kanten[i];
        var mx = (k.a.x + k.b.x) / 2, my = (k.a.y + k.b.y) / 2;
        var ddx = mx - mk.x, ddy = my - mk.y;
        if (ddx * ddx + ddy * ddy > R2) continue;
        var dx = k.b.x - k.a.x, dy = k.b.y - k.a.y;
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 10) continue;
        var pp = len / mk.wertMeter;
        var pl = GF.region.plausibilitaet(pp);
        if (pl.stufe === 'plausibel' && pl.abweichungProzent < bestAbw) {
          bestAbw = pl.abweichungProzent;
          bestNorm = pl.naechsterNormMassstab;
          bestPp = pp;
          bestMitte = { x: mx, y: my };
          bestLen = len;
        }
      }
      if (bestNorm) {
        votes[bestNorm] = (votes[bestNorm] || 0) + 1;
        gewicht[bestNorm] = (gewicht[bestNorm] || 0) + bestLen;
        (belegeProNorm[bestNorm] = belegeProNorm[bestNorm] || []).push({
          text: (typeof mk.text === 'string' ? mk.text : String(mk.wertMeter)),
          wertMeter: mk.wertMeter,
          kanteMitte: bestMitte,
          ptProMeter: bestPp,
          abweichungProzent: bestAbw
        });
      }
    }

    // Gewinner: groesste summierte Maßlinien-Laenge je Norm. Lange echte Maßlinien
    // schlagen viele kurze Zufallstreffer, die zufaellig auf einen kleineren Maßstab
    // (groesseres N) fallen. anzahlBelege/Stufe bleiben die reine Beleg-Anzahl.
    var bestKey = null, bestGew = -1;
    var keys = Object.keys(gewicht);
    for (var j = 0; j < keys.length; j++) {
      if (gewicht[keys[j]] > bestGew) { bestGew = gewicht[keys[j]]; bestKey = keys[j]; }
    }
    var bestV = bestKey ? votes[bestKey] : 0;
    if (!bestKey || bestV < 1) return null;   // schon 1 Beleg oeffnet den Dialog

    var belege = belegeProNorm[bestKey];
    var pps = belege.map(function (b) { return b.ptProMeter; }).sort(function (a, b) { return a - b; });
    var med = pps[Math.floor(pps.length / 2)];
    return {
      ptProMeter: med,
      normMassstab: bestKey,
      anzahlBelege: bestV,
      stufe: bestV >= 3 ? 'sicher' : 'unsicher',
      belege: belege
    };
  };

  /**
   * v1.3: Norm-AGNOSTISCHE Mess-Skala aus der Planbemaßung. Paart jede Maßzahl mit
   * der naechsten Maßlinie (Mitten-Abstand < R), bildet pt/m = Linienlaenge / Soll
   * und liefert den robusten Median ALLER Paare — OHNE Norm-Filter. Damit verraet
   * auch ein nicht massstabsgetreu exportierter Plan (z. B. "Auf Seite anpassen")
   * seine tatsaechliche Skala, die kein Norm-Maßstab ist. Cluster-Filter gegen
   * Fehlpaarungen: nur Werte innerhalb +/-3 % um den Roh-Median zaehlen, >=3 Pflicht.
   * @param {Array<{wertMeter:number,x:number,y:number}>} massketten
   * @param {Array<{a:Punkt,b:Punkt}>} kanten   (Tool-pt, aus GF.pdf.snapPunkte)
   * @returns {{ptProMeter:number,anzahlBelege:number}|null}
   */
  GF.pdf.gemesseneSkala = function (massketten, kanten) {
    if (!Array.isArray(massketten) || !massketten.length) return null;
    if (!Array.isArray(kanten) || !kanten.length) return null;
    var R = 60, R2 = R * R;
    var roh = [];
    for (var m = 0; m < massketten.length; m++) {
      var mk = massketten[m];
      if (!(mk.wertMeter > 0)) continue;
      var bestPp = 0, bestD2 = Infinity;
      for (var i = 0; i < kanten.length; i++) {
        var k = kanten[i];
        var mx = (k.a.x + k.b.x) / 2, my = (k.a.y + k.b.y) / 2;
        var ddx = mx - mk.x, ddy = my - mk.y;
        var d2 = ddx * ddx + ddy * ddy;
        if (d2 > R2) continue;
        var dx = k.b.x - k.a.x, dy = k.b.y - k.a.y;
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 10) continue;
        if (d2 < bestD2) { bestD2 = d2; bestPp = len / mk.wertMeter; }
      }
      if (bestPp > 0) roh.push(bestPp);
    }
    if (roh.length < 3) return null;
    roh.sort(function (a, b) { return a - b; });
    var rohMed = roh[Math.floor(roh.length / 2)];
    var klar = roh.filter(function (p) { return Math.abs(p - rohMed) <= rohMed * 0.03; });
    if (klar.length < 3) return null;
    klar.sort(function (a, b) { return a - b; });
    return { ptProMeter: klar[Math.floor(klar.length / 2)], anzahlBelege: klar.length };
  };

})(typeof window !== 'undefined' ? window : globalThis);
