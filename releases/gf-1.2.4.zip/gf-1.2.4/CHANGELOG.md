# Changelog — FlächenKlar

Alle nennenswerten Änderungen werden hier dokumentiert.
*Arbeitstitel bis Mai 2026: gf-Tool / Geschossflächen-Tool.*

## [1.2.4] — 2026-07-02

### Geändert
- **„Erstellt am" im Aufmaßblatt zeigt jetzt das Export-Datum**: Das Datum in der
  PROJEKT-Karte des Aufmaßprotokolls ist ab sofort der Zeitpunkt, an dem die PDF
  erzeugt wird — nicht mehr das Anlagedatum des Projekts. Wird ein älterer Vorgang
  erneut geöffnet und exportiert, trägt das Blatt das dann-aktuelle Datum.

## [1.2.3] — 2026-06-25

### Hinzugefügt
- **Manuelle Korrektur der Fläche ≥ 2,30 m in der Vollgeschoss-Beurteilung**: Der
  errechnete Wert der Fläche mit einer lichten Höhe von mindestens 2,30 m lässt
  sich jetzt direkt in der VG-Maske von Hand nachjustieren — genau wie ein
  Kantenmaß beim Polygon, wenn es um Zentimeter nicht passt. Der korrigierte Wert
  ist maßgeblich und zieht durch: der Anteil ≥ 2,30 m, das Vollgeschoss-Urteil und
  die anrechenbare Fläche rechnen damit. Der errechnete Ausgangswert bleibt intern
  erhalten; ändert man danach eine geometrische Eingabe, verfällt die Korrektur
  automatisch.

### Geändert
- **Kein Korrektur-Vermerk mehr im Aufmaßprotokoll**: Wird eine Teilfläche manuell
  überschrieben, druckt das Protokoll nur noch den angesetzten Wert — der frühere
  Zusatz „manuelle Korrektur" bzw. „gemessen … manuell angesetzt …" entfällt. Dass
  korrigiert wurde, bleibt im Tool sichtbar (orange Markierung); im CSV-/JSON-Export
  bleibt das Feld erhalten.

## [1.2.2] — 2026-06-25

### Hinzugefügt
- **Maßstabs-Abgleich gegen die Planbemaßung**: Bei der Maßstab-Direkteingabe
  gleicht das Tool den eingegebenen Nennmaßstab jetzt still gegen die im Plan
  gemessenen Bemaßungen ab. Ist ein PDF zwar elektronisch (Vektor), aber nicht
  maßstabsgetreu exportiert (etwa „Auf Seite anpassen", verkleinerte
  Ausfertigung oder Sammelblatt mit mehreren Maßstäben), weicht der eingegebene
  Nennmaßstab von der tatsächlich gemessenen Skala ab. Das Tool meldet das dann
  („Planbemaßung ergibt 1:52, eingegeben wurde 1:50") und bietet an, den
  gemessenen Maßstab zu übernehmen. Stimmen beide überein, bestätigt es kurz; ist
  keine Bemaßung lesbar, bleibt alles unverändert (kein Fehlalarm im Normalfall).
- **Nicht maßstabsgetreue Pläne im Aufmaßprotokoll ausgewiesen**: Weicht der
  Maßstab einer Region spürbar vom Norm-Maßstab ab, vermerkt das Protokoll dies
  („nicht maßstabsgetreu, X % Abweichung") als Transparenz für die
  Beitragsgrundlage.

### Geändert
- Der Hinweis bei erkanntem Vektor-PDF verspricht nicht mehr pauschal
  „Direkteingabe zuverlässig", sondern stellt klar, dass der Nennmaßstab nur bei
  unskaliertem Export stimmt und gegen die Bemaßung abgeglichen wird.

## [1.2.1] — 2026-06-21

### Behoben
- **In-Programm-Update-Prüfung von `file://` repariert**: Der „Auf Updates
  prüfen"-Knopf rief die Update-Adressen über `drakman07.github.io` ab. Seit
  die Custom-Domain an GitHub Pages hängt, antwortet diese mit einem
  301-Redirect ohne `Access-Control-Allow-Origin`-Header — ein `fetch()` aus
  der lokal geöffneten `index.html` (Herkunft „null") scheitert daran an der
  CORS-Prüfung, sodass das Tool „Update-Server nicht erreichbar" meldete. Die
  drei Adressen (`VERSION_CHECK_URL` und `DOWNLOAD_URL` in `js/version.js`,
  `ALLOWLIST_URL` in `js/lizenz.js`) zeigen jetzt direkt auf
  `https://download.flaechenklar.de/…` (liefert `Access-Control-Allow-Origin:
  *` ohne Redirect). Der `update.bat`/`update.ps1`-Weg war nie betroffen und
  bleibt unverändert; die Adressen dort wurden zur Konsistenz mitgezogen.

## [1.2.0] — 2026-06-21

### Hinzugefügt
- **Daten-Export (CSV und JSON)**: Das Aufmaß lässt sich zusätzlich zum
  PDF-Protokoll als CSV (Tabellenkalkulation) und JSON (maschinenlesbar)
  ausgeben — Geschosse, Regionen und anrechenbare Flächen strukturiert für
  die Weiterverarbeitung. Neue Module `js/exportdaten.js` (Datenmodell) und
  `js/exportformat.js` (CSV-/JSON-Writer).
- **Vektor-Snapping (Magnet)**: Beim Zeichnen rasten Eck- und Stützpunkte an
  den Original-Vektorlinien maßhaltiger CAD-PDFs ein. `Shift` beim Klick
  schaltet den Snap kurzzeitig aus. Neues Modul `js/snap.js` (KD-Baum-Index
  über die PDF-Vektoren).
- **Maßketten-Auto-Maßstab**: Das Tool liest die Bemaßung (Maßketten) aus
  Vektor-PDFs aus und schlägt den Maßstab automatisch vor; bei drei
  übereinstimmenden Belegen gilt die Einstufung als sicher. Manuelles
  Kalibrieren entfällt bei maßhaltigen Plänen. Erweiterung in
  `js/pdf-massketten.js` / `js/pdf-vektor.js`.
- **Rechteck-Werkzeug**: Rechteckige Flächen mit zwei Klicks über die
  Diagonale anlegen statt mit vier Einzelpunkten. Mündet in den bestehenden
  Polygon-Speicherpfad — Validierung, VG-Berechnung und Export bleiben
  unverändert. Neues Modul `js/rechteck.js`.
- **Plan mit Leertaste pannen**: `Leertaste` halten und ziehen verschiebt den
  Plan mit der Maus — auch während einer laufenden Polygon-Zeichnung.
  Im Kürzel-Dialog und Benutzerhandbuch dokumentiert.

### Geändert
- **Maßstab-Statusanzeige** überarbeitet (`js/massstab-ui.js`): klarere
  Banner- und Badge-Darstellung der aktiven Maßstab-Quelle (Referenzstrecke,
  Direkteingabe, Maßketten-Vorschlag), insbesondere beim parallelen Arbeiten
  an mehreren Plänen.
- **Release-Build** (`tools/build-release.js`): Manifest um
  `assets/fonts/*.woff2` und die zugehörige OFL-Lizenz erweitert, damit die
  Geist-Schriften im Kunden-ZIP enthalten sind (sonst Arial-Fallback).
- Test-Suite um die neuen Module erweitert (Rechteck, Vektor-Snapping,
  Maßketten, Daten-Export) — `test.html`.

## [1.1.0] — 2026-06-15

### Hinzugefügt
- **Maßstab-Direkteingabe** (für maßhaltige CAD-/Vektor-PDFs): Methodenwahl im
  Maßstab-Werkzeug — Weg A „Maßstab direkt eingeben" (Schnell-Buttons
  1:50/1:100/1:200/1:500/1:1000 oder Feld „1 : ___", nur Ganzzahl) neben dem
  bisherigen Weg B (Referenzstrecke). Das Tool erkennt den Vektor-Anteil der PDF
  (grün „Vektor-PDF erkannt", gelb „gemischt"); bei erkannten Scans ist die
  Direkteingabe gesperrt (fail-closed).
- **Variable Anrechnungs-Grenzhöhe** (kommunale Satzung, z. B. 1,50 m statt 2,30 m):
  - Neues Eingabefeld „Grenzhöhe" im VG-Modal (projektweit, Default 2,30 m,
    Bereich 0,50–3,00 m). Änderung rechnet alle gespeicherten VG-Berechnungen
    des Projekts automatisch nach.
  - Berechnung liefert zusätzlich `A_anrechenbar` (Fläche ≥ Grenzhöhe).
    Die Vollgeschoss-Beurteilung (2/3-Regel) bleibt unverändert bei 2,30 m
    nach Art. 83 Abs. 7 BayBO.
  - Querschnitt (Modal + PDF) zeigt bei abweichender Grenzhöhe eine zweite
    Linie in Teal mit eigener Schraffur für die anrechenbare Zone.
  - Anteiliger Export nutzt die anrechenbare Fläche; Aufmaßblatt, Export-Dialog,
    VG-Beurteilungsblatt und Methodik-Texte dokumentieren die verwendete
    Grenzhöhe. Bei 2,30 m bleiben alle Ausgaben wortidentisch zu v1.0.
  - Projekt-Schema: optionales `metadata.grenzhoeheAnrechnung` (Schema-Version
    bleibt 2, alte Projekte laden unverändert mit Default 2,30).
- **Rechenweg im Aufmaßprotokoll** (opt-in): Häkchen „Rechenweg anzeigen" im
  Export-Dialog ergänzt explizite Additions-Schritte der Teilflächen je Region
  und der Geschosse zur Gesamtfläche (Bürger-Nachvollziehbarkeit).
- **Rechenweg-Herleitung je Teilfläche** (Teil des Rechenweg-Häkchens):
  rechteckige Teilflächen als „Länge × Breite = Fläche" direkt unter der
  Polygon-Tabelle, unregelmäßige Flächen als Gauß-Koordinatentabelle mit
  Formelzeile auf eigenen Rechenweg-Anhangseiten (Seitenzählung läuft mit;
  manuell korrigierte Flächen: gemessener Wert hergeleitet, angesetzter
  ausgewiesen).

### Geändert
- `test.html` lädt jetzt auch `js/export.js` — die exportAnrechnung-Tests
  liefen vorher nie (Bestandslücke).
- `test.html` rendert und zählt die exportAnrechnung-Testgruppe jetzt mit —
  die Gruppe lief zwar, fehlte aber in Anzeige und Gesamtzahl (Suite zeigt
  jetzt 197 statt 168 Prüfungen).
- `vg-geometrie.js`: doppelte lokale 2,30-Konstanten zu einer Modul-Konstante
  zusammengeführt.

## [1.0.0] — 2026-05-16

Erstes stabiles Release. Solo-Dev-Tool für bayerische Bauämter.

### Hinzugefügt (Phase A8)
- Reproduzierbarer Release-Build via `npm run build-release` (Allowlist-Manifest, SHA256-Integritaetscheck, Self-Verify)
- `version.txt` im Release-ZIP-Root verhindert Update-Endlosschleife bei Erstinstallationen
- `update.ps1`: ZipSlip-Defense vor Expand-Archive (Defense-in-Depth, SHA256-Check fängt's bereits)

### Geändert
- `update.ps1`: selektives `data/`-Exclude — `data/*.example.js`-Updates kommen jetzt beim Kunden an (war: komplettes `data/` ausgeschlossen)
- `DOWNLOAD_URL` zeigt auf das öffentliche Update-Repo (war: `example.com`-Placeholder)
- VERSION von `0.1.0-dev` auf `1.0.0`

### Stand der vorigen Phasen
- A1–A5: VG-Integration (Vollgeschoss-Berechnung Art. 83 Abs. 7 BayBO)
- A6: Lizenz-Workflow mit SHA256-Whitelist auf GitHub Pages
- A7: Vorgänger-VG-Tool als archiviert markiert
- B1–B3: TypeScript-Migration via JSDoc + `tsc --checkJs`

## [0.1.0-dev] — 2026-05-12

### Hinzugefügt
- Phase-0-Skelett: Verzeichnisstruktur, klassische Scripts mit `window.GF.*`-Namespace
- Lizenzsystem aus VG-Tool übernommen, ID-Präfix auf `GF-` umgestellt
- Update-Mechanismus (`update.bat` + `update.ps1`) 1:1 aus VG-Tool
- Plan-Datei und SPEC.md angelegt
- Test-Runner (`test.html`) mit ersten Unit-Tests für `util`, `polygon`, `region`, `projekt`, `lizenz`
- Stubs für PDF-Loading, Region/Geschoss/Polygon-Verwaltung, Projekt-Speicherung, Export
- Auto-Recovery via IndexedDB (Wrapper)

### Bekannte Einschränkungen (Phase 0)
- `lib/pdf.min.js`, `lib/pdf.worker.min.js`, `lib/fflate.min.js` müssen manuell besorgt werden (`lib/README.md`)
- `GF.projekt.speichere/lade` und `GF.export.aufmassprotokoll` sind Stubs (Phase 4/5)
- Keine UI für PDF-Anzeige (Phase 1)
