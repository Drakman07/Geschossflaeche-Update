/* =====================================================================
 * data/kommune.example.js — Stammdaten der Kommune
 * ---------------------------------------------------------------------
 * Kopiere diese Datei zu data/kommune.js und passe die Werte an.
 * Wird vom Tool als Vorbelegung fuer neue Projekte und im Aufmass-
 * protokoll-Deckblatt verwendet.
 *
 * KEINE Bauherr- oder Bauantrags-Daten — nur Beh�rden-Eigendaten,
 * DSGVO-unkritisch.
 *
 * wappenPfad ist relativ zum index.html-Ordner und sollte auf eine
 * Datei in data/ zeigen (z. B. data/wappen.jpg).
 * ===================================================================== */

window.GF_KOMMUNE = {
  name: 'Markt Postbauer-Heng',
  anschrift: {
    strasse: 'Hauptstrasse 1',
    plz: '92353',
    ort: 'Postbauer-Heng'
  },
  bundesland: 'Bayern',
  wappenPfad: 'data/wappen.jpg',
  // Default-Sachbearbeiter (kann pro Projekt geaendert werden,
  // wird zusaetzlich aus LocalStorage geholt).
  defaultSachbearbeiter: ''
};
