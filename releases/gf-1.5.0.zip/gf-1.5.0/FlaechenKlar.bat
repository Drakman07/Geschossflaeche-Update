@echo off
REM ==================================================================
REM  FlaechenKlar Start-Launcher
REM  Prueft beim Start kurz auf Updates und oeffnet danach das Tool.
REM  Siehe launcher.ps1 fuer den Ablauf.
REM ==================================================================
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0launcher.ps1"
