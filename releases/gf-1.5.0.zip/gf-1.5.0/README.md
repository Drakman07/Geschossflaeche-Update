<p align="center">
  <img src="assets/flaechenklar_logo.svg" alt="FlächenKlar" width="420">
</p>

# FlächenKlar

Offline lauffähiges HTML/JS-Werkzeug, mit dem Sachbearbeiter im Bauamt einer bayerischen Kommune **Geschossflächen aus digitalen Bauantrags-PDFs** ermitteln können. Ergebnis ist ein PDF-Aufmaßprotokoll als Berechnungsgrundlage für den Herstellungsbeitrag (Art. 5 KAG Bayern).

*Arbeitstitel bis Mai 2026: gf-Tool / Geschossflächen-Tool. Funktionsumfang und Datenformat sind unverändert.*

**Status:** Pre-Release v0.1.0-dev — Funktionsumfang vollständig, Release-ZIP-Bau steht aus.

## Schnellstart

1. `lib/`-Bibliotheken besorgen (siehe `lib/README.md`)
2. Optional: `data/lizenz.example.js` → `data/lizenz.js` mit eigener Gemeinde-ID
3. Optional: `data/kommune.example.js` → `data/kommune.js` mit Kommunal-Stammdaten
4. `index.html` doppelklicken — öffnet im Default-Browser

## Entwicklung — Type-Check (optional, nur Dev)

Das Tool nutzt JSDoc-Annotationen + TypeScript-Compiler im `--checkJs --noEmit`-Modus für statische Type-Prüfung. Die App selbst läuft weiter ohne Node/npm direkt aus `index.html`; die Type-Pipeline ist rein Dev-Tooling.

```bash
npm install        # einmalig — installiert TypeScript + Lib-Typen als devDeps
npm run typecheck  # prüft alle js/*.js mit @ts-check
```

Strict-Mode (`strict: true`) ist aktuell deaktiviert; iterative Aktivierung ist als Folge-Schritt geplant.

## Verzeichnisse

```
FlaechenKlar/
├── index.html              # App-Einstieg (Doppelklick)
├── test.html               # Test-Runner
├── update.bat / update.ps1 # Windows-Updater
├── package.json            # Dev-Tooling (TypeScript-Typecheck)
├── tsconfig.json           # JSDoc + checkJs Konfiguration
├── data/                   # Kunden-spezifisch, NICHT im Repo (außer .example.js)
├── js/                     # Klassische Scripts, alle unter window.GF.* + @ts-check
├── types/                  # JSDoc-Typen (.d.ts) für GF-Namespace
├── lib/                    # Offline-Drittlibs (pdf.js, jsPDF, fflate)
├── css/                    # Stylesheet
├── tools/                  # build-allowlist.js (Hash-Generator)
└── docs/                   # SPEC.md + Benutzerhandbuch
```

## Verhältnis zum Vollgeschoss-Tool

Eigenständige Anwendung mit eigenem Repo und eigenem Vertrieb. Teilt sich aber das **Lizenz-System** (Whitelist-Hash gegen `allowlist.json` auf GitHub Pages) — Code 1:1 vom VG-Tool übernommen, ID-Präfix `GF-` statt `VG-`. Detail siehe `docs/SPEC.md`.

## Was das Tool NICHT tut

- Beitragsbescheid-Berechnung (Satzungsanwendung ist Aufgabe der Behörde)
- Automatische Außenkontur-Erkennung (KI/ML bewusst nicht im MVP)
- Cloud-Speicherung / Online-Verarbeitung (Datenschutz)

## Lizenz

Siehe `LICENSE.md`. Stichwort: proprietär, kundenspezifisch lizenziert via ID + Whitelist.
