/* =====================================================================
 * data/lizenz.example.js — VORLAGE fuer neue Auslieferungen
 * ---------------------------------------------------------------------
 * Kopiere diese Datei zu data/lizenz.js und setze die Gemeinde-ID ein.
 *
 * ID-Format: GF-XX-YYYY-NNN
 *   GF-      fester Praefix (Geschossflaechen-Tool)
 *   XX       zweistelliges Gemeinde-Kuerzel
 *   YYYY     Ausstellungsjahr
 *   NNN      laufende Nummer (3-stellig)
 *
 * Beispiele:
 *   GF-XX-2026-001   (erste Auslieferung des Jahres)
 *   GF-XY-2026-002   (zweite Auslieferung des Jahres)
 *
 * Hier stehen bewusst nur Platzhalter: diese Datei wird mit ausgeliefert
 * (auch im oeffentlichen Demo-ZIP). Echte Kunden-IDs gehoeren
 * ausschliesslich in privat/kunden.json.
 *
 * Beim Update-Check hasht die App diese ID via SHA256 und prueft den
 * Hash gegen die oeffentliche allowlist.json. Die ID selbst landet
 * niemals als Klartext auf einem Server.
 *
 * WICHTIG: Bei Auslieferung MUSS gleichzeitig der SHA256-Hash dieser
 * ID in die allowlist.json auf gh-pages aufgenommen werden, sonst
 * verweigert die App bzw. der update.bat das Update.
 *
 * ZUSATZMODULE (z. B. Beitragsbescheid): NICHT von Hand eintragen.
 * module + sig sind signiert und werden mit tools/build-lizenz.js aus
 * der kunden.json generiert (Feld "module": ["bescheid"]). Eine von
 * Hand ergaenzte Modulliste ohne gueltige sig bleibt gesperrt.
 *
 *   window.GF_LIZENZ = {
 *     id: 'GF-XX-YYYY-NNN',
 *     module: ['bescheid'],
 *     sig: '<64 Hex-Zeichen, von build-lizenz.js berechnet>'
 *   };
 * ===================================================================== */

window.GF_LIZENZ = {
  id: 'GF-XX-YYYY-NNN'
};
