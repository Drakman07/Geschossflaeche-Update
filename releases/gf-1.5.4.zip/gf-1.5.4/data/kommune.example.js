/* =====================================================================
 * data/kommune.example.js — Stammdaten der Kommune(n)
 * ---------------------------------------------------------------------
 * Kopiere diese Datei zu data/kommune.js und passe die Werte an — ODER,
 * bequemer: erzeuge sie direkt im Tool ueber den Knopf "Stammdaten"
 * (Anschrift, Wappen, Sachbearbeiter selbst pflegen; auch mehrere
 * Gemeinden fuer eine Verwaltungsgemeinschaft).
 *
 * Wird als Vorbelegung fuer neue Projekte, im Aufmassprotokoll-Deckblatt
 * und im Beitragsbescheid-Briefkopf verwendet.
 *
 * KEINE Bauherr- oder Bauantrags-Daten — nur Beh�rden-Eigendaten,
 * DSGVO-unkritisch.
 * ===================================================================== */

// -- Empfohlene Mehr-Profil-Form (Verwaltungsgemeinschaft-faehig) --------
// GF.kommune.* normalisiert beides; ein spaeter geoeffnetes Projekt friert
// die gewaehlte Gemeinde ein (Schema v5), bleibt also korrekt.
window.GF_KOMMUNE = {
  schemaVersion: 2,
  defaultProfilId: 'p-postbauer',
  profile: [
    {
      id: 'p-postbauer',                 // stabile, namensunabhaengige ID
      name: 'Markt Postbauer-Heng',
      anschrift: { strasse: 'Hauptstrasse 1', plz: '92353', ort: 'Postbauer-Heng' },
      bundesland: 'Bayern',
      // Wappen als eingebettete Base64-DataURL (der "Stammdaten"-Dialog erzeugt sie).
      // Leer lassen, wenn kein Wappen gedruckt werden soll.
      wappen: null,
      defaultSachbearbeiter: '',
      // Telefon/E-Mail des Sachbearbeiters -- werden im Bescheid rechts oben
      // im Briefkopf abgedruckt (Ansprechpartner-Block). Optional.
      defaultSachbearbeiterTelefon: '',
      defaultSachbearbeiterEmail: '',
      // Unterschriftszeile des Beitragsbescheids: Zusatz ist der Zeichnungs-
      // vermerk ueber dem Unterschriftsstrich (z. B. "i. A.", "i. V."), Name
      // der Unterzeichner, wenn er vom Sachbearbeiter abweicht (leer = der
      // Sachbearbeiter unterschreibt).
      defaultUnterschriftZusatz: '',
      defaultUnterschriftName: '',
      // Amtsbezeichnung fuer die Unterschriftszeile des Beitragsbescheids
      // (z. B. "Kämmerer", "Leiter des Bauamts"). Optional, leer = Fallback
      // "Sachbearbeiter/in".
      defaultUnterschriftAmtsbezeichnung: ''
      // Optional (nur mit Beitragsbescheid-Modul): dauerhafte Saetze je Gemeinde.
      // Werden beim Erstellen eines Bescheids automatisch vorbefuellt. Am besten
      // ueber den "Stammdaten"-Dialog pflegen (Abschnitt "Beitragsbescheid-Saetze").
      // bescheid: {
      //   wasserversorgung: { satzungName: 'BGS-WAS vom ...', satzungVom: '2020-01-01',
      //                       beitragssatzGrundstueckProQM: 3.50, beitragssatzGeschossflaecheProQM: 12.00 },
      //   entwaesserung:    { satzungName: 'BGS-EWS vom ...', satzungVom: '2020-01-01',
      //                       beitragssatzGrundstueckProQM: 4.20, beitragssatzGeschossflaecheProQM: 14.00 }
      // }
    }
    // Weitere Gemeinden derselben Verwaltungsgemeinschaft hier ergaenzen.
  ]
};

// -- Alt-Einzelform (weiterhin gueltig) ----------------------------------
// window.GF_KOMMUNE = {
//   name: 'Markt Postbauer-Heng',
//   anschrift: { strasse: 'Hauptstrasse 1', plz: '92353', ort: 'Postbauer-Heng' },
//   bundesland: 'Bayern',
//   wappenPfad: 'data/wappen.jpg',   // Dateipfad statt eingebettetem Wappen
//   defaultSachbearbeiter: ''
// };
