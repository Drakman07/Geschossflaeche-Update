@echo off
REM ==================================================================
REM  FlaechenKlar Start-Launcher
REM  Prueft beim Start kurz auf Updates und oeffnet danach das Tool.
REM  Siehe launcher.ps1 fuer den Ablauf.
REM
REM  Sichtbarkeit: powershell.exe lief hier frueher per
REM  "start ... -WindowStyle Hidden" losgeloest im Hintergrund. Damit
REM  war JEDER Startfehler unsichtbar - blockierte eine Gruppen-
REM  richtlinie, AppLocker/SRP, eine Zonenmarkierung oder Defender-ASR
REM  den PowerShell-Start, passierte fuer den Kunden sichtbar nichts.
REM  Zusaetzlich verschluckt "start" den Exit-Code, ein Ersatzweg war
REM  also gar nicht moeglich. Jetzt laeuft powershell.exe blockierend
REM  in DIESEM Fenster, die Ausgabe geht nach FlaechenKlar-Start.log,
REM  und bei jedem Exit-Code ungleich 0 oeffnet diese Datei das Tool
REM  ersatzweise selbst.
REM
REM  Zeilenenden: CRLF, Zeichensatz ASCII. cmd.exe bricht mehrzeilige
REM  for-/if-Bloecke bei LF ab. .gitattributes haelt das repo-fest.
REM ==================================================================

REM --- Self-Replace-Finalizer -------------------------------------------
REM  Staged Bootstrap-Zwillinge (X.neu -> X) uebernehmen, solange das Ziel
REM  nicht als Prozess laeuft UND der Zwilling nicht leer ist (abgebrochener/
REM  unvollstaendiger Download wird uebersprungen). FlaechenKlar.bat.neu
REM  bleibt hier aussen vor - dafuer gibt es weiter unten eine eigene Naht.
REM  Fehler still ignoriert.
for %%F in (launcher.ps1 update.ps1 update.bat) do if exist "%~dp0%%F.neu" for %%A in ("%~dp0%%F.neu") do if %%~zA GTR 0 move /Y "%~dp0%%F.neu" "%~dp0%%F" >nul 2>&1

REM  Testhaken: nur finalisieren, Tool NICHT starten.
if /I "%~1"=="finalize-only" goto :ende

REM --- Eigener Zwilling: Tausch NUR als letzte Anweisung ------------------
REM  cmd.exe liest diese Datei waehrend des Laufs immer wieder neu, an einem
REM  gemerkten Byte-Offset. Wird sie mitten im Lauf ersetzt, liest cmd im
REM  neuen Inhalt am alten Offset weiter - gemessen: der Rest der Datei
REM  wird stillschweigend uebersprungen oder ein Bruchstueck ausgefuehrt.
REM  Frueher war das ungefaehrlich, weil "start" die .bat nach Millisekunden
REM  beendete und launcher.ps1 den Tausch erst danach machte. Jetzt parkt
REM  cmd fuer die ganze Laufzeit des Launchers in der Aufrufzeile weiter
REM  unten - der Tausch muss deshalb HIER passieren, und zwar so, dass
REM  danach nicht mehr aus der Datei gelesen wird: alles in EINER Zeile,
REM  abgeschlossen mit start + exit. launcher.ps1 laesst FlaechenKlar.bat
REM  in Ruhe, solange FK_BAT_LAEUFT gesetzt ist.
REM
REM  Der Neustart haengt per && am Erfolg des move. Mit einfachem &
REM  liefe er auch nach einem gescheiterten move - der neue Prozess faende
REM  denselben Zwilling wieder, scheiterte wieder und startete wieder:
REM  eine Neustart-Schleife ohne Abbruch, aus der der Kunde nur ueber den
REM  Task-Manager herauskommt. Scheitert der move (Programmordner fuer
REM  diesen Nutzer nur lesbar, Schreibschutz auf der Zieldatei, Sperre
REM  durch Virenscanner oder Backup-Agent), laeuft cmd stattdessen in der
REM  unveraenderten alten Datei weiter - der Offset bleibt gueltig, der
REM  Start laeuft normal, und der Zwilling wird beim naechsten Mal erneut
REM  versucht.
REM
REM  Der ||-Zweig faengt den letzten wortlosen Fall: der Tausch gelingt,
REM  aber der Neustart nicht (frischer Inhalt kurz vom Virenscanner
REM  gehalten). Ohne ihn endete die Datei per exit /b 0, ohne dass etwas
REM  aufgeht - ausgerechnet direkt nach einem Update, wo der Kunde am
REM  ehesten annimmt, das Update habe das Programm zerschossen. Alles
REM  bleibt inline: nach dem Tausch darf nur noch laufen, was bereits im
REM  Speicher steht, also kein goto und kein Label.
if exist "%~dp0FlaechenKlar.bat.neu" for %%A in ("%~dp0FlaechenKlar.bat.neu") do if %%~zA GTR 0 (move /Y "%~dp0FlaechenKlar.bat.neu" "%~dp0FlaechenKlar.bat" >nul 2>&1 && (start "" "%~dp0FlaechenKlar.bat" || (echo  FEHLER: Neustart nach dem Update fehlgeschlagen. Bitte FlaechenKlar.bat erneut doppelklicken. & pause) & exit /b 0))

set "FK_BAT_LAEUFT=1"

title FlaechenKlar wird gestartet ...
echo.
echo  FlaechenKlar wird gestartet.
echo  Dieses Fenster schliesst sich von selbst, sobald der Start
echo  abgeschlossen ist.
echo.

REM --- Protokolldatei waehlen -------------------------------------------
REM  Erste Wahl: neben dieser Datei - der Support kann dann nach einer
REM  Datei fragen, die es garantiert gibt. Ist sie dort nicht beschreibbar,
REM  weicht das Protokoll nach %TEMP% aus. Faellt auch das aus, laeuft der
REM  Start ohne Umleitung weiter.
set "FKLOG=%~dp0FlaechenKlar-Start.log"
call :oeffneProtokoll
if defined FKLOG goto :logbereit
set "FKLOG=%TEMP%\FlaechenKlar-Start.log"
call :oeffneProtokoll
:logbereit

REM  Pfad an launcher.ps1 und update.bat durchreichen: die duerfen den
REM  Kunden nicht zu einer Datei schicken, die im Ausweichfall woanders
REM  liegt.
set "FK_STARTLOG=%FKLOG%"

set "FKVER=unbekannt"
if exist "%~dp0version.txt" for /f "usebackq tokens=1 delims= " %%V in ("%~dp0version.txt") do set "FKVER=%%V"

REM  Sentinel vor dem Aufruf: scheitert die Umleitung trotz Probe (z.B.
REM  weil jemand die Protokolldatei in genau diesem Moment sperrt), bricht
REM  cmd die ganze Zeile ab - der call laeuft dann NIE. Ohne Sentinel
REM  stuende %ERRORLEVEL% noch auf der 0 der Probe, der Start saehe
REM  erfolgreich aus und das Fenster ginge wortlos zu. Mit Sentinel bleibt
REM  90 stehen und der Ersatzweg greift.
cmd /c exit /b 90
if defined FKLOG (
  call :starteLauncher >>"%FKLOG%" 2>&1
) else (
  call :starteLauncher
)
set "FKRC=%ERRORLEVEL%"
if defined FKLOG (>>"%FKLOG%" echo  Exit-Code launcher.ps1: %FKRC%) 2>nul

REM  Achtung: "if errorlevel 1" taugt hier nicht. Fehlt die Skriptdatei,
REM  liefert powershell.exe einen NEGATIVEN Code (gemessen: -196608), und
REM  "if errorlevel 1" waere dann blind. Darum auf Textgleichheit pruefen.
if not "%FKRC%"=="0" goto :ersatzweg
goto :ende

:starteLauncher
echo ==================================================================
echo  FlaechenKlar Start-Protokoll
echo  Datum:   %DATE% %TIME%
echo  Version: %FKVER%
echo  Ordner:  "%~dp0"
echo ==================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher.ps1"
exit /b %ERRORLEVEL%

REM --- Protokollpfad pruefen --------------------------------------------
REM  Zwei Proben, weil jede allein eine Luecke hat:
REM    copy /y nul  legt die Datei leer an und liefert einen echten
REM                 Errorlevel - faengt den schreibgeschuetzten Fall, den
REM                 eine reine Existenzprobe durchwinkt.
REM    dir /a-d     faengt den Fall "am Pfad liegt ein Ordner", den copy
REM                 faelschlich als Erfolg meldet.
REM  Eine fehlgeschlagene Umleitung setzt KEINEN Errorlevel (gemessen),
REM  taugt als Probe also nicht. "if exist pfad\" meldet auch bei einer
REM  normalen Datei einen Ordner und taugt ebenfalls nicht.
:oeffneProtokoll
copy /y nul "%FKLOG%" >nul 2>&1
if errorlevel 1 set "FKLOG="
if defined FKLOG dir /a-d "%FKLOG%" >nul 2>&1
if defined FKLOG if errorlevel 1 set "FKLOG="
exit /b 0

REM --- Ersatzweg --------------------------------------------------------
REM  Der Launcher ist nicht durchgelaufen. Das Tool muss trotzdem aufgehen.
:ersatzweg
echo.
echo  Der Start ueber PowerShell ist fehlgeschlagen (Code %FKRC%).
if defined FKLOG echo  Einzelheiten stehen in: "%FKLOG%"
if defined FKLOG echo  Bitte senden Sie diese Datei an info@flaechenklar.de.
echo.
echo  FlaechenKlar wird jetzt auf direktem Weg geoeffnet ...
if defined FK_START_TESTMODUS (
  echo  TESTMODUS: Ersatzweg wuerde jetzt start.html oeffnen.
  goto :ende
)
call :oeffneErsatz
echo.
echo  Druecken Sie eine Taste, um dieses Fenster zu schliessen.
pause >nul
goto :ende

REM  Kein Verlass auf den Errorlevel von "start": es meldet Erfolg, sobald
REM  ShellExecute die Anfrage entgegengenommen hat - auch wenn mangels
REM  .html-Zuordnung nur der "Oeffnen mit"-Dialog erscheint. Bei einer
REM  fehlenden Datei bleibt es umgekehrt an einem modalen Fehlerdialog
REM  stehen (gemessen: kehrte in 110 s nicht zurueck). Deshalb vorher
REM  "if exist" statt einer Errorlevel-Kaskade danach.
REM  start.html zuerst: es haengt ?start=fk an, damit js/updates.js kein
REM  Hinweis-Banner zeigt.
:oeffneErsatz
if exist "%~dp0start.html" goto :ersatzStart
if exist "%~dp0index.html" goto :ersatzIndex
echo  FEHLER: Weder start.html noch index.html im Programmordner gefunden.
exit /b 1
:ersatzStart
start "" "%~dp0start.html"
exit /b 0
:ersatzIndex
start "" "%~dp0index.html"
exit /b 0

:ende
