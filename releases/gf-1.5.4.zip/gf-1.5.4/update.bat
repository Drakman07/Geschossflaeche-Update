@echo off
REM ==================================================================
REM  FlaechenKlar Companion-Updater
REM  Doppelklick startet das PowerShell-Update-Skript.
REM  Kundendaten im Ordner data\ bleiben unangetastet.
REM
REM  Zeilenenden: CRLF. cmd.exe bricht mehrzeilige if-Bloecke bei LF ab.
REM ==================================================================
echo.
echo  FlaechenKlar Update
echo  ===================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
set "FKRC=%ERRORLEVEL%"

REM  Textvergleich statt "if errorlevel 1": fehlt die Skriptdatei,
REM  liefert powershell.exe einen negativen Code, den "if errorlevel"
REM  nicht erkennt.
if not "%FKRC%"=="0" (
  echo.
  echo  Das Update wurde NICHT abgeschlossen ^(Code %FKRC%^).
  echo  Ihre installierte Version laeuft unveraendert weiter.
)

REM  Abschluss ins Start-Protokoll schreiben, damit der Support einen
REM  fehlgeschlagenen Update-Lauf auch spaeter noch sieht. Den Pfad gibt
REM  FlaechenKlar.bat per FK_STARTLOG vor - sie kann nach %TEMP% ausgewichen
REM  sein. Ohne die Variable (Doppelklick direkt auf update.bat) bleibt der
REM  Programmordner. Schlaegt die Umleitung fehl, wird das still uebergangen.
set "FKUPDLOG=%FK_STARTLOG%"
if not defined FKUPDLOG set "FKUPDLOG=%~dp0FlaechenKlar-Start.log"
(>>"%FKUPDLOG%" echo [update.bat] %DATE% %TIME% Exit-Code %FKRC%) 2>nul

echo.
echo  Druecken Sie eine Taste, um dieses Fenster zu schliessen.
pause >nul
