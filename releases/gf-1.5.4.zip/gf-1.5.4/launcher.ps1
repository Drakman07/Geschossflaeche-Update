# ===================================================================
#  FlaechenKlar Start-Launcher (PowerShell)
#  -------------------------------------------------------------------
#  Wird von FlaechenKlar.bat aufgerufen. Ablauf:
#    0. Staged Bootstrap-Zwillinge (X.neu -> X) uebernehmen (best effort,
#       still) -- eigene Naht, siehe UebernehmeNeu weiter unten.
#    1. update.ps1 -NurPruefen als eigener Prozess starten (Exit-Code
#       auswerten) -- dieselbe Pruef-Naht wie der manuelle Weg, keine
#       zweite Lizenz-/Versionslogik hier.
#    2. Exit-Code 10 (Update verfuegbar+berechtigt) -> changelog.json
#       laden (best effort, rein Anzeige), Ja/Nein-Dialog zeigen.
#    3. Ja -> update.bat sichtbar ausfuehren (bestehende UX/Meldungen),
#       warten. Nein oder alles andere -> ohne Ruecksprache weiter.
#    4. Tool oeffnen (start.html -> index.html?start=fk).
#
#  Netzwerkfehler/Timeout an jeder Stelle sind KEIN Fehlerfall fuer den
#  Start: das Tool bleibt eine Offline-Anwendung und darf nie haengen
#  bleiben oder den Start blockieren.
#
#  Exit-Codes -- FlaechenKlar.bat wertet sie aus und oeffnet bei allem
#  ungleich 0 das Tool ersatzweise selbst:
#     0  = Tool wurde geoeffnet (auch wenn das Update uebersprungen wurde)
#     3  = Tool liess sich auf keinem Weg oeffnen
#     4  = unerwarteter Fehler, Tool liess sich auch danach nicht oeffnen
# ===================================================================

param([switch]$NurFinalize)

$ErrorActionPreference = 'Stop'

$installDir = $PSScriptRoot

# --- Self-Replace-Finalizer -------------------------------------------------
# Staged Bootstrap-Zwillinge (X.neu) uebernehmen, solange das Ziel NICHT als
# Prozess laeuft. launcher.ps1.neu bleibt bewusst aussen vor (dieses Skript
# laeuft gerade) - die uebernimmt FlaechenKlar.bat vor dem Start. Alles
# best-effort und still: ein Fehler darf den Start nie blockieren.
function UebernehmeNeu {
    param([string[]]$Namen)
    foreach ($name in $Namen) {
        try {
            $neu = Join-Path $installDir ($name + '.neu')
            if ((Test-Path -LiteralPath $neu) -and ((Get-Item -LiteralPath $neu).Length -gt 0)) {
                Move-Item -LiteralPath $neu -Destination (Join-Path $installDir $name) -Force
            }
        } catch { }
    }
}
# FlaechenKlar.bat nur uebernehmen, wenn sie NICHT gerade laeuft. Seit die
# .bat blockierend auf diesen Launcher wartet, parkt cmd.exe die ganze Zeit
# in ihrer Aufrufzeile; ein Tausch hier wuerde cmd im neuen Inhalt am alten
# Byte-Offset weiterlesen lassen (gemessen: Rest der Datei faellt aus, die
# Exit-Code-Auswertung und der Ersatzweg entfallen). Die laufende .bat
# setzt FK_BAT_LAEUFT und tauscht ihren Zwilling selbst - als allerletzte
# Anweisung, gefolgt von einem Neustart.
$eigene = @('update.ps1', 'update.bat')
if (-not $env:FK_BAT_LAEUFT) { $eigene = @('FlaechenKlar.bat') + $eigene }
UebernehmeNeu -Namen $eigene

if ($NurFinalize) { exit 0 }

# --- TLS 1.2 erzwingen (nur PS 5.1 / .NET Framework relevant) ------------
# Gleiche Naht wie in update.ps1: PS 5.1 startet sonst mit TLS 1.0, der
# Update-Server spricht nur TLS 1.2+. Unter PowerShell 7 wirkungslos, aber
# unschaedlich (IWR/IRM nutzen dort HttpClient und ignorieren dieses Flag).
# Hier betrifft es nur Changelog und Versionsanzeige (beide best effort);
# try/catch bleibt bewusst still schluckend - der Start darf nie blockieren.
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$updatePs1    = Join-Path $installDir 'update.ps1'
$updateBat    = Join-Path $installDir 'update.bat'
$startHtml    = Join-Path $installDir 'start.html'
$versionDatei = Join-Path $installDir 'version.txt'
$changelogUrl = 'https://download.flaechenklar.de/changelog.json'
$versionUrl   = 'https://download.flaechenklar.de/version.txt'

# Merker fuer den trap weiter unten: steht das Tool schon offen, darf ein
# spaeterer Fehler es nicht ein zweites Mal aufmachen.
$script:toolOffen = $false

# --- Tool oeffnen -----------------------------------------------------------
# Mehrstufig und garantiert wurffrei. Frueher war das ein nacktes
# Start-Process an drei ungeschuetzten Aufrufstellen: fehlte die
# .html-Zuordnung oder war der Standardbrowser per Richtlinie gesperrt,
# starb das Skript unter $ErrorActionPreference = 'Stop' terminierend --
# und der Kunde sah gar nichts. Jede Stufe ist deshalb einzeln gekapselt;
# die Funktion wirft nie, sondern meldet per Rueckgabewert, ob das Tool
# offen ist.
function OeffneTool {
    $ziel = $startHtml
    if (-not (Test-Path -LiteralPath $ziel)) {
        $ziel = Join-Path $installDir 'index.html'
    }
    if (-not (Test-Path -LiteralPath $ziel)) {
        Write-Host ('FEHLER: Weder start.html noch index.html gefunden in ' + $installDir)
        return $false
    }

    # Stufe 1: Dateizuordnung fuer .html (Normalfall).
    try {
        Start-Process -FilePath $ziel -ErrorAction Stop
        $script:toolOffen = $true
        return $true
    } catch {
        Write-Host ('Stufe 1 (Dateizuordnung) fehlgeschlagen: ' + $_.Exception.Message)
    }

    # Stufe 2: URL-Handler. Greift auch ohne .html-Zuordnung, weil url.dll
    # den fuer http hinterlegten Standardbrowser benutzt.
    try {
        Start-Process -FilePath 'rundll32.exe' `
            -ArgumentList ('url.dll,FileProtocolHandler "' + $ziel + '"') -ErrorAction Stop
        $script:toolOffen = $true
        return $true
    } catch {
        Write-Host ('Stufe 2 (url.dll) fehlgeschlagen: ' + $_.Exception.Message)
    }

    # Stufe 3: Standardbrowser ueber die Registry aufloesen und direkt mit
    # dem Dateipfad aufrufen.
    try {
        $progId = (Get-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice' -ErrorAction Stop).ProgId
        $cmd = (Get-ItemProperty -Path ('Registry::HKEY_CLASSES_ROOT\' + $progId + '\shell\open\command') -ErrorAction Stop).'(default)'
        $m = [regex]::Match($cmd, '^\s*"([^"]+)"')
        if (-not $m.Success) { $m = [regex]::Match($cmd, '^\s*(\S+)') }
        if ($m.Success) {
            Start-Process -FilePath $m.Groups[1].Value `
                -ArgumentList ('"' + $ziel + '"') -ErrorAction Stop
            $script:toolOffen = $true
            return $true
        }
        Write-Host 'Stufe 3 (Standardbrowser): Befehlszeile nicht lesbar.'
    } catch {
        Write-Host ('Stufe 3 (Standardbrowser) fehlgeschlagen: ' + $_.Exception.Message)
    }

    # Stufe 4: bekannte Browser ueber die App-Paths der Registry probieren.
    foreach ($exe in @('msedge.exe', 'chrome.exe', 'firefox.exe')) {
        try {
            Start-Process -FilePath $exe -ArgumentList ('"' + $ziel + '"') -ErrorAction Stop
            $script:toolOffen = $true
            return $true
        } catch { }
    }

    Write-Host 'FEHLER: Kein Weg gefunden, das Tool zu oeffnen (Stufen 1-4 erschoepft).'
    return $false
}

# Fehlermeldung, die der Kunde auch dann sieht, wenn er nur auf die .bat
# doppelklickt: Konsolenzeile (landet im Start-Protokoll) plus MessageBox.
function MeldeStartFehler {
    param([string]$Text)
    Write-Host ''
    Write-Host ('FEHLER: ' + $Text)
    # FlaechenKlar.bat reicht den tatsaechlichen Protokollpfad per
    # FK_STARTLOG durch. Ohne das stuende hier "im Programmordner", obwohl
    # die .bat bei nicht beschreibbarem Ordner nach %TEMP% ausgewichen sein
    # kann - der Kunde suchte dann an der falschen Stelle.
    $protokoll = $env:FK_STARTLOG
    if (-not $protokoll) { $protokoll = Join-Path $installDir 'FlaechenKlar-Start.log' }
    Write-Host ('Protokoll: ' + $protokoll)
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $hinweis = $Text + "`n`nEinzelheiten stehen in:`n" + $protokoll +
            "`n`nBitte senden Sie diese Datei an info@flaechenklar.de."
        [System.Windows.Forms.MessageBox]::Show(
            $hinweis, 'FlaechenKlar', [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    } catch { }
}

# Gemeinsame Ausstiegsnaht: alle drei Stellen, die frueher blank
# "OeffneTool; exit 0" gemacht haben, laufen jetzt hierueber.
function OeffneUndBeende {
    if (OeffneTool) { exit 0 }
    MeldeStartFehler 'Das Tool liess sich nicht oeffnen.'
    exit 3
}

# Letztes Netz: jeder terminierende Fehler ab hier landet als Text im
# Start-Protokoll, und das Tool wird trotzdem noch geoeffnet.
trap {
    # Ein trap gilt fuer den ganzen Scope, also auch fuer den Finalizer-Block
    # weiter oben. Ohne diese Zeile wuerde ein -NurFinalize-Lauf bei einem
    # Fehler dort das Tool oeffnen und 3 oder 4 liefern - die Zusicherung
    # "finalize-only startet nichts" haengt daran.
    if ($NurFinalize) { exit 0 }
    Write-Host ''
    Write-Host ('UNERWARTETER FEHLER: ' + $_.Exception.Message)
    try { Write-Host ('  ' + $_.InvocationInfo.PositionMessage) } catch { }
    if ($script:toolOffen) { exit 0 }
    if (OeffneTool) { exit 0 }
    MeldeStartFehler 'Das Tool liess sich nach einem unerwarteten Fehler nicht oeffnen.'
    exit 4
}

Write-Host ('launcher.ps1 gestartet in ' + $installDir)

if (-not (Test-Path $updatePs1)) {
    # Unvollstaendige Installation -- Start nicht blockieren.
    Write-Host 'Hinweis: update.ps1 fehlt, Update-Pruefung wird uebersprungen.'
    OeffneUndBeende
}

# --- Schritt 1: Pruefung als eigener Prozess (NICHT per & aufrufen --
# update.ps1 beendet sich selbst per exit; im selben Prozess aufgerufen
# wuerde das den Launcher mitbeenden, bevor er reagieren kann). --------
$exitCode = 0
$protOut = Join-Path $env:TEMP ('fk-pruef-out-' + $PID + '.txt')
$protErr = Join-Path $env:TEMP ('fk-pruef-err-' + $PID + '.txt')
try {
    $argStr = '-NoProfile -ExecutionPolicy Bypass -File "' + $updatePs1 + '" -NurPruefen'
    # -NoNewWindow statt -WindowStyle Hidden: PowerShell 5.1 laesst die
    # Umleitung nur so zu (-WindowStyle verlangt UseShellExecute, Redirect
    # verbietet es). Dadurch landen die Klartextmeldungen von update.ps1
    # (TLS-Fehler, Wartungsserver nicht erreichbar) im Start-Protokoll
    # statt im Nichts.
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argStr `
        -NoNewWindow -Wait -PassThru `
        -RedirectStandardOutput $protOut -RedirectStandardError $protErr
    $exitCode = $proc.ExitCode
} catch {
    Write-Host ('Update-Pruefung nicht ausfuehrbar: ' + $_.Exception.Message)
    $exitCode = 0
} finally {
    foreach ($datei in @($protOut, $protErr)) {
        try {
            if (Test-Path -LiteralPath $datei) {
                Get-Content -LiteralPath $datei | ForEach-Object {
                    if ($_ -ne '') { Write-Host ('  [pruefung] ' + $_) }
                }
                Remove-Item -LiteralPath $datei -ErrorAction SilentlyContinue
            }
        } catch { }
    }
}
Write-Host ('Update-Pruefung Exit-Code: ' + $exitCode)

if ($exitCode -ne 10) {
    OeffneUndBeende
}

# --- Schritt 2: Changelog laden (best effort, reine Anzeige) ----------
$lokal = '0.0.0'
if (Test-Path $versionDatei) {
    $lokal = (Get-Content $versionDatei -First 1).Trim()
}

function VersionsTeile([string]$v) {
    $m = [regex]::Match($v, '^(\d+)\.(\d+)\.(\d+)')
    if ($m.Success) {
        return @([int]$m.Groups[1].Value, [int]$m.Groups[2].Value, [int]$m.Groups[3].Value)
    }
    return @(0, 0, 0)
}

function VersionGroesserAls([string]$a, [string]$b) {
    $ta = VersionsTeile $a
    $tb = VersionsTeile $b
    for ($i = 0; $i -lt 3; $i++) {
        if ($ta[$i] -gt $tb[$i]) { return $true }
        if ($ta[$i] -lt $tb[$i]) { return $false }
    }
    return $false
}

$MAX_PUNKTE = 8
$punkte = @()
try {
    $changelog = Invoke-RestMethod -Uri $changelogUrl -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    $neuere = @($changelog | Where-Object { VersionGroesserAls $_.version $lokal })
    $neuere = $neuere | Sort-Object -Property @{ Expression = { [version]$_.version } } -Descending
    $gekappt = $false
    foreach ($eintrag in $neuere) {
        foreach ($p in $eintrag.punkte) {
            if ($punkte.Count -ge $MAX_PUNKTE) { $gekappt = $true; break }
            $punkte += ('- ' + $p)
        }
        if ($gekappt) { break }
    }
    if ($gekappt) {
        $punkte += '- sowie weitere Verbesserungen aus aelteren Versionen'
    }
} catch {
    # Changelog ist reine Anzeige -- Ladefehler darf den Dialog nicht verhindern.
}

$neueVersion = '?'
try {
    $remote = Invoke-WebRequest -Uri $versionUrl -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    $neueVersion = (($remote.Content -split "`r?`n")[0]).Trim()
} catch {
    # Reine Anzeige -- update.ps1 hat die Verfuegbarkeit bereits per Exit-Code 10 belegt.
}

# --- Schritt 3: Ja/Nein-Dialog ------------------------------------------
# Ab hier in try/finally: ein Fehler in Add-Type/MessageBox/Start-Process
# (z.B. fehlendes update.bat) darf OeffneUndBeende nicht verhindern -- sonst
# bliebe der Start komplett aus, statt nur das Update zu ueberspringen.
try {
    Add-Type -AssemblyName System.Windows.Forms

    $text = 'FlaechenKlar ' + $neueVersion + ' ist verfuegbar (installiert: ' + $lokal + ').'
    if ($punkte.Count -gt 0) {
        $text += "`n`nNeu seit Ihrer Version:`n" + ($punkte -join "`n")
    }
    $text += "`n`nJetzt aktualisieren?"

    $antwort = [System.Windows.Forms.MessageBox]::Show(
        $text, 'FlaechenKlar Update', [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question)

    if ($antwort -eq [System.Windows.Forms.DialogResult]::Yes -and (Test-Path $updateBat)) {
        # Sichtbares Fenster: Kunde soll "Update erfolgreich" lesen koennen.
        # update.bat statt update.ps1 direkt -- uebernimmt die vorhandene
        # Konsolen-UX (Banner, Abschlussmeldung, Tastendruck) unveraendert.
        Start-Process -FilePath $updateBat -Wait
    }
} catch {
    Write-Host ('Update-Dialog uebersprungen: ' + $_.Exception.Message)
} finally {
    OeffneUndBeende
}
