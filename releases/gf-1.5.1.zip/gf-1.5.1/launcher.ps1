# ===================================================================
#  FlaechenKlar Start-Launcher (PowerShell)
#  -------------------------------------------------------------------
#  Wird von FlaechenKlar.bat aufgerufen. Ablauf:
#    1. update.ps1 -NurPruefen als eigener Prozess starten (Exit-Code
#       auswerten) -- dieselbe Pruef-Naht wie der manuelle Weg, keine
#       zweite Lizenz-/Versionslogik hier.
#    2. Exit-Code 10 (Update verfuegbar+berechtigt) -> changelog.json
#       laden (best effort, rein Anzeige), Ja/Nein-Dialog zeigen.
#    3. Ja -> update.bat sichtbar ausfuehren (bestehende UX/Meldungen),
#       warten. Nein oder alles andere -> ohne Ruecksprache weiter.
#    4. Tool oeffnen (start.html -> index.html?start=fk).
#
#  Netzwerkfehler/Timeout an jeder Stelle sind KEIN Fehlerfall fuer den
#  Start: das Tool bleibt eine Offline-Anwendung und darf nie haengen
#  bleiben oder den Start blockieren.
# ===================================================================

$ErrorActionPreference = 'Stop'

# --- TLS 1.2 erzwingen (nur PS 5.1 / .NET Framework relevant) ------------
# Gleiche Naht wie in update.ps1: PS 5.1 startet sonst mit TLS 1.0, der
# Update-Server spricht nur TLS 1.2+. Unter PowerShell 7 wirkungslos, aber
# unschaedlich (IWR/IRM nutzen dort HttpClient und ignorieren dieses Flag).
# Hier betrifft es nur Changelog und Versionsanzeige (beide best effort);
# try/catch bleibt bewusst still schluckend - der Start darf nie blockieren.
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$installDir   = $PSScriptRoot
$updatePs1    = Join-Path $installDir 'update.ps1'
$updateBat    = Join-Path $installDir 'update.bat'
$startHtml    = Join-Path $installDir 'start.html'
$versionDatei = Join-Path $installDir 'version.txt'
$changelogUrl = 'https://download.flaechenklar.de/changelog.json'
$versionUrl   = 'https://download.flaechenklar.de/version.txt'

function OeffneTool {
    if (Test-Path $startHtml) {
        Start-Process $startHtml
    } else {
        Start-Process (Join-Path $installDir 'index.html')
    }
}

if (-not (Test-Path $updatePs1)) {
    # Unvollstaendige Installation -- Start nicht blockieren.
    OeffneTool
    exit 0
}

# --- Schritt 1: Pruefung als eigener Prozess (NICHT per & aufrufen --
# update.ps1 beendet sich selbst per exit; im selben Prozess aufgerufen
# wuerde das den Launcher mitbeenden, bevor er reagieren kann). --------
$exitCode = 0
try {
    $argStr = '-NoProfile -ExecutionPolicy Bypass -File "' + $updatePs1 + '" -NurPruefen'
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argStr -WindowStyle Hidden -Wait -PassThru
    $exitCode = $proc.ExitCode
} catch {
    $exitCode = 0
}

if ($exitCode -ne 10) {
    OeffneTool
    exit 0
}

# --- Schritt 2: Changelog laden (best effort, reine Anzeige) ----------
$lokal = '0.0.0'
if (Test-Path $versionDatei) {
    $lokal = (Get-Content $versionDatei -First 1).Trim()
}

function VersionsTeile([string]$v) {
    $m = [regex]::Match($v, '^(\d+)\.(\d+)\.(\d+)')
    if ($m.Success) {
        return @([int]$m.Groups[1].Value, [int]$m.Groups[2].Value, [int]$m.Groups[3].Value)
    }
    return @(0, 0, 0)
}

function VersionGroesserAls([string]$a, [string]$b) {
    $ta = VersionsTeile $a
    $tb = VersionsTeile $b
    for ($i = 0; $i -lt 3; $i++) {
        if ($ta[$i] -gt $tb[$i]) { return $true }
        if ($ta[$i] -lt $tb[$i]) { return $false }
    }
    return $false
}

$MAX_PUNKTE = 8
$punkte = @()
try {
    $changelog = Invoke-RestMethod -Uri $changelogUrl -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    $neuere = @($changelog | Where-Object { VersionGroesserAls $_.version $lokal })
    $neuere = $neuere | Sort-Object -Property @{ Expression = { [version]$_.version } } -Descending
    $gekappt = $false
    foreach ($eintrag in $neuere) {
        foreach ($p in $eintrag.punkte) {
            if ($punkte.Count -ge $MAX_PUNKTE) { $gekappt = $true; break }
            $punkte += ('- ' + $p)
        }
        if ($gekappt) { break }
    }
    if ($gekappt) {
        $punkte += '- sowie weitere Verbesserungen aus aelteren Versionen'
    }
} catch {
    # Changelog ist reine Anzeige -- Ladefehler darf den Dialog nicht verhindern.
}

$neueVersion = '?'
try {
    $remote = Invoke-WebRequest -Uri $versionUrl -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 5
    $neueVersion = (($remote.Content -split "`r?`n")[0]).Trim()
} catch {
    # Reine Anzeige -- update.ps1 hat die Verfuegbarkeit bereits per Exit-Code 10 belegt.
}

# --- Schritt 3: Ja/Nein-Dialog ------------------------------------------
# Ab hier in try/finally: ein Fehler in Add-Type/MessageBox/Start-Process
# (z.B. fehlendes update.bat) darf OeffneTool nicht verhindern -- sonst
# bliebe der Start komplett aus, statt nur das Update zu ueberspringen.
try {
    Add-Type -AssemblyName System.Windows.Forms

    $text = 'FlaechenKlar ' + $neueVersion + ' ist verfuegbar (installiert: ' + $lokal + ').'
    if ($punkte.Count -gt 0) {
        $text += "`n`nNeu seit Ihrer Version:`n" + ($punkte -join "`n")
    }
    $text += "`n`nJetzt aktualisieren?"

    $antwort = [System.Windows.Forms.MessageBox]::Show(
        $text, 'FlaechenKlar Update', [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question)

    if ($antwort -eq [System.Windows.Forms.DialogResult]::Yes -and (Test-Path $updateBat)) {
        # Sichtbares Fenster: Kunde soll "Update erfolgreich" lesen koennen.
        # update.bat statt update.ps1 direkt -- uebernimmt die vorhandene
        # Konsolen-UX (Banner, Abschlussmeldung, Tastendruck) unveraendert.
        Start-Process -FilePath $updateBat -Wait
    }
} catch {
    # Dialog/Update-Ausfuehrung fehlgeschlagen -- Start trotzdem nicht blockieren.
} finally {
    OeffneTool
}
