# Changelog — FlächenKlar

Alle nennenswerten Änderungen werden hier dokumentiert.
*Arbeitstitel bis Mai 2026: gf-Tool / Geschossflächen-Tool.*

## [1.0.0] — 2026-05-16

Erstes stabiles Release. Solo-Dev-Tool für bayerische Bauämter.

### Hinzugefügt (Phase A8)
- Reproduzierbarer Release-Build via `npm run build-release` (Allowlist-Manifest, SHA256-Integritaetscheck, Self-Verify)
- `version.txt` im Release-ZIP-Root verhindert Update-Endlosschleife bei Erstinstallationen
- `update.ps1`: ZipSlip-Defense vor Expand-Archive (Defense-in-Depth, SHA256-Check fängt's bereits)

### Geändert
- `update.ps1`: selektives `data/`-Exclude — `data/*.example.js`-Updates kommen jetzt beim Kunden an (war: komplettes `data/` ausgeschlossen)
- `DOWNLOAD_URL` zeigt auf das öffentliche Update-Repo (war: `example.com`-Placeholder)
- VERSION von `0.1.0-dev` auf `1.0.0`

### Stand der vorigen Phasen
- A1–A5: VG-Integration (Vollgeschoss-Berechnung Art. 83 Abs. 7 BayBO)
- A6: Lizenz-Workflow mit SHA256-Whitelist auf GitHub Pages
- A7: Vorgänger-VG-Tool als archiviert markiert
- B1–B3: TypeScript-Migration via JSDoc + `tsc --checkJs`

## [0.1.0-dev] — 2026-05-12

### Hinzugefügt
- Phase-0-Skelett: Verzeichnisstruktur, klassische Scripts mit `window.GF.*`-Namespace
- Lizenzsystem aus VG-Tool übernommen, ID-Präfix auf `GF-` umgestellt
- Update-Mechanismus (`update.bat` + `update.ps1`) 1:1 aus VG-Tool
- Plan-Datei und SPEC.md angelegt
- Test-Runner (`test.html`) mit ersten Unit-Tests für `util`, `polygon`, `region`, `projekt`, `lizenz`
- Stubs für PDF-Loading, Region/Geschoss/Polygon-Verwaltung, Projekt-Speicherung, Export
- Auto-Recovery via IndexedDB (Wrapper)

### Bekannte Einschränkungen (Phase 0)
- `lib/pdf.min.js`, `lib/pdf.worker.min.js`, `lib/fflate.min.js` müssen manuell besorgt werden (`lib/README.md`)
- `GF.projekt.speichere/lade` und `GF.export.aufmassprotokoll` sind Stubs (Phase 4/5)
- Keine UI für PDF-Anzeige (Phase 1)
