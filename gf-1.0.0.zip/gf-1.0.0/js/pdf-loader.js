// @ts-check
// js/pdf-loader.js — PDF laden, pdf.js initialisieren, Vektor-Anteil bestimmen.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  // Gewicht eines einzelnen Bild-Operators in "Vektor-Operator-Einheiten".
  // Ein gescannter Plan hat oft NUR ein paint-image-Op fuer den ganzen Plan, das
  // dann gegen die paar Vektor-Ops (Drucker-Marken, Seitenrand) dominieren muss.
  var BILD_GEWICHT = 200;

  /**
   * Bei file://-Aufruf scheitert pdf.worker.js am CORS-Check. Workaround:
   * workerSrc leeren — pdf.js faellt auf Main-Thread zurueck.
   * @returns {boolean} false wenn pdfjsLib fehlt.
   */
  function konfigurierePdfJs() {
    if (!global.pdfjsLib) {
      console.warn('[gf-pdf] pdfjsLib nicht geladen — lib/pdf.min.js fehlt?');
      return false;
    }
    if (global.location && global.location.protocol === 'file:') {
      global.pdfjsLib.GlobalWorkerOptions.workerSrc = '';
    } else {
      global.pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
    }
    return true;
  }

  /**
   * Laedt ein File-Objekt als pdf.js-Dokument.
   * @param {File | Blob} file
   * @returns {Promise<any>}
   */
  GF.pdf.lade = function (file) {
    return new Promise(function (resolve, reject) {
      if (!konfigurierePdfJs()) {
        reject(new Error('pdf.js-Library nicht verfügbar'));
        return;
      }
      var fr = new FileReader();
      fr.onload = function () {
        var arr = new Uint8Array(/** @type {ArrayBuffer} */ (fr.result));
        global.pdfjsLib.getDocument({ data: arr }).promise
          .then(resolve)
          .catch(function (e) {
            reject(new Error('PDF konnte nicht gelesen werden: ' + (e && e.message || e)));
          });
      };
      fr.onerror = function () { reject(fr.error); };
      fr.readAsArrayBuffer(/** @type {File} */ (file));
    });
  };

  /**
   * Rohzaehlung der Operator-Typen einer Seite.
   * @param {any} pdfDoc pdf.js-Dokument
   * @param {number} seite 1-basiert
   * @returns {Promise<PdfStatistik>}
   */
  GF.pdf.statistik = function (pdfDoc, seite) {
    return pdfDoc.getPage(seite).then(function (page) {
      return page.getOperatorList().then(function (opList) {
        return _zaehleOps(opList.fnArray, global.pdfjsLib.OPS);
      });
    });
  };

  /**
   * Heuristik: Anteil Vektor-Operatoren am gewichteten Gesamtinhalt.
   * 1.0 = reines Vektor-PDF, &lt;0.3 = ueberwiegend Raster.
   * @param {any} pdfDoc
   * @param {number} seite
   * @returns {Promise<number>}
   */
  GF.pdf.vektorAnteil = function (pdfDoc, seite) {
    return GF.pdf.statistik(pdfDoc, seite).then(function (s) {
      return _berechneAnteil(s);
    });
  };

  /**
   * @param {number[]} fnArray
   * @param {any} OPS
   * @returns {PdfStatistik}
   */
  function _zaehleOps(fnArray, OPS) {
    var vektor = 0, bild = 0, andere = 0;
    var vektorOps = [
      OPS.moveTo, OPS.lineTo, OPS.curveTo, OPS.curveTo2, OPS.curveTo3,
      OPS.closePath, OPS.rectangle, OPS.fill, OPS.stroke, OPS.fillStroke,
      OPS.eoFill, OPS.eoFillStroke, OPS.closeStroke, OPS.closeFillStroke
    ];
    var bildOps = [
      OPS.paintImageXObject, OPS.paintImageMaskXObject,
      OPS.paintInlineImageXObject, OPS.paintJpegXObject,
      OPS.paintImageXObjectRepeat, OPS.paintImageMaskXObjectRepeat
    ];
    for (var i = 0; i < fnArray.length; i++) {
      var op = fnArray[i];
      if (vektorOps.indexOf(op) >= 0) vektor++;
      else if (bildOps.indexOf(op) >= 0) bild++;
      else andere++;
    }
    return { vektor: vektor, bild: bild, andere: andere, summe: fnArray.length };
  }

  /**
   * @param {PdfStatistik} s
   * @returns {number}
   */
  function _berechneAnteil(s) {
    var nenner = s.vektor + s.bild * BILD_GEWICHT;
    if (nenner === 0) return 1.0;
    return s.vektor / nenner;
  }

  GF.pdf.konfigurierePdfJs = konfigurierePdfJs;
  GF.pdf._zaehleOps = _zaehleOps;           // Test-Hook
  GF.pdf._berechneAnteil = _berechneAnteil; // Test-Hook
  GF.pdf.BILD_GEWICHT = BILD_GEWICHT;

})(typeof window !== 'undefined' ? window : globalThis);
