// @ts-check
// js/vg-geometrie.js — Koordinaten in Meter fuer Querschnitt/Grundriss/Aufriss.
// Renderer-agnostisch: liefert nur Punkte; SVG-Renderer und PDF-Renderer
// konsumieren das gleiche Datenmodell.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  /**
   * @param {number} L_B
   * @param {number} h_KL
   * @param {number} h_KR
   * @param {number} alpha_L
   * @param {number} alpha_R
   * @returns {number}
   */
  function firstX(L_B, h_KL, h_KR, alpha_L, alpha_R) {
    var tL = Math.tan(alpha_L * Math.PI / 180);
    var tR = Math.tan(alpha_R * Math.PI / 180);
    if (tL + tR === 0) return L_B / 2;
    return (h_KR - h_KL + L_B * tR) / (tL + tR);
  }

  /**
   * @param {number} x
   * @param {number} L_B
   * @param {number} h_KL
   * @param {number} h_KR
   * @param {number} alpha_L
   * @param {number} alpha_R
   * @param {number} xFirst
   * @returns {number}
   */
  function dachhoeheAn(x, L_B, h_KL, h_KR, alpha_L, alpha_R, xFirst) {
    var tL = Math.tan(alpha_L * Math.PI / 180);
    var tR = Math.tan(alpha_R * Math.PI / 180);
    if (x <= xFirst) return h_KL + x * tL;
    return h_KR + (L_B - x) * tR;
  }

  /**
   * @param {VgEingaben} eingabe
   * @param {VgErgebnis} ergebnis
   */
  function querschnitt(eingabe, ergebnis) {
    var L_B = eingabe.L_B;
    var h_KL = eingabe.h_KL;
    var h_KR = eingabe.h_KR;
    var aL = eingabe.alpha_L;
    var aR = eingabe.alpha_R;
    var xFirst = firstX(L_B, h_KL, h_KR, aL, aR);
    var firstHoehe = dachhoeheAn(xFirst, L_B, h_KL, h_KR, aL, aR, xFirst);

    var GRENZ = 2.30;

    var konturAussen = [
      { x: 0,      y: 0 },
      { x: 0,      y: h_KL },
      { x: xFirst, y: firstHoehe },
      { x: L_B,    y: h_KR },
      { x: L_B,    y: 0 }
    ];

    var X1 = ergebnis.X1;
    var X2 = ergebnis.X2;
    var xLinks = X1;
    var xRechts = L_B - X2;

    var hoch = [];
    if (xRechts > xLinks) {
      var yLinks  = dachhoeheAn(xLinks,  L_B, h_KL, h_KR, aL, aR, xFirst);
      var yRechts = dachhoeheAn(xRechts, L_B, h_KL, h_KR, aL, aR, xFirst);
      hoch.push({ x: xLinks,  y: GRENZ });
      hoch.push({ x: xLinks,  y: yLinks });
      if (xFirst > xLinks && xFirst < xRechts) {
        hoch.push({ x: xFirst, y: firstHoehe });
      }
      hoch.push({ x: xRechts, y: yRechts });
      hoch.push({ x: xRechts, y: GRENZ });
    }

    return {
      L_B: L_B,
      hoeheGesamt: Math.max(firstHoehe, h_KL, h_KR, GRENZ),
      h_KL: h_KL,
      h_KR: h_KR,
      alpha_L: aL,
      alpha_R: aR,
      xFirst: xFirst,
      firstHoehe: firstHoehe,
      konturAussen: konturAussen,
      grenzhoehe: GRENZ,
      hochpolygon: hoch,
      X1: X1,
      X2: X2,
      Bm: ergebnis.Bm
    };
  }

  /**
   * @param {VgEingaben} eingabe
   * @param {VgErgebnis} ergebnis
   */
  function grundriss(eingabe, ergebnis) {
    var L_B = eingabe.L_B, L_L = eingabe.L_L;
    var X1 = ergebnis.X1, X2 = ergebnis.X2;
    var GRENZ = 2.30;

    /**
     * @param {Gaube[]} liste
     * @param {'links' | 'rechts'} seite
     */
    function gaubenPositionen(liste, seite) {
      var arr = (liste || []).filter(function (g) { return g && g.b > 0; });
      var mitOrtgang = arr.filter(function (g) { return isFinite(g.ortgang); });
      var ohneOrtgang = arr.filter(function (g) { return !isFinite(g.ortgang); });

      var positionen = [];
      mitOrtgang.forEach(function (g) {
        positionen.push({
          b: g.b, a: g.a,
          ortgang: g.ortgang,
          tiefe: g.a,
          eingedrungen: Math.max(0, (seite === 'links' ? X1 : X2) - g.a)
        });
      });
      var n = ohneOrtgang.length;
      ohneOrtgang.forEach(function (g, i) {
        var center = (i + 1) / (n + 1) * L_L;
        var ortgang = Math.max(0, center - g.b / 2);
        positionen.push({
          b: g.b, a: g.a,
          ortgang: ortgang, tiefe: g.a,
          eingedrungen: Math.max(0, (seite === 'links' ? X1 : X2) - g.a)
        });
      });
      return positionen;
    }

    return {
      L_B: L_B, L_L: L_L,
      X1: X1, X2: X2,
      grenzhoehe: GRENZ,
      gauben_links:  gaubenPositionen(eingabe.gauben_links,  'links'),
      gauben_rechts: gaubenPositionen(eingabe.gauben_rechts, 'rechts')
    };
  }

  /**
   * @param {'links' | 'rechts'} seite
   * @param {VgEingaben} eingabe
   * @param {VgErgebnis} ergebnis
   */
  function aufriss(seite, eingabe, ergebnis) {
    var L_L = eingabe.L_L;
    var L_B = eingabe.L_B;
    var h_K = (seite === 'links') ? eingabe.h_KL : eingabe.h_KR;
    var alpha = (seite === 'links') ? eingabe.alpha_L : eingabe.alpha_R;
    var xFirst = firstX(L_B, eingabe.h_KL, eingabe.h_KR, eingabe.alpha_L, eingabe.alpha_R);
    var firstHoehe = dachhoeheAn(xFirst, L_B, eingabe.h_KL, eingabe.h_KR, eingabe.alpha_L, eingabe.alpha_R, xFirst);
    var GAUBE_HOEHE_STD = 1.5;

    var gaubenListe = ((seite === 'links') ? eingabe.gauben_links : eingabe.gauben_rechts) || [];
    var positionen = gaubenListe
      .filter(function (g) { return g && g.b > 0; })
      .map(function (g, i, arr) {
        var ortgang = isFinite(g.ortgang)
          ? g.ortgang
          : Math.max(0, ((i + 1) / (arr.length + 1)) * L_L - g.b / 2);
        var sitzhoehe = h_K + g.a * Math.tan(alpha * Math.PI / 180);
        return {
          b: g.b, a: g.a,
          ortgang: ortgang,
          sitzhoehe: sitzhoehe,
          dachhoehe: GAUBE_HOEHE_STD
        };
      });

    return {
      L_L: L_L,
      h_K: h_K,
      alpha: alpha,
      firstHoehe: firstHoehe,
      gauben: positionen,
      seite: seite
    };
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.Vollgeschoss = GF.Vollgeschoss || /** @type {GfVollgeschossModule} */ ({});
  GF.Vollgeschoss.geometrie = {
    querschnitt: querschnitt,
    grundriss: grundriss,
    aufriss: aufriss,
    firstX: firstX,
    dachhoeheAn: dachhoeheAn
  };

})(typeof window !== 'undefined' ? window : globalThis);
