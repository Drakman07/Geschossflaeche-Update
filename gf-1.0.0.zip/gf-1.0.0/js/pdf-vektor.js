// @ts-check
// js/pdf-vektor.js — Vektor-Endpunkte aus PDF extrahieren fuer Snap.
// PHASE 3: Implementierung folgt (page.getOperatorList iterieren).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  /**
   * Liefert ein Array mit Snap-Punkten aus dem PDF.
   * Aktuell Stub — Phase 3.
   * @param {any} pdfDoc
   * @param {number} seite
   * @returns {Promise<Punkt[]>}
   */
  GF.pdf.snapPunkte = function (pdfDoc, seite) {
    // TODO Phase 3: pdf.js OPS.moveTo/lineTo/curveTo durchgehen,
    // Endpunkte und Kreuzungen sammeln.
    return Promise.resolve([]);
  };

})(typeof window !== 'undefined' ? window : globalThis);
