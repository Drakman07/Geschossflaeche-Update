// @ts-check
// js/export-dialog.js — Anrechnungs-Dialog vor dem PDF-Export.
// Erscheint nur, wenn mindestens ein Geschoss eine durchgefuehrte VG-Berechnung hat.
// Default-Vorauswahl: projekt.metadata.vgAnrechnung || 'voll'.
//
// Oeffentliche API:
//   GF.ExportDialog.oeffne(projekt, callback)
//     - callback(modus|null)  // 'voll' | 'anteilig' bei OK, null bei Abbrechen
//   GF.ExportDialog.istOffen()
//   GF.ExportDialog.sammleVgGeschosse(projekt)  // [{geschoss, polygonFlaeche, A_2_30}]

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});

  /** @param {string} id @returns {any} */
  function $(id) { return document.getElementById(id); }

  /** @type {Projekt | null} */
  var aktivesProjekt = null;
  /** @type {((m: VgAnrechnungsModus) => void) | null} */
  var aktiverCallback = null;

  GF.ExportDialog = {
    oeffne: oeffne,
    schliesse: schliesse,
    istOffen: function () {
      var bd = $('exportDialogBackdrop');
      return !!(bd && bd.classList.contains('aktiv'));
    },
    sammleVgGeschosse: sammleVgGeschosse
  };

  // Liefert alle Geschosse mit durchgefuehrter VG-Berechnung, jeweils mit der
  // Summe der Polygonflaechen und A_2_30 aus der VG-Beurteilung. Sortiert nach
  // reihenfolge (wie auf dem Aufmassblatt).
  function sammleVgGeschosse(projekt) {
    if (!projekt || !Array.isArray(projekt.geschosse)) return [];
    var geschosse = projekt.geschosse.slice().sort(function (a, b) {
      return (a.reihenfolge || 0) - (b.reihenfolge || 0);
    });
    var out = [];
    geschosse.forEach(function (g) {
      var vg = g.vollgeschoss;
      if (!vg || vg.durchgefuehrt !== true || !vg.ergebnis) return;
      if (typeof vg.ergebnis.A_2_30 !== 'number' || !isFinite(vg.ergebnis.A_2_30)) return;
      var polys = (projekt.polygone || []).filter(function (p) { return p.geschossId === g.id; });
      var polygonFlaeche = polys.reduce(function (s, p) {
        return s + (p.flaecheAngesetztQM || 0);
      }, 0);
      out.push({
        geschoss: g,
        polygonFlaeche: polygonFlaeche,
        A_2_30: vg.ergebnis.A_2_30
      });
    });
    return out;
  }

  function oeffne(projekt, callback) {
    if (!projekt) { if (callback) callback(null); return; }
    var bd = $('exportDialogBackdrop');
    if (!bd) { if (callback) callback(null); return; }

    // Doppelaufruf-Schutz: laeuft ein Dialog bereits, loesen wir den alten
    // Callback mit null auf, damit kein Caller im haengenden Promise stehen bleibt.
    if (bd.classList.contains('aktiv') && aktiverCallback) {
      var alterCb = aktiverCallback;
      aktiverCallback = null;
      try { alterCb(null); } catch (e) { /* ignore */ }
    }

    aktivesProjekt = projekt;
    aktiverCallback = callback || function () {};

    var vgListe = sammleVgGeschosse(projekt);
    rendereVorschau(vgListe);
    rendereIntro(vgListe);

    // Default-Vorauswahl
    var modus = (projekt.metadata && projekt.metadata.vgAnrechnung === 'anteilig')
      ? 'anteilig' : 'voll';
    setzeAuswahl(modus);

    bd.classList.add('aktiv');
    setTimeout(function () {
      var first = bd.querySelector('input[type="radio"]:checked');
      if (first) first.focus();
    }, 50);
  }

  function rendereIntro(vgListe) {
    var el = $('exportDialogIntro');
    if (!el) return;
    var n = vgListe.length;
    var txt;
    if (n === 1) {
      txt = 'Für 1 Geschoss liegt eine Vollgeschoss-Berechnung vor. '
          + 'Welche Fläche soll im Aufmaßblatt eingetragen werden?';
    } else {
      txt = 'Für ' + n + ' Geschosse liegt eine Vollgeschoss-Berechnung vor. '
          + 'Welche Fläche soll im Aufmaßblatt eingetragen werden?';
    }
    el.textContent = txt;
  }

  function rendereVorschau(vgListe) {
    var voll = $('exVorschauVoll');
    var anteilig = $('exVorschauAnteilig');
    if (voll) voll.innerHTML = '';
    if (anteilig) anteilig.innerHTML = '';
    if (vgListe.length === 0) return;
    vgListe.forEach(function (eintrag) {
      var name = (eintrag.geschoss.bezeichnung || 'Geschoss');
      if (voll) {
        var liV = document.createElement('li');
        liV.innerHTML = '<span>' + esc(name) + '</span><strong>'
          + formatQM(eintrag.polygonFlaeche) + '</strong>';
        voll.appendChild(liV);
      }
      if (anteilig) {
        var liA = document.createElement('li');
        liA.innerHTML = '<span>' + esc(name) + '</span><strong>'
          + formatQM(eintrag.A_2_30) + '</strong>';
        anteilig.appendChild(liA);
      }
    });
  }

  function setzeAuswahl(modus) {
    var inps = document.querySelectorAll('#exportDialogBackdrop input[name="exVgAnrechnung"]');
    Array.prototype.forEach.call(inps, function (inp) {
      inp.checked = (inp.value === modus);
    });
  }

  function leseAuswahl() {
    var inp = /** @type {HTMLInputElement | null} */ (document.querySelector('#exportDialogBackdrop input[name="exVgAnrechnung"]:checked'));
    return inp ? inp.value : 'voll';
  }

  function bestaetige() {
    if (!aktivesProjekt) { schliesseStill(); return; }
    var rohModus = leseAuswahl();
    /** @type {VgAnrechnungsModus} */
    var modus = (rohModus === 'anteilig') ? 'anteilig' : 'voll';

    // Wahl wird immer im Projekt gemerkt: spaetere Exporte zeigen die letzte
    // Auswahl als Vorauswahl im Dialog. Aendern bleibt jederzeit moeglich.
    // (GF.state.update(fn) mutiert direkt fn(GF.state), kein Klon — siehe
    //  js/state.js. Daher ist die Mutation hier vor dem update()-Aufruf safe.)
    // @ts-ignore - Metadata kann theoretisch unbefuellt sein (alte Snapshots)
    aktivesProjekt.metadata = aktivesProjekt.metadata || {};
    var altWert = aktivesProjekt.metadata.vgAnrechnung || null;
    if (altWert !== modus) {
      aktivesProjekt.metadata.vgAnrechnung = modus;
      if (GF.state && GF.state.update) {
        GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
      }
      if (GF.projekt && GF.projekt.historieEintrag) {
        GF.projekt.historieEintrag(aktivesProjekt,
          'Anrechnungs-Modus gesetzt',
          'Modus: ' + (modus === 'anteilig' ? 'anteilig >= 2,30 m' : 'volle Grundfläche'));
      }
    }

    var cb = aktiverCallback;
    schliesseStill();
    if (cb) cb(modus);
  }

  function abbrechen() {
    var cb = aktiverCallback;
    schliesseStill();
    if (cb) cb(null);
  }

  function schliesseStill() {
    var bd = $('exportDialogBackdrop');
    if (bd) bd.classList.remove('aktiv');
    aktivesProjekt = null;
    aktiverCallback = null;
  }

  function schliesse() { abbrechen(); }

  // --- Hilfsfunktionen ---
  function formatQM(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    var fmt = (GF.util && GF.util.formatZahlDE) ? GF.util.formatZahlDE : function (v, k) { return v.toFixed(k).replace('.', ','); };
    return fmt(n, 2) + ' m²';
  }
  function esc(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;' }[c];
    });
  }

  // --- Wiring ---
  function wire() {
    var bd = $('exportDialogBackdrop');
    if (!bd) return;

    var btnOk = $('btnExportOk');
    if (btnOk) btnOk.addEventListener('click', bestaetige);
    var btnAbb = $('btnExportAbbrechen');
    if (btnAbb) btnAbb.addEventListener('click', abbrechen);

    // Klick auf Label (.ex-option) togglet auch das Radio — Browser-Default.
    // Wir muessen nichts extra verdrahten.

    // Backdrop-Klick = Abbrechen (mousedown+click muss beide auf bd).
    var bdMd = null;
    bd.addEventListener('mousedown', function (e) { bdMd = e.target; });
    bd.addEventListener('click', function (e) {
      if (e.target === bd && bdMd === bd) abbrechen();
      bdMd = null;
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wire);
  } else {
    wire();
  }

})(typeof window !== 'undefined' ? window : globalThis);
