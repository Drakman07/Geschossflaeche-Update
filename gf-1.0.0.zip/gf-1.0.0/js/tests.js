// @ts-check
// js/tests.js — Test-Runner ohne externe Library.

/** @param {GfGlobalLike & {GF_test_assertions?: any}} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern + tests-Modul ist offen typisiert
  var GF = /** @type {GF & {tests: any}} */ (global.GF = global.GF || {});
  GF.tests = GF.tests || /** @type {any} */ ({});

  var TOL = 1e-9;

  function nahe(ist, soll, tol) {
    return Math.abs(ist - soll) <= (tol === undefined ? TOL : tol);
  }

  function fmt(n) {
    return (typeof n === 'number') ? n.toFixed(4) : String(n);
  }

  // ---- util-Tests ----

  function utilTests() {
    var r = [];

    // parseZahlDE
    r.push({ name: 'parseZahlDE("1,23") = 1.23',
             ok: nahe(GF.util.parseZahlDE('1,23'), 1.23, 1e-9),
             detail: 'ist=' + GF.util.parseZahlDE('1,23') });
    r.push({ name: 'parseZahlDE("8.92") = 8.92',
             ok: nahe(GF.util.parseZahlDE('8.92'), 8.92, 1e-9),
             detail: 'ist=' + GF.util.parseZahlDE('8.92') });
    r.push({ name: 'parseZahlDE("") = NaN',
             ok: isNaN(GF.util.parseZahlDE('')),
             detail: '' });
    r.push({ name: 'parseZahlDE("1.234,56") = 1234.56 (Tausender + Komma)',
             ok: nahe(GF.util.parseZahlDE('1.234,56'), 1234.56, 1e-9),
             detail: 'ist=' + GF.util.parseZahlDE('1.234,56') });

    // formatZahlDE
    r.push({ name: 'formatZahlDE(105.05, 2) = "105,05"',
             ok: GF.util.formatZahlDE(105.05, 2) === '105,05',
             detail: 'ist=' + GF.util.formatZahlDE(105.05, 2) });

    // Neue Tests: Default-Stellen und deterministische 5-auf-Rundung
    r.push({ name: 'formatZahlDE(1.234) ohne stellen-Param = "1,23" (Default 2)',
             ok: GF.util.formatZahlDE(1.234) === '1,23',
             detail: 'ist=' + GF.util.formatZahlDE(1.234) });
    r.push({ name: 'formatZahlDE(1.235, 2) = "1,24" (deterministische 5-auf-Rundung)',
             ok: GF.util.formatZahlDE(1.235, 2) === '1,24',
             detail: 'ist=' + GF.util.formatZahlDE(1.235, 2) });
    r.push({ name: 'formatZahlDE(1.234, 3) = "1,234" (Edit-Vorbelegung mit 3 Stellen)',
             ok: GF.util.formatZahlDE(1.234, 3) === '1,234',
             detail: 'ist=' + GF.util.formatZahlDE(1.234, 3) });
    // Regression-Check fuer 105.05 ist schon in dem bestehenden Test in Zeile 42-44 abgedeckt.

    // abstand2D
    r.push({ name: 'abstand2D((0,0),(3,4)) = 5',
             ok: nahe(GF.util.abstand2D({x:0,y:0},{x:3,y:4}), 5),
             detail: '' });

    // segmenteSchneidenSich
    r.push({ name: 'kreuzende Strecken erkannt',
             ok: GF.util.segmenteSchneidenSich({x:0,y:0},{x:10,y:10},{x:0,y:10},{x:10,y:0}),
             detail: '' });
    r.push({ name: 'parallele Strecken kein Schnitt',
             ok: !GF.util.segmenteSchneidenSich({x:0,y:0},{x:10,y:0},{x:0,y:5},{x:10,y:5}),
             detail: '' });

    return r;
  }

  // ---- polygon-Tests ----

  function polygonTests() {
    var r = [];

    // Rechteck 10x10 m bei 1:100 (28.346 pt/m)
    var p100 = 28.346;
    var rect10 = [
      { x: 0,         y: 0         },
      { x: 10 * p100, y: 0         },
      { x: 10 * p100, y: 10 * p100 },
      { x: 0,         y: 10 * p100 }
    ];
    var f = GF.polygon.berechneFlaeche(rect10, p100);
    r.push({ name: 'Rechteck 10x10 m -> 100 m^2',
             ok: nahe(f, 100, 1e-6),
             detail: 'ist=' + fmt(f) });

    // Dreieck Basis 10, Hoehe 10
    var tri = [
      { x: 0,         y: 0 },
      { x: 10 * p100, y: 0 },
      { x: 0,         y: 10 * p100 }
    ];
    var fT = GF.polygon.berechneFlaeche(tri, p100);
    r.push({ name: 'Dreieck (10,10) -> 50 m^2',
             ok: nahe(fT, 50, 1e-6),
             detail: 'ist=' + fmt(fT) });

    // Polygon mit < 3 Punkten -> Fehler
    var fehler = false;
    try { GF.polygon.berechneFlaeche([{x:0,y:0},{x:1,y:1}], p100); }
    catch (e) { fehler = true; }
    r.push({ name: 'Polygon mit 2 Punkten -> Fehler',
             ok: fehler, detail: '' });

    // Selbstueberschneidung erkannt
    var bowtie = [
      { x: 0, y: 0 },
      { x: 10, y: 10 },
      { x: 10, y: 0 },
      { x: 0, y: 10 }
    ];
    r.push({ name: 'Bowtie (selbstueberschneidend) erkannt',
             ok: GF.polygon.hatSelbstueberschneidung(bowtie),
             detail: '' });

    // Rechteck ist nicht selbstueberschneidend
    r.push({ name: 'Rechteck nicht selbstueberschneidend',
             ok: !GF.polygon.hatSelbstueberschneidung(rect10),
             detail: '' });

    // editKante: 10m-Kante auf 8m -> p2 wandert
    var poly = /** @type {Polygon} */ (/** @type {any} */ ({ punkte: [
      { x: 0,         y: 0 },
      { x: 10 * p100, y: 0 },
      { x: 10 * p100, y: 5 * p100 },
      { x: 0,         y: 5 * p100 }
    ]}));
    GF.polygon.editKante(poly, 0, 8, p100);   // Kante 0->1 auf 8m
    var k0Len = GF.util.abstand2D(poly.punkte[0], poly.punkte[1]) / p100;
    r.push({ name: 'editKante: 10m -> 8m',
             ok: nahe(k0Len, 8, 1e-6),
             detail: 'ist=' + fmt(k0Len) });
    // p1 und p2 unveraendert? p1 ist Index 0 (Start der Kante), p2 ist Index 1
    // Der Test fokussiert: NUR Index 1 hat sich bewegt, alle anderen fix.
    r.push({ name: 'editKante: Index 0 unveraendert',
             ok: poly.punkte[0].x === 0 && poly.punkte[0].y === 0,
             detail: '' });
    r.push({ name: 'editKante: Index 2 unveraendert',
             ok: poly.punkte[2].x === 10 * p100 && poly.punkte[2].y === 5 * p100,
             detail: '' });

    return r;
  }

  // ---- region-Tests ----

  function regionTests() {
    var r = [];

    // Massstab aus zwei Punkten: 334.7 pt fuer 11.79 m
    var m = GF.region.berechneMassstab({x:0,y:0}, {x:334.7,y:0}, 11.79);
    r.push({ name: 'Massstab 334.7pt / 11.79m ~ 28.39 pt/m',
             ok: nahe(m, 334.7 / 11.79, 1e-6),
             detail: 'ist=' + fmt(m) });

    // Plausibilitaet bei Norm-1:100 -> plausibel
    var pl = GF.region.plausibilitaet(28.346);
    r.push({ name: 'Plausibilitaet bei 1:100-Norm -> plausibel',
             ok: pl.stufe === 'plausibel' && pl.naechsterNormMassstab === '1:100',
             detail: 'abw=' + fmt(pl.abweichungProzent) + '% stufe=' + pl.stufe });

    // Plausibilitaet bei Abw 1% -> hinweis
    var pl2 = GF.region.plausibilitaet(28.346 * 1.01);
    r.push({ name: 'Plausibilitaet bei +1% -> hinweis',
             ok: pl2.stufe === 'hinweis',
             detail: 'abw=' + fmt(pl2.abweichungProzent) + '% stufe=' + pl2.stufe });

    // Sollmass 0 -> Fehler
    var fehler = false;
    try { GF.region.berechneMassstab({x:0,y:0}, {x:100,y:0}, 0); }
    catch (e) { fehler = true; }
    r.push({ name: 'Sollmass 0 -> Fehler', ok: fehler, detail: '' });

    return r;
  }

  // ---- projekt-Schema-Tests ----

  function schemaTests() {
    var r = [];

    var p = GF.projekt.neu({ projektName: 'Test', sachbearbeiter: 'Tester' });
    r.push({ name: 'projekt.neu hat schemaVersion=2',
             ok: p.schemaVersion === 2, detail: 'ist=' + p.schemaVersion });
    r.push({ name: 'projekt.neu validiert ohne Fehler',
             ok: GF.projekt.validiere(p) === true, detail: '' });

    // Schema v1 (alte Files) laden ohne Fehler
    var pV1 = JSON.parse(JSON.stringify(p));
    pV1.schemaVersion = 1;
    var v1Ok = false;
    try { v1Ok = (GF.projekt.validiere(pV1) === true); } catch (e) { v1Ok = false; }
    r.push({ name: 'Schema v1 (alte .zip) wird klaglos validiert',
             ok: v1Ok, detail: '' });

    // VG-Block: gueltig
    var pVg = JSON.parse(JSON.stringify(p));
    pVg.geschosse.push({ id: 'g-dg', bezeichnung: 'DG', reihenfolge: 1,
      vollgeschoss: {
        durchgefuehrt: true,
        berechnetAm: '2026-05-12T10:00:00+02:00',
        berechnetVon: 'Tester',
        eingaben: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                     gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
        ergebnis: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120, A_2_30: 88.80,
                     zweidrittel_flaeche: 80, anteil_2_30: 0.74, vollgeschoss: true,
                     differenz: 8.80, warnungen: [] },
        plausibilitaet: null,
        kommentar: ''
      }});
    var pVgOk = false;
    try { pVgOk = (GF.projekt.validiere(pVg) === true); } catch (e) { pVgOk = false; }
    r.push({ name: 'Schema v2 mit gueltigem vollgeschoss-Block validiert',
             ok: pVgOk, detail: '' });

    // Manipuliert: schemaVersion falsch
    var pBad = JSON.parse(JSON.stringify(p));
    pBad.schemaVersion = 999;
    var fehler = false;
    try { GF.projekt.validiere(pBad); } catch (e) { fehler = true; }
    r.push({ name: 'falsche schemaVersion -> Fehler',
             ok: fehler, detail: '' });

    // Polygon mit dangling regionId
    var pBad2 = JSON.parse(JSON.stringify(p));
    pBad2.polygone.push({
      id: 'x', geschossId: 'y', regionId: 'NICHT_EXISTENT',
      bezeichnung: '', punkte: [{x:0,y:0},{x:1,y:0},{x:0,y:1}]
    });
    var fehler2 = false;
    try { GF.projekt.validiere(pBad2); } catch (e) { fehler2 = true; }
    r.push({ name: 'dangling regionId -> Fehler',
             ok: fehler2, detail: '' });

    return r;
  }

  // ---- lizenz-Tests ----

  /**
   * Setzt window.GF_LIZENZ vor fn() und stellt es danach wieder her.
   * Pruefe-Tests sind safe: pruefeWhitelist() liest die ID synchron beim
   * Aufruf, danach laeuft alles in Promise-then-Closures mit dem schon
   * gefangenen Wert weiter — Wiederherstellung im finally ist deshalb OK.
   *
   * @param {{id: string} | undefined} val
   * @param {Function} fn
   * @returns {any}
   */
  function withGlobalLizenz(val, fn) {
    var prev = global.GF_LIZENZ;
    var hadKey = 'GF_LIZENZ' in /** @type {any} */ (global);
    if (val === undefined) {
      try { delete (/** @type {any} */ (global)).GF_LIZENZ; }
      catch (e) { global.GF_LIZENZ = /** @type {any} */ (undefined); }
    } else {
      global.GF_LIZENZ = val;
    }
    try { return fn(); }
    finally {
      if (hadKey) global.GF_LIZENZ = prev;
      else {
        try { delete (/** @type {any} */ (global)).GF_LIZENZ; }
        catch (e) { global.GF_LIZENZ = /** @type {any} */ (undefined); }
      }
    }
  }

  /**
   * Setzt localStorage['gf.lizenz.demo.start'] vor fn() und stellt es
   * danach wieder her.
   * @param {string | null} isoOrNull
   * @param {Function} fn
   * @returns {any}
   */
  function withDemoStart(isoOrNull, fn) {
    var KEY = 'gf.lizenz.demo.start';
    var prev = null;
    var hadKey = false;
    try {
      prev = localStorage.getItem(KEY);
      hadKey = (prev !== null);
      if (isoOrNull === null) localStorage.removeItem(KEY);
      else localStorage.setItem(KEY, isoOrNull);
    } catch (e) { /* privater Modus / Quota */ }
    try { return fn(); }
    finally {
      try {
        if (hadKey && prev !== null) localStorage.setItem(KEY, prev);
        else localStorage.removeItem(KEY);
      } catch (e) {}
    }
  }

  function diagnoseTests() {
    var r = [];

    /** @type {any} */
    var fakeProjekt = {
      schemaVersion: 2,
      appVersion: '0.1.0-dev',
      metadata: {
        projektName: 'Max Mustermann Anbau',
        bauherr: 'Max Mustermann',
        bauherrAnschriftStrasse: 'Hauptstr. 1',
        bauherrAnschriftPLZ: '92345',
        bauherrAnschriftOrt: 'Postbauer-Heng',
        bauherrPKNr: 'PK-12345',
        sachbearbeiter: 'Frau Schmidt',
        bauortStrasse: 'Nebenstr. 2',
        bauortPLZ: '92345',
        bauortOrt: 'Postbauer-Heng',
        flurnummer: '123/4',
        gemarkung: 'Postbauer-Heng',
        kommune: 'Markt Postbauer-Heng',
        projektNummer: '2026/16',
        bauvorhaben: 'Anbau',
        zusatzinfo: '',
        erstelltAm: '',
        geandertAm: '',
        revision: 1,
        vgAnrechnung: null
      },
      einstellungen: {},
      historie: [],
      pdfs: [
        { id: 'p1', dateiName: 'plan.pdf', anzahlSeiten: 3,
          binaer: new Uint8Array([1,2,3]), pdfDoc: { fake: true } }
      ],
      planRegionen: [{ id: 'r1' }],
      geschosse: [
        { id: 'g1', bezeichnung: 'EG', reihenfolge: 0, vollgeschoss: { ja: true } },
        { id: 'g2', bezeichnung: 'OG', reihenfolge: 1 }
      ],
      polygone: [
        { id: 'p1', regionId: 'r1', geschossId: 'g1', flaeche: 100.5, punkte: [] },
        { id: 'p2', regionId: 'r1', geschossId: 'g2', flaeche: 80.25, punkte: [] }
      ]
    };

    // Minimal: nur tool/version/browser, kein projekt
    var minimal = GF.diagnose.erstelle({ tiefe: 'minimal', projekt: fakeProjekt });
    r.push({ name: 'diagnose_minimal_enthaelt_tool_version',
             ok: minimal.tool === 'FlaechenKlar' && typeof minimal.version === 'string',
             detail: 'tool=' + minimal.tool + ' version=' + minimal.version });
    r.push({ name: 'diagnose_minimal_enthaelt_browser',
             ok: typeof minimal.browser === 'object' && minimal.browser !== null,
             detail: '' });
    r.push({ name: 'diagnose_minimal_KEIN_projekt',
             ok: minimal.projekt === undefined,
             detail: 'projekt=' + JSON.stringify(minimal.projekt) });

    // Standard: metadata redacted + stats, KEIN snapshot
    var standard = GF.diagnose.erstelle({ tiefe: 'standard', projekt: fakeProjekt });
    r.push({ name: 'diagnose_standard_enthaelt_stats',
             ok: standard.projekt && standard.projekt.stats &&
                 standard.projekt.stats.anzahlPolygone === 2 &&
                 standard.projekt.stats.anzahlGeschosse === 2 &&
                 standard.projekt.stats.anzahlMitVgBerechnung === 1,
             detail: JSON.stringify(standard.projekt && standard.projekt.stats) });
    r.push({ name: 'diagnose_standard_KEIN_snapshot',
             ok: standard.projekt && standard.projekt.snapshot === undefined,
             detail: 'snapshot=' + (standard.projekt && JSON.stringify(standard.projekt.snapshot)) });

    // Voll: snapshot vorhanden mit Polygonen, geschossen
    var voll = GF.diagnose.erstelle({ tiefe: 'voll', projekt: fakeProjekt });
    r.push({ name: 'diagnose_voll_enthaelt_snapshot',
             ok: voll.projekt && voll.projekt.snapshot &&
                 voll.projekt.snapshot.polygone.length === 2 &&
                 voll.projekt.snapshot.geschosse.length === 2,
             detail: '' });

    // Anonymisierung: PII redacted in voll
    var meta = voll.projekt.metadata;
    r.push({ name: 'diagnose_PII_bauherr_redacted',
             ok: meta.bauherr === '<redacted>',
             detail: 'ist=' + meta.bauherr });
    r.push({ name: 'diagnose_PII_sachbearbeiter_redacted',
             ok: meta.sachbearbeiter === '<redacted>',
             detail: 'ist=' + meta.sachbearbeiter });
    r.push({ name: 'diagnose_PII_adresse_redacted',
             ok: meta.bauherrAnschriftStrasse === '<redacted>' &&
                 meta.bauortStrasse === '<redacted>',
             detail: '' });
    r.push({ name: 'diagnose_NICHT_PII_kommune_bleibt',
             ok: meta.kommune === 'Markt Postbauer-Heng',
             detail: 'ist=' + meta.kommune });

    // Snapshot enthaelt KEINE PDF-Binaerdaten
    var pdfSnap = voll.projekt.snapshot.pdfs[0];
    r.push({ name: 'diagnose_snapshot_KEIN_pdf_binaer',
             ok: pdfSnap.binaer === undefined && pdfSnap.pdfDoc === undefined,
             detail: 'keys=' + Object.keys(pdfSnap).join(',') });

    // Leeres Projekt: minimal sollte trotzdem laufen
    var leer = GF.diagnose.erstelle({ tiefe: 'minimal', projekt: null });
    r.push({ name: 'diagnose_minimal_ohne_projekt_ok',
             ok: leer.tool === 'FlaechenKlar' && leer.projekt === undefined,
             detail: '' });

    return r;
  }

  function lizenzTests() {
    var r = [];
    // Bekannte SHA256-Vektoren (vorgeneriert via tools/build-allowlist.js):
    var HASH_DEMO_001 = '81b22855e3a3cf0aa984b3daa221025dc4664c03b728f3ea95b4049b4af5de2f';
    var DAY_MS = 24 * 60 * 60 * 1000;

    // ---- 4.1 holeID (3 Tests) ----

    withGlobalLizenz(undefined, function () {
      r.push({ name: 'lizenz_test_holeID_ohne_window_GF_LIZENZ',
               ok: GF.lizenz.holeID() === null,
               detail: 'ist=' + GF.lizenz.holeID() });
    });

    withGlobalLizenz({ id: 'GF-PH-2026-001' }, function () {
      r.push({ name: 'lizenz_test_holeID_korrektes_praefix',
               ok: GF.lizenz.holeID() === 'GF-PH-2026-001',
               detail: 'ist=' + GF.lizenz.holeID() });
    });

    withGlobalLizenz({ id: 'VG-PH-2026-001' }, function () {
      // console.warn unterdruecken (Tool warnt absichtlich bei falschem Praefix)
      var origWarn = console.warn;
      console.warn = function () {};
      try {
        r.push({ name: 'lizenz_test_holeID_falsches_praefix',
                 ok: GF.lizenz.holeID() === null,
                 detail: 'ist=' + GF.lizenz.holeID() });
      } finally {
        console.warn = origWarn;
      }
    });

    // ---- 4.4 Demo-Tage (4 Tests, sync) ----

    var jetzt = Date.now();
    withDemoStart(new Date(jetzt).toISOString(), function () {
      r.push({ name: 'lizenz_test_tageVerbleibend_frischer_start',
               ok: GF.lizenz.tageVerbleibend() === 14,
               detail: 'ist=' + GF.lizenz.tageVerbleibend() });
    });
    withDemoStart(new Date(jetzt - 5 * DAY_MS).toISOString(), function () {
      r.push({ name: 'lizenz_test_tageVerbleibend_nach_5_tagen',
               ok: GF.lizenz.tageVerbleibend() === 9,
               detail: 'ist=' + GF.lizenz.tageVerbleibend() });
    });
    withDemoStart(new Date(jetzt - 20 * DAY_MS).toISOString(), function () {
      r.push({ name: 'lizenz_test_tageVerbleibend_ueberschritten',
               ok: GF.lizenz.tageVerbleibend() === 0,
               detail: 'ist=' + GF.lizenz.tageVerbleibend() });
    });
    withDemoStart(new Date(jetzt - 15 * DAY_MS).toISOString(), function () {
      r.push({ name: 'lizenz_test_demoAbgelaufen_true',
               ok: GF.lizenz.demoAbgelaufen() === true,
               detail: 'ist=' + GF.lizenz.demoAbgelaufen() });
    });

    // ---- 4.2 sha256Hex (2 Tests, async) ----

    var pSha1 = GF.lizenz.sha256Hex('GF-PH-2026-001').then(function (hash) {
      r.push({ name: 'sha256("GF-PH-2026-001") liefert 64-Hex',
               ok: typeof hash === 'string' && /^[0-9a-f]{64}$/.test(hash),
               detail: hash.slice(0, 16) + '...' });
    });

    var pSha2 = GF.lizenz.sha256Hex('GF-DEMO-001').then(function (hash) {
      r.push({ name: 'lizenz_test_sha256Hex_known_vector',
               ok: hash === HASH_DEMO_001,
               detail: 'ist=' + (hash || '').slice(0, 24) + '...' });
    });

    // ---- 4.3 pruefeWhitelist (5 Tests, async) ----

    /**
     * Mock-Fetcher-Factory: liefert beim Aufruf das gewuenschte Resultat.
     * @param {any} resultOrError
     * @param {boolean} [rejects]
     * @returns {{fn: (url: string) => Promise<any>, calls: number}}
     */
    function mockFetcher(resultOrError, rejects) {
      var state = { fn: /** @type {(url: string) => Promise<any>} */ (function () { return Promise.resolve(); }), calls: 0 };
      state.fn = function () {
        state.calls += 1;
        if (rejects) return Promise.reject(resultOrError);
        return Promise.resolve(resultOrError);
      };
      return state;
    }

    var p1 = withGlobalLizenz(undefined, function () {
      var mock = mockFetcher({ hashes: [] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_demo_modus',
                 ok: res.ok === false && res.modus === 'demo' && mock.calls === 0,
                 detail: 'res=' + JSON.stringify(res) + ' calls=' + mock.calls });
      });
    });

    var p2 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: [HASH_DEMO_001] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_id_in_liste',
                 ok: res.ok === true && res.modus === 'voll',
                 detail: JSON.stringify(res) });
      });
    });

    var p3 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: [] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_id_nicht_in_liste',
                 ok: res.ok === false && res.modus === 'voll' && res.grund === 'unbekannt',
                 detail: JSON.stringify(res) });
      });
    });

    var p4 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher(new Error('mock net err'), true);
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_netzwerk_fehler',
                 ok: res.ok === false && res.grund === 'netzwerk',
                 detail: JSON.stringify(res) });
      });
    });

    var p5 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      // Antwort ohne 'hashes'-Feld → 'kaputt'
      var mock = mockFetcher({});
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_kaputt',
                 ok: res.ok === false && res.grund === 'kaputt',
                 detail: JSON.stringify(res) });
      });
    });

    // hashes-Array enthaelt nicht-Hex-Werte (number, null) → 'kaputt'.
    // Schuetzt vor stillen indexOf-Misses bei verfaelschten Listen.
    var p6 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: [HASH_DEMO_001, 12345, null] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_hashes_nicht_hex',
                 ok: res.ok === false && res.grund === 'kaputt',
                 detail: JSON.stringify(res) });
      });
    });

    // hashes-Array enthaelt zu kurzen Hex-String → 'kaputt'
    var p7 = withGlobalLizenz({ id: 'GF-DEMO-001' }, function () {
      var mock = mockFetcher({ hashes: ['abc'] });
      return GF.lizenz.pruefeWhitelist({ fetcher: mock.fn }).then(function (res) {
        r.push({ name: 'lizenz_test_pruefeWhitelist_hash_zu_kurz',
                 ok: res.ok === false && res.grund === 'kaputt',
                 detail: JSON.stringify(res) });
      });
    });

    // ---- 4.5 updates.vergleiche (6 Tests, sync) ----
    // Lebt im Update-Subsystem aber hängt am Lizenz/Versions-Thema.

    if (GF.updates && typeof GF.updates.vergleiche === 'function') {
      var v = GF.updates.vergleiche;
      r.push({ name: 'vergleiche("1.0.0","1.0.0") = 0',
               ok: v('1.0.0', '1.0.0') === 0,
               detail: 'ist=' + v('1.0.0', '1.0.0') });
      r.push({ name: 'vergleiche("1.0.0","1.0.1") = -1',
               ok: v('1.0.0', '1.0.1') === -1,
               detail: 'ist=' + v('1.0.0', '1.0.1') });
      r.push({ name: 'vergleiche("2.0.0","1.99.99") = 1',
               ok: v('2.0.0', '1.99.99') === 1,
               detail: 'ist=' + v('2.0.0', '1.99.99') });
      // Pre-Release-Suffix wird ignoriert (semver-relaxed): "0.1.0-dev" == "0.1.0"
      r.push({ name: 'vergleiche("0.1.0-dev","0.1.0") = 0 (Suffix wird gestrippt)',
               ok: v('0.1.0-dev', '0.1.0') === 0,
               detail: 'ist=' + v('0.1.0-dev', '0.1.0') });
      r.push({ name: 'vergleiche("0.1.0-rc1","0.2.0") = -1 (Suffix wird gestrippt)',
               ok: v('0.1.0-rc1', '0.2.0') === -1,
               detail: 'ist=' + v('0.1.0-rc1', '0.2.0') });
      // Garbage-In → behandelt als 0.0.0, gleicher Garbage → 0
      r.push({ name: 'vergleiche("foo","bar") = 0 (beide → 0.0.0)',
               ok: v('foo', 'bar') === 0,
               detail: 'ist=' + v('foo', 'bar') });
    }

    return Promise.all([pSha1, pSha2, p1, p2, p3, p4, p5, p6, p7]).then(function () {
      return r;
    });
  }

  // ---- pdf-Tests (vektorAnteil-Heuristik + Viewport-Mathe) ----

  function pdfTests() {
    var r = [];

    // Fake OPS-Tabelle mit unverwechselbaren IDs (entspricht pdf.js-Verhalten)
    var OPS = {
      moveTo: 1, lineTo: 2, curveTo: 3, curveTo2: 4, curveTo3: 5,
      closePath: 6, rectangle: 7, fill: 8, stroke: 9, fillStroke: 10,
      eoFill: 11, eoFillStroke: 12, closeStroke: 13, closeFillStroke: 14,
      paintImageXObject: 100, paintImageMaskXObject: 101,
      paintInlineImageXObject: 102, paintJpegXObject: 103,
      paintImageXObjectRepeat: 104, paintImageMaskXObjectRepeat: 105
    };

    // Reines Vektor-PDF
    var s1 = GF.pdf._zaehleOps([1, 2, 2, 2, 3, 6], OPS);
    r.push({ name: 'zaehleOps: 6 Vektor-Ops -> vektor=6, bild=0',
             ok: s1.vektor === 6 && s1.bild === 0,
             detail: JSON.stringify(s1) });

    // Reines Raster-PDF (1 Bild)
    var s2 = GF.pdf._zaehleOps([100], OPS);
    r.push({ name: 'zaehleOps: 1 Bild -> bild=1, vektor=0',
             ok: s2.vektor === 0 && s2.bild === 1,
             detail: '' });

    // Gemischt
    var s3 = GF.pdf._zaehleOps([1, 2, 100, 3, 102, 999 /* andere */], OPS);
    r.push({ name: 'zaehleOps: gemischt vektor=3, bild=2, andere=1',
             ok: s3.vektor === 3 && s3.bild === 2 && s3.andere === 1,
             detail: JSON.stringify(s3) });

    // berechneAnteil: rein Vektor -> 1.0
    r.push({ name: 'berechneAnteil(vektor=100,bild=0) = 1.0',
             ok: GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 100, bild: 0 })) === 1.0,
             detail: '' });
    // berechneAnteil: rein Bild -> 0.0
    r.push({ name: 'berechneAnteil(vektor=0,bild=1) = 0.0',
             ok: GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 0, bild: 1 })) === 0.0,
             detail: '' });
    // berechneAnteil: leer -> 1.0 (Default)
    r.push({ name: 'berechneAnteil(vektor=0,bild=0) = 1.0',
             ok: GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 0, bild: 0 })) === 1.0,
             detail: '' });
    // Gemischtes Beispiel: 50 Vektor + 1 Bild (Gewicht 200) -> 50/(50+200) = 0.2 -> Warnung
    var anteil = GF.pdf._berechneAnteil(/** @type {any} */ ({ vektor: 50, bild: 1 }));
    r.push({ name: 'berechneAnteil(50/1) liegt unter Warnschwelle 0.3',
             ok: anteil < 0.3,
             detail: 'anteil=' + fmt(anteil) });

    // ---- Viewport-Mathe ----

    // zoomUmPunkt: Maus bei (100,100), Zoom 1->2, Pan(0,0)
    // mausPdf = 0 + 100/1 = 100, neuPan = 100 - 100/2 = 50
    var pan = GF.pdf.zoomUmPunkt(100, 100, 1, 2, { x: 0, y: 0 });
    r.push({ name: 'zoomUmPunkt: Maus (100,100), zoom 1->2 -> pan(50,50)',
             ok: nahe(pan.x, 50) && nahe(pan.y, 50),
             detail: 'pan=' + JSON.stringify(pan) });

    // Verifikation invariante Position: nach dem Zoom liegt PDF-Punkt (100,100) bei canvas (100,100)
    // canvasX = (pdfX - panX) * zoom = (100 - 50) * 2 = 100
    r.push({ name: 'Maus-Position invariant: PDF(100,100) bleibt bei canvas(100,100)',
             ok: nahe((100 - pan.x) * 2, 100) && nahe((100 - pan.y) * 2, 100),
             detail: '' });

    // fitViewport: cache 400x300, canvas 800x600 -> zoom < 2.0 (mit 5% Rand)
    var fakeCache  = /** @type {any} */ ({ breitePt: 400, hoehePt: 300 });
    var fakeCanvas = /** @type {any} */ ({ width: 800, height: 600 });
    var fit = GF.pdf.fitViewport(fakeCache, fakeCanvas);
    r.push({ name: 'fitViewport: zoom = min(2,2) * 0.95 = 1.9',
             ok: nahe(fit.zoom, 1.9, 1e-6),
             detail: 'zoom=' + fmt(fit.zoom) });

    // Seite ist zentriert: panX so, dass Mittelpunkt der Seite (200) bei canvas-Mitte (400) landet
    // canvasX(200) = (200 - panX) * zoom = 400 -> panX = 200 - 400/zoom = 200 - 210.5 = -10.5
    r.push({ name: 'fitViewport: Seitenmitte landet in Canvas-Mitte',
             ok: nahe((200 - fit.panX) * fit.zoom, 400, 1e-3),
             detail: 'panX=' + fmt(fit.panX) });

    return r;
  }

  // ---- Container-Roundtrip (.gfproj ZIP) ----
  // Async: liefert Promise<Array<{name, ok, detail}>>
  function containerRoundtripTest() {
    if (!global.fflate) {
      return Promise.resolve([{
        name: 'gfproj-Roundtrip: fflate verfuegbar', ok: false, detail: 'fflate fehlt'
      }]);
    }

    var projekt = GF.projekt.neu({ projektName: 'Test-Roundtrip', sachbearbeiter: 'Tester' });
    // 2 PDFs, 1 Geschoss, 1 Region, 1 Polygon — vollstaendiger Datenflow
    var pdfA = { id: 'pdf-a', dateiName: 'plan-1.pdf', originalDateiName: 'EG.pdf',
                 groesseBytes: 0, anzahlSeiten: 1, vektorAnteil: 0.9 };
    var pdfB = { id: 'pdf-b', dateiName: 'plan-2.pdf', originalDateiName: 'OG.pdf',
                 groesseBytes: 0, anzahlSeiten: 1, vektorAnteil: 0.5 };
    projekt.pdfs = [pdfA, pdfB];
    projekt.geschosse = [{ id: 'g1', bezeichnung: 'EG', reihenfolge: 0 }];
    projekt.planRegionen = [{
      id: 'r1', pdfId: 'pdf-a', seite: 1, geschossId: 'g1', bezeichnung: 'EG-Region',
      ausschnitt: { x: 10, y: 10, breite: 200, hoehe: 150 },
      kalibrierung: { punkt1: {x:0,y:0}, punkt2: {x:100,y:0}, abstandMeter: 5,
                      ptProMeter: 20, quelle: 'manuell',
                      abweichungVonNormProzent: 0, normMassstab: '1:100' }
    }];
    projekt.polygone = [{
      id: 'p1', regionId: 'r1', geschossId: 'g1', bezeichnung: 'Aussenkontur',
      punkte: [{x:0,y:0},{x:100,y:0},{x:100,y:100},{x:0,y:100}],
      flaecheGemessenQM: 25, flaecheAngesetztQM: 25,
      manuelleKorrektur: false, korrekturKommentar: '',
      farbeOverlay: '#ff8800', deckkraft: 0.5
    }];

    // Mini-PDF-Header — beginnt mit %PDF- (sonst Magic-Check failt)
    var pdfABytes = new TextEncoder().encode('%PDF-1.4\n%minimal A\n%%EOF\n');
    var pdfBBytes = new TextEncoder().encode('%PDF-1.4\n%minimal B\n%%EOF\n');
    var binaer = { 'plan-1.pdf': pdfABytes, 'plan-2.pdf': pdfBBytes };

    return GF.projekt.speichere(projekt, binaer).then(function (blob) {
      return blob.arrayBuffer().then(function (ab) {
        var fakeFile = /** @type {File} */ (/** @type {any} */ ({
          name: 'test.gfproj',
          arrayBuffer: function () { return Promise.resolve(ab); }
        }));
        return GF.projekt.lade(fakeFile);
      });
    }).then(function (ergebnis) {
      var r = [];
      r.push({ name: 'Roundtrip: projektName erhalten',
               ok: ergebnis.projekt.metadata.projektName === 'Test-Roundtrip',
               detail: 'ist=' + ergebnis.projekt.metadata.projektName });
      r.push({ name: 'Roundtrip: 2 PDFs erhalten',
               ok: ergebnis.projekt.pdfs.length === 2,
               detail: 'ist=' + ergebnis.projekt.pdfs.length });
      r.push({ name: 'Roundtrip: Polygon-Flaeche erhalten',
               ok: nahe(ergebnis.projekt.polygone[0].flaecheGemessenQM, 25, 1e-9),
               detail: 'ist=' + ergebnis.projekt.polygone[0].flaecheGemessenQM });
      r.push({ name: 'Roundtrip: PDF-A Bytes identisch',
               ok: bytesGleich(ergebnis.pdfBinaer['plan-1.pdf'], pdfABytes),
               detail: 'len=' + ergebnis.pdfBinaer['plan-1.pdf'].length });
      r.push({ name: 'Roundtrip: PDF-B Bytes identisch',
               ok: bytesGleich(ergebnis.pdfBinaer['plan-2.pdf'], pdfBBytes),
               detail: 'len=' + ergebnis.pdfBinaer['plan-2.pdf'].length });
      r.push({ name: 'Roundtrip: Kalibrierung ptProMeter erhalten',
               ok: nahe(ergebnis.projekt.planRegionen[0].kalibrierung.ptProMeter, 20, 1e-9),
               detail: '' });
      return r;
    }).catch(function (err) {
      return [{ name: 'gfproj-Roundtrip', ok: false, detail: err.message }];
    });
  }

  function bytesGleich(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  // ---- vollgeschoss-Tests (portiert aus VG-Tool v1.2.0) ----
  // Toleranz fuer Laengen/Flaechen: 0.01 (Geometrie ist rundungsempfindlich).

  var VG_TOL = 0.01;

  var VG_BERECHNUNGS_FAELLE = [
    {
      name: 'VG-A symm. Satteldach 45 Grad, h_K=1,00',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 88.80, vollgeschoss: true }
    },
    {
      name: 'VG-B flaches Dach 25 Grad, h_K=0,40',
      eingabe: { L_B: 10, L_L: 12, h_KL: 0.4, h_KR: 0.4, alpha_L: 25, alpha_R: 25,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 4.0744, X2: 4.0744, Bm: 1.8512, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 22.214, vollgeschoss: false }
    },
    {
      name: 'VG-C asymm. h_KL=1,5/h_KR=0,8 alpha_L=30/alpha_R=35',
      eingabe: { L_B: 8, L_L: 10, h_KL: 1.5, h_KR: 0.8, alpha_L: 30, alpha_R: 35,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.3856, X2: 2.1421, Bm: 4.4723, A_G: 80.00,
                   zweidrittel_flaeche: 53.333, A_2_30: 44.723, vollgeschoss: false }
    },
    {
      name: 'VG-D mit Gaube links (verschiebt 2,30-Linie)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 2.0, a: 0.3 }], gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 90.80, vollgeschoss: true }
    },
    {
      name: 'VG-E Abzuege getrennt (A_kleiner Nenner / A_groesser Zaehler)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 6, A_groesser: 2 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 114.00,
                   zweidrittel_flaeche: 76.00, A_2_30: 86.80, vollgeschoss: true }
    },
    {
      name: 'VG-G zwei Gauben links, unterschiedliche Traufabstaende',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 1.0, a: 0.0 }, { b: 1.5, a: 0.5 }],
                 gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 91.30, vollgeschoss: true }
    },
    {
      name: 'VG-F Pultdach (h_KR=2,5 >= Grenze -> X2=0)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 1.0, h_KR: 2.5, alpha_L: 45, alpha_R: 30,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 1.30, X2: 0.00, Bm: 8.70, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 104.40, vollgeschoss: true }
    },
    {
      name: 'VG-H h_KL genau an Grenze (=2,30) -> X1=0',
      eingabe: { L_B: 10, L_L: 12, h_KL: 2.30, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 0.00, X2: 1.30, Bm: 8.70, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 104.40, vollgeschoss: true }
    },
    {
      name: 'VG-I beide Kniestoecke >= 2,30 (Vollwand-DG)',
      eingabe: { L_B: 10, L_L: 12, h_KL: 2.5, h_KR: 2.5, alpha_L: 30, alpha_R: 30,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
      erwartung: { X1: 0.00, X2: 0.00, Bm: 10.00, A_G: 120.00,
                   zweidrittel_flaeche: 80.00, A_2_30: 120.00, vollgeschoss: true }
    }
  ];

  function vollgeschossTests() {
    var r = [];
    if (!GF.Vollgeschoss || !GF.Vollgeschoss.berechne) {
      r.push({ name: 'GF.Vollgeschoss.berechne verfuegbar', ok: false,
               detail: 'Modul vollgeschoss.js nicht geladen' });
      return r;
    }

    VG_BERECHNUNGS_FAELLE.forEach(function (fall) {
      var ergebnis = GF.Vollgeschoss.berechne(fall.eingabe);
      ['X1', 'X2', 'Bm', 'A_G', 'zweidrittel_flaeche', 'A_2_30'].forEach(function (k) {
        var ist = ergebnis[k];
        var soll = fall.erwartung[k];
        r.push({
          name: fall.name + ' - ' + k,
          ok: nahe(ist, soll, VG_TOL),
          detail: 'ist=' + fmt(ist) + ', soll=' + fmt(soll)
        });
      });
      r.push({
        name: fall.name + ' - vollgeschoss',
        ok: ergebnis.vollgeschoss === fall.erwartung.vollgeschoss,
        detail: 'ist=' + ergebnis.vollgeschoss
      });
    });

    var p = GF.Vollgeschoss.validierung.parseEingabe;
    var b = GF.Vollgeschoss.berechne;

    // Mikrotest 1: Komma-Parsing
    var m1 = p({ L_B: '10,5', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45' });
    r.push({ name: 'VG-Mikro: parseEingabe akzeptiert Komma',
             ok: m1.fehler.length === 0 && nahe(m1.eingabe.L_B, 10.5),
             detail: 'fehler=' + m1.fehler.length + ' L_B=' + m1.eingabe.L_B });

    // Mikrotest 2: alpha=0 -> Fehler
    var m2 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '0', alpha_R: '45' });
    r.push({ name: 'VG-Mikro: alpha_L=0 produziert Fehler',
             ok: m2.fehler.some(function (f) { return f.indexOf('alpha_L') !== -1; }),
             detail: JSON.stringify(m2.fehler) });

    // Mikrotest 3: alpha=90 -> Fehler
    var m3 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '90' });
    r.push({ name: 'VG-Mikro: alpha_R=90 produziert Fehler',
             ok: m3.fehler.some(function (f) { return f.indexOf('alpha_R') !== -1; }),
             detail: JSON.stringify(m3.fehler) });

    // Mikrotest 4: Bm-Clamp + Warnung
    var m4 = b({ L_B: 4, L_L: 10, h_KL: 0, h_KR: 0, alpha_L: 15, alpha_R: 15,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: sehr flaches Dach clampt Bm=0 + Warnung',
             ok: m4.Bm === 0 && m4.warnungen.some(function (w) { return w.indexOf('Bm') !== -1; }),
             detail: 'Bm=' + m4.Bm });

    // Mikrotest 5: leere optionale Felder -> 0
    var m5 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                 A_kleiner: '', A_groesser: '' });
    r.push({ name: 'VG-Mikro: leere optionale Felder werden 0',
             ok: m5.fehler.length === 0 && m5.eingabe.A_kleiner === 0 && m5.eingabe.A_groesser === 0,
             detail: '' });

    // Mikrotest 6: Sum Gaubenbreiten > L_L -> Fehler
    var m6 = p({ L_B: '10', L_L: '5', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                 gauben_links: [{ b: '6', a: '0' }] });
    r.push({ name: 'VG-Mikro: Summe Gaubenbreiten > L_L produziert Fehler',
             ok: m6.fehler.some(function (f) { return /Gaubenbreiten/.test(f); }),
             detail: JSON.stringify(m6.fehler) });

    // Mikrotest 7: Plausi-Obergrenze L_B > 500
    var m7 = p({ L_B: '10000', L_L: '8', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45' });
    r.push({ name: 'VG-Mikro: L_B > 500 m produziert Fehler',
             ok: m7.fehler.some(function (f) { return f.indexOf('L_B') !== -1; }),
             detail: '' });

    // Mikrotest 8: A_kleiner > A_G_brutto -> Warnung + nicht VG
    var m8 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [], gauben_rechts: [], A_kleiner: 200, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: A_kleiner > A_G_brutto produziert Warnung + vollgeschoss=false',
             ok: m8.warnungen.some(function (w) { return w.indexOf('Abzug') !== -1; }) && m8.vollgeschoss === false,
             detail: 'vollgeschoss=' + m8.vollgeschoss });

    // Mikrotest 9: Gauben-Warnung wenn a >= X
    var m9 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                 gauben_links: [{ b: 1.0, a: 1.5 }], gauben_rechts: [],
                 A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: Gaube mit a >= X warnt und traegt nicht bei',
             ok: m9.warnungen.some(function (w) { return /Gaube #1 links/.test(w); }) && nahe(m9.A_2_30, 88.80, VG_TOL),
             detail: 'A_2_30=' + m9.A_2_30 });

    // Mikrotest 10: A_kleiner > 1000 -> Fehler (Tippfehler-Schutz)
    var m10 = p({ L_B: '10', L_L: '12', h_KL: '1', h_KR: '1', alpha_L: '45', alpha_R: '45',
                  A_kleiner: '5000' });
    r.push({ name: 'VG-Mikro: A_kleiner > 1000 m^2 produziert Fehler',
             ok: m10.fehler.some(function (f) { return f.indexOf('Abzug < 2,30 m') !== -1; }),
             detail: '' });

    // Mikrotest 11: anteil_2_30 = null bei A_G <= 0
    var m11 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                  gauben_links: [], gauben_rechts: [], A_kleiner: 200, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: anteil_2_30 = null bei A_G <= 0 (kein NaN)',
             ok: m11.anteil_2_30 === null,
             detail: 'anteil_2_30=' + m11.anteil_2_30 });

    // Mikrotest 12: anteil_2_30 = A_2_30 / A_G (praezise)
    var m12 = b({ L_B: 10, L_L: 12, h_KL: 1, h_KR: 1, alpha_L: 45, alpha_R: 45,
                  gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 });
    r.push({ name: 'VG-Mikro: anteil_2_30 = A_2_30 / A_G (Fall A ~0,74)',
             ok: Math.abs(m12.anteil_2_30 - (m12.A_2_30 / m12.A_G)) < 1e-9
              && m12.anteil_2_30 > 0.73 && m12.anteil_2_30 < 0.75,
             detail: 'anteil_2_30=' + m12.anteil_2_30 });

    // Geometrie-Smoketest: querschnitt / grundriss / aufriss liefern Werte
    var ergG = b(VG_BERECHNUNGS_FAELLE[0].eingabe);
    var q = GF.Vollgeschoss.geometrie.querschnitt(VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    r.push({ name: 'VG-Geom: querschnitt liefert konturAussen mit 5 Punkten',
             ok: Array.isArray(q.konturAussen) && q.konturAussen.length === 5,
             detail: '' });
    r.push({ name: 'VG-Geom: querschnitt liefert hochpolygon bei Fall A',
             ok: Array.isArray(q.hochpolygon) && q.hochpolygon.length >= 3,
             detail: 'punkte=' + (q.hochpolygon || []).length });

    var gr = GF.Vollgeschoss.geometrie.grundriss(VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    r.push({ name: 'VG-Geom: grundriss liefert L_B/L_L korrekt',
             ok: gr.L_B === 10 && gr.L_L === 12,
             detail: '' });

    var auL = GF.Vollgeschoss.geometrie.aufriss('links',  VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    var auR = GF.Vollgeschoss.geometrie.aufriss('rechts', VG_BERECHNUNGS_FAELLE[0].eingabe, ergG);
    r.push({ name: 'VG-Geom: aufriss links liefert h_K=1,0',
             ok: auL.h_K === 1.0 && auL.seite === 'links',
             detail: '' });
    r.push({ name: 'VG-Geom: aufriss rechts liefert h_K=1,0',
             ok: auR.h_K === 1.0 && auR.seite === 'rechts',
             detail: '' });

    return r;
  }

  function exportAnrechnungTests() {
    var r = [];
    if (!GF.export || !GF.export.sammlerFlaechenJeGeschoss) {
      r.push({ name: 'GF.export.sammlerFlaechenJeGeschoss vorhanden',
               ok: false, detail: 'Funktion fehlt — export.js nicht geladen?' });
      return r;
    }

    // Mock-Projekt: 1 PDF, 1 Region, 1 Geschoss (DG), 1 Polygon, 1 VG-Block
    /**
     * @param {boolean} vgVorhanden
     * @returns {Projekt}
     */
    function machProjekt(vgVorhanden) {
      var p = GF.projekt.neu({ projektName: 'TestExport', sachbearbeiter: 'Tester' });
      p.pdfs.push(/** @type {any} */ ({ id: 'pdf-1', dateiName: 'Plan.pdf', containerPfad: 'plan-1.pdf' }));
      p.planRegionen.push(/** @type {any} */ ({ id: 'reg-1', pdfId: 'pdf-1', geschossId: 'g-dg',
                            seite: 1, rect: { x: 0, y: 0, w: 100, h: 100 } }));
      p.geschosse.push({ id: 'g-dg', bezeichnung: 'DG', reihenfolge: 1 });
      p.polygone.push(/** @type {any} */ ({ id: 'pl-1', regionId: 'reg-1', geschossId: 'g-dg',
                        bezeichnung: 'Hauptgebaeude',
                        punkte: [{x:0,y:0},{x:10,y:0},{x:10,y:10},{x:0,y:10}],
                        flaecheAngesetztQM: 100, manuelleKorrektur: false }));
      if (vgVorhanden) {
        p.geschosse[0].vollgeschoss = /** @type {VollgeschossBlock} */ (/** @type {any} */ ({
          durchgefuehrt: true,
          berechnetAm: '2026-05-12T10:00:00+02:00',
          berechnetVon: 'Tester',
          eingaben: { L_B: 10, L_L: 10, h_KL: 1.0, h_KR: 1.0, alpha_L: 45, alpha_R: 45,
                       gauben_links: [], gauben_rechts: [], A_kleiner: 0, A_groesser: 0 },
          ergebnis: { X1: 1.30, X2: 1.30, Bm: 7.40, A_G: 100, A_2_30: 42.5,
                       zweidrittel_flaeche: 66.67, anteil_2_30: 0.425, vollgeschoss: false,
                       differenz: -24.17, warnungen: [] },
          plausibilitaet: null,
          kommentar: ''
        }));
      }
      return p;
    }

    // 1) 'voll'-Modus: Zeile zeigt Polygonflaeche
    var pVoll = machProjekt(true);
    var tVoll = GF.export.sammlerFlaechenJeGeschoss(pVoll, { vgAnrechnung: 'voll' });
    r.push({ name: 'voll-Modus: Zeile zeigt Polygonflaeche (100 m²)',
             ok: tVoll.zeilen.length === 1 && Math.abs(tVoll.zeilen[0].flaeche - 100) < 0.001
                 && tVoll.zeilen[0].anrechnung === 'voll',
             detail: 'flaeche=' + tVoll.zeilen[0].flaeche + ', anr=' + tVoll.zeilen[0].anrechnung });

    // 2) 'anteilig'-Modus: Zeile zeigt A_2_30
    var pAnt = machProjekt(true);
    var tAnt = GF.export.sammlerFlaechenJeGeschoss(pAnt, { vgAnrechnung: 'anteilig' });
    r.push({ name: 'anteilig-Modus: Zeile zeigt A_2_30 (42,5 m²) + anrechnung="anteilig"',
             ok: tAnt.zeilen.length === 1 && Math.abs(tAnt.zeilen[0].flaeche - 42.5) < 0.001
                 && tAnt.zeilen[0].anrechnung === 'anteilig'
                 && Math.abs((tAnt.zeilen[0].polygonFlaeche || 0) - 100) < 0.001,
             detail: 'flaeche=' + tAnt.zeilen[0].flaeche + ', polygon=' + tAnt.zeilen[0].polygonFlaeche });

    // 3) anteilig-Modus + Geschoss ohne VG: bleibt Polygonflaeche
    var pKein = machProjekt(false);
    var tKein = GF.export.sammlerFlaechenJeGeschoss(pKein, { vgAnrechnung: 'anteilig' });
    r.push({ name: 'anteilig-Modus + kein VG: Polygonflaeche bleibt, anrechnung="voll"',
             ok: tKein.zeilen.length === 1 && Math.abs(tKein.zeilen[0].flaeche - 100) < 0.001
                 && tKein.zeilen[0].anrechnung === 'voll',
             detail: 'flaeche=' + tKein.zeilen[0].flaeche + ', anr=' + tKein.zeilen[0].anrechnung });

    // 4) Gesamtsumme entspricht Summe der gewaehlten Werte
    r.push({ name: 'Gesamtsumme = Summe der gewaehlten flaeche-Werte (anteilig)',
             ok: Math.abs(tAnt.gesamt - 42.5) < 0.001,
             detail: 'gesamt=' + tAnt.gesamt });

    // 5) metadata.vgAnrechnung Validierung: 'voll' / 'anteilig' / null akzeptiert
    var pmA = GF.projekt.neu({ projektName: 'T', sachbearbeiter: '' });
    pmA.metadata.vgAnrechnung = 'voll';
    var okA = false; try { okA = GF.projekt.validiere(pmA) === true; } catch (e) { okA = false; }
    r.push({ name: 'metadata.vgAnrechnung="voll" wird akzeptiert',
             ok: okA && pmA.metadata.vgAnrechnung === 'voll', detail: '' });

    var pmB = GF.projekt.neu({ projektName: 'T', sachbearbeiter: '' });
    pmB.metadata.vgAnrechnung = 'anteilig';
    var okB = false; try { okB = GF.projekt.validiere(pmB) === true; } catch (e) { okB = false; }
    r.push({ name: 'metadata.vgAnrechnung="anteilig" wird akzeptiert',
             ok: okB && pmB.metadata.vgAnrechnung === 'anteilig', detail: '' });

    // 6) Unbekannter Wert wird auf null zurueckgesetzt (lenient)
    var pmC = GF.projekt.neu({ projektName: 'T', sachbearbeiter: '' });
    pmC.metadata.vgAnrechnung = /** @type {any} */ ('irgendwas');
    try { GF.projekt.validiere(pmC); } catch (e) { /* nicht erwartet */ }
    r.push({ name: 'metadata.vgAnrechnung mit unbekanntem Wert wird auf null zurueckgesetzt',
             ok: pmC.metadata.vgAnrechnung === null,
             detail: 'ist=' + pmC.metadata.vgAnrechnung });

    // 7) ExportDialog.sammleVgGeschosse listet nur VG-Geschosse
    if (GF.ExportDialog && GF.ExportDialog.sammleVgGeschosse) {
      var vg = GF.ExportDialog.sammleVgGeschosse(pVoll);
      r.push({ name: 'ExportDialog.sammleVgGeschosse: 1 VG-Geschoss erkannt',
               ok: vg.length === 1 && vg[0].geschoss.bezeichnung === 'DG'
                   && Math.abs(vg[0].polygonFlaeche - 100) < 0.001
                   && Math.abs(vg[0].A_2_30 - 42.5) < 0.001,
               detail: JSON.stringify(vg.map(function (x) { return {n:x.geschoss.bezeichnung, p:x.polygonFlaeche, a:x.A_2_30}; })) });
      var vgKein = GF.ExportDialog.sammleVgGeschosse(pKein);
      r.push({ name: 'ExportDialog.sammleVgGeschosse: kein VG-Geschoss erkannt',
               ok: vgKein.length === 0, detail: 'len=' + vgKein.length });
    }

    return r;
  }

  GF.tests.fmt = fmt;
  GF.tests.runAll = function () {
    return {
      util: utilTests(),
      polygon: polygonTests(),
      region: regionTests(),
      schema: schemaTests(),
      pdf: pdfTests(),
      vollgeschoss: vollgeschossTests(),
      diagnose: diagnoseTests(),
      exportAnrechnung: exportAnrechnungTests()
    };
  };
  GF.tests.runLizenzTests = lizenzTests;
  GF.tests.runContainerTests = containerRoundtripTest;

})(typeof window !== 'undefined' ? window : globalThis);
