// @ts-check
// js/projekt.js — Projekt-Verwaltung: Anlegen, Speichern als .gfproj (ZIP),
// Laden, Schema-Validierung, Historien-Eintraege.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.projekt = GF.projekt || /** @type {GfProjektModule} */ ({});

  /** @type {2} */
  var SCHEMA_VERSION = 2; // v2: optionales geschosse[].vollgeschoss-Sub-Objekt
  /** @type {'zip-v1'} */
  var CONTAINER_FORMAT = 'zip-v1';
  /** @type {Array<1 | 2>} */
  var AKZEPTIERTE_SCHEMA_VERSIONEN = [1, 2];

  GF.projekt.SCHEMA_VERSION   = SCHEMA_VERSION;
  GF.projekt.CONTAINER_FORMAT = CONTAINER_FORMAT;

  /**
   * Liefert das aktuelle Projekt oder legt ein leeres an, falls noch keines
   * existiert. Aufrufen, sobald Daten gespeichert werden sollen (PDF laden,
   * Region zeichnen, etc.) -- der Sachbearbeiter muss kein "Neues Projekt"
   * explizit klicken.
   * @returns {Projekt}
   */
  GF.projekt.sorgeFuerProjekt = function () {
    if (GF.state.projekt) return GF.state.projekt;
    var neu = GF.projekt.neu({
      projektName: '(neu)',
      sachbearbeiter: (global.GF_KOMMUNE && global.GF_KOMMUNE.defaultSachbearbeiter) || '',
      kommune: (global.GF_KOMMUNE && global.GF_KOMMUNE.name) || ''
    });
    GF.state.update(function (s) {
      s.projekt = neu;
      s.ungespeicherteAenderungen = false;
    });
    return neu;
  };

  // Default-Metadaten (zentral, damit Lade- und Neu-Weg dasselbe Schema garantieren).
  GF.projekt.METADATA_DEFAULTS = {
    projektName: '',
    projektNummer: '',            // Akten-/Aktenzeichen, z. B. "2022/16"
    bauvorhaben: '',
    bauherr: '',
    bauherrAnschriftStrasse: '',
    bauherrAnschriftPLZ: '',
    bauherrAnschriftOrt: '',
    bauherrPKNr: '',              // Personen-/Kundennummer im Verwaltungssystem
    bauortStrasse: '',
    bauortPLZ: '',
    bauortOrt: '',
    flurnummer: '',
    gemarkung: '',
    sachbearbeiter: '',
    zusatzinfo: '',               // mehrzeilig
    kommune: '',
    erstelltAm: '',
    geandertAm: '',
    revision: 1,
    // Anrechnungs-Modus fuer VG-Geschosse beim PDF-Export:
    //   null      -> noch nicht gewaehlt (Dialog fragt beim ersten Export)
    //   'voll'    -> Polygonflaeche (komplette Grundflaeche)
    //   'anteilig'-> A_2,30 aus VG-Berechnung (nur Bereich mit lichter Hoehe >=2,30 m)
    vgAnrechnung: null
  };

  /**
   * @param {Partial<ProjektMetadata>} [metadaten]
   * @returns {Projekt}
   */
  GF.projekt.neu = function (metadaten) {
    var jetzt = new Date().toISOString();
    var defaults = Object.assign({}, GF.projekt.METADATA_DEFAULTS, {
      kommune: (global.GF_KOMMUNE && global.GF_KOMMUNE.name) || '',
      erstelltAm: jetzt,
      geandertAm: jetzt
    });
    return {
      schemaVersion: SCHEMA_VERSION,
      appVersion: GF.VERSION || '0.0.0',
      containerFormat: CONTAINER_FORMAT,
      metadata: Object.assign(defaults, metadaten || {}),
      historie: [{
        revision: 1,
        datum: jetzt,
        sachbearbeiter: (metadaten && metadaten.sachbearbeiter) || '',
        aktion: 'Projekt angelegt',
        kommentar: ''
      }],
      einstellungen: {
        rundungsRegel: 'keine',
        rundungsStellen: 2,
        snapToleranzPunkte: 8,
        winkelToleranzGrad: 2,
        protokollFormat: 'A4'
      },
      pdfs: [],
      planRegionen: [],
      geschosse: [],
      polygone: []
    };
  };

  /**
   * Validiert ein Projekt-Objekt. Wirft mit aussagekraeftiger Meldung.
   * @param {Projekt} projekt
   * @returns {true}
   */
  GF.projekt.validiere = function (projekt) {
    if (!projekt || typeof projekt !== 'object') throw new Error('Projekt fehlt');
    if (AKZEPTIERTE_SCHEMA_VERSIONEN.indexOf(projekt.schemaVersion) < 0) {
      throw new Error('Unbekannte schemaVersion: ' + projekt.schemaVersion + ' (akzeptiert: ' + AKZEPTIERTE_SCHEMA_VERSIONEN.join(', ') + ')');
    }
    if (projekt.containerFormat !== CONTAINER_FORMAT) {
      throw new Error('Unbekanntes containerFormat: ' + projekt.containerFormat);
    }
    if (!Array.isArray(projekt.pdfs)) throw new Error('projekt.pdfs muss Array sein');
    if (!Array.isArray(projekt.planRegionen)) throw new Error('projekt.planRegionen muss Array sein');
    if (!Array.isArray(projekt.geschosse)) throw new Error('projekt.geschosse muss Array sein');
    if (!Array.isArray(projekt.polygone)) throw new Error('projekt.polygone muss Array sein');

    // metadata.vgAnrechnung: nur 'voll' | 'anteilig' | null akzeptieren.
    // Lenient: unbekannten Wert auf null zuruecksetzen, damit der Dialog
    // beim naechsten Export wieder fragt.
    if (projekt.metadata && projekt.metadata.vgAnrechnung != null
        && projekt.metadata.vgAnrechnung !== 'voll'
        && projekt.metadata.vgAnrechnung !== 'anteilig') {
      console.warn('[gf-projekt] metadata.vgAnrechnung hat unbekannten Wert "'
        + projekt.metadata.vgAnrechnung + '" — wird auf null zurückgesetzt.');
      projekt.metadata.vgAnrechnung = null;
    }

    // Referentielle Integritaet
    var pdfIds = projekt.pdfs.map(function (p) { return p.id; });
    var regionIds = projekt.planRegionen.map(function (r) { return r.id; });
    var geschossIds = projekt.geschosse.map(function (g) { return g.id; });

    projekt.planRegionen.forEach(function (r, i) {
      if (pdfIds.indexOf(r.pdfId) < 0) {
        throw new Error('planRegionen[' + i + '].pdfId verweist auf nicht-existente PDF: ' + r.pdfId);
      }
      if (r.geschossId !== null && geschossIds.indexOf(r.geschossId) < 0) {
        throw new Error('planRegionen[' + i + '].geschossId nicht gefunden: ' + r.geschossId);
      }
    });

    projekt.polygone.forEach(function (p, i) {
      if (regionIds.indexOf(p.regionId) < 0) {
        throw new Error('polygone[' + i + '].regionId nicht gefunden: ' + p.regionId);
      }
      if (geschossIds.indexOf(p.geschossId) < 0) {
        throw new Error('polygone[' + i + '].geschossId nicht gefunden: ' + p.geschossId);
      }
      if (!Array.isArray(p.punkte) || p.punkte.length < 3) {
        throw new Error('polygone[' + i + '] braucht mindestens 3 Punkte');
      }
    });

    // Lenient: vollgeschoss-Blocks (Schema v2). Bei Verstoss console.warn,
    // kein throw — Akten leben 30+ Jahre, kein Datenverlust durch Lade-Abbruch.
    var polygonIds = projekt.polygone.map(function (p) { return p.id; });
    projekt.geschosse.forEach(function (g, gi) {
      if (!g.vollgeschoss) return;
      var vg = g.vollgeschoss;
      var warnungen = [];
      if (vg.durchgefuehrt !== true) warnungen.push('vollgeschoss.durchgefuehrt nicht true');
      if (!vg.eingaben || typeof vg.eingaben !== 'object') warnungen.push('vollgeschoss.eingaben fehlt');
      else {
        ['L_B','L_L','h_KL','h_KR','alpha_L','alpha_R'].forEach(function (k) {
          var v = vg.eingaben[k];
          if (typeof v !== 'number' || !isFinite(v)) warnungen.push('eingaben.' + k + ' fehlt oder kein Zahl');
        });
      }
      if (!vg.ergebnis || typeof vg.ergebnis !== 'object') warnungen.push('vollgeschoss.ergebnis fehlt');
      else if (typeof vg.ergebnis.A_G === 'number' && typeof vg.ergebnis.A_2_30 === 'number'
               && vg.ergebnis.A_G > 0 && vg.ergebnis.A_2_30 > vg.ergebnis.A_G + 0.01) {
        warnungen.push('A_2_30 > A_G (Eingabe inkonsistent)');
      }
      if (vg.plausibilitaet && vg.plausibilitaet.polygonId
          && polygonIds.indexOf(vg.plausibilitaet.polygonId) < 0) {
        warnungen.push('plausibilitaet.polygonId verweist auf nicht-existentes Polygon');
        vg.plausibilitaet = null; // ungueltige Ref entfernen
      }
      if (warnungen.length > 0) {
        console.warn('[gf-projekt] vollgeschoss-Block geschosse[' + gi + '] "' + g.bezeichnung + '" inkonsistent:', warnungen);
      }
    });

    return true;
  };

  /**
   * @param {Projekt} projekt
   * @param {string} aktion
   * @param {string} [kommentar]
   */
  GF.projekt.historieEintrag = function (projekt, aktion, kommentar) {
    var jetzt = new Date().toISOString();
    projekt.metadata.revision = (projekt.metadata.revision || 0) + 1;
    projekt.metadata.geandertAm = jetzt;
    projekt.historie.push({
      revision: projekt.metadata.revision,
      datum: jetzt,
      sachbearbeiter: projekt.metadata.sachbearbeiter || '',
      aktion: aktion,
      kommentar: kommentar || ''
    });
  };

  /**
   * Speichert Projekt + zugehoerige PDF-Binaerdaten als .gfproj-ZIP-Blob.
   * Map containerPfad -> Uint8Array (z.B. {"plan-1.pdf": Uint8Array(...)});
   * der Key muss zu projekt.pdfs[].containerPfad passen (Fallback: dateiName).
   * @param {Projekt} projekt validiertes Projekt-Objekt
   * @param {Record<string, Uint8Array>} [pdfBinaer]
   * @returns {Promise<Blob>}
   */
  GF.projekt.speichere = function (projekt, pdfBinaer) {
    // Schema-Lift: alte v1-Projekte werden beim Speichern auf v2 angehoben.
    projekt.schemaVersion = SCHEMA_VERSION;
    try {
      GF.projekt.validiere(projekt);
    } catch (e) {
      return Promise.reject(e);
    }
    if (!global.fflate) {
      return Promise.reject(new Error('fflate-Lib nicht geladen (lib/fflate.min.js fehlt)'));
    }
    pdfBinaer = pdfBinaer || {};

    // Pruefe dass jede in projekt.pdfs gelistete PDF auch als Binary vorliegt.
    // Container-Pfad ist getrennt vom Anzeigename (dateiName).
    for (var i = 0; i < projekt.pdfs.length; i++) {
      var pn = projekt.pdfs[i].containerPfad || projekt.pdfs[i].dateiName;
      if (!pdfBinaer[pn] || !(pdfBinaer[pn] instanceof Uint8Array)) {
        return Promise.reject(new Error(
          'PDF-Binary fehlt für "' + pn + '" — kann nicht speichern.'
        ));
      }
    }

    // ZIP-Struktur aufbauen: flat map of {dateiName: Uint8Array}
    var zipObj = Object.create(null);
    var jsonText = JSON.stringify(projekt, null, 2);
    zipObj['projekt.json'] = new TextEncoder().encode(jsonText);
    Object.keys(pdfBinaer).forEach(function (name) {
      zipObj[name] = pdfBinaer[name];
    });

    return new Promise(function (resolve, reject) {
      if (!global.fflate) { reject(new Error('fflate fehlt')); return; }
      global.fflate.zip(zipObj, { level: 6 }, function (err, data) {
        if (err) { reject(err); return; }
        resolve(new Blob([/** @type {BlobPart} */ (data)], { type: 'application/zip' }));
      });
    });
  };

  /**
   * Laedt eine .gfproj-Datei und validiert das Projekt-Objekt vor der Rueckgabe.
   * @param {File | Blob} file
   * @returns {Promise<{projekt: Projekt, pdfBinaer: Record<string, Uint8Array>}>}
   */
  GF.projekt.lade = function (file) {
    if (!global.fflate) {
      return Promise.reject(new Error('fflate-Lib nicht geladen (lib/fflate.min.js fehlt)'));
    }
    if (!file || typeof file.arrayBuffer !== 'function') {
      return Promise.reject(new Error('Ungueltige Datei (File-Objekt erwartet)'));
    }
    return file.arrayBuffer().then(function (ab) {
      return new Promise(function (resolve, reject) {
        var bytes = new Uint8Array(ab);
        global.fflate.unzip(bytes, function (err, unzipped) {
          if (err) { reject(new Error('ZIP konnte nicht entpackt werden: ' + err.message)); return; }
          try {
            if (!unzipped['projekt.json']) {
              throw new Error('projekt.json fehlt im Container (keine gueltige .gfproj-Datei?)');
            }
            var jsonText = new TextDecoder('utf-8').decode(unzipped['projekt.json']);
            var projekt;
            try {
              projekt = JSON.parse(jsonText);
            } catch (jsonErr) {
              throw new Error('projekt.json ist kein gueltiges JSON: ' + jsonErr.message);
            }
            // Vorwaerts-Migration: fehlende Metadaten-Felder mit Defaults auffuellen,
            // damit aeltere Projekte ohne projektNummer / Bauherr-Anschrift / etc.
            // weiter funktionieren und das Aufmassprotokoll keine 'undefined' druckt.
            projekt.metadata = Object.assign({}, GF.projekt.METADATA_DEFAULTS, projekt.metadata || {});
            GF.projekt.validiere(projekt);

            // PDF-Binaerdaten zusammensammeln und gegen projekt.pdfs abgleichen.
            // containerPfad ist der ZIP-Eintragsname; bei aelteren Containern
            // (vor Schema-Update) liegt er noch in dateiName.
            var pdfBinaer = Object.create(null);
            for (var i = 0; i < projekt.pdfs.length; i++) {
              var meta = projekt.pdfs[i];
              var pn = meta.containerPfad || meta.dateiName;
              if (!unzipped[pn]) {
                throw new Error('PDF "' + pn + '" fehlt im Container');
              }
              // Magic-Bytes-Check (%PDF-)
              var head = unzipped[pn];
              if (head.length < 5 || head[0] !== 0x25 || head[1] !== 0x50 || head[2] !== 0x44 || head[3] !== 0x46 || head[4] !== 0x2D) {
                throw new Error('Eintrag "' + pn + '" beginnt nicht mit %PDF-');
              }
              pdfBinaer[pn] = head;
              // Schema-Migration fuer aeltere .zip-Dateien (Phase-4b-Vintage,
              // bei denen dateiName == ZIP-Pfad war):
              //   - containerPfad fehlte -> aus dateiName uebernehmen
              //   - dateiName sah aus wie "plan-N.pdf" und originalDateiName war
              //     da -> Anzeigename auf originalDateiName setzen
              if (!meta.containerPfad) {
                meta.containerPfad = meta.dateiName;
                if (/^plan-\d+\.pdf$/i.test(meta.dateiName || '') && meta.originalDateiName) {
                  meta.dateiName = meta.originalDateiName;
                }
              }
              if (!meta.dateiName) meta.dateiName = meta.originalDateiName || meta.containerPfad;
            }
            resolve({ projekt: projekt, pdfBinaer: pdfBinaer });
          } catch (validationErr) {
            reject(validationErr);
          }
        });
      });
    });
  };

})(typeof window !== 'undefined' ? window : globalThis);
