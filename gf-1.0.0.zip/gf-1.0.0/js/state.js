// @ts-check
// js/state.js — Zentraler App-State mit Observer-Pattern.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});

  /** @type {Array<(s: GfStateFields) => void>} */
  var listeners = [];

  GF.state = /** @type {GfStateModule} */ ({
    projekt: null,                 // Aktuelles geladenes Projekt oder null
    aktiveRegionId: null,
    aktivesGeschossId: null,
    aktivesPolygonId: null,
    aktivesWerkzeug: 'pan',        // 'pan' | 'region' | 'massstab' | 'polygon' | 'bearbeiten'
    ungespeicherteAenderungen: false,

    // PDF-Anzeige (Phase 1, Multi-PDF)
    pdfs: [],                      // Array von {id, dateiName, pdfDoc, anzahlSeiten}
    aktivePdfId: null,             // id aus pdfs[] (oder null wenn nichts geladen)
    aktuelleSeite: 1,              // Seite innerhalb des aktiven PDF
    vektorAnteil: null,            // Vektor-Anteil der aktuell sichtbaren Seite, null|[0..1]
    pdfCache: null,                // Pre-Render-Cache {canvas, breitePt, hoehePt, renderScale}
    viewport: { zoom: 1.0, panX: 0, panY: 0 },

    // Anzeige-Toggle (LocalStorage-persistiert via app.js)
    massstabSichtbar: true
  });

  /**
   * Registriert einen State-Listener. Liefert eine Unsubscribe-Funktion zurueck.
   * @param {(s: GfStateFields) => void} fn
   * @returns {() => void}
   */
  GF.state.subscribe = function (fn) {
    listeners.push(fn);
    return function unsubscribe() {
      var i = listeners.indexOf(fn);
      if (i >= 0) listeners.splice(i, 1);
    };
  };

  /**
   * Mutiert den State (Updater wird mit dem State-Singleton aufgerufen) und
   * informiert alle Listener.
   * @param {(s: GfStateFields) => void} [updater]
   */
  GF.state.update = function (updater) {
    if (typeof updater === 'function') updater(GF.state);
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](GF.state); } catch (e) { console.error('[gf-state]', e); }
    }
  };

  GF.state.markiereGeaendert = function () {
    GF.state.ungespeicherteAenderungen = true;
    GF.state.update(function () {});
  };

  // Convenience-Lookups

  /**
   * @param {string} id
   * @returns {Polygon | null}
   */
  GF.state.findPolygon = function (id) {
    var p = GF.state.projekt;
    if (!p || !p.polygone) return null;
    for (var i = 0; i < p.polygone.length; i++) if (p.polygone[i].id === id) return p.polygone[i];
    return null;
  };

  /**
   * @param {string} id
   * @returns {Region | null}
   */
  GF.state.findRegion = function (id) {
    var p = GF.state.projekt;
    if (!p || !p.planRegionen) return null;
    for (var i = 0; i < p.planRegionen.length; i++) if (p.planRegionen[i].id === id) return p.planRegionen[i];
    return null;
  };

  /**
   * @param {string} id
   * @returns {Geschoss | null}
   */
  GF.state.findGeschoss = function (id) {
    var p = GF.state.projekt;
    if (!p || !p.geschosse) return null;
    for (var i = 0; i < p.geschosse.length; i++) if (p.geschosse[i].id === id) return p.geschosse[i];
    return null;
  };

  /**
   * @param {string | null} id
   * @returns {Pdf | null}
   */
  GF.state.findPdf = function (id) {
    if (id == null) return null;
    for (var i = 0; i < GF.state.pdfs.length; i++) {
      if (GF.state.pdfs[i].id === id) return GF.state.pdfs[i];
    }
    return null;
  };

  /** @returns {Pdf | null} */
  GF.state.aktivesPdf = function () {
    return GF.state.findPdf(GF.state.aktivePdfId);
  };

})(typeof window !== 'undefined' ? window : globalThis);
