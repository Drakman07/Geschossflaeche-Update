// @ts-check
// js/vg-diagramm.js — SVG-Renderer fuer Querschnitt, Grundriss, Aufriss.
// Konsumiert GF.Vollgeschoss.geometrie.{querschnitt,grundriss,aufriss}.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';

  /**
   * SVG-Element-Helper. Erstellt ein Element im SVG-Namespace, setzt Attribute,
   * haengt optional in einen Parent ein.
   * @param {string} name
   * @param {Record<string, string | number | null | undefined>} [attrs]
   * @param {Element} [parent]
   * @returns {SVGElement}
   */
  function el(name, attrs, parent) {
    var n = document.createElementNS(NS, name);
    if (attrs) for (var k in attrs) if (attrs[k] !== undefined && attrs[k] !== null) n.setAttribute(k, String(attrs[k]));
    if (parent) parent.appendChild(n);
    return /** @type {SVGElement} */ (n);
  }

  function fmtM(n) {
    return n.toLocaleString('de-DE', { maximumFractionDigits: 2, minimumFractionDigits: 2 }) + ' m';
  }
  function fmtGrad(n) {
    return n.toLocaleString('de-DE', { maximumFractionDigits: 1, minimumFractionDigits: 0 }) + '°';
  }

  // Querschnitt (Hauptdiagramm)
  function renderQuerschnitt(svg, q) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);

    var W = 400, H = 240;
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);

    var padL = 44, padR = 44, padT = 18, padB = 56;
    var innerW = W - padL - padR;
    var innerH = H - padT - padB;

    var maxX = q.L_B || 1;
    var maxY = q.hoeheGesamt + 0.4;
    var sx = innerW / maxX;
    var sy = innerH / maxY;
    var s = Math.min(sx, sy);

    var drawW = maxX * s;
    var drawH = maxY * s;
    var ox = padL + (innerW - drawW) / 2;
    var oy = padT + innerH;

    function px(p) { return ox + p.x * s; }
    function py(p) { return oy - p.y * s; }

    // Bodenlinie
    el('line', {
      x1: padL - 6, x2: W - padR + 6, y1: oy + 0.5, y2: oy + 0.5,
      stroke: '#d1d5db', 'stroke-width': 1
    }, svg);

    // Aussenkontur (DG-Innenraum)
    var konturPts = q.konturAussen.map(function (p) { return px(p) + ',' + py(p); }).join(' ');
    el('polygon', {
      points: konturPts,
      fill: '#f3f4f6', stroke: '#4b5563', 'stroke-width': 1.4
    }, svg);

    // Schraffur "Bereich >= 2,30 m"
    if (q.hochpolygon && q.hochpolygon.length >= 3) {
      var hochPts = q.hochpolygon.map(function (p) { return px(p) + ',' + py(p); }).join(' ');
      el('polygon', {
        points: hochPts,
        fill: 'rgba(21, 128, 61, 0.22)', stroke: '#15803d', 'stroke-width': 1
      }, svg);
    }

    // 2,30 m-Linie
    var yGrenz = py({ x: 0, y: q.grenzhoehe });
    el('line', {
      x1: ox - 6, x2: ox + drawW + 6, y1: yGrenz, y2: yGrenz,
      stroke: '#b91c1c', 'stroke-width': 1, 'stroke-dasharray': '5 3'
    }, svg);
    el('text', {
      x: ox + drawW + 4, y: yGrenz - 2, 'text-anchor': 'end',
      font: '10px -apple-system, sans-serif', fill: '#b91c1c'
    }, svg).textContent = '2,30 m';

    // Pfeilkoepfe
    var defs = el('defs', {}, svg);
    var marker = el('marker', {
      id: 'arrow', viewBox: '0 0 10 10', refX: 5, refY: 5,
      markerWidth: 5, markerHeight: 5, orient: 'auto'
    }, defs);
    el('path', { d: 'M0,0 L10,5 L0,10 z', fill: '#15803d' }, marker);
    var markerR = el('marker', {
      id: 'arrow-danger', viewBox: '0 0 10 10', refX: 5, refY: 5,
      markerWidth: 5, markerHeight: 5, orient: 'auto'
    }, defs);
    el('path', { d: 'M0,0 L10,5 L0,10 z', fill: '#b91c1c' }, markerR);
    var markerG = el('marker', {
      id: 'arrow-grey', viewBox: '0 0 10 10', refX: 5, refY: 5,
      markerWidth: 5, markerHeight: 5, orient: 'auto'
    }, defs);
    el('path', { d: 'M0,0 L10,5 L0,10 z', fill: '#4b5563' }, markerG);

    // X1/X2 Tracking-Linien
    if (q.X1 > 0) {
      var xX1 = ox + q.X1 * s;
      el('line', { x1: xX1, x2: xX1, y1: oy, y2: yGrenz,
                   stroke: '#9ca3af', 'stroke-width': 0.8, 'stroke-dasharray': '2 2' }, svg);
    }
    if (q.X2 > 0) {
      var xX2r = ox + (q.L_B - q.X2) * s;
      el('line', { x1: xX2r, x2: xX2r, y1: oy, y2: yGrenz,
                   stroke: '#9ca3af', 'stroke-width': 0.8, 'stroke-dasharray': '2 2' }, svg);
    }

    // Bm-Bemassung (mit "lichte Höhe ≥ 2,30 m"-Hinweis darunter, klein)
    if (q.Bm > 0 && q.X1 + q.X2 < q.L_B) {
      var xa = ox + q.X1 * s;
      var xb = ox + (q.L_B - q.X2) * s;
      var ybm = yGrenz - 7;
      el('line', { x1: xa, x2: xb, y1: ybm, y2: ybm,
                   stroke: '#15803d', 'stroke-width': 1.2,
                   'marker-end': 'url(#arrow)', 'marker-start': 'url(#arrow)' }, svg);
      el('text', { x: (xa + xb) / 2, y: ybm - 4, 'text-anchor': 'middle',
                   font: 'bold 10px -apple-system, sans-serif', fill: '#15803d' }, svg)
        .textContent = fmtM(q.Bm);
    }

    // X1/X2-Bemassungen unterhalb des Bodens (nur Werte, ohne "X1=" Praefix)
    var yX12 = oy + 14;
    if (q.X1 > 0) {
      el('line', { x1: ox, x2: ox + q.X1 * s, y1: yX12, y2: yX12,
                   stroke: '#b91c1c', 'stroke-width': 1.1,
                   'marker-end': 'url(#arrow-danger)', 'marker-start': 'url(#arrow-danger)' }, svg);
      el('text', { x: ox + q.X1 * s / 2, y: yX12 + 11, 'text-anchor': 'middle',
                   font: '9px -apple-system, sans-serif', fill: '#b91c1c' }, svg)
        .textContent = fmtM(q.X1);
    }
    if (q.X2 > 0) {
      var xax2 = ox + (q.L_B - q.X2) * s;
      var xbx2 = ox + drawW;
      el('line', { x1: xax2, x2: xbx2, y1: yX12, y2: yX12,
                   stroke: '#b91c1c', 'stroke-width': 1.1,
                   'marker-end': 'url(#arrow-danger)', 'marker-start': 'url(#arrow-danger)' }, svg);
      el('text', { x: (xax2 + xbx2) / 2, y: yX12 + 11, 'text-anchor': 'middle',
                   font: '9px -apple-system, sans-serif', fill: '#b91c1c' }, svg)
        .textContent = fmtM(q.X2);
    }

    // Gebaeudebreite unten (Maßkette mit Pfeilen)
    var yLB = oy + 32;
    el('line', { x1: ox, x2: ox + drawW, y1: yLB, y2: yLB,
                 stroke: '#4b5563', 'stroke-width': 0.8,
                 'marker-end': 'url(#arrow-grey)', 'marker-start': 'url(#arrow-grey)' }, svg);
    el('text', { x: ox + drawW / 2, y: yLB - 3, 'text-anchor': 'middle',
                 font: '10px -apple-system, sans-serif', fill: '#1f2937' }, svg)
      .textContent = fmtM(q.L_B);

    // Kniestockhoehen links/rechts (nur Werte, dezent, mit etwas Abstand zur Wand)
    var yKL = py({ x: 0, y: q.h_KL / 2 });
    el('text', { x: ox - 6, y: yKL, 'text-anchor': 'end', 'dominant-baseline': 'middle',
                 font: '9px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = fmtM(q.h_KL);
    var yKR = py({ x: 0, y: q.h_KR / 2 });
    el('text', { x: ox + drawW + 6, y: yKR, 'text-anchor': 'start', 'dominant-baseline': 'middle',
                 font: '9px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = fmtM(q.h_KR);

    // Dachneigungen: pro Dachhaelfte ein kleines Label
    var dachMittelLx = ox + (q.xFirst * s) / 2;
    var dachMittelLy = py({ x: q.xFirst / 2, y: (q.h_KL + q.firstHoehe) / 2 }) - 4;
    el('text', { x: dachMittelLx, y: dachMittelLy, 'text-anchor': 'middle',
                 font: '9px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = fmtGrad(q.alpha_L);
    var dachMittelRx = ox + q.xFirst * s + (drawW - q.xFirst * s) / 2;
    var dachMittelRy = py({ x: (q.L_B + q.xFirst) / 2, y: (q.h_KR + q.firstHoehe) / 2 }) - 4;
    el('text', { x: dachMittelRx, y: dachMittelRy, 'text-anchor': 'middle',
                 font: '9px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = fmtGrad(q.alpha_R);
  }

  // Grundriss (Draufsicht)
  function renderGrundriss(svg, g) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var W = 400, H = 240;
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);

    // padT erhoeht fuer Gauben-Labels oberhalb; padR fuer X1/X2-Labels
    var padL = 30, padR = 32, padT = 30, padB = 36;
    var innerW = W - padL - padR;
    var innerH = H - padT - padB;
    var sx = innerW / (g.L_L || 1);
    var sy = innerH / (g.L_B || 1);
    var s = Math.min(sx, sy);
    var drawW = (g.L_L || 0) * s;
    var drawH = (g.L_B || 0) * s;
    var ox = padL + (innerW - drawW) / 2;
    var oy = padT;

    // Bm-Bereich gruen
    el('rect', { x: ox, y: oy, width: drawW, height: drawH,
                 fill: 'rgba(21, 128, 61, 0.10)',
                 stroke: '#9ca3af', 'stroke-width': 1 }, svg);

    // Streifen X1 oben
    if (g.X1 > 0) {
      el('rect', { x: ox, y: oy, width: drawW, height: g.X1 * s,
                   fill: '#f3f4f6', stroke: 'none' }, svg);
      el('line', { x1: ox, y1: oy + g.X1 * s, x2: ox + drawW, y2: oy + g.X1 * s,
                   stroke: '#b91c1c', 'stroke-width': 1, 'stroke-dasharray': '4 3' }, svg);
    }
    // Streifen X2 unten
    if (g.X2 > 0) {
      el('rect', { x: ox, y: oy + drawH - g.X2 * s, width: drawW, height: g.X2 * s,
                   fill: '#f3f4f6' }, svg);
      el('line', { x1: ox, y1: oy + drawH - g.X2 * s, x2: ox + drawW, y2: oy + drawH - g.X2 * s,
                   stroke: '#b91c1c', 'stroke-width': 1, 'stroke-dasharray': '4 3' }, svg);
    }

    // Aussenrahmen
    el('rect', { x: ox, y: oy, width: drawW, height: drawH,
                 fill: 'none', stroke: '#4b5563', 'stroke-width': 1.5 }, svg);

    // Gauben — Labels AUSSERHALB der Rechtecke mit grosszuegigem Abstand
    function zeichneGauben(liste, seiteOben) {
      liste.forEach(function (gp, idx) {
        var gx = ox + gp.ortgang * s;
        var gw = gp.b * s;
        var gy, gh;
        if (seiteOben) {
          gy = oy + gp.a * s;
          gh = gp.eingedrungen * s;
          if (gh < 4) gh = 4;
        } else {
          gy = oy + drawH - gp.a * s - gp.eingedrungen * s;
          gh = gp.eingedrungen * s;
          if (gh < 4) { gh = 4; gy = oy + drawH - gp.a * s - 4; }
        }
        el('rect', { x: gx, y: gy, width: gw, height: gh,
                     fill: 'rgba(180, 83, 9, 0.35)',
                     stroke: '#b45309', 'stroke-width': 1 }, svg);
        // Label-Position: OBEN ueberhalb des Aussenrahmens, UNTEN unterhalb
        var labelY = seiteOben ? oy - 4 : oy + drawH + 11;
        el('text', { x: gx + gw / 2, y: labelY,
                     'text-anchor': 'middle',
                     font: 'bold 9px -apple-system, sans-serif',
                     fill: '#7c3a0a' }, svg)
          .textContent = 'G' + (idx + 1);
        el('text', { x: gx + gw / 2, y: labelY + (seiteOben ? -10 : 10),
                     'text-anchor': 'middle',
                     font: '8px -apple-system, sans-serif',
                     fill: '#7c3a0a' }, svg)
          .textContent = fmtM(gp.b) + ' × ' + fmtM(gp.a);
      });
    }
    zeichneGauben(g.gauben_links,  true);
    zeichneGauben(g.gauben_rechts, false);

    // Gebaeudelaenge unten + Gebaeudebreite links (nur Werte mit Pfeil-Maßketten)
    var yLL = oy + drawH + 22;
    el('line', { x1: ox, x2: ox + drawW, y1: yLL, y2: yLL,
                 stroke: '#4b5563', 'stroke-width': 0.8,
                 'marker-end': 'url(#arrow-grey-grd)', 'marker-start': 'url(#arrow-grey-grd)' }, svg);
    el('text', { x: ox + drawW / 2, y: yLL - 3, 'text-anchor': 'middle',
                 font: '10px -apple-system, sans-serif', fill: '#1f2937' }, svg)
      .textContent = fmtM(g.L_L);

    var xLB = ox - 16;
    el('line', { x1: xLB, x2: xLB, y1: oy, y2: oy + drawH,
                 stroke: '#4b5563', 'stroke-width': 0.8,
                 'marker-end': 'url(#arrow-grey-grd)', 'marker-start': 'url(#arrow-grey-grd)' }, svg);
    el('text', { x: xLB - 3, y: oy + drawH / 2, 'text-anchor': 'end',
                 'dominant-baseline': 'middle',
                 font: '10px -apple-system, sans-serif', fill: '#1f2937',
                 transform: 'rotate(-90 ' + (xLB - 3) + ' ' + (oy + drawH / 2) + ')' }, svg)
      .textContent = fmtM(g.L_B);

    // X1/X2-Labels rechts: jetzt mit Wert statt nur Buchstaben
    if (g.X1 > 0) {
      el('text', { x: ox + drawW + 4, y: oy + g.X1 * s / 2, 'text-anchor': 'start',
                   'dominant-baseline': 'middle',
                   font: '9px -apple-system, sans-serif', fill: '#b91c1c' }, svg)
        .textContent = fmtM(g.X1);
    }
    if (g.X2 > 0) {
      el('text', { x: ox + drawW + 4, y: oy + drawH - g.X2 * s / 2, 'text-anchor': 'start',
                   'dominant-baseline': 'middle',
                   font: '9px -apple-system, sans-serif', fill: '#b91c1c' }, svg)
        .textContent = fmtM(g.X2);
    }

    // grey arrow marker (eigene ID weil pro SVG-Element unique)
    var defsG = el('defs', {}, svg);
    var mG1 = el('marker', { id: 'arrow-grey-grd', viewBox: '0 0 10 10', refX: 5, refY: 5,
                             markerWidth: 5, markerHeight: 5, orient: 'auto' }, defsG);
    el('path', { d: 'M0,0 L10,5 L0,10 z', fill: '#4b5563' }, mG1);
  }

  // Aufriss (Seitenansicht)
  function renderAufriss(svg, a) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var W = 400, H = 200;
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);

    var padL = 22, padR = 22, padT = 16, padB = 28;
    var innerW = W - padL - padR;
    var innerH = H - padT - padB;
    var maxX = a.L_L || 1;
    var maxY = (a.firstHoehe || a.h_K || 1) + 0.5;
    var sx = innerW / maxX;
    var sy = innerH / maxY;
    var s = Math.min(sx, sy);
    var drawW = maxX * s;
    var drawH = maxY * s;
    var ox = padL + (innerW - drawW) / 2;
    var oy = padT + drawH;

    function px(x) { return ox + x * s; }
    function py(y) { return oy - y * s; }

    el('line', { x1: ox - 6, x2: ox + drawW + 6, y1: oy + 0.5, y2: oy + 0.5,
                 stroke: '#d1d5db', 'stroke-width': 1 }, svg);

    el('polygon', {
      points: [
        ox + ',' + oy,
        ox + ',' + py(a.h_K),
        (ox + drawW) + ',' + py(a.h_K),
        (ox + drawW) + ',' + oy
      ].join(' '),
      fill: '#f3f4f6', stroke: '#4b5563', 'stroke-width': 1.4
    }, svg);

    el('line', { x1: ox, x2: ox + drawW, y1: py(a.firstHoehe), y2: py(a.firstHoehe),
                 stroke: '#4b5563', 'stroke-width': 1 }, svg);
    el('line', { x1: ox, y1: py(a.h_K), x2: ox + 8, y2: py(a.firstHoehe),
                 stroke: '#9ca3af', 'stroke-width': 0.8 }, svg);
    el('line', { x1: ox + drawW, y1: py(a.h_K), x2: ox + drawW - 8, y2: py(a.firstHoehe),
                 stroke: '#9ca3af', 'stroke-width': 0.8 }, svg);

    a.gauben.forEach(function (gp, idx) {
      var gx = px(gp.ortgang);
      var gw = gp.b * s;
      var gh = gp.dachhoehe * s;
      var gy = py(gp.sitzhoehe + gp.dachhoehe);
      el('rect', { x: gx, y: gy, width: gw, height: gh,
                   fill: 'rgba(180, 83, 9, 0.45)',
                   stroke: '#b45309', 'stroke-width': 1 }, svg);
      // Label: G-Nummer fett oben, Breite klein darunter — beides oberhalb der Gaube
      el('text', { x: gx + gw / 2, y: gy - 12, 'text-anchor': 'middle',
                   font: 'bold 9px -apple-system, sans-serif', fill: '#7c3a0a' }, svg)
        .textContent = 'G' + (idx + 1);
      el('text', { x: gx + gw / 2, y: gy - 3, 'text-anchor': 'middle',
                   font: '8px -apple-system, sans-serif', fill: '#7c3a0a' }, svg)
        .textContent = fmtM(gp.b);
    });

    // Untere Beschriftung: nur "Linke Seite"/"Rechte Seite" + Laenge als Maßkette
    el('text', { x: ox + drawW / 2, y: H - 10, 'text-anchor': 'middle',
                 font: '10px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = (a.seite === 'links' ? 'Linke Seite' : 'Rechte Seite')
                   + '  ·  ' + fmtM(a.L_L);
    // Kniestock-Maß seitlich (dezent)
    el('text', { x: ox - 4, y: py(a.h_K / 2), 'text-anchor': 'end', 'dominant-baseline': 'middle',
                 font: '9px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = fmtM(a.h_K);
    // Dachneigung am First (nur Wert)
    el('text', { x: ox + drawW - 2, y: py(a.firstHoehe) - 3, 'text-anchor': 'end',
                 font: '9px -apple-system, sans-serif', fill: '#4b5563' }, svg)
      .textContent = fmtGrad(a.alpha);
  }

  // Platzhalter wenn Eingaben unvollstaendig
  function renderPlatzhalter(svg, msg, w, h) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    w = w || 400; h = h || 240;
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    el('rect', { x: 0.5, y: 0.5, width: w - 1, height: h - 1,
                 fill: '#f9fafb', stroke: '#e5e7eb', rx: 6 }, svg);
    el('text', { x: w / 2, y: h / 2, 'text-anchor': 'middle', 'dominant-baseline': 'middle',
                 fill: '#9ca3af', 'font-size': 12,
                 'font-family': '-apple-system, "Segoe UI", sans-serif' }, svg)
      .textContent = msg || 'Geometrie eingeben für Visualisierung';
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.Vollgeschoss = GF.Vollgeschoss || /** @type {GfVollgeschossModule} */ ({});
  GF.Vollgeschoss.diagramm = {
    renderQuerschnitt: renderQuerschnitt,
    renderGrundriss: renderGrundriss,
    renderAufriss: renderAufriss,
    renderPlatzhalter: renderPlatzhalter
  };

})(typeof window !== 'undefined' ? window : globalThis);
