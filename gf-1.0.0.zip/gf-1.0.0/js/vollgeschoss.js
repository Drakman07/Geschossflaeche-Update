// @ts-check
// js/vollgeschoss.js — Vollgeschoss-Berechnung Dachgeschoss nach Art. 83 Abs. 7 BayBO.
// Portiert aus VG-Tool v1.2.0 (identische Algorithmen). Reine Berechnungslogik (kein DOM).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  /** @type {2.30} m, lichte Hoehe fuer Vollgeschoss-Anrechnung */
  var GRENZHOEHE = 2.30;

  /**
   * @param {number} grad
   * @returns {number}
   */
  function tanGrad(grad) {
    return Math.tan(grad * Math.PI / 180);
  }

  /**
   * @param {Gaube[]} gauben
   * @param {number} X Eindringtiefe (m)
   * @param {string} seitenLabel
   * @param {string[]} warnungen
   * @returns {number}
   */
  function summeGauben(gauben, X, seitenLabel, warnungen) {
    var s = 0;
    for (var i = 0; i < gauben.length; i++) {
      var g = gauben[i];
      if (!g) continue;
      var b = +g.b || 0;
      var a = +g.a || 0;
      if (b <= 0) continue;
      if (X > 0 && a >= X) {
        warnungen.push('Gaube #' + (i + 1) + ' ' + seitenLabel
          + ': Traufabstand a (' + a.toLocaleString('de-DE') + ' m)'
          + ' ist >= Eindringtiefe X (' + X.toLocaleString('de-DE', { maximumFractionDigits: 2 }) + ' m)'
          + ' — Gaube trägt nicht zur Fläche >=2,30 m bei.');
      }
      s += Math.max(0, b * (X - a));
    }
    return s;
  }

  /**
   * @param {VgEingaben} e
   * @param {string[]} warnungen
   * @returns {{X1: number, X2: number, Bm: number}}
   */
  function berechneGrenzlinien(e, warnungen) {
    var X1 = e.h_KL >= GRENZHOEHE ? 0 : (GRENZHOEHE - e.h_KL) / tanGrad(e.alpha_L);
    var X2 = e.h_KR >= GRENZHOEHE ? 0 : (GRENZHOEHE - e.h_KR) / tanGrad(e.alpha_R);
    var Bm = e.L_B - X1 - X2;
    if (Bm < 0) {
      warnungen.push('Bm rechnerisch < 0 (Kniestöcke und Dachneigungen so flach, dass sich die 2,30-m-Linien überschneiden). Bm wurde auf 0 gesetzt.');
      Bm = 0;
    }
    return { X1: X1, X2: X2, Bm: Bm };
  }

  /**
   * @param {VgEingaben} e
   * @param {string[]} warnungen
   * @returns {{A_G: number, A_G_brutto: number}}
   */
  function berechneGrundflaeche(e, warnungen) {
    var A_G_brutto = e.L_B * e.L_L;
    if (e.A_kleiner > A_G_brutto) {
      warnungen.push('Abzug < 2,30 m (' + e.A_kleiner.toLocaleString('de-DE')
        + ' m^2) ist größer als die Gebäude-Grundfläche ('
        + A_G_brutto.toLocaleString('de-DE') + ' m^2). Eingabe prüfen.');
    }
    return { A_G: A_G_brutto - e.A_kleiner, A_G_brutto: A_G_brutto };
  }

  /**
   * @param {VgEingaben} e
   * @param {number} X1
   * @param {number} X2
   * @param {number} Bm
   * @param {string[]} warnungen
   * @returns {number}
   */
  function berechneFlaecheUeber230(e, X1, X2, Bm, warnungen) {
    var A_rechteck = Bm * e.L_L;
    var A_Gauben_L = summeGauben(e.gauben_links  || [], X1, 'links',  warnungen);
    var A_Gauben_R = summeGauben(e.gauben_rechts || [], X2, 'rechts', warnungen);
    return A_rechteck + A_Gauben_L + A_Gauben_R - e.A_groesser;
  }

  /**
   * @param {VgEingaben} e
   * @returns {VgErgebnis}
   */
  function berechneVollgeschoss(e) {
    /** @type {string[]} */
    var warnungen = [];
    var grenz = berechneGrenzlinien(e, warnungen);
    var grund = berechneGrundflaeche(e, warnungen);
    var A_2_30 = berechneFlaecheUeber230(e, grenz.X1, grenz.X2, grenz.Bm, warnungen);

    // A_G: bevorzugt die im gf-Tool ermittelte Polygonflaeche, sonst Rechteck-Modell.
    var A_G_geometrie = grund.A_G;
    var hatPolygonAG = typeof e.A_G_polygon === 'number' && isFinite(e.A_G_polygon) && e.A_G_polygon > 0;
    var A_G = hatPolygonAG ? e.A_G_polygon : A_G_geometrie;

    if (hatPolygonAG && A_G_geometrie > 0) {
      var abwPct = Math.abs(A_G - A_G_geometrie) / A_G_geometrie * 100;
      if (abwPct > 5) {
        warnungen.push('Polygonfläche (' + A_G.toLocaleString('de-DE', { maximumFractionDigits: 2 })
          + ' m^2) weicht um ' + abwPct.toLocaleString('de-DE', { maximumFractionDigits: 1 })
          + ' % von L_B * L_L (' + A_G_geometrie.toLocaleString('de-DE', { maximumFractionDigits: 2 })
          + ' m^2) ab. Eingaben prüfen.');
      }
    }

    if (A_2_30 > A_G) {
      warnungen.push('A_2,30 > A_G — Eingaben prüfen (Fläche mit >=2,30 m kann nicht größer als Gesamtgeschossfläche sein).');
    }

    var zweidrittel_breite  = (2 / 3) * e.L_B;
    var zweidrittel_flaeche = (2 / 3) * A_G;
    var vollgeschoss = (A_G > 0) && (A_2_30 >= zweidrittel_flaeche);

    return {
      X1: grenz.X1,
      X2: grenz.X2,
      Bm: grenz.Bm,
      zweidrittel_breite: zweidrittel_breite,
      A_G: A_G,
      A_G_geometrie: A_G_geometrie,
      A_G_quelle: hatPolygonAG ? 'polygon' : 'geometrie',
      zweidrittel_flaeche: zweidrittel_flaeche,
      A_2_30: A_2_30,
      vollgeschoss: vollgeschoss,
      differenz: A_2_30 - zweidrittel_flaeche,
      anteil_2_30: (A_G > 0) ? (A_2_30 / A_G) : null,
      warnungen: warnungen
    };
  }

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.Vollgeschoss = GF.Vollgeschoss || /** @type {GfVollgeschossModule} */ ({});
  GF.Vollgeschoss.berechne = berechneVollgeschoss;
  GF.Vollgeschoss.GRENZHOEHE = GRENZHOEHE;

})(typeof window !== 'undefined' ? window : globalThis);
