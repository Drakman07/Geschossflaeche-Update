// @ts-check
// js/pdf-massketten.js — Bemassungstexte aus PDF erkennen.
// PHASE 2: Heuristik folgt (Textbloecke + Massstrichchen-Suche).

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});
  GF.pdf = GF.pdf || /** @type {GfPdfModule} */ ({});

  /**
   * Liefert {text, x, y, vermuteteLaengePt} fuer jede mutmassliche Massangabe.
   * Aktuell Stub — Phase 2.
   * @param {any} pdfDoc
   * @param {number} seite
   * @returns {Promise<any[]>}
   */
  GF.pdf.findeMassketten = function (pdfDoc, seite) {
    // TODO Phase 2:
    //   1. page.getTextContent() iterieren
    //   2. Filter auf Zahlen mit Komma/Punkt im Bereich 0,5 – 200
    //   3. fuer jede Zahl in Radius 30 pt nach Mass-Stricheln suchen
    return Promise.resolve([]);
  };

})(typeof window !== 'undefined' ? window : globalThis);
