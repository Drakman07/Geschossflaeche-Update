// @ts-check
// js/app.js — Bootstrap, UI-Wiring, Event-Handler.

/** @param {GfGlobalLike} global */
(function (global) {
  'use strict';

  // @ts-ignore - Bootstrap-Pattern
  var GF = /** @type {GF} */ (global.GF = global.GF || {});

  /**
   * Element-Helper. Liefert `any`, damit Aufrufer direkt `.value`/`.disabled`/
   * `.style`/etc. ohne Cast nutzen kann (UI-Wiring-Code).
   * @param {string} id
   * @returns {any}
   */
  function $(id) { return document.getElementById(id); }

  // ---- Toast-Hilfe ----
  /**
   * @param {string} msg
   * @param {string} [kind]
   * @param {number} [dauerMs]
   */
  function showToast(msg, kind, dauerMs) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast aktiv' + (kind ? ' ' + kind : '');
    clearTimeout(/** @type {any} */ (showToast)._t);
    /** @type {any} */ (showToast)._t = setTimeout(function () { t.classList.remove('aktiv'); }, dauerMs || 4500);
  }

  // ---- Header / Footer ----
  function setzeVersion() {
    var el = $('versionInfo');
    if (el && GF.VERSION) {
      el.textContent = 'Version ' + GF.VERSION + ' · ' + (GF.BUILD_DATUM || '');
    }
  }

  function setzeKommune() {
    if (!global.GF_KOMMUNE) return;
    var k = global.GF_KOMMUNE;
    var name = $('kommunenName');
    if (name) name.textContent = k.name || '';
    var wappen = $('wappenLogo');
    if (wappen && k.wappenPfad) {
      wappen.src = k.wappenPfad;
      wappen.style.display = '';
    }
  }

  function setzeLibStatus() {
    var el = $('libStatusKurz');
    if (!el) return;
    var s = [
      'pdf.js:'   + (global.pdfjsLib ? '✓' : '✗'),
      'jsPDF:'    + (global.jspdf && global.jspdf.jsPDF ? '✓' : '✗'),
      'fflate:'   + (global.fflate ? '✓' : '✗')
    ];
    el.textContent = 'Libs: ' + s.join(' · ');
  }

  // ---- Recovery beim Start ----
  function pruefeRecovery() {
    if (!GF.recovery || !GF.recovery.pruefeBeimStart) return;
    GF.recovery.pruefeBeimStart().then(function (snap) {
      if (!snap) return;
      var datumLes = new Date(snap.datum).toLocaleString('de-DE');
      var ok = global.confirm(
        'Beim letzten Mal wurde ein Projekt nicht gespeichert.\n' +
        'Soll der Stand von ' + datumLes + ' wiederhergestellt werden?'
      );
      if (!ok) {
        GF.recovery.loesche();
        return;
      }
      stellSnapshotWiederHer(snap).then(function () {
        showToast('Stand vom ' + datumLes + ' wiederhergestellt.', 'success');
      }).catch(function (e) {
        console.error('[gf-app] Restore-Fehler:', e);
        showToast('Wiederherstellung fehlgeschlagen: ' + (e.message || e), 'danger');
      });
    });
  }

  function stellSnapshotWiederHer(snap) {
    if (!global.pdfjsLib) {
      return Promise.reject(new Error('pdf.js nicht geladen'));
    }
    GF.pdf.konfigurierePdfJs();

    var pdfsRestored = [];
    var kette = Promise.resolve();
    var serPdfs = snap.pdfs || [];

    serPdfs.forEach(function (serPdf) {
      kette = kette.then(function () {
        if (!serPdf.binary) return;
        // Wichtig: Kopie der Bytes, weil getDocument den TypedArray konsumieren kann
        var bytes = new Uint8Array(serPdf.binary);
        return global.pdfjsLib.getDocument({ data: bytes }).promise.then(function (doc) {
          pdfsRestored.push({
            id: serPdf.id,
            dateiName: serPdf.dateiName,
            containerPfad: serPdf.containerPfad || serPdf.dateiName,
            originalDateiName: serPdf.originalDateiName,
            pdfDoc: doc,
            anzahlSeiten: serPdf.anzahlSeiten || doc.numPages
          });
        });
      });
    });

    return kette.then(function () {
      GF.state.update(function (s) {
        s.projekt = snap.projekt || null;
        s.pdfs = pdfsRestored;
        s.aktivePdfId = snap.aktivePdfId || (pdfsRestored[0] ? pdfsRestored[0].id : null);
        s.aktuelleSeite = snap.aktuelleSeite || 1;
        s.aktivesGeschossId = snap.aktivesGeschossId || null;
        s.aktiveRegionId = snap.aktiveRegionId || null;
        s.pdfCache = null;
        s.vektorAnteil = null;
        // Stand kommt aus dem Snapshot -> als "noch nicht gespeichert" markieren,
        // damit der Save-Reminder weiterhin wirkt.
        s.ungespeicherteAenderungen = true;
      });
      aktualisiereGeschossListe();

      // Wenn eine aktive Seite im Snapshot war: rendern + dann Viewport explizit setzen
      if (GF.state.aktivePdfId && pdfsRestored.length > 0) {
        return zeigeSeite(GF.state.aktuelleSeite || 1).then(function () {
          if (snap.viewport) {
            GF.state.update(function (s) { s.viewport = snap.viewport; });
            redraw();
          }
        });
      }
      return Promise.resolve();
    });
  }

  // ============================================================
  // PDF laden + anzeigen
  // ============================================================

  function frageAnzeigeName(originalName, alterName, kontext) {
    var vorschlag = (alterName || originalName).replace(/\.pdf$/i, '');
    var prefix = kontext ? '[' + kontext + '] ' : '';
    var eingabe = global.prompt(
      prefix + 'Wie soll diese PDF im Tool angezeigt werden?\n' +
      '(z. B. "Laerchenstr. 18 EG" — kürzer als Dateinamen)\n\n' +
      'Original: ' + originalName,
      vorschlag
    );
    if (eingabe === null) return null;     // Abbrechen
    var t = eingabe.trim();
    return t || vorschlag;
  }

  /** Laedt mehrere PDFs nacheinander (eine Promise-Kette). */
  function ladePdfDateien(dateien) {
    var arr = Array.prototype.slice.call(dateien || []);
    if (arr.length === 0) return Promise.resolve();
    if (!global.pdfjsLib) {
      showToast('pdf.js-Library fehlt — siehe lib/README.md.', 'danger');
      return Promise.resolve();
    }
    var kette = Promise.resolve();
    arr.forEach(function (file, idx) {
      kette = kette.then(function () {
        return ladePdfEinzeln(file, idx + 1, arr.length);
      });
    });
    return kette;
  }

  function ladePdfEinzeln(file, idx, gesamt) {
    var batchInfo = gesamt > 1 ? (idx + ' von ' + gesamt) : null;
    showToast('Lade ' + file.name + (batchInfo ? ' (' + batchInfo + ')' : '') + ' …');
    return GF.pdf.lade(file).then(function (pdfDoc) {
      var anzeige = frageAnzeigeName(file.name, null, batchInfo);
      if (anzeige === null) {
        // Bei Batch: nur diese PDF abbrechen, naechste laeuft weiter.
        showToast('Übersprungen: ' + file.name, 'warn');
        return null;
      }
      // Sicherstellen, dass ein Projekt existiert, BEVOR die PDF in den State
      // wandert. Sonst leben PDFs im State, waehrend state.projekt null bleibt,
      // und alle nachfolgenden Operationen (Loeschen, Speichern, Polygon-
      // Zeichnen, VG-Beurteilung) fallen still durch ihre projekt-Guards.
      GF.projekt.sorgeFuerProjekt();
      var neueId = GF.util.uuid();
      GF.state.update(function (s) {
        s.pdfs.push({
          id: neueId,
          dateiName: anzeige,
          originalDateiName: file.name,
          pdfDoc: pdfDoc,
          anzahlSeiten: pdfDoc.numPages
        });
        s.aktivePdfId = neueId;
        s.aktuelleSeite = 1;
        s.pdfCache = null;
        s.vektorAnteil = null;
        // Geladene PDF ist eine echte Aenderung am Projekt -> Save-Reminder
        // und Sicherheitsabfrage bei "Neu"/"Oeffnen" greifen jetzt korrekt.
        s.ungespeicherteAenderungen = true;
      });
      return zeigeSeite(1).then(function () {
        showToast('PDF geladen: ' + anzeige, 'success');
      });
    }).catch(function (e) {
      console.error('[gf-app] PDF-Lade-Fehler:', e);
      showToast('Konnte ' + file.name + ' nicht laden: ' + (e.message || e), 'danger');
    });
  }

  function benennePdfUm(pdfId) {
    var pdf = GF.state.findPdf(pdfId);
    if (!pdf) return;
    var neu = frageAnzeigeName(pdf.originalDateiName || pdf.dateiName, pdf.dateiName);
    if (neu === null) return;
    GF.state.update(function () { pdf.dateiName = neu; });
    aktualisiereToolbar();
    showToast('Umbenannt: ' + neu);
  }

  function loeschePdf(pdfId) {
    var s = GF.state;
    var pdf = s.findPdf(pdfId);
    // Defensiv: falls eine PDF im State liegt aber noch kein Projekt-Objekt
    // existiert (z. B. nach altem Bug-Stand vor v1.0.1), legen wir hier eines an.
    if (pdf && !s.projekt) GF.projekt.sorgeFuerProjekt();
    if (!pdf || !s.projekt) {
      console.warn('[gf-app] loeschePdf abgebrochen: pdf=' + !!pdf + ', projekt=' + !!s.projekt);
      return;
    }

    // Was geht mit verloren?
    var regionen = s.projekt.planRegionen.filter(function (r) { return r.pdfId === pdfId; });
    var regionIds = regionen.map(function (r) { return r.id; });
    var polygone = s.projekt.polygone.filter(function (p) { return regionIds.indexOf(p.regionId) >= 0; });

    var msg = 'PDF "' + (pdf.dateiName || pdf.originalDateiName) + '" aus dem Projekt entfernen?';
    if (regionen.length || polygone.length) {
      msg += '\n\nDamit gehen auch verloren:';
      if (regionen.length) msg += '\n  · ' + regionen.length + ' Region(en)';
      if (polygone.length) msg += '\n  · ' + polygone.length + ' Polygon(e)';
    }
    if (!global.confirm(msg)) return;

    // Aus state und projekt entfernen
    s.pdfs = s.pdfs.filter(function (p) { return p.id !== pdfId; });
    s.projekt.planRegionen = s.projekt.planRegionen.filter(function (r) { return r.pdfId !== pdfId; });
    s.projekt.polygone     = s.projekt.polygone.filter(function (p) { return regionIds.indexOf(p.regionId) < 0; });
    if (Array.isArray(s.projekt.pdfs)) {
      s.projekt.pdfs = s.projekt.pdfs.filter(function (p) { return p.id !== pdfId; });
    }

    GF.projekt.historieEintrag(s.projekt, 'PDF entfernt',
      (pdf.dateiName || pdf.originalDateiName) +
      (regionen.length ? ' · ' + regionen.length + ' Region(en)' : '') +
      (polygone.length ? ' · ' + polygone.length + ' Polygon(e)' : ''));

    var aktivWegGefallen = (s.aktivePdfId === pdfId);
    var naechste = s.pdfs[0] ? s.pdfs[0].id : null;

    GF.state.update(function (st) {
      if (aktivWegGefallen) {
        st.aktivePdfId = naechste;
        st.aktuelleSeite = 1;
        st.pdfCache = null;
        st.vektorAnteil = null;
      }
      if (regionIds.indexOf(st.aktiveRegionId) >= 0) st.aktiveRegionId = null;
      // aktivesPolygonId pruefen — Polygon evtl. mitgeloescht
      if (st.aktivesPolygonId &&
          !st.projekt.polygone.some(function (p) { return p.id === st.aktivesPolygonId; })) {
        st.aktivesPolygonId = null;
      }
      st.ungespeicherteAenderungen = true;
    });

    aktualisiereToolbar();
    aktualisiereGeschossListe();

    if (aktivWegGefallen && naechste) {
      zeigeSeite(1);
    } else if (!naechste) {
      // Keine PDFs mehr — Canvas leeren
      var c = $('planCanvas');
      if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height);
      redraw();
    } else {
      redraw();
    }

    showToast('PDF entfernt: ' + (pdf.dateiName || pdf.originalDateiName), 'success');
  }

  function wechsleZuPdf(pdfId) {
    if (!pdfId || pdfId === GF.state.aktivePdfId) return Promise.resolve();
    var pdf = GF.state.findPdf(pdfId);
    if (!pdf) return Promise.resolve();
    GF.state.update(function (s) {
      s.aktivePdfId = pdfId;
      s.aktuelleSeite = 1;
      s.pdfCache = null;
      s.vektorAnteil = null;
    });
    return zeigeSeite(1).then(function () {
      showToast('Aktive PDF: ' + pdf.dateiName);
    });
  }

  function zeigeSeite(seite) {
    var pdf = GF.state.aktivesPdf();
    if (!pdf) return Promise.resolve();
    var doc = pdf.pdfDoc;
    if (seite < 1) seite = 1;
    if (seite > doc.numPages) seite = doc.numPages;

    return GF.pdf.preRender(doc, seite, GF.pdf.DEFAULT_RENDER_SCALE).then(function (cache) {
      // Fit-Viewport berechnen anhand aktueller Canvas-Groesse
      passeCanvasGroesseAn();
      var canvas = $('planCanvas');
      var fit = GF.pdf.fitViewport(cache, canvas);

      GF.state.update(function (s) {
        s.pdfCache = cache;
        s.aktuelleSeite = seite;
        s.viewport = fit;
      });
      redraw();

      // Vektor-Anteil asynchron, blockiert nicht
      GF.pdf.vektorAnteil(doc, seite).then(function (a) {
        GF.state.update(function (s) { s.vektorAnteil = a; });
        zeigeVektorBadge(a);
        if (a < 0.3) {
          showToast(
            'Hinweis: PDF besteht überwiegend aus Rasterbildern (gescannt). ' +
            'Vermessung mit Toleranz ±1-2%.',
            'warn'
          );
        }
      });

    });
  }

  function zeigeVektorBadge(anteil) {
    var b = $('vektorBadge');
    var grp = $('vektorGruppe');
    if (!b || !grp) return;
    grp.hidden = false;
    var prozent = Math.round(anteil * 100);
    b.textContent = 'Vektor ' + prozent + '%';
    b.className = 'badge ' +
      (anteil >= 0.7 ? 'vektor-hoch' :
       anteil >= 0.3 ? 'vektor-mittel' : 'vektor-niedrig');
    b.title = anteil >= 0.7 ? 'Vektor-PDF — praezise vermessbar'
            : anteil >= 0.3 ? 'Gemischtes PDF — Vermessung moeglich, Toleranz beachten'
            :                 'Raster-PDF — Vermessung pixelbasiert, ±1-2% Toleranz';
  }

  // ============================================================
  // Canvas-Groesse + Redraw
  // ============================================================

  function passeCanvasGroesseAn() {
    var host = $('canvasHost');
    var canvas = $('planCanvas');
    if (!host || !canvas) return false;
    var r = host.getBoundingClientRect();
    var w = Math.max(100, Math.floor(r.width));
    var h = Math.max(100, Math.floor(r.height));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
      return true;
    }
    return false;
  }

  function redraw() {
    var canvas = $('planCanvas');
    if (!canvas || !GF.state.pdfCache) return;
    GF.pdf.zeichne(GF.state.pdfCache, canvas, GF.state.viewport);
    zeichneOverlay(canvas);
    aktualisiereToolbar();
  }

  // ---- Overlay: Plan-Regionen + Temp-Rechteck waehrend Region-Drag ----

  function pdfZuCanvas(pdfX, pdfY) {
    var vp = GF.state.viewport;
    return { x: (pdfX - vp.panX) * vp.zoom, y: (pdfY - vp.panY) * vp.zoom };
  }
  function canvasZuPdf(canvasX, canvasY) {
    var vp = GF.state.viewport;
    return { x: vp.panX + canvasX / vp.zoom, y: vp.panY + canvasY / vp.zoom };
  }

  function normalisiereRechteck(p1, p2) {
    return {
      x: Math.min(p1.x, p2.x),
      y: Math.min(p1.y, p2.y),
      breite: Math.abs(p2.x - p1.x),
      hoehe:  Math.abs(p2.y - p1.y)
    };
  }

  // Hitboxen — werden in jedem zeichneOverlay-Aufruf neu befuellt.
  var kantenLabelHitboxen = [];
  var eckpunktHitboxen = [];

  function zeichneOverlay(canvas) {
    var s = GF.state;
    var ctx = canvas.getContext('2d');
    kantenLabelHitboxen = [];
    eckpunktHitboxen = [];

    if (s.projekt && s.aktivePdfId) {
      var regionen = s.projekt.planRegionen.filter(function (r) {
        return r.pdfId === s.aktivePdfId && r.seite === s.aktuelleSeite;
      });
      regionen.forEach(function (r) { zeichneRegion(ctx, r); });

      // Polygone fuer Regionen auf der aktuellen Seite
      var aktuelleRegionIds = regionen.map(function (r) { return r.id; });
      var polygone = s.projekt.polygone.filter(function (p) {
        return aktuelleRegionIds.indexOf(p.regionId) >= 0;
      });
      polygone.forEach(function (p) { zeichnePolygon(ctx, p); });
      // Kanten-Labels und Eckpunkt-Marker nur im Plan-Modus
      if (GF.state.aktivesWerkzeug === 'pan') {
        polygone.forEach(function (p) { zeichneKantenLabels(ctx, p); });
        // Eckpunkt-Marker nur fuer das aktive Polygon (sonst optische Ueberlast)
        var ap = polygone.filter(function (p) { return p.id === s.aktivesPolygonId; })[0];
        if (ap) zeichneEckpunktMarker(ctx, ap);
      }
    }

    // Polygon-Live waehrend Zeichnung
    if (GF.state.aktivesWerkzeug === 'polygon' && polygonPunkte.length > 0) {
      zeichnePolygonLive(ctx);
    }

    // Massstab-Linie waehrend Kalibrierung
    if (GF.state.aktivesWerkzeug === 'massstab' && massPunkt1) {
      var endPdf = massPunkt2 || massMaus || massPunkt1;
      zeichneMassstabLinie(ctx, massPunkt1, endPdf, !massPunkt2);
    }

    // Temp-Rechteck waehrend des Region-Drags
    if (regionDragAktiv && regionStartPdf && regionAktuellPdf) {
      var tmp = normalisiereRechteck(regionStartPdf, regionAktuellPdf);
      var c = pdfZuCanvas(tmp.x, tmp.y);
      var z = s.viewport.zoom;
      ctx.save();
      ctx.fillStyle = 'rgba(0, 51, 153, 0.15)';
      ctx.strokeStyle = '#003399';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 4]);
      ctx.fillRect(c.x, c.y, tmp.breite * z, tmp.hoehe * z);
      ctx.strokeRect(c.x, c.y, tmp.breite * z, tmp.hoehe * z);
      ctx.restore();
    }
  }

  function zeichnePolygon(ctx, p) {
    if (!p.punkte || p.punkte.length < 3) return;
    var s = GF.state;
    var farbe = p.farbeOverlay || '#7f8c8d';
    var aktiv = (p.id === s.aktivesPolygonId);
    var deckkraft = (typeof p.deckkraft === 'number') ? p.deckkraft : 0.5;
    if (aktiv) deckkraft = Math.min(1, deckkraft + 0.15);

    // Fill mit konfigurierbarer Deckkraft, Stroke immer voll sichtbar
    ctx.save();
    ctx.beginPath();
    p.punkte.forEach(function (pt, i) {
      var c = pdfZuCanvas(pt.x, pt.y);
      if (i === 0) ctx.moveTo(c.x, c.y);
      else         ctx.lineTo(c.x, c.y);
    });
    ctx.closePath();
    if (deckkraft > 0) {
      ctx.globalAlpha = deckkraft;
      ctx.fillStyle = farbe;
      ctx.fill();
      ctx.globalAlpha = 1.0;
    }
    ctx.strokeStyle = farbe;
    ctx.lineWidth = aktiv ? 2.5 : 1.5;
    ctx.stroke();

    // Label im geometrischen Mittel
    var cx = 0, cy = 0;
    p.punkte.forEach(function (pt) {
      var c = pdfZuCanvas(pt.x, pt.y);
      cx += c.x; cy += c.y;
    });
    cx /= p.punkte.length; cy /= p.punkte.length;
    var label = p.bezeichnung + '  ·  ' + GF.util.formatZahlDE(p.flaecheAngesetztQM, 2) + ' m²';
    ctx.font = 'bold 12px Segoe UI, Arial';
    var metrik = ctx.measureText(label);
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(cx - metrik.width/2 - 5, cy - 9, metrik.width + 10, 18);
    ctx.fillStyle = farbe;
    ctx.fillText(label, cx - metrik.width/2, cy + 4);
    ctx.restore();
  }

  // Zeichnet pro Kante ein klickbares Maß-Label und sammelt die Hitbox.
  function zeichneKantenLabels(ctx, p) {
    if (!p.punkte || p.punkte.length < 3) return;
    var region = GF.state.findRegion(p.regionId);
    if (!region || !region.kalibrierung || !region.kalibrierung.ptProMeter) return;
    var ptProM = region.kalibrierung.ptProMeter;
    var n = p.punkte.length;

    ctx.save();
    ctx.font = '11px Segoe UI, Arial';
    for (var i = 0; i < n; i++) {
      var p1 = p.punkte[i];
      var p2 = p.punkte[(i + 1) % n];
      var midPdf = { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 };
      var dx = p2.x - p1.x, dy = p2.y - p1.y;
      var laengeM = Math.sqrt(dx * dx + dy * dy) / ptProM;
      if (laengeM < 0.001) continue;
      var text = GF.util.formatZahlDE(laengeM, 2) + ' m';
      var c = pdfZuCanvas(midPdf.x, midPdf.y);
      var w = ctx.measureText(text).width;
      var pad = 4, h = 16;
      var bx = c.x - w / 2 - pad;
      var by = c.y - h / 2;

      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 1;
      ctx.fillRect(bx, by, w + 2 * pad, h);
      ctx.strokeRect(bx, by, w + 2 * pad, h);
      ctx.fillStyle = '#7c3a07';
      ctx.fillText(text, c.x - w / 2, c.y + 4);

      kantenLabelHitboxen.push({
        polygonId: p.id, kantenIndex: i,
        x: bx, y: by, w: w + 2 * pad, h: h
      });
    }
    ctx.restore();
  }

  function findeKantenLabel(canvasX, canvasY) {
    for (var i = kantenLabelHitboxen.length - 1; i >= 0; i--) {
      var hb = kantenLabelHitboxen[i];
      if (canvasX >= hb.x && canvasX <= hb.x + hb.w &&
          canvasY >= hb.y && canvasY <= hb.y + hb.h) {
        return hb;
      }
    }
    return null;
  }

  // Eckpunkt-Marker fuer das aktive Polygon (zum Verschieben einzelner Punkte).
  function zeichneEckpunktMarker(ctx, p) {
    if (!p.punkte || p.punkte.length < 3) return;
    ctx.save();
    for (var i = 0; i < p.punkte.length; i++) {
      var c = pdfZuCanvas(p.punkte[i].x, p.punkte[i].y);
      // Aussenring (dunkler) + Innenkreis (weiss) — gut sichtbar auf jedem Hintergrund
      ctx.beginPath();
      ctx.arc(c.x, c.y, 6, 0, 2 * Math.PI);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.strokeStyle = '#003399';
      ctx.lineWidth = 2;
      ctx.stroke();
      // Innen-Punkt
      ctx.beginPath();
      ctx.arc(c.x, c.y, 2, 0, 2 * Math.PI);
      ctx.fillStyle = '#003399';
      ctx.fill();

      eckpunktHitboxen.push({
        polygonId: p.id, punktIndex: i, x: c.x, y: c.y, radius: 9
      });
    }
    ctx.restore();
  }

  function findeEckpunkt(canvasX, canvasY) {
    for (var i = eckpunktHitboxen.length - 1; i >= 0; i--) {
      var hb = eckpunktHitboxen[i];
      var dx = canvasX - hb.x;
      var dy = canvasY - hb.y;
      if (dx * dx + dy * dy <= hb.radius * hb.radius) return hb;
    }
    return null;
  }

  function zeichnePolygonLive(ctx) {
    if (polygonPunkte.length === 0) return;
    ctx.save();

    // Fester Teil (bereits gesetzte Punkte) — Pfad
    function pfadFix() {
      ctx.beginPath();
      polygonPunkte.forEach(function (pt, i) {
        var c = pdfZuCanvas(pt.x, pt.y);
        if (i === 0) ctx.moveTo(c.x, c.y);
        else         ctx.lineTo(c.x, c.y);
      });
    }

    // Halo + Vordergrund fuer den festen Teil
    pfadFix();
    ctx.lineWidth = 5;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.setLineDash([]);
    ctx.stroke();
    pfadFix();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#0a3fa3';
    ctx.setLineDash([8, 4]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Live-Linie zur Maus — separat, mit Farbwechsel bei 90°-Snap
    if (polygonMaus) {
      var letzter = polygonPunkte[polygonPunkte.length - 1];
      var clL = pdfZuCanvas(letzter.x, letzter.y);
      var cm  = pdfZuCanvas(polygonMaus.x, polygonMaus.y);
      // Halo
      ctx.beginPath();
      ctx.moveTo(clL.x, clL.y); ctx.lineTo(cm.x, cm.y);
      ctx.lineWidth = 5;
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.setLineDash([]);
      ctx.stroke();
      // Vordergrund: gruen-durchgezogen bei aktivem Snap, sonst blau-gestrichelt
      ctx.beginPath();
      ctx.moveTo(clL.x, clL.y); ctx.lineTo(cm.x, cm.y);
      ctx.lineWidth = 2.5;
      if (winkelSnapAktiv) {
        ctx.strokeStyle = '#10b981';
        ctx.setLineDash([]);
      } else {
        ctx.strokeStyle = '#0a3fa3';
        ctx.setLineDash([8, 4]);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Kleines ⊥-Symbol oberhalb der Maus wenn Snap greift
      if (winkelSnapAktiv) {
        ctx.font = 'bold 11px Segoe UI, Arial';
        var text = '⊥ 90°';
        var w = ctx.measureText(text).width;
        ctx.fillStyle = 'rgba(16, 185, 129, 0.95)';
        ctx.fillRect(cm.x + 10, cm.y - 22, w + 8, 16);
        ctx.fillStyle = '#fff';
        ctx.fillText(text, cm.x + 14, cm.y - 10);
      }
    }

    // Punkt-Marker
    polygonPunkte.forEach(function (pt, idx) {
      var c = pdfZuCanvas(pt.x, pt.y);
      ctx.beginPath();
      ctx.arc(c.x, c.y, 4, 0, 2 * Math.PI);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = idx === 0 ? '#10b981' : '#003399';   // Startpunkt gruen
      ctx.stroke();
    });

    // Startpunkt-Highlight wenn Polygon schliessbar
    if (polygonPunkte.length >= 3) {
      var c0 = pdfZuCanvas(polygonPunkte[0].x, polygonPunkte[0].y);
      ctx.beginPath();
      ctx.arc(c0.x, c0.y, 10, 0, 2 * Math.PI);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Live-Flaechen-Anzeige bei 3+ Punkten
    if (polygonPunkte.length >= 3) {
      var s = GF.state;
      var r = null;
      for (var i = 0; i < s.projekt.planRegionen.length; i++) {
        if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
      }
      if (r && r.kalibrierung) {
        try {
          var f = GF.polygon.berechneFlaeche(polygonPunkte, r.kalibrierung.ptProMeter);
          // Live-Vorschau: noch kein Schlusssegment vorhanden -> closed=false
          var ueb = GF.polygon.hatSelbstueberschneidung(polygonPunkte, false);
          var letzter = polygonPunkte[polygonPunkte.length - 1];
          var cL = pdfZuCanvas(letzter.x, letzter.y);
          var t = ueb
            ? '⚠ Selbstüberschneidung'
            : GF.util.formatZahlDE(f, 2) + ' m² (' + polygonPunkte.length + ' Punkte)';
          ctx.font = '600 12px Segoe UI, Arial';
          var metrik = ctx.measureText(t);
          ctx.fillStyle = ueb ? 'rgba(254,226,226,0.95)' : 'rgba(255,255,255,0.92)';
          ctx.fillRect(cL.x + 10, cL.y - 22, metrik.width + 12, 20);
          ctx.fillStyle = ueb ? '#b91c1c' : '#003399';
          ctx.fillText(t, cL.x + 16, cL.y - 8);
        } catch (e) { /* still <3 effective points etc. */ }
      }
    }

    ctx.restore();
  }

  function zeichneMassstabLinie(ctx, p1, p2, gestrichelt) {
    var c1 = pdfZuCanvas(p1.x, p1.y);
    var c2 = pdfZuCanvas(p2.x, p2.y);
    // Bei aktivem Winkel-Snap UND wenn das die Live-Linie ist (gestrichelt=true):
    // gruene durchgezogene Linie statt orange-gestrichelt — visuelles Snap-Signal.
    var snapAnzeige = !!(gestrichelt && winkelSnapAktiv);
    ctx.save();
    ctx.lineWidth = 2;
    if (snapAnzeige) {
      ctx.strokeStyle = '#10b981';
      ctx.setLineDash([]);
    } else {
      ctx.strokeStyle = '#d97706';
      if (gestrichelt) ctx.setLineDash([6, 4]);
    }
    ctx.beginPath();
    ctx.moveTo(c1.x, c1.y);
    ctx.lineTo(c2.x, c2.y);
    ctx.stroke();
    // Endpunkt-Marker
    var markerFarbe = snapAnzeige ? '#10b981' : '#d97706';
    [c1, c2].forEach(function (pt) {
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 5, 0, 2 * Math.PI);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.setLineDash([]);
      ctx.strokeStyle = markerFarbe;
      ctx.stroke();
    });
    // Kleines ⊥-Label am zweiten Endpunkt wenn Snap greift
    if (snapAnzeige) {
      ctx.font = 'bold 11px Segoe UI, Arial';
      var text = '⊥ 90°';
      var w = ctx.measureText(text).width;
      ctx.fillStyle = 'rgba(16, 185, 129, 0.95)';
      ctx.fillRect(c2.x + 10, c2.y - 22, w + 8, 16);
      ctx.fillStyle = '#fff';
      ctx.fillText(text, c2.x + 14, c2.y - 10);
    }
    ctx.restore();
  }

  function zeichneRegion(ctx, region) {
    var s = GF.state;
    var c = pdfZuCanvas(region.ausschnitt.x, region.ausschnitt.y);
    var w = region.ausschnitt.breite * s.viewport.zoom;
    var h = region.ausschnitt.hoehe  * s.viewport.zoom;
    var aktiv = region.id === s.aktiveRegionId;
    ctx.save();
    ctx.fillStyle = aktiv ? 'rgba(0, 51, 153, 0.10)' : 'rgba(80, 80, 80, 0.06)';
    ctx.strokeStyle = aktiv ? '#003399' : '#666';
    ctx.lineWidth = aktiv ? 2 : 1;
    ctx.fillRect(c.x, c.y, w, h);
    ctx.strokeRect(c.x, c.y, w, h);
    // Label inkl. Kalibrierungs-Status
    var label = region.bezeichnung || '?';
    if (region.kalibrierung) {
      label += '  · ' + (region.kalibrierung.normMassstab || (GF.util.formatZahlDE(region.kalibrierung.ptProMeter, 2) + ' pt/m'));
    }
    ctx.font = 'bold 12px Segoe UI, Arial';
    var pad = 4;
    var metrik = ctx.measureText(label);
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillRect(c.x + pad, c.y + pad, metrik.width + 6, 16);
    ctx.fillStyle = aktiv ? '#003399' : '#333';
    ctx.fillText(label, c.x + pad + 3, c.y + pad + 12);
    // Gespeicherte Kalibrierungs-Punkte als kleine Marker zeigen
    // (kann ueber den Toggle in der Werkzeug-Sidebar ausgeblendet werden)
    if (region.kalibrierung && region.kalibrierung.punkt1 && region.kalibrierung.punkt2 &&
        GF.state.massstabSichtbar !== false) {
      zeichneMassstabLinie(ctx, region.kalibrierung.punkt1, region.kalibrierung.punkt2, false);
    }
    ctx.restore();
  }

  function aktualisiereToolbar() {
    var s = GF.state;
    var pdf = s.aktivesPdf();
    var hatPdfs = s.pdfs.length > 0;

    // Lade-Button-Text wechselt: bei leerem State "PDF laden",
    // bei mindestens einem geladenen "+ PDF" (additiv).
    var lbl = $('lblPdfLaden');
    if (lbl) lbl.textContent = hatPdfs ? '+ PDF' : 'PDF laden';

    var info = $('pdfDateiInfo');
    if (info) info.hidden = hatPdfs;

    var btnRen = $('btnPdfUmbenennen');
    if (btnRen) btnRen.hidden = !hatPdfs;

    var btnLoe = $('btnPdfLoeschen');
    if (btnLoe) btnLoe.hidden = !hatPdfs;

    var sel = $('pdfSelect');
    if (sel) {
      sel.hidden = !hatPdfs;
      // Optionen nur neu aufbauen, wenn sich Liste ODER Anzeigename geaendert hat
      var signatur = s.pdfs.map(function (p) { return p.id + ':' + (p.dateiName || ''); }).join('|');
      if (sel.dataset.signatur !== signatur) {
        sel.innerHTML = '';
        s.pdfs.forEach(function (p) {
          var opt = document.createElement('option');
          opt.value = p.id;
          opt.textContent = p.dateiName;
          sel.appendChild(opt);
        });
        sel.dataset.signatur = signatur;
      }
      if (s.aktivePdfId) sel.value = s.aktivePdfId;
    }

    var anzahl = pdf ? pdf.anzahlSeiten : 0;
    $('seiteAktuell').textContent = s.aktuelleSeite;
    $('seiteGesamt').textContent = anzahl;
    $('seitenNav').hidden = anzahl <= 0;
    $('zoomGroup').hidden = !s.pdfCache;
    $('zoomAnzeige').textContent = Math.round((s.viewport.zoom || 0) * 100);

    var emptyState = $('emptyState');
    if (emptyState) emptyState.style.display = pdf ? 'none' : '';

    var btnPrev = $('btnSeitePrev');
    var btnNext = $('btnSeiteNext');
    if (btnPrev) btnPrev.disabled = s.aktuelleSeite <= 1;
    if (btnNext) btnNext.disabled = s.aktuelleSeite >= anzahl;

    // Speichern aktivieren, sobald ein Projekt existiert
    var btnSp = $('btnSpeichern');
    if (btnSp) {
      btnSp.disabled = !s.projekt;
      // Visueller Hinweis auf ungespeicherte Aenderungen
      if (s.projekt && s.ungespeicherteAenderungen) {
        btnSp.classList.add('ungespeichert');
        btnSp.textContent = 'Speichern *';
      } else {
        btnSp.classList.remove('ungespeichert');
        btnSp.textContent = 'Speichern';
      }
    }
    var btnPD = $('btnProjektdaten');
    if (btnPD) btnPD.disabled = !s.projekt;

    var btnPr = $('btnProtokoll');
    if (btnPr) {
      // Protokoll geht erst wenn ein Projekt MIT mindestens einem Polygon existiert
      var hatPolygone = s.projekt && s.projekt.polygone && s.projekt.polygone.length > 0;
      btnPr.disabled = !hatPolygone;
    }
  }

  // ============================================================
  // Maus-Events
  // ============================================================

  function wireFileInput() {
    var input = $('pdfInput');
    if (!input) return;
    input.addEventListener('change', function (e) {
      var files = e.target.files;
      if (files && files.length > 0) ladePdfDateien(files);
      input.value = '';   // damit dieselben Dateien nochmal geladen werden koennen
    });

    var gfInp = $('gfprojInput');
    if (gfInp) {
      gfInp.addEventListener('change', function (e) {
        var files = e.target.files;
        if (files && files.length > 0) ladeProjektDatei(files[0]);
        gfInp.value = '';
      });
    }
  }

  // ============================================================
  // Projekt-Speichern / -Laden (.gfproj-ZIP)
  // ============================================================

  // Speichert das aktuelle Projekt als .gfproj-Datei (Browser-Download).
  // Falls noch kein Projektname gesetzt: window.prompt() fuer Eingabe.
  //
  // Ablauf-Reihenfolge ist wichtig: showSaveFilePicker MUSS direkt nach
  // dem User-Klick aufgerufen werden, sonst expired die transient user
  // activation (5-Sekunden-Budget) und der Browser blockt den Dialog.
  // Deshalb erst Ziel waehlen (Picker auf), dann erst die teuren
  // Async-Schritte (PDF-Binaerdaten lesen, ZIP bauen).
  function speichereProjekt() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Kein Projekt zum Speichern vorhanden.', 'warn');
      return Promise.resolve(false);
    }

    // Projektname sicherstellen
    var name = (s.projekt.metadata && s.projekt.metadata.projektName || '').trim();
    if (!name || name === '(neu)') {
      var eingabe = global.prompt(
        'Projektname (wird der Dateiname):',
        'Bauantrag-' + new Date().toISOString().slice(0, 10)
      );
      if (eingabe === null) return Promise.resolve(false);   // Abbruch
      eingabe = eingabe.trim();
      if (!eingabe) {
        showToast('Projektname darf nicht leer sein.', 'warn');
        return Promise.resolve(false);
      }
      s.projekt.metadata.projektName = eingabe;
      name = eingabe;
    }

    var dateiName = name.replace(/[\\/:*?"<>|]/g, '_') + '.zip';

    // Save-Ziel ZUERST waehlen (User-Activation ist hier noch frisch).
    return waehleSaveZiel(dateiName).then(function (ziel) {
      if (!ziel) return false;   // User hat im Picker abgebrochen

      // Container-Pfade frisch vergeben (stabil und konsistent zur aktuellen Reihenfolge).
      // dateiName = Anzeigename des Users, getrennt vom ZIP-Eintragspfad.
      s.pdfs.forEach(function (p, idx) {
        p.containerPfad = 'plan-' + (idx + 1) + '.pdf';
      });

      // PDF-Binaerdaten aus den geladenen pdfDocs holen
      var pdfBinaer = Object.create(null);
      var kette = Promise.resolve();
      s.pdfs.forEach(function (p) {
        var cPfad = p.containerPfad;
        kette = kette.then(function () {
          if (!p.pdfDoc || typeof p.pdfDoc.getData !== 'function') {
            throw new Error('Keine PDF-Binary für "' + cPfad + '" verfügbar (pdfDoc fehlt).');
          }
          return p.pdfDoc.getData().then(function (bytes) {
            pdfBinaer[cPfad] = bytes;
          });
        });
      });

      return kette.then(function () {
        // projekt.pdfs synchron mit aktuellem state.
        //   dateiName     = Anzeigename (vom User editierbar)
        //   containerPfad = ZIP-Eintragsname (plan-1.pdf, ...)
        s.projekt.pdfs = s.pdfs.map(function (p) {
          return {
            id: p.id,
            dateiName: p.dateiName,
            containerPfad: p.containerPfad,
            originalDateiName: p.originalDateiName || p.dateiName,
            groesseBytes: pdfBinaer[p.containerPfad].length,
            anzahlSeiten: p.anzahlSeiten,
            vektorAnteil: p.vektorAnteil || null
          };
        });

        GF.projekt.historieEintrag(s.projekt, 'Projekt gespeichert',
          s.pdfs.length + ' PDF(s), ' + s.projekt.polygone.length + ' Polygon(e)');

        return GF.projekt.speichere(s.projekt, pdfBinaer);
      }).then(function (blob) {
        return schreibeAnZiel(ziel, blob, dateiName).then(function (gespeichert) {
          if (!gespeichert) return false;
          GF.state.update(function (st) { st.ungespeicherteAenderungen = false; });
          if (GF.recovery && GF.recovery.loesche) GF.recovery.loesche();
          aktualisiereToolbar();
          showToast('Projekt gespeichert: ' + dateiName, 'success');
          return true;
        });
      });
    }).catch(function (err) {
      console.error('[gf-save]', err);
      showToast('Speichern fehlgeschlagen: ' + err.message, 'danger', 8000);
      return false;
    });
  }

  // Liefert den Container-internen Dateinamen einer geladenen PDF.
  // Stabil ueber Sessions hinweg, damit das gleiche pdf.id immer denselben Eintrag bekommt.
  function projektPdfDateiName(pdfEntry) {
    var s = GF.state;
    var idx = s.pdfs.indexOf(pdfEntry);
    if (idx < 0) idx = s.pdfs.length;
    return 'plan-' + (idx + 1) + '.pdf';
  }

  function datenBlobDownload(blob, dateiName) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = dateiName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
  }

  // ---- Letzter-Speicherort merken (IndexedDB, getrennt vom Recovery-Store) ----
  // FileSystemFileHandle ist structured-cloneable -> wir koennen ihn direkt speichern
  // und beim naechsten Save als startIn-Hinweis fuer den Save-Dialog wiederverwenden.
  var SAVE_DB_NAME = 'gf-savehandle';
  var SAVE_STORE   = 'handles';
  var SAVE_KEY     = 'last';

  function oeffneSaveDb() {
    return new Promise(function (resolve, reject) {
      if (!global.indexedDB) { reject(new Error('keine IndexedDB')); return; }
      var req = global.indexedDB.open(SAVE_DB_NAME, 1);
      req.onerror = function () { reject(req.error); };
      req.onsuccess = function () { resolve(req.result); };
      req.onupgradeneeded = function () {
        try { req.result.createObjectStore(SAVE_STORE); } catch (e) {}
      };
    });
  }

  function holeLetztenSaveHandle() {
    return oeffneSaveDb().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(SAVE_STORE, 'readonly');
          var st = tx.objectStore(SAVE_STORE);
          var req = st.get(SAVE_KEY);
          req.onsuccess = function () { resolve(req.result || null); };
          req.onerror = function () { resolve(null); };
        } catch (e) { resolve(null); }
      });
    }).catch(function () { return null; });
  }

  function speichereSaveHandle(handle) {
    return oeffneSaveDb().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(SAVE_STORE, 'readwrite');
          tx.objectStore(SAVE_STORE).put(handle, SAVE_KEY);
          tx.oncomplete = function () { resolve(); };
          tx.onerror    = function () { resolve(); };
        } catch (e) { resolve(); }
      });
    }).catch(function () { return null; });
  }

  // Fragt den User nach dem Speicherort und liefert ein Ziel, an das der Blob
  // spaeter geschrieben werden kann. MUSS direkt nach dem User-Klick aufgerufen
  // werden, sonst expired die transient user activation (5-Sekunden-Budget) und
  // showSaveFilePicker faellt auf den anchor-Download zurueck (= Downloads-Ordner
  // ohne Dialog). Die teuren Schritte (ZIP/PDF-Bau) MUESSEN nach diesem Aufruf
  // passieren, nicht davor.
  //
  // Liefert Promise<null | SaveZiel> mit:
  //   null                                  -> User-Abbruch im Picker
  //   { kind: 'handle', handle }            -> User hat Speicherort gewaehlt
  //   { kind: 'download' }                  -> Picker nicht verfuegbar (Firefox,
  //                                            file://-Aufruf), beim Schreiben
  //                                            wird auf anchor-Download zurueckgefallen
  function waehleSaveZiel(dateiName) {
    if (typeof global.showSaveFilePicker !== 'function') {
      // Kein Save-Picker verfuegbar -> beim Schreiben Browser-Standard-Download
      return Promise.resolve({ kind: 'download' });
    }
    var endung = (dateiName.match(/\.[^.]+$/) || ['.zip'])[0].toLowerCase();
    var fileTypes;
    if (endung === '.pdf') {
      fileTypes = [{ description: 'PDF', accept: { 'application/pdf': ['.pdf'] } }];
    } else {
      fileTypes = [{ description: 'FlächenKlar Projekt (ZIP-Container)', accept: { 'application/zip': ['.zip'] } }];
    }

    return holeLetztenSaveHandle().then(function (letzterHandle) {
      var options = { suggestedName: dateiName, types: fileTypes };
      // startIn kann ein FileSystemHandle oder eine well-known location sein.
      // Bei File-Handle oeffnet der Dialog im Parent-Ordner. Falls der Handle
      // nicht mehr existiert: Browser ignoriert ihn meist und nimmt Default.
      options.startIn = letzterHandle || 'documents';
      return global.showSaveFilePicker(options).then(function (handle) {
        return { kind: 'handle', handle: handle };
      }).catch(function (err) {
        if (err && err.name === 'AbortError') return null;
        // Eventuell ist ein veralteter Handle das Problem: nochmal ohne startIn=handle versuchen
        if (letzterHandle && err && (err.name === 'TypeError' || err.name === 'NotFoundError')) {
          return global.showSaveFilePicker({
            suggestedName: dateiName, types: fileTypes, startIn: 'documents'
          }).then(function (handle) {
            return { kind: 'handle', handle: handle };
          }).catch(function (err2) {
            if (err2 && err2.name === 'AbortError') return null;
            console.warn('[gf-save] Picker zweiter Versuch fehlgeschlagen, Fallback auf Download:', err2);
            return { kind: 'download' };
          });
        }
        console.warn('[gf-save] showSaveFilePicker fehlgeschlagen, Fallback auf Download:', err);
        return { kind: 'download' };
      });
    });
  }

  // Schreibt blob an das durch waehleSaveZiel() ermittelte Ziel. Darf beliebig
  // spaeter aufgerufen werden (User-Activation egal — Handle ist schon vergeben).
  // Liefert Promise<boolean> — true bei Erfolg, false bei Abbruch / null-Ziel.
  function schreibeAnZiel(ziel, blob, dateiName) {
    if (!ziel) return Promise.resolve(false);
    if (ziel.kind === 'download') {
      datenBlobDownload(blob, dateiName);
      return Promise.resolve(true);
    }
    if (ziel.kind === 'handle') {
      return ziel.handle.createWritable().then(function (writable) {
        return writable.write(blob).then(function () { return writable.close(); });
      }).then(function () {
        // Handle merken fuer den naechsten Save — Fehler ignorieren.
        return speichereSaveHandle(ziel.handle).catch(function () {});
      }).then(function () { return true; }).catch(function (err) {
        console.error('[gf-save] Schreiben in Handle fehlgeschlagen, Fallback auf Download:', err);
        datenBlobDownload(blob, dateiName);
        return true;
      });
    }
    return Promise.resolve(false);
  }

  // Oeffnet eine .gfproj-Datei und ersetzt das aktuelle Projekt damit.
  function ladeProjektDatei(file) {
    var s = GF.state;
    if (s.projekt && s.ungespeicherteAenderungen) {
      if (!global.confirm(
        'Das aktuelle Projekt hat ungespeicherte Änderungen. ' +
        'Beim Öffnen gehen sie verloren.\n\nTrotzdem fortfahren?'
      )) return Promise.resolve(false);
    }

    var status = $('appStartStatus');
    if (status) status.textContent = 'Öffne ' + file.name + ' …';

    return GF.projekt.lade(file).then(function (ergebnis) {
      var projekt = ergebnis.projekt;
      var pdfBinaer = ergebnis.pdfBinaer;

      // PDFs durch pdf.js parsen, in state.pdfs einsetzen.
      // dateiName = Anzeigename (User-editierbar), containerPfad = ZIP-Eintrag.
      var pdfMetaInProjekt = projekt.pdfs || [];
      var kette = Promise.resolve();
      var pdfEintraege = [];
      pdfMetaInProjekt.forEach(function (meta) {
        var cPfad = meta.containerPfad || meta.dateiName;
        var bytes = pdfBinaer[cPfad];
        kette = kette.then(function () {
          // pdf.js braucht ein FRISCHES Uint8Array — sonst meckert es spaeter
          // ueber "detached buffer" wenn getData() aufgerufen wird.
          var kopie = new Uint8Array(bytes);
          return global.pdfjsLib.getDocument({ data: kopie }).promise.then(function (doc) {
            pdfEintraege.push({
              id: meta.id,
              dateiName: meta.dateiName,
              containerPfad: cPfad,
              originalDateiName: meta.originalDateiName || meta.dateiName,
              anzahlSeiten: doc.numPages,
              vektorAnteil: meta.vektorAnteil || null,
              pdfDoc: doc
            });
          });
        });
      });

      return kette.then(function () {
        // Bestehenden State komplett verwerfen
        GF.state.update(function (st) {
          st.projekt = projekt;
          st.pdfs = pdfEintraege;
          st.aktivePdfId = pdfEintraege[0] ? pdfEintraege[0].id : null;
          st.aktuelleSeite = 1;
          st.aktivesGeschossId = null;
          st.aktiveRegionId = null;
          st.aktivesPolygonId = null;
          st.pdfCache = null;
          st.viewport = { zoom: 1.0, panX: 0, panY: 0 };
          st.ungespeicherteAenderungen = false;
        });
        aktualisiereToolbar();
        aktualisiereGeschossListe();

        if (pdfEintraege.length > 0) {
          return zeigeSeite(1);
        }
        return null;
      }).then(function () {
        if (status) status.textContent = 'Projekt geladen: ' + file.name;
        showToast('Projekt geöffnet: ' + (projekt.metadata.projektName || file.name) +
                  ' (' + pdfEintraege.length + ' PDF, ' + projekt.polygone.length + ' Polygon).',
                  'success', 6000);
        return true;
      });
    }).catch(function (err) {
      console.error('[gf-open]', err);
      if (status) status.textContent = 'Bereit.';
      showToast('Öffnen fehlgeschlagen: ' + err.message, 'danger', 9000);
      return false;
    });
  }

  function oeffneProjektDialog() {
    var inp = $('gfprojInput');
    if (inp) inp.click();
  }

  function wireProjektButtons() {
    var btnN = $('btnNeu');
    if (btnN) btnN.addEventListener('click', neuesProjekt);
    var btnS = $('btnSpeichern');
    if (btnS) btnS.addEventListener('click', function () { speichereProjekt(); });
    var btnO = $('btnOeffnen');
    if (btnO) btnO.addEventListener('click', oeffneProjektDialog);
    var btnPD = $('btnProjektdaten');
    if (btnPD) btnPD.addEventListener('click', oeffneProjektdaten);
  }

  // Verwirft das aktuelle Projekt und stellt den Tool-Start-Zustand wieder her.
  // Fragt bei ungespeicherten Aenderungen vorher nach.
  function neuesProjekt() {
    var s = GF.state;
    if (s.projekt && s.ungespeicherteAenderungen) {
      if (!global.confirm(
        'Das aktuelle Projekt hat ungespeicherte Änderungen. ' +
        'Beim Anlegen eines neuen Projekts gehen sie verloren.\n\nTrotzdem fortfahren?'
      )) return;
    }
    // Laufende Tool-Aktionen abbrechen
    if (typeof abbrecheEckpunktDrag === 'function' && aktiverPunktDrag) abbrecheEckpunktDrag();
    if (typeof abbrecheKantenEdit === 'function' && $('kantenEdit') && !$('kantenEdit').hidden) abbrecheKantenEdit();

    GF.state.update(function (st) {
      st.projekt = null;
      st.pdfs = [];
      st.aktivePdfId = null;
      st.aktuelleSeite = 1;
      st.aktivesGeschossId = null;
      st.aktiveRegionId = null;
      st.aktivesPolygonId = null;
      st.pdfCache = null;
      st.vektorAnteil = null;
      st.viewport = { zoom: 1.0, panX: 0, panY: 0 };
      st.ungespeicherteAenderungen = false;
    });

    // Canvas leeren (sonst bleibt das alte Bild stehen)
    var canvas = $('planCanvas');
    if (canvas) canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);

    // Recovery-Snapshot loeschen — wir starten frisch
    if (GF.recovery && GF.recovery.loesche) GF.recovery.loesche();

    aktualisiereToolbar();
    aktualisiereGeschossListe();
    aktualisiereCursor();
    redraw();

    var status = $('appStartStatus');
    if (status) status.textContent = 'Bereit. PDF laden, um zu beginnen.';
    showToast('Neues Projekt — PDF laden, um zu beginnen.');
  }

  // ============================================================
  // Projektdaten-Modal (Bauherr, Bauvorhaben, Adresse, ...)
  // ============================================================

  // Felder im Modal -> Schluessel in projekt.metadata
  var PD_FELDER = {
    pdProjektName:        'projektName',
    pdProjektNummer:      'projektNummer',
    pdBauvorhaben:        'bauvorhaben',
    pdBauortStrasse:      'bauortStrasse',
    pdBauortPLZ:          'bauortPLZ',
    pdBauortOrt:          'bauortOrt',
    pdFlurnummer:         'flurnummer',
    pdGemarkung:          'gemarkung',
    pdBauherr:            'bauherr',
    pdBauherrStrasse:     'bauherrAnschriftStrasse',
    pdBauherrPLZ:         'bauherrAnschriftPLZ',
    pdBauherrOrt:         'bauherrAnschriftOrt',
    pdBauherrPKNr:        'bauherrPKNr',
    pdSachbearbeiter:     'sachbearbeiter',
    pdZusatzinfo:         'zusatzinfo'
  };

  var SACHBEARBEITER_LS_KEY = 'gf.sachbearbeiter';

  function oeffneProjektdaten() {
    if (!GF.state.projekt) {
      showToast('Erst ein Projekt anlegen (PDF laden) oder öffnen.', 'warn');
      return;
    }
    var meta = GF.state.projekt.metadata || {};
    Object.keys(PD_FELDER).forEach(function (id) {
      var el = $(id);
      if (!el) return;
      var key = PD_FELDER[id];
      var wert = meta[key];
      // Sachbearbeiter vorbelegen aus LocalStorage, wenn im Projekt leer
      if (key === 'sachbearbeiter' && !wert) {
        try { wert = localStorage.getItem(SACHBEARBEITER_LS_KEY) || ''; } catch (e) { wert = ''; }
      }
      el.value = wert || '';
    });
    $('pdFehler').hidden = true;
    $('projektdatenBackdrop').classList.add('aktiv');
    setTimeout(function () {
      var inp = $('pdProjektName');
      if (inp) inp.focus();
    }, 30);
  }

  function abbrecheProjektdaten() {
    $('projektdatenBackdrop').classList.remove('aktiv');
  }

  function uebernehmeProjektdaten() {
    var meta = GF.state.projekt && GF.state.projekt.metadata;
    if (!meta) { abbrecheProjektdaten(); return; }

    var name = ($('pdProjektName').value || '').trim();
    if (!name) {
      var fehler = $('pdFehler');
      fehler.textContent = 'Projektname ist Pflichtfeld.';
      fehler.hidden = false;
      $('pdProjektName').focus();
      return;
    }

    // Alle Felder uebernehmen
    Object.keys(PD_FELDER).forEach(function (id) {
      var el = $(id);
      if (!el) return;
      meta[PD_FELDER[id]] = (el.value || '').trim();
    });

    // Sachbearbeiter in LocalStorage merken (komfortabel beim naechsten Projekt)
    if (meta.sachbearbeiter) {
      try { localStorage.setItem(SACHBEARBEITER_LS_KEY, meta.sachbearbeiter); } catch (e) {}
    }

    GF.projekt.historieEintrag(GF.state.projekt, 'Projektdaten geändert', '');
    GF.state.markiereGeaendert();
    aktualisiereToolbar();
    abbrecheProjektdaten();
    showToast('Projektdaten übernommen.', 'success');
  }

  function wireProjektdaten() {
    var ok = $('btnProjektdatenOk');
    var ab = $('btnProjektdatenAbbrechen');
    if (ok) ok.addEventListener('click', uebernehmeProjektdaten);
    if (ab) ab.addEventListener('click', abbrecheProjektdaten);
  }

  // ---- Maßstab-Linien-Toggle (Anzeige-Setting, LocalStorage) ----
  var MASS_VISIBLE_LS_KEY = 'gf.massstabSichtbar';

  function wireMassstabToggle() {
    var inp = $('massstabToggle');
    if (!inp) return;
    // Initial aus LocalStorage holen
    try {
      var gespeichert = localStorage.getItem(MASS_VISIBLE_LS_KEY);
      if (gespeichert === '0' || gespeichert === 'false') {
        GF.state.update(function (s) { s.massstabSichtbar = false; });
      }
    } catch (e) {}
    inp.checked = (GF.state.massstabSichtbar !== false);
    inp.addEventListener('change', function () {
      var sichtbar = inp.checked;
      GF.state.update(function (s) { s.massstabSichtbar = sichtbar; });
      try { localStorage.setItem(MASS_VISIBLE_LS_KEY, sichtbar ? '1' : '0'); } catch (e) {}
      redraw();
    });
  }

  // ============================================================
  // Aufmassprotokoll erzeugen
  // ============================================================

  function oeffneProtokollModal() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Erst ein Projekt anlegen.', 'warn');
      return;
    }
    // Sanity-Checks: Projektname + mindestens ein Polygon
    var meta = s.projekt.metadata || /** @type {ProjektMetadata} */ ({});
    if (!meta.projektName || meta.projektName === '(neu)') {
      showToast('Bitte zuerst Projektdaten ausfüllen (mindestens Projektname).', 'warn', 7000);
      oeffneProjektdaten();
      return;
    }
    if (!s.projekt.polygone || s.projekt.polygone.length === 0) {
      showToast('Noch keine Polygone gezeichnet — Protokoll wäre leer.', 'warn');
      return;
    }
    $('ppAufmassblatt').checked = true;
    $('ppBerechnung').checked = true;
    $('ppKantenmasse').checked = true;
    $('ppFehler').hidden = true;
    // Kantenmaß-Checkbox nur aktiv wenn Berechnungsdarstellung an ist
    aktualisiereKantenmasseEnabled();
    var info = $('ppInfo');
    if (info) {
      var ist = istDemoModus();
      info.hidden = !ist;
      if (ist) info.textContent = 'Hinweis: Lizenz im Demo-Modus — das PDF erhält ein diagonales Wasserzeichen.';
    }
    $('protokollBackdrop').classList.add('aktiv');
  }

  function abbrecheProtokollModal() {
    $('protokollBackdrop').classList.remove('aktiv');
  }

  function istDemoModus() {
    // Vollversion liegt vor, wenn eine Lizenz-ID hinterlegt ist (data/lizenz.js).
    // Die echte Whitelist-Pruefung erfolgt in Phase 6 — fuer das Wasserzeichen
    // reicht der ID-Check, weil die Whitelist-Datei selbst kontrolliert wird.
    if (GF.lizenz && typeof GF.lizenz.holeID === 'function') {
      try { return !GF.lizenz.holeID(); } catch (e) { return true; }
    }
    return true;
  }

  // Wandelt das #wappenLogo-Element (falls geladen) in eine PNG-DataURL um.
  function wappenAlsDataUrl() {
    var img = /** @type {HTMLImageElement | null} */ (document.getElementById('wappenLogo'));
    if (!img || !img.complete || img.naturalWidth === 0) return null;
    try {
      var c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      var ctx = /** @type {CanvasRenderingContext2D} */ (c.getContext('2d'));
      ctx.drawImage(img, 0, 0);
      return c.toDataURL('image/png');
    } catch (e) {
      console.warn('[gf-export] Wappen konnte nicht extrahiert werden:', e);
      return null;
    }
  }

  function aktualisiereKantenmasseEnabled() {
    var b = $('ppBerechnung');
    var k = $('ppKantenmasse');
    if (b && k) k.disabled = !b.checked;
  }

  function erzeugeProtokoll() {
    var s = GF.state;
    if (!s.projekt) return;
    var enthaltAufmassblatt = $('ppAufmassblatt').checked;
    var enthaltBerechnung   = $('ppBerechnung').checked;
    var enthaltKantenmasse  = enthaltBerechnung && $('ppKantenmasse').checked;
    if (!enthaltAufmassblatt && !enthaltBerechnung) {
      var f = $('ppFehler');
      f.textContent = 'Mindestens einen Inhalt auswählen.';
      f.hidden = false;
      return;
    }

    var basisName = (s.projekt.metadata.projektName || 'Aufmaß').replace(/[\\/:*?"<>|]/g, '_');
    var dateiName = basisName + '_Aufmassprotokoll.pdf';

    // btn + status muessen im aeusseren Scope leben, damit der finale .then()
    // sie reseten kann — auch wenn die UI erst nach dem Picker-Erfolg disabled wird.
    var btn    = $('btnProtokollErzeugen');
    var status = $('appStartStatus');

    // Save-Ziel ZUERST waehlen (User-Activation ist hier noch frisch).
    // Anschliessend rendert starteExport das PDF asynchron — das dauert bei
    // grossen Projekten mehrere Sekunden und wuerde sonst die Activation
    // verbrauchen, sodass der Picker auf Downloads-Fallback faellt.
    return waehleSaveZiel(dateiName).then(function (ziel) {
      if (!ziel) return false;   // User-Abbruch im Picker

      if (btn)    { btn.disabled = true; btn.textContent = 'Erstelle …'; }
      if (status) status.textContent = 'Erzeuge Aufmaßprotokoll …';

      var opt = {
        enthaltAufmassblatt: enthaltAufmassblatt,
        enthaltBerechnung:   enthaltBerechnung,
        enthaltKantenmasse:  enthaltKantenmasse,
        demoMode:            istDemoModus(),
        wappenDataUrl:       wappenAlsDataUrl()
      };

      return GF.export.starteExport(s.projekt, s.pdfs, opt).then(function (blob) {
        // null = User hat den Anrechnungs-Dialog abgebrochen — kein Fehler.
        if (!blob) return false;
        return schreibeAnZiel(ziel, blob, dateiName).then(function (gespeichert) {
          if (gespeichert) {
            GF.projekt.historieEintrag(s.projekt, 'Aufmaßprotokoll erstellt',
              (enthaltAufmassblatt ? 'Aufmaßblatt' : '') +
              (enthaltAufmassblatt && enthaltBerechnung ? ' + ' : '') +
              (enthaltBerechnung ? 'Berechnungsdarstellung' : ''));
            GF.state.markiereGeaendert();
            showToast('Aufmaßprotokoll erstellt: ' + dateiName, 'success', 6000);
            abbrecheProtokollModal();
          }
          return gespeichert;
        });
      });
    }).catch(function (err) {
      console.error('[gf-export]', err);
      var f = $('ppFehler');
      f.textContent = 'Erstellen fehlgeschlagen: ' + err.message;
      f.hidden = false;
    }).then(function () {
      if (btn) { btn.disabled = false; btn.textContent = 'PDF erstellen'; }
      if (status) status.textContent = 'Bereit.';
    });
  }

  function wireProtokoll() {
    var btn = $('btnProtokoll');
    if (btn) btn.addEventListener('click', oeffneProtokollModal);
    var ok = $('btnProtokollErzeugen');
    var ab = $('btnProtokollAbbrechen');
    if (ok) ok.addEventListener('click', erzeugeProtokoll);
    if (ab) ab.addEventListener('click', abbrecheProtokollModal);
    var b = $('ppBerechnung');
    if (b) b.addEventListener('change', aktualisiereKantenmasseEnabled);
  }

  // Strg+S / Strg+O global. Nur aktiv wenn KEIN Eingabefeld fokussiert ist.
  // preventDefault() unterdrueckt den Browser-eigenen "Webseite speichern" / "Datei oeffnen".
  function wireTastenkuerzel() {
    global.addEventListener('keydown', function (e) {
      var key = e.key && e.key.toLowerCase();
      var modifier = e.ctrlKey || e.metaKey;
      if (!modifier) return;
      if (istEingabeAktiv()) return;
      if (key === 's') {
        e.preventDefault();
        if (GF.state.projekt) speichereProjekt();
      } else if (key === 'o') {
        e.preventDefault();
        oeffneProjektDialog();
      }
    });
  }

  function wireDragDrop() {
    var host = $('canvasHost');
    var overlay = $('dropOverlay');
    if (!host || !overlay) return;
    var counter = 0;
    host.addEventListener('dragenter', function (e) {
      var types = (e.dataTransfer && e.dataTransfer.types) || [];
      var hatFiles = Array.prototype.indexOf.call(types, 'Files') >= 0;
      if (!hatFiles) return;
      counter++;
      overlay.classList.add('aktiv');
    });
    host.addEventListener('dragleave', function () {
      counter--;
      if (counter <= 0) {
        counter = 0;
        overlay.classList.remove('aktiv');
      }
    });
    host.addEventListener('dragover', function (e) {
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    });
    host.addEventListener('drop', function (e) {
      e.preventDefault();
      counter = 0;
      overlay.classList.remove('aktiv');
      var files = (e.dataTransfer && e.dataTransfer.files) || [];
      // file.type ist auf manchen Windows-Browsern leer / "application/octet-stream".
      // Fallback: Dateiendung pruefen.
      // .zip hat Vorrang: ein einzelnes Projekt-File ersetzt den State.
      // Die Tool-Erkennung passiert spaeter ueber projekt.json + containerFormat.
      var zips = Array.prototype.filter.call(files, function (f) {
        return /\.zip$/i.test(f.name) || /\.gfproj$/i.test(f.name);
      });
      if (zips.length > 0) {
        if (zips.length > 1) {
          showToast('Mehrere ZIP-Dateien — nur die erste wird geoeffnet.', 'warn');
        }
        ladeProjektDatei(zips[0]);
        return;
      }
      var pdfs = Array.prototype.filter.call(files, function (f) {
        return (f.type === 'application/pdf') || /\.pdf$/i.test(f.name);
      });
      if (pdfs.length === 0) {
        showToast('Nur PDF- oder .zip-Dateien werden unterstuetzt.', 'warn');
        return;
      }
      if (pdfs.length < files.length) {
        showToast('Nicht unterstuetzte Dateien wurden ignoriert.', 'warn');
      }
      ladePdfDateien(pdfs);
    });
  }

  // ============================================================
  // Werkzeug-Auswahl (Pan / Region / Massstab / Polygon)
  // ============================================================

  function setzeWerkzeug(name) {
    var aktiv = GF.state.aktivesWerkzeug;
    if (aktiv === name) return;
    // Werkzeug-Wechsel raeumt laufende Aktionen auf
    if (regionDragAktiv) {
      regionDragAktiv = false;
      regionStartPdf = null;
      regionAktuellPdf = null;
    }
    resetMass();
    resetPolygon();
    winkelSnapAktiv = false;
    // Kanten-Edit-Panel schliessen, falls offen
    if ($('kantenEdit') && !$('kantenEdit').hidden) abbrecheKantenEdit();
    // Laufenden Eckpunkt-Drag abbrechen (Punkt auf Originalpos zurueck)
    if (aktiverPunktDrag) abbrecheEckpunktDrag();

    // Vorpruefung beim Aktivieren bestimmter Werkzeuge
    if (name === 'massstab') {
      if (!starteMassstab()) return;     // bricht ab wenn keine Region aktiv
    }
    if (name === 'polygon') {
      if (!startePolygonWerkzeug()) return;
    }

    GF.state.update(function (s) { s.aktivesWerkzeug = name; });
    aktualisiereWerkzeugUI();
    aktualisiereCursor();
    redraw();

    // Fokus vom Werkzeug-Button wegnehmen, damit Tastatur-Events (ESC/Enter)
    // sauber am window-Listener ankommen und nicht der Button selbst reagiert.
    var ae = /** @type {HTMLElement | null} */ (document.activeElement);
    if (ae && typeof ae.blur === 'function') {
      ae.blur();
    }
  }

  function aktualisiereWerkzeugUI() {
    var liste = $('werkzeugListe');
    if (!liste) return;
    var aktiv = GF.state.aktivesWerkzeug;
    liste.querySelectorAll('.wkz').forEach(function (b) {
      if (b.dataset.werkzeug === aktiv) b.classList.add('aktiv');
      else b.classList.remove('aktiv');
    });
  }

  function aktualisiereCursor() {
    var canvas = $('planCanvas');
    if (!canvas) return;
    canvas.classList.remove('region-mode', 'massstab-mode', 'polygon-mode', 'panning', 'space-pan');
    canvas.style.cursor = '';                 // inline-Cursor vom Kanten-Hover wegraeumen
    if (spaceGehalten) {
      canvas.classList.add('space-pan');
      return;
    }
    if (GF.state.aktivesWerkzeug === 'region')   canvas.classList.add('region-mode');
    if (GF.state.aktivesWerkzeug === 'massstab') canvas.classList.add('massstab-mode');
    if (GF.state.aktivesWerkzeug === 'polygon')  canvas.classList.add('polygon-mode');
  }

  // ---- Space-Hold = temporaerer Pan-Modus (CAD-Konvention) ----
  var spaceGehalten = false;

  function istEingabeAktiv() {
    var t = /** @type {HTMLElement | null} */ (document.activeElement);
    return !!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable));
  }

  function wireSpacePan() {
    global.addEventListener('keydown', function (e) {
      if ((e.key === ' ' || e.code === 'Space') && !spaceGehalten && !istEingabeAktiv()) {
        spaceGehalten = true;
        e.preventDefault();
        aktualisiereCursor();
      }
    });
    global.addEventListener('keyup', function (e) {
      if (e.key === ' ' || e.code === 'Space') {
        if (spaceGehalten) {
          spaceGehalten = false;
          aktualisiereCursor();
        }
      }
    });
    // Falls Fokus den Browser verlaesst, Space als "losgelassen" werten
    global.addEventListener('blur', function () {
      if (spaceGehalten) { spaceGehalten = false; aktualisiereCursor(); }
    });
  }

  function wireWerkzeug() {
    var liste = $('werkzeugListe');
    if (liste) {
      liste.addEventListener('click', function (e) {
        var btn = e.target.closest && e.target.closest('.wkz');
        if (!btn || btn.disabled) return;
        setzeWerkzeug(btn.dataset.werkzeug);
      });
    }
  }

  // ============================================================
  // Geschoss-Verwaltung
  // ============================================================

  function frageGeschossName(vorbelegung) {
    var eingabe = global.prompt(
      'Bezeichnung des Geschosses:\n(z. B. "Kellergeschoss", "EG", "1. OG", "Dachgeschoss")',
      vorbelegung || ''
    );
    if (eingabe === null) return null;
    var t = eingabe.trim();
    return t || null;
  }

  function legeGeschossAn() {
    var name = frageGeschossName('');
    if (!name) return;
    var projekt = GF.projekt.sorgeFuerProjekt();
    var maxReihenfolge = projekt.geschosse.reduce(function (m, g) {
      return Math.max(m, g.reihenfolge);
    }, 0);
    var neu = GF.geschoss.erzeuge(name, maxReihenfolge + 1);
    projekt.geschosse.push(neu);
    GF.projekt.historieEintrag(projekt, 'Geschoss angelegt', name);
    GF.state.update(function (s) {
      s.aktivesGeschossId = neu.id;
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    showToast('Geschoss angelegt: ' + name, 'success');
  }

  function benenneGeschossUm(id) {
    var g = GF.state.findGeschoss(id);
    if (!g) return;
    var neu = frageGeschossName(g.bezeichnung);
    if (!neu) return;
    GF.state.update(function () {
      GF.geschoss.umbenenne(g, neu);
      GF.state.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();   // Labels in Region-Overlays aktualisieren
  }

  function loescheGeschoss(id) {
    var g = GF.state.findGeschoss(id);
    if (!g) return;
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var regionen = projekt.planRegionen.filter(function (r) { return r.geschossId === id; });
    var polygone = projekt.polygone   .filter(function (p) { return p.geschossId === id; });
    var hinweis = 'Geschoss "' + g.bezeichnung + '" wirklich löschen?';
    if (regionen.length || polygone.length) {
      hinweis += '\n\nAuch ' + regionen.length + ' Region(en) und ' + polygone.length + ' Polygon(e) werden geloescht.';
    }
    if (!global.confirm(hinweis)) return;
    // Cascading delete
    projekt.planRegionen = projekt.planRegionen.filter(function (r) { return r.geschossId !== id; });
    projekt.polygone    = projekt.polygone   .filter(function (p) { return p.geschossId !== id; });
    projekt.geschosse   = projekt.geschosse  .filter(function (g0) { return g0.id !== id; });
    GF.projekt.historieEintrag(projekt, 'Geschoss geloescht', g.bezeichnung);
    GF.state.update(function (s) {
      if (s.aktivesGeschossId === id) s.aktivesGeschossId = null;
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();
  }

  function aktivierteGeschoss(id) {
    GF.state.update(function (s) { s.aktivesGeschossId = id; });
    aktualisiereGeschossListe();
    // Wenn das Geschoss Regionen hat: zur ersten Region springen (PDF + Seite
    // umschalten falls noetig). Sonst nur State setzen.
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var regionen = projekt.planRegionen.filter(function (r) { return r.geschossId === id; });
    if (regionen.length === 0) return;
    var ersteRegion = regionen[0];
    // Springen nur wenn wir nicht eh schon dort sind
    if (ersteRegion.pdfId !== GF.state.aktivePdfId || ersteRegion.seite !== GF.state.aktuelleSeite ||
        ersteRegion.id !== GF.state.aktiveRegionId) {
      springZuRegion(ersteRegion.id);
    }
  }

  function aktualisiereGeschossListe() {
    var ul = $('geschossListe');
    if (!ul) return;
    var projekt = GF.state.projekt;
    var geschosse = projekt ? GF.geschoss.sortiereNachReihenfolge(projekt.geschosse) : [];
    var esc = GF.util.esc;

    if (geschosse.length === 0) {
      ul.innerHTML = '<li class="sb-empty">— noch keine Geschosse —</li>';
      return;
    }

    var html = '';
    geschosse.forEach(function (g) {
      var aktiv = (g.id === GF.state.aktivesGeschossId);
      var regionen = projekt.planRegionen.filter(function (r) { return r.geschossId === g.id; });
      var polygone = projekt.polygone   .filter(function (p) { return p.geschossId === g.id; });
      html += '<li class="gs ' + (aktiv ? 'aktiv' : '') + '" data-geschoss-id="' + esc(g.id) + '">'
            +   '<div class="gs-header">'
            +     '<span class="gs-name" title="' + esc(g.bezeichnung) + '">' + esc(g.bezeichnung) + '</span>'
            +     '<span class="gs-count">'
            +       (regionen.length ? regionen.length + 'R ' : '')
            +       (polygone.length ? polygone.length + 'P' : '')
            +     '</span>'
            +     '<button type="button" class="gs-btn" data-aktion="umbenennen" title="Geschoss umbenennen">✎</button>'
            +     '<button type="button" class="gs-btn" data-aktion="loeschen"   title="Geschoss komplett loeschen">🗑</button>'
            +   '</div>';

      // VG-Bereich (vor Region-Subliste)
      var maxReihenfolge = -Infinity;
      for (var ri = 0; ri < geschosse.length; ri++) {
        if (geschosse[ri].reihenfolge > maxReihenfolge) maxReihenfolge = geschosse[ri].reihenfolge;
      }
      var istOberstes = (g.reihenfolge === maxReihenfolge);
      var vg = g.vollgeschoss;
      var vgKlasse = 'gs-vg' + (istOberstes ? '' : ' gs-vg-inaktiv');
      if (vg && vg.durchgefuehrt) {
        var anteilPct = (vg.ergebnis && vg.ergebnis.anteil_2_30 != null)
          ? GF.util.formatZahlDE(vg.ergebnis.anteil_2_30 * 100, 1) + ' %'
          : '–';
        var istVg = vg.ergebnis && vg.ergebnis.vollgeschoss;
        var vgKls  = istVg ? 'ok' : 'nein';
        var vgText = (istVg ? 'Vollgeschoss' : 'Kein Vollgeschoss') + ' (' + anteilPct + ')';
        html += '<div class="' + vgKlasse + '">'
              +   '<div class="gs-vg-zeile">'
              +     '<span class="gs-vg-label">VG</span>'
              +     '<span class="gs-vg-status ' + vgKls + '">' + esc(vgText) + '</span>'
              +     '<button type="button" class="gs-vg-bearbeiten" data-aktion="vg-aufrufen" title="VG-Beurteilung bearbeiten">Bearbeiten</button>'
              +   '</div>'
              + '</div>';
      } else {
        var titleAttr = istOberstes
          ? 'Vollgeschoss-Beurteilung starten'
          : 'Vollgeschoss-Prüfung üblicherweise nur für DG / oberstes Geschoss';
        html += '<div class="' + vgKlasse + '" title="' + esc(titleAttr) + '">'
              +   '<div class="gs-vg-zeile">'
              +     '<span class="gs-vg-label">VG</span>'
              +     '<span class="gs-vg-status gs-vg-leer"></span>'
              +     '<button type="button" class="gs-vg-aufrufen" data-aktion="vg-aufrufen">Aufrufen</button>'
              +   '</div>'
              + '</div>';
      }

      if (regionen.length > 0) {
        html += '<ul class="region-subliste">';
        regionen.forEach(function (r, idx) {
          var pdf = GF.state.findPdf(r.pdfId);
          var pdfName = pdf ? pdf.dateiName : '?';
          var aktivR = (r.id === GF.state.aktiveRegionId);
          var kal = r.kalibrierung;
          var kalLabel = '';
          var kalKlasse = 'rg-kal-fehlt';
          if (kal) {
            // Label: bei uebernommen zeigt das ⇆-Praefix den uebertragenen
            // Charakter; die Farbcodierung kommt einheitlich aus der Abweichung,
            // damit Quell- und uebernommene Region bei identischem ptProMeter
            // garantiert denselben Status zeigen.
            var massText = kal.normMassstab || (GF.util.formatZahlDE(kal.ptProMeter, 2) + ' pt/m');
            kalLabel = (kal.quelle === 'übernommen') ? ('⇆ ' + massText) : massText;
            kalKlasse = 'rg-kal-ok';
            if (kal.abweichungVonNormProzent > 3) kalKlasse = 'rg-kal-warn';
            else if (kal.abweichungVonNormProzent > 0.5) kalKlasse = 'rg-kal-hinweis';
          } else {
            kalLabel = 'Maßstab ✗';
          }
          var polysProRegion = projekt.polygone.filter(function (pp) { return pp.regionId === r.id; });
          html += '<li class="region-item ' + (aktivR ? 'aktiv' : '') + '" data-region-id="' + esc(r.id) + '" title="Zur Region springen">'
                +   '<span class="rg-marker">▭</span>'
                +   '<span class="rg-name">' + (idx + 1) + ') ' + esc(pdfName) + ' · S.' + r.seite + '</span>'
                +   '<span class="rg-kal ' + kalKlasse + '">' + esc(kalLabel) + '</span>'
                +   '<button type="button" class="gs-btn" data-aktion="region-loeschen" title="Nur diese Region loeschen">🗑</button>'
                + '</li>';
          if (polysProRegion.length > 0) {
            html += '<ul class="polygon-subliste">';
            polysProRegion.forEach(function (pp) {
              var aktivP = (pp.id === GF.state.aktivesPolygonId);
              var farbe = pp.farbeOverlay || '#7f8c8d';
              var deckkraft = (typeof pp.deckkraft === 'number') ? pp.deckkraft : 0.5;
              var dProzent = Math.round(deckkraft * 100);
              var manuell = pp.manuelleKorrektur === true;
              var fAngesetzt = GF.util.formatZahlDE(pp.flaecheAngesetztQM, 2);
              var fGemessen  = GF.util.formatZahlDE(pp.flaecheGemessenQM, 2);
              var flaecheTitel = manuell
                ? 'Manuell angesetzt: ' + fAngesetzt + ' m² (gemessen ' + fGemessen + ' m²). Klick auf ✎ zum Anpassen.'
                : 'Gemessene Fläche: ' + fAngesetzt + ' m². Klick auf ✎ um manuell zu überschreiben.';
              html += '<li class="polygon-item ' + (aktivP ? 'aktiv' : '') + '" data-polygon-id="' + esc(pp.id) + '" title="Polygon aktivieren">'
                    +   '<span class="pg-swatch" style="background:' + farbe + '" title="Klick: Farbe aendern"></span>'
                    +   '<span class="pg-name">' + esc(pp.bezeichnung) + '</span>'
                    +   '<span class="pg-flaeche' + (manuell ? ' korrigiert' : '') + '" title="' + esc(flaecheTitel) + '">' + fAngesetzt + ' m²</span>'
                    +   (manuell ? '<span class="pg-gemessen" title="aus Polygon-Geometrie">(gem. ' + fGemessen + ')</span>' : '')
                    +   '<button type="button" class="pg-edit-flaeche" data-aktion="flaeche-edit" title="' + (manuell ? 'Flaechenkorrektur bearbeiten' : 'Flaeche manuell ueberschreiben') + '">✎</button>'
                    +   '<button type="button" class="pg-deckkraft" data-aktion="deckkraft" title="Transparenz: ' + dProzent + ' %. Klick wechselt 0/25/50/75/100.">' + dProzent + '%</button>'
                    +   '<button type="button" class="gs-btn" data-aktion="polygon-loeschen" title="Polygon loeschen">🗑</button>'
                    + '</li>';
            });
            html += '</ul>';
          }
        });
        html += '</ul>';
      }
      html += '</li>';
    });
    ul.innerHTML = html;
  }

  function loescheRegion(rid) {
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var r = null;
    for (var i = 0; i < projekt.planRegionen.length; i++) {
      if (projekt.planRegionen[i].id === rid) { r = projekt.planRegionen[i]; break; }
    }
    if (!r) return;

    var polygone = projekt.polygone.filter(function (p) { return p.regionId === rid; });
    var hinweis = 'Diese Plan-Region wirklich löschen?';
    if (polygone.length) hinweis += '\n\nAuch ' + polygone.length + ' Polygon(e) in dieser Region werden geloescht.';
    if (!global.confirm(hinweis)) return;

    projekt.planRegionen = projekt.planRegionen.filter(function (x) { return x.id !== rid; });
    projekt.polygone    = projekt.polygone   .filter(function (p) { return p.regionId !== rid; });

    GF.projekt.historieEintrag(projekt, 'Region geloescht',
      'Geschoss: ' + (GF.state.findGeschoss(r.geschossId) || {}).bezeichnung);

    GF.state.update(function (s) {
      if (s.aktiveRegionId === rid) s.aktiveRegionId = null;
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();
    showToast('Region geloescht.', 'success');
  }

  function springZuRegion(rid) {
    var projekt = GF.state.projekt;
    if (!projekt) return;
    var r = null;
    for (var i = 0; i < projekt.planRegionen.length; i++) {
      if (projekt.planRegionen[i].id === rid) { r = projekt.planRegionen[i]; break; }
    }
    if (!r) return;

    function aktiviere() {
      GF.state.update(function (s) {
        s.aktiveRegionId = rid;
        s.aktivesGeschossId = r.geschossId;
      });
      aktualisiereGeschossListe();
      redraw();
    }

    var pdfWechsel = (r.pdfId !== GF.state.aktivePdfId);
    var seiteWechsel = (r.seite !== GF.state.aktuelleSeite);

    if (pdfWechsel) {
      wechsleZuPdf(r.pdfId).then(function () {
        return seiteWechsel ? zeigeSeite(r.seite) : Promise.resolve();
      }).then(aktiviere);
    } else if (seiteWechsel) {
      zeigeSeite(r.seite).then(aktiviere);
    } else {
      aktiviere();
    }
  }

  function wireGeschosse() {
    $('btnGeschossNeu').addEventListener('click', legeGeschossAn);

    var ul = $('geschossListe');
    ul.addEventListener('click', function (e) {
      // Polygon-Eintrag-Aktion zuerst (am tiefsten)
      var polyItem = e.target.closest && e.target.closest('.polygon-item');
      if (polyItem) {
        var pid = polyItem.dataset.polygonId;
        var polyBtn = e.target.closest && e.target.closest('.gs-btn');
        if (polyBtn) {
          e.stopPropagation();
          if (polyBtn.dataset.aktion === 'polygon-loeschen') loeschePolygon(pid);
          return;
        }
        // Deckkraft-Button: Transparenz zyklisch wechseln
        if (e.target.classList && e.target.classList.contains('pg-deckkraft')) {
          e.stopPropagation();
          aenderePolygonDeckkraft(pid);
          return;
        }
        // Farb-Swatch: Farbe aendern
        if (e.target.classList && e.target.classList.contains('pg-swatch')) {
          e.stopPropagation();
          aenderePolygonFarbe(pid);
          return;
        }
        // ✎-Button: Flaechen-Korrektur-Modal oeffnen
        if (e.target.classList && e.target.classList.contains('pg-edit-flaeche')) {
          e.stopPropagation();
          oeffneFlaechenKorrektur(pid);
          return;
        }
        e.stopPropagation();
        aktivierePolygon(pid);
        return;
      }
      // Region-Eintrag-Aktion zuerst pruefen (er liegt INNER li.gs)
      var regionItem = e.target.closest && e.target.closest('.region-item');
      if (regionItem) {
        var rid = regionItem.dataset.regionId;
        var regBtn = e.target.closest && e.target.closest('.gs-btn');
        if (regBtn) {
          e.stopPropagation();
          if (regBtn.dataset.aktion === 'region-loeschen') loescheRegion(rid);
          return;
        }
        e.stopPropagation();
        springZuRegion(rid);
        return;
      }

      // Geschoss-Aktion
      var li = e.target.closest && e.target.closest('li.gs');
      if (!li) return;
      var id = li.dataset.geschossId;

      // VG-Aufrufen / Bearbeiten
      var vgBtn = e.target.closest && e.target.closest('[data-aktion="vg-aufrufen"]');
      if (vgBtn) {
        e.stopPropagation();
        if (GF.VgModal && GF.VgModal.oeffne) GF.VgModal.oeffne(id, GF.state.projekt);
        return;
      }

      var aktBtn = e.target.closest && e.target.closest('.gs-btn');
      if (aktBtn) {
        e.stopPropagation();
        var aktion = aktBtn.dataset.aktion;
        if (aktion === 'umbenennen') benenneGeschossUm(id);
        else if (aktion === 'loeschen') loescheGeschoss(id);
        return;
      }
      aktivierteGeschoss(id);
    });
  }

  // ============================================================
  // Polygon-Werkzeug (Aussenkontur klicken)
  // ============================================================

  var polygonPunkte = [];        // gesammelte Punkte (PDF-Koord)
  var polygonMaus   = null;      // aktuelle Maus (PDF-Koord) fuer Live-Linie

  function startePolygonWerkzeug() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Bitte erst eine Plan-Region anlegen.', 'warn');
      return false;
    }
    if (!s.aktiveRegionId) {
      showToast('Bitte erst eine Region in der Sidebar aktivieren.', 'warn');
      return false;
    }
    var r = null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
    }
    if (!r) return false;
    if (!r.kalibrierung || !r.kalibrierung.ptProMeter) {
      showToast('Region hat noch keinen Maßstab — bitte erst kalibrieren.', 'warn');
      return false;
    }
    if (r.pdfId !== s.aktivePdfId || r.seite !== s.aktuelleSeite) {
      showToast('Aktive Region liegt auf anderer PDF/Seite — bitte erst dorthin springen.', 'warn');
      return false;
    }
    resetPolygon();
    showToast('Außenkontur klicken. Doppelklick / Enter / Klick auf Startpunkt = schließen. ' +
              'Bei rechtem Winkel zur letzten Kante rastet die Linie auf 90° ein (grün) — Shift halten unterdrückt das. ' +
              'Pannen: Mausrad-Klick + Ziehen.', null, 11000);
    return true;
  }

  // Winkel-Snap-Status fuer Live-Vorschau (gruene Linie wenn 90°/0° greift)
  var winkelSnapAktiv = false;
  var WINKEL_SNAP_TOLERANZ = 2;       // Grad
  var WINKEL_SNAP_MIN_LAENGE = 5;     // Pixel auf Canvas — sehr kurze Striche nicht snappen

  // Wendet 90°-Snap auf einen neuen Punkt an (zur letzten gesetzten Kante).
  // shiftKey=true unterdrueckt den Snap.
  function vielleichtWinkelSnap(pdfPt, shiftKey) {
    if (shiftKey) return pdfPt;
    if (polygonPunkte.length === 0) return pdfPt;
    var letzter = polygonPunkte[polygonPunkte.length - 1];
    var dx = pdfPt.x - letzter.x;
    var dy = pdfPt.y - letzter.y;
    var laengePt = Math.sqrt(dx * dx + dy * dy);
    var laengeCanvas = laengePt * GF.state.viewport.zoom;
    if (laengeCanvas < WINKEL_SNAP_MIN_LAENGE) return pdfPt;
    var s = GF.polygon.snap.aufRechtwinkel(letzter, pdfPt, WINKEL_SNAP_TOLERANZ);
    return s;   // hat .snapped Property wenn gesnappt
  }

  // Prueft, ob ein PDF-Punkt innerhalb des Ausschnitt-Rechtecks einer Region liegt.
  // Gibt true zurueck, wenn keine Region uebergeben wird oder die Region keinen
  // Ausschnitt definiert (defensiv — kein false-Reject).
  function pdfPunktInRegion(pdfPt, region) {
    if (!region || !region.ausschnitt) return true;
    var a = region.ausschnitt;
    return pdfPt.x >= a.x && pdfPt.x <= a.x + a.breite
        && pdfPt.y >= a.y && pdfPt.y <= a.y + a.hoehe;
  }

  function findeAktiveRegion() {
    var s = GF.state;
    if (!s.projekt || !s.aktiveRegionId) return null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) return s.projekt.planRegionen[i];
    }
    return null;
  }

  // Findet eine andere Region als die aktive, in deren Ausschnitt der Punkt liegt.
  // Genutzt fuer praezisere Hinweis-Texte ("Region X aktivieren?").
  function findeRegionFuerPdfPunkt(pdfPt) {
    var s = GF.state;
    if (!s.projekt) return null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      var r = s.projekt.planRegionen[i];
      if (r.pdfId !== s.aktivePdfId || r.seite !== s.aktuelleSeite) continue;
      if (pdfPunktInRegion(pdfPt, r)) return r;
    }
    return null;
  }

  function polygonKlick(canvasX, canvasY, shiftKey) {
    // Nahe dem Startpunkt? -> Polygon schliessen
    if (polygonPunkte.length >= 3) {
      var startCanvas = pdfZuCanvas(polygonPunkte[0].x, polygonPunkte[0].y);
      var dx = canvasX - startCanvas.x;
      var dy = canvasY - startCanvas.y;
      if (Math.sqrt(dx * dx + dy * dy) < 10) {
        schliessePolygon();
        return;
      }
    }
    // Doppelklick-Effekt: zweiter Click sehr nah am letzten Punkt -> ignorieren
    if (polygonPunkte.length > 0) {
      var letzter = polygonPunkte[polygonPunkte.length - 1];
      var lc = pdfZuCanvas(letzter.x, letzter.y);
      var dxL = canvasX - lc.x;
      var dyL = canvasY - lc.y;
      if (Math.sqrt(dxL * dxL + dyL * dyL) < 3) return;
    }
    var pdfPt = canvasZuPdf(canvasX, canvasY);
    pdfPt = vielleichtWinkelSnap(pdfPt, shiftKey);

    // Region-Grenze hart durchsetzen: Polygon-Punkte muessen innerhalb der
    // aktiven Region liegen, damit Polygone keiner falschen Region zugeordnet
    // werden (Daten-Integritaet beim Aufmassprotokoll). Hinweistext ist
    // praeziser, wenn der Klick zufaellig in einer anderen Region landet.
    var aktiveRegion = findeAktiveRegion();
    if (aktiveRegion && !pdfPunktInRegion(pdfPt, aktiveRegion)) {
      var andere = findeRegionFuerPdfPunkt(pdfPt);
      var hinweis;
      if (andere) {
        hinweis = 'Punkt liegt in Region "' + (andere.bezeichnung || '?')
          + '", aktiv ist aber "' + (aktiveRegion.bezeichnung || '?')
          + '". Erst die richtige Region in der Sidebar aktivieren.';
      } else {
        hinweis = 'Punkt liegt ausserhalb der aktiven Region "'
          + (aktiveRegion.bezeichnung || '?')
          + '". Bitte innerhalb des Region-Rechtecks klicken.';
      }
      showToast(hinweis, 'warn', 5000);
      return;
    }

    polygonPunkte.push({ x: pdfPt.x, y: pdfPt.y });
    polygonMaus = { x: pdfPt.x, y: pdfPt.y };
    winkelSnapAktiv = false;     // nach Klick zuruecksetzen, naechster mousemove setzt neu
    redraw();
  }

  function polygonMausBewegung(canvasX, canvasY, shiftKey) {
    var pdfPt = canvasZuPdf(canvasX, canvasY);
    pdfPt = vielleichtWinkelSnap(pdfPt, shiftKey);
    polygonMaus = { x: pdfPt.x, y: pdfPt.y };
    winkelSnapAktiv = !!pdfPt.snapped;
    redraw();
  }

  function abbrechePolygon() {
    if (polygonPunkte.length > 0) showToast('Polygon abgebrochen.');
    resetPolygon();
    redraw();
  }

  function schliessePolygon() {
    if (polygonPunkte.length < 3) {
      showToast('Polygon braucht mindestens 3 Punkte.', 'warn');
      return;
    }
    if (GF.polygon.hatSelbstueberschneidung(polygonPunkte)) {
      if (!global.confirm(
        'Das Polygon hat eine Selbstüberschneidung — die Flächenberechnung ist dann nicht korrekt.\n\n' +
        'Trotzdem speichern? (Empfohlen: Abbrechen und Polygon neu zeichnen.)'
      )) return;
    }
    var bez = global.prompt(
      'Bezeichnung des Polygons:\n(z. B. "Hauptgebäude", "Garage", "Nebengebäude", "Anbau")',
      'Hauptgebäude'
    );
    if (bez === null) return;
    bez = bez.trim() || 'Hauptgebäude';
    speicherePolygon(bez);
  }

  function speicherePolygon(bezeichnung) {
    var s = GF.state;
    var r = null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
    }
    if (!r) return;

    var flaeche;
    try {
      flaeche = GF.polygon.berechneFlaeche(polygonPunkte, r.kalibrierung.ptProMeter);
    } catch (e) {
      showToast('Flächenberechnung fehlgeschlagen: ' + e.message, 'danger');
      return;
    }

    var polygon = {
      id: GF.util.uuid(),
      geschossId: r.geschossId,
      regionId: r.id,
      bezeichnung: bezeichnung,
      punkte: polygonPunkte.map(function (p) { return { x: p.x, y: p.y }; }),
      flaecheGemessenQM: flaeche,
      flaecheAngesetztQM: flaeche,
      manuelleKorrektur: false,
      korrekturKommentar: '',
      farbeOverlay: farbeFuerPolygon(bezeichnung),
      deckkraft: 0.5   // 0 / 0.25 / 0.5 / 0.75 / 1.0 — per Sidebar wechselbar
    };

    s.projekt.polygone.push(polygon);
    GF.projekt.historieEintrag(s.projekt, 'Polygon angelegt',
      bezeichnung + ' / ' + GF.util.formatZahlDE(flaeche, 2) + ' m^2');

    GF.state.update(function (s2) {
      s2.aktivesPolygonId = polygon.id;
      s2.ungespeicherteAenderungen = true;
    });
    resetPolygon();
    setzeWerkzeug('pan');
    aktualisiereGeschossListe();
    redraw();
    showToast('Polygon angelegt: ' + bezeichnung + ' = ' +
              GF.util.formatZahlDE(flaeche, 2) + ' m^2', 'success', 6000);
  }

  function resetPolygon() {
    polygonPunkte = [];
    polygonMaus = null;
    winkelSnapAktiv = false;
  }

  function farbeFuerPolygon(bezeichnung) {
    var b = (bezeichnung || '').toLowerCase();
    if (b.indexOf('garage') >= 0)       return '#3498DB';
    if (b.indexOf('nebengeb') >= 0)     return '#2ECC71';
    if (b.indexOf('anbau') >= 0)        return '#F39C12';
    if (b.indexOf('hauptgeb') >= 0 || !b) return '#E74C3C';
    return '#7f8c8d';
  }

  function loeschePolygon(pid) {
    var s = GF.state;
    if (!s.projekt) return;
    var p = null;
    for (var i = 0; i < s.projekt.polygone.length; i++) {
      if (s.projekt.polygone[i].id === pid) { p = s.projekt.polygone[i]; break; }
    }
    if (!p) return;
    if (!global.confirm('Polygon "' + p.bezeichnung + '" (' +
        GF.util.formatZahlDE(p.flaecheAngesetztQM, 2) + ' m^2) wirklich löschen?')) return;
    s.projekt.polygone = s.projekt.polygone.filter(function (x) { return x.id !== pid; });
    GF.projekt.historieEintrag(s.projekt, 'Polygon geloescht', p.bezeichnung);
    GF.state.update(function (st) {
      if (st.aktivesPolygonId === pid) st.aktivesPolygonId = null;
      st.ungespeicherteAenderungen = true;
    });
    aktualisiereGeschossListe();
    redraw();
    showToast('Polygon geloescht.', 'success');
  }

  function aktivierePolygon(pid) {
    var poly = GF.state.findPolygon(pid);
    GF.state.update(function (s) { s.aktivesPolygonId = pid; });
    aktualisiereGeschossListe();
    redraw();
    // Wenn das Polygon auf einer anderen Seite / einem anderen PDF liegt,
    // automatisch dorthin springen.
    if (poly && poly.regionId) {
      var region = GF.state.findRegion(poly.regionId);
      if (region && (region.pdfId !== GF.state.aktivePdfId ||
                     region.seite !== GF.state.aktuelleSeite ||
                     region.id    !== GF.state.aktiveRegionId)) {
        springZuRegion(region.id);
      }
    }
  }

  function naechsteDeckkraft(d) {
    var stufen = [0, 0.25, 0.5, 0.75, 1.0];
    var ind = stufen.indexOf(Math.round((d || 0) * 4) / 4);
    if (ind < 0) ind = 2;
    return stufen[(ind + 1) % stufen.length];
  }

  function aenderePolygonDeckkraft(pid) {
    var s = GF.state;
    if (!s.projekt) return;
    var p = null;
    for (var i = 0; i < s.projekt.polygone.length; i++) {
      if (s.projekt.polygone[i].id === pid) { p = s.projekt.polygone[i]; break; }
    }
    if (!p) return;
    var alt = (typeof p.deckkraft === 'number') ? p.deckkraft : 0.5;
    p.deckkraft = naechsteDeckkraft(alt);
    GF.state.update(function (st) { st.ungespeicherteAenderungen = true; });
    aktualisiereGeschossListe();
    redraw();
  }

  function aenderePolygonFarbe(pid) {
    var s = GF.state;
    if (!s.projekt) return;
    var p = null;
    for (var i = 0; i < s.projekt.polygone.length; i++) {
      if (s.projekt.polygone[i].id === pid) { p = s.projekt.polygone[i]; break; }
    }
    if (!p) return;
    // Native Farbauswahl via temporaerem input[type=color]
    var inp = document.createElement('input');
    inp.type = 'color';
    inp.value = (p.farbeOverlay || '#7f8c8d').slice(0, 7);
    inp.style.position = 'fixed';
    inp.style.left = '-9999px';
    document.body.appendChild(inp);
    inp.addEventListener('change', function () {
      p.farbeOverlay = inp.value;
      GF.state.update(function (st) { st.ungespeicherteAenderungen = true; });
      aktualisiereGeschossListe();
      redraw();
      document.body.removeChild(inp);
    });
    inp.addEventListener('input', function () {
      // Live-Preview waehrend des Auswaehlens
      p.farbeOverlay = inp.value;
      redraw();
    });
    inp.click();
  }

  // ============================================================
  // Kanten-Edit (Klick auf ein Maß-Label im Plan-Modus)
  // ============================================================

  var kantenEditPolygonId = null;
  var kantenEditIndex     = -1;

  function oeffneKantenEdit(polygonId, kantenIndex) {
    var poly = GF.state.findPolygon(polygonId);
    if (!poly) return;
    var region = GF.state.findRegion(poly.regionId);
    if (!region || !region.kalibrierung || !region.kalibrierung.ptProMeter) {
      showToast('Region ist nicht kalibriert — bitte zuerst Maßstab setzen.', 'warn');
      return;
    }
    var n = poly.punkte.length;
    var p1 = poly.punkte[kantenIndex];
    var p2 = poly.punkte[(kantenIndex + 1) % n];
    var dx = p2.x - p1.x, dy = p2.y - p1.y;
    var laengeM = Math.sqrt(dx * dx + dy * dy) / region.kalibrierung.ptProMeter;

    kantenEditPolygonId = polygonId;
    kantenEditIndex     = kantenIndex;
    $('kantenEditNr').textContent     = (kantenIndex + 1) + ' / ' + n;
    $('kantenEditBisher').textContent = GF.util.formatZahlDE(laengeM, 2) + ' m';
    // Edit-Vorbelegung absichtlich mit 3 Stellen (voller Storage-Wert):
    // User darf eine bestehende 1,234 weiter verfeinern ohne Praezisions-Verlust.
    $('kantenEditInput').value        = GF.util.formatZahlDE(laengeM, 3);
    $('kantenEdit').hidden = false;
    setTimeout(function () {
      var inp = $('kantenEditInput');
      if (inp) { inp.focus(); inp.select(); }
    }, 30);
  }

  function abbrecheKantenEdit() {
    $('kantenEdit').hidden = true;
    kantenEditPolygonId = null;
    kantenEditIndex = -1;
  }

  function bestaetigeKantenEdit() {
    var v = GF.util.parseZahlDE($('kantenEditInput').value);
    if (!isFinite(v) || v <= 0) {
      showToast('Ungueltiges Maß — bitte positive Zahl eingeben.', 'warn');
      return;
    }
    var poly = GF.state.findPolygon(kantenEditPolygonId);
    if (!poly) { abbrecheKantenEdit(); return; }
    var region = GF.state.findRegion(poly.regionId);
    if (!region || !region.kalibrierung) { abbrecheKantenEdit(); return; }

    try {
      GF.polygon.editKante(poly, kantenEditIndex, v, region.kalibrierung.ptProMeter);
    } catch (e) {
      showToast('Kanten-Edit fehlgeschlagen: ' + e.message, 'danger');
      return;
    }

    // Selbstueberschneidung nach dem Edit pruefen
    if (GF.polygon.hatSelbstueberschneidung(poly.punkte)) {
      if (!global.confirm(
        'Durch die Änderung überschneidet sich das Polygon nun selbst — die ' +
        'Flächenberechnung ist dann nicht korrekt.\n\nTrotzdem übernehmen?'
      )) {
        // Edit rueckgaengig machen ist hier nicht trivial, weil editKante in-place
        // mutiert. Pragmatisch: User soll Polygon neu zeichnen.
        showToast('Hinweis: Polygon hat jetzt eine Selbstüberschneidung.', 'warn');
      }
    }

    // Flaeche neu berechnen
    var neueFlaeche = GF.polygon.berechneFlaeche(poly.punkte, region.kalibrierung.ptProMeter);
    poly.flaecheGemessenQM = Math.round(neueFlaeche * 1000) / 1000;
    var hatteKorrektur = !!poly.manuelleKorrektur;
    poly.flaecheAngesetztQM = poly.flaecheGemessenQM;
    poly.manuelleKorrektur  = false;
    poly.korrekturKommentar = '';

    GF.projekt.historieEintrag(GF.state.projekt, 'Kantenmaß geändert',
      poly.bezeichnung + ' · Kante ' + (kantenEditIndex + 1) + ' → ' +
      GF.util.formatZahlDE(v, 2) + ' m · neue Fläche ' +
      GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²');

    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    abbrecheKantenEdit();
    redraw();
    if (hatteKorrektur) {
      showToast('Kante geändert. Frühere manuelle Flächenkorrektur wurde verworfen.', 'success', 7000);
    } else {
      showToast('Kante ' + (kantenEditIndex + 1) + ' = ' + GF.util.formatZahlDE(v, 2) +
                ' m · neue Fläche ' + GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²',
                'success');
    }
  }

  // ============================================================
  // Eckpunkt-Drag (Punkt eines aktiven Polygons verschieben)
  // ============================================================

  var aktiverPunktDrag = null;   // {polygonId, punktIndex, originalX, originalY}

  function starteEckpunktDrag(hit) {
    var poly = GF.state.findPolygon(hit.polygonId);
    if (!poly) return;
    var pp = poly.punkte[hit.punktIndex];
    aktiverPunktDrag = {
      polygonId: hit.polygonId,
      punktIndex: hit.punktIndex,
      originalX: pp.x,
      originalY: pp.y
    };
    var c = $('planCanvas');
    if (c) c.style.cursor = 'grabbing';
  }

  function bewegeEckpunktDrag(canvasX, canvasY) {
    if (!aktiverPunktDrag) return;
    var poly = GF.state.findPolygon(aktiverPunktDrag.polygonId);
    if (!poly) return;
    var pdfPt = canvasZuPdf(canvasX, canvasY);
    poly.punkte[aktiverPunktDrag.punktIndex].x = pdfPt.x;
    poly.punkte[aktiverPunktDrag.punktIndex].y = pdfPt.y;
    redraw();
  }

  function beendeEckpunktDrag() {
    if (!aktiverPunktDrag) return;
    var poly = GF.state.findPolygon(aktiverPunktDrag.polygonId);
    var idx  = aktiverPunktDrag.punktIndex;
    aktiverPunktDrag = null;
    var c = $('planCanvas');
    if (c) c.style.cursor = '';
    if (!poly) { redraw(); return; }
    var region = GF.state.findRegion(poly.regionId);
    if (!region || !region.kalibrierung) { redraw(); return; }

    // Selbstueberschneidungs-Check (nur Warn, kein Rollback)
    if (GF.polygon.hatSelbstueberschneidung(poly.punkte)) {
      showToast('Hinweis: Polygon hat jetzt eine Selbstüberschneidung — Fläche ggf. ungenau.', 'warn', 7000);
    }

    var f = GF.polygon.berechneFlaeche(poly.punkte, region.kalibrierung.ptProMeter);
    poly.flaecheGemessenQM = Math.round(f * 1000) / 1000;
    var hatteKorrektur = !!poly.manuelleKorrektur;
    poly.flaecheAngesetztQM = poly.flaecheGemessenQM;
    poly.manuelleKorrektur  = false;
    poly.korrekturKommentar = '';

    GF.projekt.historieEintrag(GF.state.projekt, 'Eckpunkt verschoben',
      poly.bezeichnung + ' · Punkt ' + (idx + 1) + ' · neue Fläche ' +
      GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²');
    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    redraw();
    if (hatteKorrektur) {
      showToast('Eckpunkt verschoben. Frühere manuelle Flächenkorrektur wurde verworfen.', 'success', 7000);
    } else {
      showToast('Eckpunkt verschoben. Neue Fläche: ' +
                GF.util.formatZahlDE(poly.flaecheAngesetztQM, 2) + ' m²', 'success');
    }
  }

  function abbrecheEckpunktDrag() {
    if (!aktiverPunktDrag) return;
    var poly = GF.state.findPolygon(aktiverPunktDrag.polygonId);
    if (poly) {
      poly.punkte[aktiverPunktDrag.punktIndex].x = aktiverPunktDrag.originalX;
      poly.punkte[aktiverPunktDrag.punktIndex].y = aktiverPunktDrag.originalY;
    }
    aktiverPunktDrag = null;
    var c = $('planCanvas');
    if (c) c.style.cursor = '';
    redraw();
    showToast('Eckpunkt-Verschiebung abgebrochen.');
  }

  function wireKantenEdit() {
    var ok = $('btnKantenOk');
    var ab = $('btnKantenAbbrechen');
    var inp = $('kantenEditInput');
    if (ok) ok.addEventListener('click', bestaetigeKantenEdit);
    if (ab) ab.addEventListener('click', abbrecheKantenEdit);
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter')  { e.preventDefault(); bestaetigeKantenEdit(); }
      if (e.key === 'Escape') { e.preventDefault(); abbrecheKantenEdit();   }
    });
  }

  // ============================================================
  // Flaechen-Korrektur-Modal (manuell ueberschreiben mit Begruendung)
  // ============================================================

  var flaecheModalPolygonId = null;

  function oeffneFlaechenKorrektur(polygonId) {
    var poly = GF.state.findPolygon(polygonId);
    if (!poly) return;
    flaecheModalPolygonId = polygonId;
    $('flaecheModalName').textContent     = poly.bezeichnung;
    $('flaecheModalGemessen').textContent = GF.util.formatZahlDE(poly.flaecheGemessenQM, 2) + ' m²';
    // Edit-Vorbelegung absichtlich mit 3 Stellen (voller Storage-Wert):
    // User darf eine bestehende 1,234 weiter verfeinern ohne Praezisions-Verlust.
    $('flaecheModalAngesetzt').value      = GF.util.formatZahlDE(poly.flaecheAngesetztQM, 3);
    $('flaecheModalKommentar').value      = poly.korrekturKommentar || '';
    $('flaecheModalFehler').hidden = true;
    $('flaecheBackdrop').classList.add('aktiv');
    setTimeout(function () {
      var inp = $('flaecheModalAngesetzt');
      if (inp) { inp.focus(); inp.select(); }
    }, 30);
  }

  function abbrecheFlaechenKorrektur() {
    $('flaecheBackdrop').classList.remove('aktiv');
    flaecheModalPolygonId = null;
  }

  function zeigeFlaecheFehler(msg) {
    var el = $('flaecheModalFehler');
    el.textContent = msg;
    el.hidden = false;
  }

  function bestaetigeFlaechenKorrektur() {
    var poly = GF.state.findPolygon(flaecheModalPolygonId);
    if (!poly) { abbrecheFlaechenKorrektur(); return; }
    var v = GF.util.parseZahlDE($('flaecheModalAngesetzt').value);
    var k = $('flaecheModalKommentar').value.trim();
    if (!isFinite(v) || v <= 0) {
      zeigeFlaecheFehler('Bitte gültige Fläche eingeben (> 0).');
      return;
    }
    if (!k) {
      zeigeFlaecheFehler('Begründung ist Pflicht — wird im Aufmaßprotokoll vermerkt.');
      return;
    }
    var angesetzt = Math.round(v * 1000) / 1000;
    poly.flaecheAngesetztQM = angesetzt;
    poly.korrekturKommentar = k;
    // Abweichung > 0.005 m² ist die Schwelle (sonst koennten 142,37 vs. 142,37 unterschiedlich sein wegen Float)
    poly.manuelleKorrektur = Math.abs(angesetzt - poly.flaecheGemessenQM) > 0.005;

    GF.projekt.historieEintrag(GF.state.projekt, 'Fläche manuell angesetzt',
      poly.bezeichnung + ': ' + GF.util.formatZahlDE(angesetzt, 2) + ' m² (gemessen ' +
      GF.util.formatZahlDE(poly.flaecheGemessenQM, 2) + ' m²) · ' + k);

    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    redraw();
    abbrecheFlaechenKorrektur();
    showToast('Fläche angepasst: ' + GF.util.formatZahlDE(angesetzt, 2) + ' m²', 'success');
  }

  function flaecheZuruecksetzen() {
    var poly = GF.state.findPolygon(flaecheModalPolygonId);
    if (!poly) return;
    poly.flaecheAngesetztQM = poly.flaecheGemessenQM;
    poly.manuelleKorrektur  = false;
    poly.korrekturKommentar = '';
    GF.projekt.historieEintrag(GF.state.projekt, 'Flächenkorrektur zurückgesetzt',
      poly.bezeichnung + ' → gemessen ' + GF.util.formatZahlDE(poly.flaecheGemessenQM, 2) + ' m²');
    GF.state.markiereGeaendert();
    aktualisiereGeschossListe();
    redraw();
    abbrecheFlaechenKorrektur();
    showToast('Fläche auf gemessenen Wert zurückgesetzt.', 'success');
  }

  function wireFlaechenKorrektur() {
    var ok  = $('btnFlaecheOk');
    var ab  = $('btnFlaecheAbbrechen');
    var rst = $('btnFlaecheZuruecksetzen');
    if (ok)  ok.addEventListener('click',  bestaetigeFlaechenKorrektur);
    if (ab)  ab.addEventListener('click',  abbrecheFlaechenKorrektur);
    if (rst) rst.addEventListener('click', flaecheZuruecksetzen);
    var inp = $('flaecheModalAngesetzt');
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); bestaetigeFlaechenKorrektur(); }
    });
  }

  // ============================================================
  // Massstab-Kalibrierung (Zwei-Klick)
  // ============================================================

  var massPunkt1 = null;       // erster Klick (PDF-Koord), null = noch keiner
  var massPunkt2 = null;       // zweiter Klick (PDF-Koord)
  var massMaus   = null;       // aktuelle Mauspos waehrend des Wartens auf 2. Klick

  function starteMassstab() {
    var r = aktiveRegionFuerKalibrierung();
    if (!r) return false;
    massPunkt1 = null;
    massPunkt2 = null;
    massMaus = null;
    showToast('Klick auf den ERSTEN Punkt einer bekannten Bemassung.');
    return true;
  }

  function aktiveRegionFuerKalibrierung() {
    var s = GF.state;
    if (!s.projekt) {
      showToast('Bitte erst eine Plan-Region anlegen.', 'warn');
      return null;
    }
    if (!s.aktiveRegionId) {
      showToast('Bitte erst eine Region in der Sidebar aktivieren.', 'warn');
      return null;
    }
    var r = null;
    for (var i = 0; i < s.projekt.planRegionen.length; i++) {
      if (s.projekt.planRegionen[i].id === s.aktiveRegionId) { r = s.projekt.planRegionen[i]; break; }
    }
    if (!r) return null;
    if (r.pdfId !== s.aktivePdfId || r.seite !== s.aktuelleSeite) {
      showToast('Aktive Region liegt auf anderer PDF/Seite. Bitte erst dorthin springen.', 'warn');
      return null;
    }
    return r;
  }

  // Versucht 90°-Snap des aktuellen Punktes zur Massstab-Linie ab massPunkt1.
  function massWinkelSnap(pdfPt, shiftKey) {
    if (shiftKey || !massPunkt1) return pdfPt;
    var dx = pdfPt.x - massPunkt1.x;
    var dy = pdfPt.y - massPunkt1.y;
    var laengePt = Math.sqrt(dx * dx + dy * dy);
    var laengeCanvas = laengePt * GF.state.viewport.zoom;
    if (laengeCanvas < WINKEL_SNAP_MIN_LAENGE) return pdfPt;
    return GF.polygon.snap.aufRechtwinkel(massPunkt1, pdfPt, WINKEL_SNAP_TOLERANZ);
  }

  function massstabKlick(canvasX, canvasY, shiftKey) {
    if (massEingabeOffen) return;     // Eingabe-Panel offen -> Klicks ignorieren
    var punkt = canvasZuPdf(canvasX, canvasY);
    if (!massPunkt1) {
      massPunkt1 = punkt;
      massMaus = punkt;
      showToast('Klick auf den ZWEITEN Punkt. Linie rastet bei 90°/0° zur Maus-Richtung ein (grün) — Shift unterdrückt das. ' +
                'Pannen: Mausrad-Klick + Ziehen, Zoomen: Mausrad-Drehen.', null, 11000);
      redraw();
      return;
    }
    var gesnappt = massWinkelSnap(punkt, shiftKey);
    massPunkt2 = { x: gesnappt.x, y: gesnappt.y };
    massMaus = massPunkt2;
    winkelSnapAktiv = false;
    var distanzPt = GF.util.abstand2D(massPunkt1, massPunkt2);
    if (distanzPt < 2) {
      showToast('Die zwei Punkte sind zu nah aneinander.', 'warn');
      resetMass();
      redraw();
      return;
    }
    redraw();
    zeigeMassEingabe(distanzPt);
  }

  function massstabMausBewegung(canvasX, canvasY, shiftKey) {
    if (!massPunkt1 || massPunkt2) return;
    var p = canvasZuPdf(canvasX, canvasY);
    var gesnappt = massWinkelSnap(p, shiftKey);
    massMaus = { x: gesnappt.x, y: gesnappt.y };
    winkelSnapAktiv = !!gesnappt.snapped;
    redraw();
  }

  // ---- Inline-Eingabe-Panel ----
  var massEingabeOffen = false;

  function zeigeMassEingabe(distanzPt) {
    var panel = $('massEingabe');
    var inp   = $('massEingabeInput');
    if (!panel || !inp) return;
    panel.hidden = false;
    massEingabeOffen = true;
    inp.value = '';
    inp.placeholder = 'z. B. 11,79  (PDF: ' + GF.util.formatZahlDE(distanzPt, 1) + ' pt)';
    setTimeout(function () { inp.focus(); inp.select(); }, 0);
  }

  function versteckeMassEingabe() {
    var panel = $('massEingabe');
    if (panel) panel.hidden = true;
    massEingabeOffen = false;
  }

  function uebernehmeMassEingabe() {
    var inp = $('massEingabeInput');
    var r = aktiveRegionFuerKalibrierung();
    if (!r) { abbrecheMassEingabe(); return; }
    if (!massPunkt1 || !massPunkt2) { abbrecheMassEingabe(); return; }
    var meter = GF.util.parseZahlDE(inp.value);
    if (!isFinite(meter) || meter <= 0) {
      showToast('Ungueltige Eingabe. Zahl in Metern, z. B. "11,79".', 'warn');
      inp.focus();
      inp.select();
      return;
    }
    try {
      var ptProMeter = GF.region.berechneMassstab(massPunkt1, massPunkt2, meter);
      var pl = GF.region.plausibilitaet(ptProMeter);
      r.kalibrierung = {
        punkt1: { x: massPunkt1.x, y: massPunkt1.y },
        punkt2: { x: massPunkt2.x, y: massPunkt2.y },
        abstandMeter: meter,
        ptProMeter: ptProMeter,
        quelle: 'manuell_zweipunkt',
        abweichungVonNormProzent: pl.abweichungProzent,
        normMassstab: pl.naechsterNormMassstab
      };
      GF.projekt.historieEintrag(GF.state.projekt, 'Maßstab kalibriert',
        (GF.state.findGeschoss(r.geschossId) || {}).bezeichnung + ' / ' + pl.naechsterNormMassstab);
      GF.state.update(function (s) { s.ungespeicherteAenderungen = true; });
      zeigeKalibrierungsToast(pl, ptProMeter);
      vielleichtUebernehmen(r, ptProMeter);
    } catch (e) {
      showToast('Kalibrierung fehlgeschlagen: ' + e.message, 'danger');
    }
    versteckeMassEingabe();
    resetMass();
    setzeWerkzeug('pan');
    aktualisiereGeschossListe();
    redraw();
  }

  function abbrecheMassEingabe() {
    versteckeMassEingabe();
    resetMass();
    redraw();
    // Im Massstab-Modus bleiben, damit User direkt neu klicken kann
    if (GF.state.aktivesWerkzeug === 'massstab') {
      showToast('Abgebrochen. Klick auf neuen ERSTEN Punkt.');
    }
  }

  function wireMassEingabe() {
    var inp = $('massEingabeInput');
    var ok  = $('btnMassOk');
    var ab  = $('btnMassAbbrechen');
    if (!inp || !ok || !ab) return;
    ok.addEventListener('click', uebernehmeMassEingabe);
    ab.addEventListener('click', abbrecheMassEingabe);
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); uebernehmeMassEingabe(); }
      else if (e.key === 'Escape') { e.preventDefault(); abbrecheMassEingabe(); }
    });
  }

  function zeigeKalibrierungsToast(pl, ptProMeter) {
    var prozent = GF.util.formatZahlDE(pl.abweichungProzent, 2);
    var pt = GF.util.formatZahlDE(ptProMeter, 2);
    if (pl.stufe === 'plausibel') {
      showToast('Maßstab gespeichert: ' + pl.naechsterNormMassstab + ' (' + pt + ' pt/m).', 'success');
    } else if (pl.stufe === 'hinweis') {
      showToast('Maßstab gespeichert: ' + pt + ' pt/m. Hinweis: ' + prozent + ' % Abweichung vom Norm-Maßstab ' + pl.naechsterNormMassstab + '.', 'warn');
    } else {
      showToast('Maßstab gespeichert: ' + pt + ' pt/m. WARNUNG: ' + prozent + ' % Abweichung — bitte prüfen.', 'danger');
    }
  }

  function vielleichtUebernehmen(quellRegion, ptProMeter) {
    var s = GF.state;
    var allesAufSeite = s.projekt.planRegionen.filter(function (r) {
      return r.id !== quellRegion.id
          && r.pdfId === quellRegion.pdfId
          && r.seite === quellRegion.seite;
    });
    // Zwei Gruppen:
    //   - unkalibrierte:  echte Erst-Uebertragung — der User soll bestaetigen
    //   - uebernommene:   stehen schon auf einem aelteren ptProMeter aus einer
    //                     frueheren Uebernahme. Bei Re-Kalibrierung der Quelle
    //                     waere es widerspruechlich, sie auf altem Stand stehen
    //                     zu lassen. Deshalb hier automatisch mitziehen (ohne
    //                     erneute Nachfrage).
    var unkalibriert = allesAufSeite.filter(function (r) { return !r.kalibrierung; });
    var uebernommen  = allesAufSeite.filter(function (r) {
      return r.kalibrierung && r.kalibrierung.quelle === 'übernommen';
    });

    function setzeUebernommen(r) {
      r.kalibrierung = {
        punkt1: null,
        punkt2: null,
        abstandMeter: null,
        ptProMeter: ptProMeter,
        quelle: 'übernommen',
        abweichungVonNormProzent: quellRegion.kalibrierung.abweichungVonNormProzent,
        normMassstab: quellRegion.kalibrierung.normMassstab
      };
    }

    // 1) Frueher uebernommene Regionen werden automatisch mit aktualisiert,
    //    damit "Maßstab fuer alle uebernehmen" nicht jedes Mal erneut bestaetigt
    //    werden muss und alle Regionen denselben ptProMeter teilen.
    if (uebernommen.length > 0) {
      uebernommen.forEach(setzeUebernommen);
      GF.projekt.historieEintrag(s.projekt, 'Maßstab synchronisiert',
        uebernommen.length + ' Region(en) auf neuen Wert');
      showToast('Maßstab in ' + uebernommen.length
        + ' übernommener Region(en) automatisch mit aktualisiert.', 'success');
    }

    // 2) Erst-Uebertragung auf unkalibrierte Regionen — wie bisher per confirm.
    if (unkalibriert.length === 0) return;
    var frage = 'Soll dieser Maßstab auch für ' + unkalibriert.length +
      ' weitere unkalibrierte Region(en) auf der gleichen Seite übernommen werden?';
    if (!global.confirm(frage)) return;
    unkalibriert.forEach(setzeUebernommen);
    GF.projekt.historieEintrag(s.projekt, 'Maßstab übernommen',
      'auf ' + unkalibriert.length + ' weitere Region(en)');
    showToast('Maßstab auf ' + unkalibriert.length + ' weitere Region(en) übernommen.', 'success');
  }

  function resetMass() {
    massPunkt1 = null;
    massPunkt2 = null;
    massMaus = null;
    versteckeMassEingabe();
  }

  // ============================================================
  // Region-Rechteck-Tool
  // ============================================================

  var regionDragAktiv = false;
  var regionStartPdf = null;
  var regionAktuellPdf = null;

  function starteRegionDrag(canvasX, canvasY) {
    regionStartPdf = canvasZuPdf(canvasX, canvasY);
    regionAktuellPdf = { x: regionStartPdf.x, y: regionStartPdf.y };
    regionDragAktiv = true;
  }

  function bewegeRegionDrag(canvasX, canvasY) {
    if (!regionDragAktiv) return;
    regionAktuellPdf = canvasZuPdf(canvasX, canvasY);
    redraw();
  }

  function beendeRegionDrag() {
    if (!regionDragAktiv) return;
    regionDragAktiv = false;
    var rect = normalisiereRechteck(regionStartPdf, regionAktuellPdf);
    regionStartPdf = null;
    regionAktuellPdf = null;
    if (rect.breite < 10 || rect.hoehe < 10) {
      // zu klein, verwerfen
      redraw();
      return;
    }
    speichereNeueRegion(rect);
  }

  function speichereNeueRegion(rect) {
    var projekt = GF.projekt.sorgeFuerProjekt();
    if (projekt.geschosse.length === 0) {
      showToast('Bitte erst ein Geschoss anlegen (links im Sidebar "+").', 'warn');
      redraw();
      return;
    }
    var geschossId = GF.state.aktivesGeschossId;
    if (!geschossId) {
      // Frag den Sachbearbeiter, welches Geschoss
      var moeglich = projekt.geschosse.map(function (g, i) { return (i + 1) + ') ' + g.bezeichnung; }).join('\n');
      var wahl = global.prompt('Welchem Geschoss soll diese Region zugeordnet werden?\n\n' + moeglich + '\n\nNummer eingeben:');
      if (wahl === null) { redraw(); return; }
      var idx = parseInt(wahl, 10) - 1;
      if (isNaN(idx) || idx < 0 || idx >= projekt.geschosse.length) {
        showToast('Ungueltige Auswahl.', 'warn');
        redraw();
        return;
      }
      geschossId = projekt.geschosse[idx].id;
    }
    var g = GF.state.findGeschoss(geschossId);
    var region = GF.region.erzeuge(GF.state.aktivePdfId, GF.state.aktuelleSeite, rect, g.bezeichnung);
    region.geschossId = geschossId;
    projekt.planRegionen.push(region);
    GF.projekt.historieEintrag(projekt, 'Plan-Region angelegt', g.bezeichnung);
    GF.state.update(function (s) {
      s.aktiveRegionId = region.id;
      s.aktivesGeschossId = geschossId;
      s.aktivesWerkzeug = 'pan';
      s.ungespeicherteAenderungen = true;
    });
    aktualisiereWerkzeugUI();
    aktualisiereCursor();
    aktualisiereGeschossListe();
    redraw();
    showToast('Region angelegt für ' + g.bezeichnung, 'success');
  }

  // ============================================================

  function wireToolbar() {
    $('pdfSelect').addEventListener('change', function (e) {
      wechsleZuPdf(e.target.value);
    });
    $('btnPdfUmbenennen').addEventListener('click', function () {
      if (GF.state.aktivePdfId) benennePdfUm(GF.state.aktivePdfId);
    });
    $('btnPdfLoeschen').addEventListener('click', function () {
      if (GF.state.aktivePdfId) {
        loeschePdf(GF.state.aktivePdfId);
      } else {
        showToast('Keine PDF zum Löschen ausgewählt.', 'warn');
      }
    });
    $('btnSeitePrev').addEventListener('click', function () {
      zeigeSeite(GF.state.aktuelleSeite - 1);
    });
    $('btnSeiteNext').addEventListener('click', function () {
      zeigeSeite(GF.state.aktuelleSeite + 1);
    });
    $('btnZoomIn').addEventListener('click', function () {
      zoomMitFaktor(1.25, null, null);
    });
    $('btnZoomOut').addEventListener('click', function () {
      zoomMitFaktor(1 / 1.25, null, null);
    });
    $('btnFit').addEventListener('click', function () {
      if (!GF.state.pdfCache) return;
      passeCanvasGroesseAn();
      var fit = GF.pdf.fitViewport(GF.state.pdfCache, $('planCanvas'));
      GF.state.update(function (s) { s.viewport = fit; });
      redraw();
    });
  }

  function zoomMitFaktor(faktor, mausX, mausY) {
    if (!GF.state.pdfCache) return;
    var alt = GF.state.viewport.zoom;
    var neu = Math.max(0.05, Math.min(20, alt * faktor));
    if (neu === alt) return;
    var canvas = $('planCanvas');
    var mx = (mausX !== null && mausX !== undefined) ? mausX : canvas.width / 2;
    var my = (mausY !== null && mausY !== undefined) ? mausY : canvas.height / 2;
    var neuerPan = GF.pdf.zoomUmPunkt(mx, my, alt, neu, {
      x: GF.state.viewport.panX,
      y: GF.state.viewport.panY
    });
    GF.state.update(function (s) {
      s.viewport = { zoom: neu, panX: neuerPan.x, panY: neuerPan.y };
    });
    redraw();
  }

  function wireCanvas() {
    var canvas = $('planCanvas');
    if (!canvas) return;

    // Wheel-Zoom
    canvas.addEventListener('wheel', function (e) {
      if (!GF.state.pdfCache) return;
      e.preventDefault();
      var rect = canvas.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;
      var faktor = e.deltaY < 0 ? 1.1 : (1 / 1.1);
      zoomMitFaktor(faktor, mx, my);
    }, { passive: false });

    // Drag-Pan (Maustaste 1 oder Mitteltaste)
    var panAktiv = false;
    var startX = 0, startY = 0;
    var startPanX = 0, startPanY = 0;
    var startZoom = 1;

    canvas.addEventListener('mousedown', function (e) {
      if (!GF.state.pdfCache) return;
      if (e.button !== 0 && e.button !== 1) return;
      var rect = canvas.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;

      // Space-halten ueberlagert das aktuelle Werkzeug: immer Pan.
      // Mittel-Klick (button 1) ebenfalls immer Pan.
      var forcePan = spaceGehalten || e.button === 1;

      // Eckpunkt-Drag (nur im Plan-Modus, hat Vorrang vor Kanten-Label)
      if (!forcePan && GF.state.aktivesWerkzeug === 'pan' && e.button === 0) {
        var ep = findeEckpunkt(mx, my);
        if (ep) {
          starteEckpunktDrag(ep);
          return;
        }
        var hit = findeKantenLabel(mx, my);
        if (hit) {
          oeffneKantenEdit(hit.polygonId, hit.kantenIndex);
          return;
        }
      }

      if (!forcePan && GF.state.aktivesWerkzeug === 'region' && e.button === 0) {
        starteRegionDrag(mx, my);
        return;
      }
      if (!forcePan && GF.state.aktivesWerkzeug === 'massstab' && e.button === 0) {
        massstabKlick(mx, my, e.shiftKey);
        return;
      }
      if (!forcePan && GF.state.aktivesWerkzeug === 'polygon' && e.button === 0) {
        polygonKlick(mx, my, e.shiftKey);
        return;
      }
      // Pan
      panAktiv = true;
      startX = e.clientX;
      startY = e.clientY;
      startPanX = GF.state.viewport.panX;
      startPanY = GF.state.viewport.panY;
      startZoom = GF.state.viewport.zoom;
      canvas.classList.add('panning');
    });

    global.addEventListener('mousemove', function (e) {
      var rect = canvas.getBoundingClientRect();
      var mx = e.clientX - rect.left;
      var my = e.clientY - rect.top;
      mauspositionAnzeigen(mx, my);

      // Aktive Drags haben Vorrang vor Tool-Vorschauen
      if (regionDragAktiv) { bewegeRegionDrag(mx, my); return; }
      if (aktiverPunktDrag) { bewegeEckpunktDrag(mx, my); return; }

      if (panAktiv) {
        var dx = e.clientX - startX;
        var dy = e.clientY - startY;
        GF.state.update(function (s) {
          s.viewport = {
            zoom: startZoom,
            panX: startPanX - dx / startZoom,
            panY: startPanY - dy / startZoom
          };
        });
        redraw();
        return;
      }

      // Hover im Plan-Modus: Eckpunkt -> move, Kanten-Label -> pointer
      if (GF.state.aktivesWerkzeug === 'pan' && !spaceGehalten) {
        if (findeEckpunkt(mx, my))         canvas.style.cursor = 'move';
        else if (findeKantenLabel(mx, my)) canvas.style.cursor = 'pointer';
        else                               canvas.style.cursor = '';
      }

      // Tool-Vorschau (Massstab-Linie zur Maus)
      if (GF.state.aktivesWerkzeug === 'massstab' && massPunkt1 && !massPunkt2) {
        massstabMausBewegung(mx, my, e.shiftKey);
      }
      // Polygon-Live-Linie zur Maus
      if (GF.state.aktivesWerkzeug === 'polygon' && polygonPunkte.length > 0) {
        polygonMausBewegung(mx, my, e.shiftKey);
      }
    });

    // Doppelklick schliesst Polygon
    canvas.addEventListener('dblclick', function (e) {
      if (GF.state.aktivesWerkzeug !== 'polygon') return;
      if (polygonPunkte.length < 3) return;
      e.preventDefault();
      schliessePolygon();
    });

    global.addEventListener('mouseup', function () {
      if (regionDragAktiv)  { beendeRegionDrag();  return; }
      if (aktiverPunktDrag) { beendeEckpunktDrag(); return; }
      if (!panAktiv) return;
      panAktiv = false;
      canvas.classList.remove('panning');
    });

    // Tastatur: ESC bricht laufende Aktionen ab, Enter schliesst Polygon,
    // Pfeiltasten pannen den Plan (analog Mittelmaus-/Space-Pan).
    global.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && GF.state.aktivesWerkzeug === 'polygon' && polygonPunkte.length >= 3 && !istEingabeAktiv()) {
        e.preventDefault();
        schliessePolygon();
        return;
      }

      // Pfeiltasten-Pan: gleiche Guards wie Mittelmaus-Pan (Plan geladen,
      // keine Eingabe fokussiert). Schrittweite in PDF-Koordinaten so
      // skaliert, dass der visuelle Sprung in Bildschirmpixel konstant
      // bleibt unabhaengig vom Zoom. Shift = 5x Schritt (CAD-Konvention).
      if ((e.key === 'ArrowUp'   || e.key === 'ArrowDown'
        || e.key === 'ArrowLeft' || e.key === 'ArrowRight')
          && GF.state.pdfs.length > 0
          && !istEingabeAktiv()) {
        e.preventDefault();
        var step = (e.shiftKey ? 200 : 40) / GF.state.viewport.zoom;
        GF.state.update(function (s) {
          if (e.key === 'ArrowLeft')  s.viewport.panX -= step;
          if (e.key === 'ArrowRight') s.viewport.panX += step;
          if (e.key === 'ArrowUp')    s.viewport.panY -= step;
          if (e.key === 'ArrowDown')  s.viewport.panY += step;
        });
        redraw();
        return;
      }

      if (e.key !== 'Escape') return;
      // 0) Eckpunkt-Drag aktiv -> Punkt auf Originalposition zurueck
      if (aktiverPunktDrag) {
        abbrecheEckpunktDrag();
        return;
      }
      // 0a*) VG-Modal offen -> nur das schliessen (hoechste Modal-Prio nach Drag)
      if ($('vgBackdrop') && $('vgBackdrop').classList.contains('aktiv')) {
        if (GF.VgModal && GF.VgModal.schliesse) GF.VgModal.schliesse();
        return;
      }
      // 0a**) Anrechnungs-Dialog offen -> als Abbruch behandeln
      if ($('exportDialogBackdrop') && $('exportDialogBackdrop').classList.contains('aktiv')) {
        if (GF.ExportDialog && GF.ExportDialog.schliesse) GF.ExportDialog.schliesse();
        return;
      }
      // 0a) Flaechen-Korrektur-Modal offen -> nur das schliessen
      if ($('flaecheBackdrop') && $('flaecheBackdrop').classList.contains('aktiv')) {
        abbrecheFlaechenKorrektur();
        return;
      }
      // 0a2) Projektdaten-Modal offen -> nur das schliessen
      if ($('projektdatenBackdrop') && $('projektdatenBackdrop').classList.contains('aktiv')) {
        abbrecheProjektdaten();
        return;
      }
      // 0a3) Protokoll-Modal offen -> nur das schliessen
      if ($('protokollBackdrop') && $('protokollBackdrop').classList.contains('aktiv')) {
        abbrecheProtokollModal();
        return;
      }
      // 0b) Kanten-Edit-Panel offen -> nur das schliessen
      if (!$('kantenEdit').hidden) {
        abbrecheKantenEdit();
        return;
      }
      // 1) Eingabe-Panel offen -> nur das schliessen
      if (massEingabeOffen) {
        abbrecheMassEingabe();
        return;
      }
      // 2) Region-Drag aktiv -> abbrechen
      if (regionDragAktiv) {
        regionDragAktiv = false;
        regionStartPdf = null;
        regionAktuellPdf = null;
        redraw();
        return;
      }
      // 3) Polygon-Zeichnung -> abbrechen
      if (polygonPunkte.length > 0) {
        abbrechePolygon();
        return;
      }
      // 4) Massstab gerade in der Klick-Phase -> Mass-State zuruecksetzen
      if (massPunkt1 || massPunkt2) {
        resetMass();
        redraw();
        return;
      }
      // 5) Sonst: Werkzeug zurueck auf Pan
      if (GF.state.aktivesWerkzeug !== 'pan') setzeWerkzeug('pan');
    });
  }

  function mauspositionAnzeigen(mx, my) {
    var el = $('mausPos');
    if (!el || !GF.state.pdfCache) return;
    var vp = GF.state.viewport;
    var pdfX = vp.panX + mx / vp.zoom;
    var pdfY = vp.panY + my / vp.zoom;
    el.textContent = 'PDF: ' +
      GF.util.formatZahlDE(pdfX, 1) + ' / ' +
      GF.util.formatZahlDE(pdfY, 1) + ' pt';
  }

  // Resize → Canvas neu vermessen + Redraw (Viewport bleibt; Cache bleibt).
  function wireResize() {
    var resizeTimer = null;
    global.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () {
        if (passeCanvasGroesseAn()) redraw();
      }, 100);
    });
  }

  // ============================================================
  // Init
  // ============================================================

  function init() {
    setzeVersion();
    setzeKommune();
    setzeLibStatus();
    pruefeRecovery();
    if (GF.recovery && GF.recovery.start) GF.recovery.start();

    wireFileInput();
    wireDragDrop();
    wireToolbar();
    wireCanvas();
    wireResize();
    wireWerkzeug();
    wireGeschosse();
    wireSpacePan();
    wireMassEingabe();
    wireKantenEdit();
    wireFlaechenKorrektur();
    wireProjektButtons();
    wireProjektdaten();
    wireProtokoll();
    wireMassstabToggle();
    wireTastenkuerzel();

    // State -> Toolbar-Aktualisierung (insbesondere fuer Speichern-Button-Status)
    GF.state.subscribe(function () { aktualisiereToolbar(); });

    passeCanvasGroesseAn();
    aktualisiereToolbar();
    aktualisiereWerkzeugUI();
    aktualisiereGeschossListe();
    aktualisiereCursor();

    var status = $('appStartStatus');
    if (status) status.textContent = 'Bereit. PDF laden, um zu beginnen.';
  }

  // Expose-Punkte fuer Sub-Module (z. B. VG-Modal)
  GF.app = GF.app || {};
  GF.app.aktualisiereGeschossListe = aktualisiereGeschossListe;
  GF.app.aktualisiereToolbar = aktualisiereToolbar;
  GF.app.showToast = showToast;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})(typeof window !== 'undefined' ? window : globalThis);
